import 'dart:async';

import 'package:expandable_page_view/expandable_page_view.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

List<Map> sizeMapData = [
  {
    'key': 'Nike&Jordan',
    'logoType': 1,
    'logo': [
      'assets/etc/size_guide/brands/nike.png',
      'assets/etc/size_guide/brands/jordan.png',
    ],
    'title': ['Nike &', 'Jordan'],
    'theader': 'Men',
    'imageTitle': 'MEN',
    'rightSideImage': 'assets/etc/size_guide/man.png',
  },
  {
    'key': 'Nike&JordanWomen',
    'logoType': 1,
    'logo': [
      'assets/etc/size_guide/brands/nike.png',
      'assets/etc/size_guide/brands/jordan.png',
    ],
    'title': ['Nike &', 'Jordan'],
    'theader': 'Women',
    'imageTitle': 'WOMEN',
    'rightSideImage': 'assets/etc/size_guide/woman.png',
  },
  {
    'key': 'Nike&Jordan(GS)',
    'logoType': 1,
    'logo': [
      'assets/etc/size_guide/brands/nike.png',
      'assets/etc/size_guide/brands/jordan.png',
    ],
    'title': ['Nike &', 'Jordan(GS)'],
    'theader': 'GS',
    'imageTitle': 'WOMEN',
    'rightSideImage': 'assets/etc/size_guide/woman.png',
  },
  {
    'key': 'Nike&Jordan(PS)',
    'logoType': 1,
    'logo': [
      'assets/etc/size_guide/brands/nike.png',
      'assets/etc/size_guide/brands/jordan.png',
    ],
    'title': ['Nike &', 'Jordan(PS)'],
    'theader': 'Kids',
    'imageTitle': 'KIDS',
    'rightSideImage': 'assets/etc/size_guide/son.png',
  },
  {
    'key': 'Nike&Jordan(TD)',
    'logoType': 1,
    'logo': [
      'assets/etc/size_guide/brands/nike.png',
      'assets/etc/size_guide/brands/jordan.png',
    ],
    'title': ['Nike &', 'Jordan(TD)'],
    'theader': 'Toddler',
    'imageTitle': 'BABY',
    'rightSideImage': 'assets/etc/size_guide/baby.png',
  },
  {
    'key': 'Adidas&Yeezy',
    'logoType': 2,
    'logo': [
      'assets/etc/size_guide/brands/adidas.png',
      'assets/etc/size_guide/brands/yeezy.png',
    ],
    'title': ['Adidas &', 'Yeezy'],
    'theader': 'Men',
    'imageTitle': 'MEN',
    'rightSideImage': 'assets/etc/size_guide/man.png',
  },
  {
    'key': 'Adidas&YeezyWomen',
    'logoType': 2,
    'logo': [
      'assets/etc/size_guide/brands/adidas.png',
      'assets/etc/size_guide/brands/yeezy.png',
    ],
    'title': ['Adidas &', 'Yeezy'],
    'theader': 'Women',
    'imageTitle': 'WOMEN',
    'rightSideImage': 'assets/etc/size_guide/woman.png',
  },
  {
    'key': 'Adidas&YeezyKids',
    'logoType': 2,
    'logo': [
      'assets/etc/size_guide/brands/adidas.png',
      'assets/etc/size_guide/brands/yeezy.png',
    ],
    'title': ['Adidas &', 'Yeezy'],
    'theader': 'Kids',
    'imageTitle': 'KIDS',
    'rightSideImage': 'assets/etc/size_guide/son.png',
  },
  {
    'key': 'Adidas&YeezyInfants',
    'logoType': 2,
    'logo': [
      'assets/etc/size_guide/brands/adidas.png',
      'assets/etc/size_guide/brands/yeezy.png',
    ],
    'title': ['Adidas &', 'Yeezy'],
    'theader': 'Infants',
    'imageTitle': 'BABY',
    'rightSideImage': 'assets/etc/size_guide/baby.png',
  },
  {
    'key': 'NewBalance',
    'logoType': 3,
    'logo': ['assets/etc/size_guide/brands/new-balance.png'],
    'title': ['New', 'Balance'],
    'theader': 'Men',
    'imageTitle': 'MEN',
    'rightSideImage': 'assets/etc/size_guide/man.png',
  },
  {
    'key': 'NewBalanceWomen',
    'logoType': 3,
    'logo': ['assets/etc/size_guide/brands/new-balance.png'],
    'title': ['New', 'Balance'],
    'theader': 'Women',
    'imageTitle': 'WOMEN',
    'rightSideImage': 'assets/etc/size_guide/woman.png',
  },
  {
    'key': 'NewBalance(GS)',
    'logoType': 3,
    'logo': ['assets/etc/size_guide/brands/new-balance.png'],
    'title': ['New', 'Balance(GS)'],
    'theader': 'GS',
    'imageTitle': 'WOMEN',
    'rightSideImage': 'assets/etc/size_guide/woman.png',
  },
  {
    'key': 'NewBalance(PS)',
    'logoType': 3,
    'logo': ['assets/etc/size_guide/brands/new-balance.png'],
    'title': ['New', 'Balance(PS)'],
    'theader': 'Kids',
    'imageTitle': 'KIDS',
    'rightSideImage': 'assets/etc/size_guide/son.png',
  },
  {
    'key': 'NewBalance(TD)',
    'logoType': 3,
    'logo': ['assets/etc/size_guide/brands/new-balance.png'],
    'title': ['New', 'Balance(TD)'],
    'theader': 'Toddler',
    'imageTitle': 'BABY',
    'rightSideImage': 'assets/etc/size_guide/baby.png',
  },
];

class SizeGuidePage extends StatefulWidget {
  const SizeGuidePage({Key? key}) : super(key: key);

  @override
  State<SizeGuidePage> createState() => _SizeGuidePageState();
}

class _SizeGuidePageState extends State<SizeGuidePage> {
  bool activeNike = false;
  bool activeAdidas = false;
  bool activeNB = false;

  final PageController nikePageViewController = PageController(initialPage: 0);
  final PageController adidasPageViewController =
      PageController(initialPage: 0);
  final PageController newBalancePageViewController =
      PageController(initialPage: 0);

  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    checkNetworkStatus();
    super.initState();
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    super.dispose();
  }

  Widget getSizeChat(String type, List<Map> sizes) {
    Map data =
        sizeMapData.where((element) => element['key'] == type).toList().first;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(50, 0, 50, 15),
          child: Material(
            elevation: 7,
            borderRadius: const BorderRadius.all(Radius.circular(15.0)),
            child: Container(
              padding: const EdgeInsets.fromLTRB(15, 5, 15, 5),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  width: 0.5,
                  color: Colors.white,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 50,
                    width: 50,
                    child: Image.asset(
                      data['rightSideImage'],
                    ),
                  ),
                  Text(
                    data['imageTitle'],
                    style: robotoStyle(
                      FontWeight.w700,
                      const Color.fromARGB(255, 49, 48, 54),
                      26,
                      null,
                    ),
                  ),
                  if (data['logoType'] == 1)
                    SizedBox(
                      height: 50,
                      width: 50,
                      child: Stack(
                        alignment: Alignment.topRight,
                        children: [
                          Align(
                            alignment: const Alignment(-1, -1),
                            child: Image.asset(
                              data['logo'][0],
                              width: 40,
                              height: 40,
                            ),
                          ),
                          Align(
                            alignment: const Alignment(1, 1),
                            child: Image.asset(
                              data['logo'][1],
                              width: 32,
                              height: 32,
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (data['logoType'] == 2)
                    SizedBox(
                      height: 50,
                      width: 50,
                      child: Stack(
                        alignment: Alignment.topRight,
                        children: [
                          Align(
                            alignment: const Alignment(0, -0.8),
                            child: Image.asset(
                              data['logo'][0],
                              width: 40,
                              height: 30,
                            ),
                          ),
                          Align(
                            alignment: const Alignment(0, 0.8),
                            child: Image.asset(
                              data['logo'][1],
                              width: 50,
                              height: 15,
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (data['logoType'] == 3)
                    Stack(
                      alignment: Alignment.topRight,
                      children: [
                        Align(
                          alignment: const Alignment(0, 0),
                          child: Image.asset(
                            data['logo'][0],
                            height: 36,
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(0, 5, 0, 5),
          decoration:
              const BoxDecoration(color: Color.fromARGB(255, 117, 125, 144)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  Text(
                    'US',
                    style: robotoStyle(FontWeight.bold, Colors.white, 24, null),
                  ),
                  Text(
                    data['theader'],
                    style: robotoStyle(FontWeight.bold, Colors.white, 14, null),
                  ),
                ],
              ),
              Column(
                children: [
                  Text(
                    'EU',
                    style: robotoStyle(FontWeight.bold, Colors.white, 24, null),
                  ),
                  Text(
                    '.',
                    style: robotoStyle(FontWeight.bold, Colors.white, 14, null),
                  ),
                ],
              ),
              Column(
                children: [
                  Text(
                    'UK',
                    style: robotoStyle(FontWeight.bold, Colors.white, 24, null),
                  ),
                  Text(
                    '.',
                    style: robotoStyle(FontWeight.bold, Colors.white, 14, null),
                  ),
                ],
              ),
              Column(
                children: [
                  Text(
                    'JP',
                    style: robotoStyle(FontWeight.bold, Colors.white, 24, null),
                  ),
                  Text(
                    'CM',
                    style: robotoStyle(FontWeight.bold, Colors.white, 14, null),
                  ),
                ],
              ),
            ],
          ),
        ),
        SizedBox(
          height: sizes.length * 24,
          child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: sizes.length,
            padding: const EdgeInsets.only(bottom: 5),
            itemBuilder: (context, position) {
              return Container(
                decoration: BoxDecoration(
                  color: position.isEven ? Colors.black12 : Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 60) / 4,
                      child: Center(
                        child: Container(
                          width: 50,
                          padding: const EdgeInsets.fromLTRB(0, 2, 0, 2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              topLeft: position == 0
                                  ? const Radius.circular(20)
                                  : const Radius.circular(0),
                              topRight: position == 0
                                  ? const Radius.circular(20)
                                  : const Radius.circular(0),
                              bottomLeft: position == sizes.length - 1
                                  ? const Radius.circular(20)
                                  : const Radius.circular(0),
                              bottomRight: position == sizes.length - 1
                                  ? const Radius.circular(20)
                                  : const Radius.circular(0),
                            ),
                            color: Colors.black12,
                          ),
                          child: Center(
                            child: Text(
                              sizes[position].keys.first,
                              style: robotoStyle(
                                FontWeight.w400,
                                Colors.black87,
                                16,
                                null,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 60) / 4,
                      child: Center(
                        child: Text(
                          searchSize('EU', sizes[position].keys.first, type),
                          style: robotoStyle(
                              FontWeight.w400, Colors.black87, 16, null),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 60) / 4,
                      child: Center(
                        child: Text(
                          searchSize('UK', sizes[position].keys.first, type),
                          style: robotoStyle(
                              FontWeight.w400, Colors.black87, 16, null),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: (MediaQuery.of(context).size.width - 60) / 4,
                      child: Center(
                        child: Text(
                          searchSize('JP', sizes[position].keys.first, type),
                          style: robotoStyle(
                              FontWeight.w400, Colors.black87, 16, null),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return Scaffold(
      body: Column(
        children: [
          const SizedBox(height: 50),
          Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: IconButton(
                  iconSize: 25,
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back_ios_rounded),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Text(
                  AppLocalizations.of(context).sizeGuide_title,
                  style: robotoStyle(
                    FontWeight.w800,
                    const Color.fromARGB(255, 49, 48, 54),
                    20,
                    null,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          const Divider(
            color: Colors.grey,
            height: 0,
            thickness: 1,
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushReplacementNamed(
                          '/SizeGuide',
                        );
                      },
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(0, 20, 0, 20),
                        child: const Image(
                          height: 35,
                          image: AssetImage('./assets/etc/splash-cropped.png'),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: ExpansionPanelList(
                              expansionCallback: (panelIndex, isExpanded) {
                                if (panelIndex == 0) {
                                  setState(() {
                                    activeNike = !activeNike;
                                  });
                                }
                              },
                              children: <ExpansionPanel>[
                                ExpansionPanel(
                                  backgroundColor:
                                      const Color.fromARGB(255, 235, 235, 235),
                                  headerBuilder: (context, isExpanded) {
                                    return Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const SizedBox(
                                          width: 50,
                                        ),
                                        Text(
                                          "Nike & Jordan",
                                          style: robotoStyle(
                                            FontWeight.w900,
                                            activeNike
                                                ? const Color.fromARGB(
                                                    255,
                                                    255,
                                                    35,
                                                    35,
                                                  )
                                                : const Color.fromARGB(
                                                    255,
                                                    49,
                                                    48,
                                                    54,
                                                  ),
                                            24,
                                            null,
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                  body: Container(
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                    ),
                                    padding: const EdgeInsets.fromLTRB(
                                      10,
                                      25,
                                      10,
                                      0,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                          child: ExpandablePageView(
                                            controller: nikePageViewController,
                                            children: [
                                              getSizeChat(
                                                'Nike&Jordan',
                                                nikeAndJordanSizes,
                                              ),
                                              getSizeChat(
                                                'Nike&JordanWomen',
                                                nikeAndJordanWomenSizes,
                                              ),
                                              getSizeChat(
                                                'Nike&Jordan(GS)',
                                                nikeAndJordanGSSizes,
                                              ),
                                              getSizeChat(
                                                'Nike&Jordan(PS)',
                                                nikeAndJordanPSSizes,
                                              ),
                                              getSizeChat(
                                                'Nike&Jordan(TD)',
                                                nikeAndJordanTDSizes,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              top: 15,
                                            ),
                                            child: IconButton(
                                              iconSize: 25,
                                              onPressed: () {
                                                nikePageViewController
                                                    .previousPage(
                                                  duration: const Duration(
                                                    milliseconds: 150,
                                                  ),
                                                  curve: Curves.easeInOut,
                                                );
                                              },
                                              icon: const Icon(
                                                Icons.arrow_back_ios_rounded,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              top: 15,
                                            ),
                                            child: IconButton(
                                              iconSize: 25,
                                              onPressed: () {
                                                nikePageViewController.nextPage(
                                                  duration: const Duration(
                                                    milliseconds: 150,
                                                  ),
                                                  curve: Curves.easeInOut,
                                                );
                                              },
                                              icon: const Icon(Icons
                                                  .arrow_forward_ios_rounded),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  isExpanded: activeNike,
                                  canTapOnHeader: true,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: ExpansionPanelList(
                              expansionCallback: (panelIndex, isExpanded) {
                                if (panelIndex == 0) {
                                  setState(() {
                                    activeAdidas = !activeAdidas;
                                  });
                                }
                              },
                              children: <ExpansionPanel>[
                                ExpansionPanel(
                                  backgroundColor: const Color.fromARGB(
                                    255,
                                    235,
                                    235,
                                    235,
                                  ),
                                  headerBuilder: (context, isExpanded) {
                                    return Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const SizedBox(
                                          width: 50,
                                        ),
                                        Text(
                                          "Adidas & Yeezy",
                                          style: robotoStyle(
                                            FontWeight.w900,
                                            activeAdidas
                                                ? const Color.fromARGB(
                                                    255,
                                                    255,
                                                    35,
                                                    35,
                                                  )
                                                : const Color.fromARGB(
                                                    255,
                                                    49,
                                                    48,
                                                    54,
                                                  ),
                                            24,
                                            null,
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                  body: Container(
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                    ),
                                    padding: const EdgeInsets.fromLTRB(
                                      10,
                                      25,
                                      10,
                                      0,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                          child: ExpandablePageView(
                                            controller:
                                                adidasPageViewController,
                                            children: [
                                              getSizeChat(
                                                'Adidas&Yeezy',
                                                adidasYeezySizes,
                                              ),
                                              getSizeChat(
                                                'Adidas&YeezyWomen',
                                                adidasYeezyWomenSizes,
                                              ),
                                              getSizeChat(
                                                'Adidas&YeezyKids',
                                                adidasYeezyKidsSizes,
                                              ),
                                              getSizeChat(
                                                'Adidas&YeezyInfants',
                                                adidasYeezyInfantsSizes,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              top: 15,
                                            ),
                                            child: IconButton(
                                              iconSize: 25,
                                              onPressed: () {
                                                adidasPageViewController
                                                    .previousPage(
                                                  duration: const Duration(
                                                    milliseconds: 150,
                                                  ),
                                                  curve: Curves.easeInOut,
                                                );
                                              },
                                              icon: const Icon(
                                                Icons.arrow_back_ios_rounded,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              top: 15,
                                            ),
                                            child: IconButton(
                                              iconSize: 25,
                                              onPressed: () {
                                                adidasPageViewController
                                                    .nextPage(
                                                  duration: const Duration(
                                                    milliseconds: 150,
                                                  ),
                                                  curve: Curves.easeInOut,
                                                );
                                              },
                                              icon: const Icon(Icons
                                                  .arrow_forward_ios_rounded),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  isExpanded: activeAdidas,
                                  canTapOnHeader: true,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: ExpansionPanelList(
                              expansionCallback: (panelIndex, isExpanded) {
                                if (panelIndex == 0) {
                                  setState(() {
                                    activeNB = !activeNB;
                                  });
                                }
                              },
                              children: <ExpansionPanel>[
                                ExpansionPanel(
                                  backgroundColor: const Color.fromARGB(
                                    255,
                                    235,
                                    235,
                                    235,
                                  ),
                                  headerBuilder: (context, isExpanded) {
                                    return Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const SizedBox(
                                          width: 50,
                                        ),
                                        Text(
                                          "New Balance",
                                          style: robotoStyle(
                                            FontWeight.w900,
                                            activeNB
                                                ? const Color.fromARGB(
                                                    255,
                                                    255,
                                                    35,
                                                    35,
                                                  )
                                                : const Color.fromARGB(
                                                    255,
                                                    49,
                                                    48,
                                                    54,
                                                  ),
                                            24,
                                            null,
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                  body: Container(
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                    ),
                                    padding: const EdgeInsets.fromLTRB(
                                      10,
                                      25,
                                      10,
                                      0,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                          child: ExpandablePageView(
                                            controller:
                                                newBalancePageViewController,
                                            children: [
                                              getSizeChat(
                                                'NewBalance',
                                                newBalanceSizes,
                                              ),
                                              getSizeChat(
                                                'NewBalanceWomen',
                                                newBalanceWomenSizes,
                                              ),
                                              getSizeChat(
                                                'NewBalance(GS)',
                                                newBalanceGSSizes,
                                              ),
                                              getSizeChat(
                                                'NewBalance(PS)',
                                                newBalancePSSizes,
                                              ),
                                              getSizeChat(
                                                'NewBalance(TD)',
                                                newBalanceTDSizes,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topLeft,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              top: 15,
                                            ),
                                            child: IconButton(
                                              iconSize: 25,
                                              onPressed: () {
                                                newBalancePageViewController
                                                    .previousPage(
                                                  duration: const Duration(
                                                    milliseconds: 150,
                                                  ),
                                                  curve: Curves.easeInOut,
                                                );
                                              },
                                              icon: const Icon(
                                                Icons.arrow_back_ios_rounded,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                              top: 15,
                                            ),
                                            child: IconButton(
                                              iconSize: 25,
                                              onPressed: () {
                                                newBalancePageViewController
                                                    .nextPage(
                                                  duration: const Duration(
                                                    milliseconds: 150,
                                                  ),
                                                  curve: Curves.easeInOut,
                                                );
                                              },
                                              icon: const Icon(Icons
                                                  .arrow_forward_ios_rounded),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  isExpanded: activeNB,
                                  canTapOnHeader: true,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
