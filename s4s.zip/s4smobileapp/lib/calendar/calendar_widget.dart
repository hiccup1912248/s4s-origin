import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_fgbg/flutter_fgbg.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:s4s_mobileapp/calendar/calendar_detail_widget.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sticky_headers/sticky_headers.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'dart:ui';

int positionCalendarPage = 0;
bool isUpcoming = true;
bool isPast = false;

class CalendarWidget extends StatefulWidget {
  const CalendarWidget({Key? key}) : super(key: key);

  @override
  State<CalendarWidget> createState() => _CalendarWidgetState();
}

class _CalendarWidgetState extends State<CalendarWidget> {
  final RefreshController upcompingRefreshController =
      RefreshController(initialRefresh: false);
  final RefreshController pastRefreshController =
      RefreshController(initialRefresh: false);
  final ScrollController upcomingScrollController = ScrollController();
  final ScrollController pastScrollController = ScrollController();

  final PageController calendarMainPageController =
      PageController(initialPage: 0);

  List upcomings = [];
  List filteredUpcomings = [];
  List pasts = [];
  List filteredPasts = [];

  Timer? timer1;
  List calendarFilter = [];
  String logoPath = '';

  late StreamSubscription<FGBGType> subscription;

  List<String> brands = [
    'Jordan',
    'Nike',
    'Converse',
    'Off White',
    'Yeezy',
    'Adidas',
    'New Balance',
    'Travis Scott',
    'Asics',
    'Reebok',
    'Puma',
  ];
  List<String> checkedBrands = [];

  @override
  void initState() {
    upcomings = upcoming;
    pasts = past;
    timer1 = Timer.periodic(const Duration(minutes: 3), (Timer timer) {
      getUpcomingAndPastData();
    });

    subscription = FGBGEvents.stream.listen((event) {
      if (event == FGBGType.foreground) {
        getUpcomingAndPastData();
      }
    });
    checkedBrands = prefs.getStringList("upcomingFilterBrands") ?? [];

    // getBrandsData();
    super.initState();
  }

  @override
  void dispose() {
    timer1?.cancel();
    subscription.cancel();
    super.dispose();
  }

  getBrandsData() {
    getAllBrandsData().then((e) {
      if (mounted) {
        brands = e;
      }
    });
  }

  getUpcomingAndPastData() {
    getUpcomings().then((e) {
      upcoming = e;
      if (mounted) {
        setState(() {
          upcomings = e;
        });
      }
    });
    getPasts().then((e) {
      pasts = e;
      if (mounted) {
        setState(() {
          pasts = e;
        });
      }
    });
  }

  Widget renderCalendarTile(List<dynamic> product, int indexProduct) {
    MediaQueryData mediaQuery = MediaQuery.of(context);
    double pixelRatio = mediaQuery.devicePixelRatio;

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    double actualWindow = window.physicalSize.width;

    print(
        "viewport width ==> ${width} actualWindow ==> ${actualWindow}  height ==> ${height}  pixelRatio ==> ${pixelRatio}");
    double defaultFontSize = 18;

    if (pixelRatio > 1) {
      defaultFontSize = 22.2;
    }
    if (pixelRatio > 2) {
      defaultFontSize = 19.4;
    }
    if (pixelRatio > 2.5) {
      defaultFontSize = 18;
    }
    if (pixelRatio > 3) {
      defaultFontSize = 16.6;
    }

    TextStyle productNameStyle = GoogleFonts.roboto(
      fontWeight: FontWeight.w700,
      color: const Color(
        0xFF313036,
      ),
      fontSize: ScreenUtil().setSp(defaultFontSize),
    );

    String productResellValuePourcentStr =
        product[indexProduct]['ResellValuePourcent'].toString();
    String productResellValuePourcent =
        productResellValuePourcentStr.replaceAll('%', '');

    int resellState = returnResellState(productResellValuePourcent);

    return InkWell(
      onTap: () {
        calendarProductDetail = product[indexProduct];
        Navigator.of(context).pushNamed("/CalendarDetail");
      },
      child: Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: const Color(0xffc5c5c5).withOpacity(0.8),
              width: 0.2,
            ),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      product[indexProduct]['ProductName'] != null
                          ? product[indexProduct]['ProductName'].toString()
                          : '',
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: productNameStyle,
                      textScaleFactor: 1.sp,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          product[indexProduct]['xxShops'] != null
                              ? product[indexProduct]['xxShops'].toString()
                              : '',
                          style: w400Black16,
                        ),
                        Text(
                          AppLocalizations.of(context).calendar_shops,
                          style: w400Black16,
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    product[indexProduct]['ResellValuePourcent'] != null &&
                            productResellValuePourcentStr != 'TBC' &&
                            productResellValuePourcentStr != ""
                        ? Material(
                            elevation: 8,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(20)),
                            child: Container(
                              width: 83,
                              height: 18,
                              // padding: const EdgeInsets.fromLTRB(5, 8, 5, 8),
                              decoration: BoxDecoration(
                                color: resellState == 2
                                    ? Color(0xFF21ED8B)
                                    : resellState == 1
                                        ? Color(0xFFFFC654)
                                        : Color(0xFF758390),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    resellState == 2
                                        ? 'HIGH RESELL'
                                        : resellState == 1
                                            ? 'MID RESELL'
                                            : 'LOW RESELL',
                                    style: w900White12,
                                  ),
                                ],
                              ),
                            ),
                          )
                        : Text(
                            'TBC',
                            style: w500Black15,
                          ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 0, 25),
                child: SizedBox(
                  height: 95,
                  width: 120,
                  child: product[indexProduct]['ProductImage'] != ''
                      ? CachedNetworkImage(
                          imageUrl: product[indexProduct]['ProductImage'],
                          fit: BoxFit.contain,
                          errorWidget: (
                            context,
                            error,
                            stackTrace,
                          ) {
                            return Image.asset(
                              'assets/etc/NoImage-trans.png',
                              fit: BoxFit.contain,
                            );
                          },
                        )
                      : Image.asset(
                          'assets/etc/NoImage-trans.png',
                          fit: BoxFit.contain,
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget pageCalendarMainUpcoming() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 30),
              child: InkWell(
                onTap: () {
                  positionCalendarPage = 0;
                  Navigator.of(context).pushReplacementNamed('/Calendar');
                },
                child: const Image(
                  height: 35,
                  image: AssetImage('./assets/etc/splash-cropped.png'),
                ),
              ),
            ),
            const SizedBox(
              height: 70,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 20,
                    ),
                    child: InkWell(
                      onTap: () async {
                        String deepLink = await createDynamicLink(
                          "/Calendar",
                        );
                        s4sSocialShare(deepLink);
                      },
                      child: Image.asset(
                        "assets/etc/share.gif",
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                ),
                Align(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      right: 30,
                    ),
                    child: IconButton(
                      icon: const Icon(
                        FontAwesomeIcons.arrowDownWideShort,
                      ),
                      color: calendarFilter.isNotEmpty
                          ? Colors.red
                          : Colors.black54,
                      iconSize: 30,
                      onPressed: () {
                        calendarFilterPopUp(context);
                      },
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        const Divider(
          color: Colors.grey,
          height: 0,
          thickness: 1,
        ),
        Expanded(
          child: SmartRefresher(
            enablePullDown: false,
            enablePullUp: true,
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus? mode) {
                return const SizedBox(height: 0, width: 0);
              },
            ),
            controller: upcompingRefreshController,
            child: ListView.separated(
              key: const PageStorageKey<String>('Listview Upcoming Parent'),
              controller: upcomingScrollController,
              physics: const BouncingScrollPhysics(),
              itemCount: filteredUpcomings.isEmpty
                  ? upcomings.length
                  : filteredUpcomings.length,
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(
                  height: 0,
                );
              },
              itemBuilder: (BuildContext context, int index) {
                return StickyHeader(
                  header: calendarDateBarUpcoming(
                    filteredUpcomings.isEmpty
                        ? upcomings[index]
                        : filteredUpcomings[index],
                  ),
                  content: Column(
                    children: [
                      ListView.builder(
                        padding: const EdgeInsets.only(bottom: 0),
                        key: const PageStorageKey<String>(
                          'Listview Upcoming Child 0',
                        ),
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: filteredUpcomings.isEmpty
                            ? upcomings[index][upcomings[index].keys.first]
                                .length
                            : filteredUpcomings[index]
                                    [filteredUpcomings[index].keys.first]
                                .length,
                        itemBuilder: (BuildContext context, int indexProduct) {
                          var product = filteredUpcomings.isEmpty
                              ? upcomings[index][upcomings[index].keys.first]
                              : filteredUpcomings[index]
                                  [filteredUpcomings[index].keys.first];

                          return renderCalendarTile(product, indexProduct);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget pageCalendarMainPast() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 30),
              child: InkWell(
                onTap: () {
                  positionCalendarPage = 1;
                  Navigator.of(context).pushReplacementNamed('/Calendar');
                },
                child: const Image(
                  height: 35,
                  image: AssetImage('./assets/etc/splash-cropped.png'),
                ),
              ),
            ),
            const SizedBox(
              height: 70,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Align(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 20,
                    ),
                    child: InkWell(
                      onTap: () async {
                        String deepLink = await createDynamicLink(
                          "/Calendar",
                        );
                        s4sSocialShare(deepLink);
                      },
                      child: Image.asset(
                        "assets/etc/share.gif",
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                ),
                Align(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      right: 30,
                    ),
                    child: IconButton(
                      icon: const Icon(
                        FontAwesomeIcons.arrowDownWideShort,
                      ),
                      color: calendarFilter.isNotEmpty
                          ? Colors.red
                          : Colors.black54,
                      iconSize: 30,
                      onPressed: () {
                        calendarFilterPopUp(context);
                      },
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        const Divider(
          color: Colors.grey,
          height: 0,
          thickness: 1,
        ),
        Expanded(
          child: SmartRefresher(
            enablePullDown: false,
            enablePullUp: true,
            footer: CustomFooter(
              builder: (BuildContext context, LoadStatus? mode) {
                return const SizedBox(height: 0, width: 0);
              },
            ),
            controller: pastRefreshController,
            child: ListView.separated(
              key: const PageStorageKey<String>('Listview Past Parent'),
              controller: pastScrollController,
              physics: const BouncingScrollPhysics(),
              itemCount:
                  filteredPasts.isEmpty ? pasts.length : filteredPasts.length,
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(
                  height: 0,
                );
              },
              itemBuilder: (BuildContext context, int index) {
                return StickyHeader(
                  header: calendarDateBarUpcoming(
                    filteredPasts.isEmpty ? pasts[index] : filteredPasts[index],
                  ),
                  content: Column(
                    children: [
                      ListView.builder(
                        padding: const EdgeInsets.only(bottom: 0),
                        key: const PageStorageKey<String>(
                          'Listview Past Child 0',
                        ),
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: filteredPasts.isEmpty
                            ? pasts[index][pasts[index].keys.first].length
                            : filteredPasts[index]
                                    [filteredPasts[index].keys.first]
                                .length,
                        itemBuilder: (BuildContext context, int indexProduct) {
                          var product = filteredPasts.isEmpty
                              ? pasts[index][pasts[index].keys.first]
                              : filteredPasts[index]
                                  [filteredPasts[index].keys.first];

                          return renderCalendarTile(product, indexProduct);
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  void animateToMainPage(int pageIndex) {
    Future.delayed(const Duration(milliseconds: 200), () {
      if (calendarMainPageController.hasClients) {
        calendarMainPageController.animateToPage(
          pageIndex,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 16,
      color: Colors.white30,
    );
    Widget text;
    switch (value.toInt()) {
      case 2:
        text = const Text('MAR', style: style);
        break;
      case 5:
        text = const Text('JUN', style: style);
        break;
      case 8:
        text = const Text('SEP', style: style);
        break;
      default:
        text = const Text('', style: style);
        break;
    }

    return SideTitleWidget(
      axisSide: meta.axisSide,
      child: text,
    );
  }

  Widget leftTitleWidgets(double value, TitleMeta meta) {
    if (kDebugMode) {
      print(meta);
    }
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 15,
      color: Colors.white30,
    );
    String text;
    switch (value.toInt()) {
      case 1:
        text = '10K';
        break;
      case 3:
        text = '30k';
        break;
      case 5:
        text = '50k';
        break;
      default:
        return Container();
    }

    return Text(text, style: style, textAlign: TextAlign.left);
  }

  Future calendarFilterPopUp(BuildContext context) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: ((context, setStateDialog) {
          return Dialog(
            insetPadding: const EdgeInsets.all(0),
            backgroundColor: Colors.transparent,
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: const Color(0xFFF6F6F6),
              ),
              width: 338,
              height: 600,
              child: Column(
                children: [
                  const SizedBox(height: 25),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        width: 10,
                      ),
                      const Icon(
                        FontAwesomeIcons.arrowDownWideShort,
                        size: 35,
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            AppLocalizations.of(context).calendar_filters,
                            style: w700Black25,
                          ),
                          Text(
                            AppLocalizations.of(context).calendar_byResellValue,
                            style: w300Black14,
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 480,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Center(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              width: 280,
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                children: [
                                  Text(
                                    AppLocalizations.of(context)
                                        .calendar_byResellValue,
                                    style: w900Black20,
                                  ),
                                  Text(
                                    AppLocalizations.of(context)
                                        .calendar_filterFromMarketType,
                                    style: w400Black12,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          if (calendarFilter.contains('Low')) {
                                            calendarFilter.remove("Low");
                                          } else {
                                            calendarFilter.add("Low");
                                          }
                                          setStateDialog(() {
                                            calendarFilter = calendarFilter;
                                          });
                                          setState(() {
                                            calendarFilter = calendarFilter;
                                            filteredUpcomings =
                                                calendarFilterFunc(
                                              upcomings,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                            filteredPasts = calendarFilterFunc(
                                              pasts,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                          });
                                        },
                                        child: Material(
                                          elevation: 8,
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(20),
                                          ),
                                          child: Container(
                                            width: 113,
                                            height: 40,
                                            padding: const EdgeInsets.fromLTRB(
                                                5, 8, 5, 8),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF758390),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(
                                                  AppLocalizations.of(context)
                                                      .calendar_filterLow,
                                                  style: w900White14,
                                                ),
                                                Image.asset(
                                                  calendarFilter.contains('Low')
                                                      ? 'assets/etc/restock/checked_white.png'
                                                      : 'assets/etc/restock/unchecked_white.png',
                                                  height: 20,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      InkWell(
                                        onTap: () {
                                          if (calendarFilter.contains('High')) {
                                            calendarFilter.remove("High");
                                          } else {
                                            calendarFilter.add("High");
                                          }
                                          setStateDialog(() {
                                            calendarFilter = calendarFilter;
                                          });
                                          setState(() {
                                            calendarFilter = calendarFilter;
                                            filteredUpcomings =
                                                calendarFilterFunc(
                                              upcomings,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                            filteredPasts = calendarFilterFunc(
                                              pasts,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                          });
                                        },
                                        child: Material(
                                          elevation: 8,
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(20),
                                          ),
                                          child: Container(
                                            width: 113,
                                            height: 40,
                                            padding: const EdgeInsets.fromLTRB(
                                                5, 8, 5, 8),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFF21ED8B),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(
                                                  AppLocalizations.of(context)
                                                      .calendar_filterHigh,
                                                  style: w900White14,
                                                ),
                                                Image.asset(
                                                  calendarFilter
                                                          .contains('High')
                                                      ? 'assets/etc/restock/checked_white.png'
                                                      : 'assets/etc/restock/unchecked_white.png',
                                                  height: 20,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          if (calendarFilter
                                              .contains('Medium')) {
                                            calendarFilter.remove("Medium");
                                          } else {
                                            calendarFilter.add("Medium");
                                          }
                                          setStateDialog(() {
                                            calendarFilter = calendarFilter;
                                          });
                                          setState(() {
                                            calendarFilter = calendarFilter;
                                            filteredUpcomings =
                                                calendarFilterFunc(
                                              upcomings,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                            filteredPasts = calendarFilterFunc(
                                              pasts,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                          });
                                        },
                                        child: Material(
                                          elevation: 8,
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(20),
                                          ),
                                          child: Container(
                                            width: 113,
                                            height: 40,
                                            padding: const EdgeInsets.fromLTRB(
                                                5, 8, 5, 8),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFFFC654),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(
                                                  AppLocalizations.of(context)
                                                      .calendar_filterMid,
                                                  style: w900White14,
                                                ),
                                                Image.asset(
                                                  calendarFilter
                                                          .contains('Medium')
                                                      ? 'assets/etc/restock/checked_white.png'
                                                      : 'assets/etc/restock/unchecked_white.png',
                                                  height: 20,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      InkWell(
                                        onTap: () {
                                          if (calendarFilter.contains('High')) {
                                            calendarFilter.remove("High");
                                          } else {
                                            calendarFilter.add("High");
                                          }
                                          setStateDialog(() {
                                            calendarFilter = calendarFilter;
                                          });
                                          setState(() {
                                            calendarFilter = calendarFilter;
                                            filteredUpcomings =
                                                calendarFilterFunc(
                                              upcomings,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                            filteredPasts = calendarFilterFunc(
                                              pasts,
                                              calendarFilter,
                                              checkedBrands,
                                            );
                                          });
                                        },
                                        child: Material(
                                          elevation: 8,
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(20),
                                          ),
                                          child: Container(
                                            width: 113,
                                            height: 40,
                                            padding: const EdgeInsets.fromLTRB(
                                                5, 8, 5, 8),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFF55E5E),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(
                                                  AppLocalizations.of(context)
                                                      .calendar_filterHeat,
                                                  style: w900White14,
                                                ),
                                                Image.asset(
                                                  calendarFilter
                                                          .contains('High')
                                                      ? 'assets/etc/restock/checked_white.png'
                                                      : 'assets/etc/restock/unchecked_white.png',
                                                  height: 20,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Center(
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFFF55E5E),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              width: 287,
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                children: [
                                  Text(
                                    AppLocalizations.of(context)
                                        .calendar_byBrands,
                                    style: w900White20,
                                  ),
                                  Text(
                                    AppLocalizations.of(context)
                                        .calendar_filterFromSelectedBrands,
                                    style: w400White12,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      top: 10,
                                      left: 0,
                                      right: 0,
                                    ),
                                    child: Wrap(
                                      spacing: 0,
                                      runSpacing: 0,
                                      alignment: WrapAlignment.center,
                                      children: [
                                        for (String brand in brands)
                                          Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0, 0, 0, 0),
                                            child: Container(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      5, 0, 5, 0),
                                              decoration: BoxDecoration(
                                                border: checkedBrands
                                                        .indexOf(brand)
                                                        .isNegative
                                                    ? Border(
                                                        bottom: BorderSide(
                                                          color: Colors
                                                              .red.shade400,
                                                          width: 0.2,
                                                        ),
                                                      )
                                                    : const Border(
                                                        bottom: BorderSide(
                                                          color: Colors.white70,
                                                          width: 2,
                                                        ),
                                                      ),
                                              ),
                                              child: IconButton(
                                                onPressed: () async {
                                                  List<String> temp =
                                                      checkedBrands;
                                                  if (temp
                                                      .indexOf(brand)
                                                      .isNegative) {
                                                    checkedBrands.add(brand);
                                                  } else {
                                                    checkedBrands.remove(brand);
                                                  }
                                                  setStateDialog(() {
                                                    checkedBrands = temp;
                                                  });
                                                  setState(() {
                                                    checkedBrands = temp;
                                                  });
                                                  prefs.setStringList(
                                                    "upcomingFilterBrands",
                                                    checkedBrands,
                                                  );
                                                  upcoming =
                                                      await getUpcomings();
                                                  past = await getPasts();
                                                  setState(() {
                                                    upcomings = upcoming;
                                                    pasts = past;
                                                  });
                                                  filteredUpcomings =
                                                      calendarFilterFunc(
                                                    upcomings,
                                                    calendarFilter,
                                                    checkedBrands,
                                                  );
                                                  filteredPasts =
                                                      calendarFilterFunc(
                                                    pasts,
                                                    calendarFilter,
                                                    checkedBrands,
                                                  );
                                                },
                                                icon: Image.asset(
                                                  'assets/brands/white/$brand.png',
                                                  color: Colors.white,
                                                ),
                                                iconSize: 35,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }));
      },
    );
  }

  DateTime currentBackPressTime = DateTime.now();

  Future<bool> onBackPressed() {
    DateTime now = DateTime.now();
    if (now.difference(currentBackPressTime) > const Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(msg: 'Press Back Button Again to Exit');

      return Future.value(false);
    }

    exit(0);
  }

  Widget buildCalendarMainPage() {
    animateToMainPage(positionCalendarPage);

    return PageView(
      controller: calendarMainPageController,
      onPageChanged: (value) {
        setState(() {
          isUpcoming = value == 0;
          isPast = value == 1;
          positionCalendarPage = value;
        });
      },
      children: [
        pageCalendarMainUpcoming(),
        pageCalendarMainPast(),
      ],
    );
  }

  void scrollToTop(int index) {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (index == 0) {
        if (upcomingScrollController.hasClients) {
          upcomingScrollController.animateTo(
            0,
            duration: const Duration(milliseconds: 50),
            curve: Curves.easeInOut,
          );
        }
      } else {
        if (pastScrollController.hasClients) {
          pastScrollController.animateTo(
            0,
            duration: const Duration(milliseconds: 50),
            curve: Curves.easeInOut,
          );
        }
      }
    });
  }

  Widget getCalendarContent() {
    Widget pastButton = buildFloatingButtonMainCalendar(
      AppLocalizations.of(context).calendar_past,
      !isPast ? Colors.white : const Color(0xFFF55E5E),
      !isPast ? const Color(0xFF757D90) : Colors.white,
      () {
        setState(
          () {
            isPast = true;
            isUpcoming = false;
            positionCalendarPage = 1;
          },
        );
      },
      width: 170,
    );

    Widget upcomingButton = buildFloatingButtonMainCalendar(
      AppLocalizations.of(context).calendar_upcoming,
      isUpcoming ? const Color(0xFFF55E5E) : Colors.white,
      isUpcoming ? Colors.white : const Color(0xFF757D90),
      () {
        setState(
          () {
            isUpcoming = true;
            isPast = false;
            positionCalendarPage = 0;
          },
        );
      },
      width: 170,
    );

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          buildCalendarMainPage(),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Stack(
        alignment: Alignment.center,
        children: [
          !isUpcoming
              ? Align(
                  alignment: const Alignment(-0.6, 0.92),
                  child: GestureDetector(
                    onDoubleTap: () {
                      setState(
                        () {
                          isUpcoming = true;
                          isPast = false;
                          positionCalendarPage = 0;
                          scrollToTop(0);
                        },
                      );
                    },
                    child: upcomingButton,
                  ),
                )
              : Align(
                  alignment: const Alignment(0.6, 0.92),
                  child: GestureDetector(
                    onDoubleTap: () {
                      setState(
                        () {
                          isPast = true;
                          isUpcoming = false;
                          positionCalendarPage = 1;
                          scrollToTop(1);
                        },
                      );
                    },
                    child: pastButton,
                  ),
                ),
          !isPast
              ? Align(
                  alignment: const Alignment(-0.6, 0.92),
                  child: GestureDetector(
                    onDoubleTap: () {
                      setState(
                        () {
                          isUpcoming = true;
                          isPast = false;
                          positionCalendarPage = 0;
                          scrollToTop(0);
                        },
                      );
                    },
                    child: upcomingButton,
                  ),
                )
              : Align(
                  alignment: const Alignment(0.6, 0.92),
                  child: GestureDetector(
                    onDoubleTap: () {
                      setState(
                        () {
                          isPast = true;
                          isUpcoming = false;
                          positionCalendarPage = 1;
                          scrollToTop(1);
                        },
                      );
                    },
                    child: pastButton,
                  ),
                ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      resizeToAvoidBottomInset: false,
      appBar: null,
      backgroundColor: Colors.white,
      body: getCalendarContent(),
    );
  }

  List calendarFilterFunc(List data, List keys, List<String> checkedBrands) {
    List result = [];
    for (var n in data) {
      if (n is Map) {
        List temp = [];
        var tempList = n.values.first;
        if (tempList is List) {
          for (var element in tempList) {
            if (element["ResellValueState"] != null) {
              for (var i = 0; i < keys.length; i++) {
                if (element["ResellValueState"] == keys[i]) {
                  if (checkedBrands.isNotEmpty) {
                    if (isBrandMatch(
                      checkedBrands,
                      element['ProductBrand'].toString().toLowerCase(),
                    )) {
                      temp.add(element);
                    }
                  } else {
                    temp.add(element);
                  }
                }
              }
            }
          }
        }
        if (temp.isNotEmpty) {
          result.add({n.keys.first: temp});
        }
      }
    }

    return result;
  }
}
