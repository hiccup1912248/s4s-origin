import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:imageview360/imageview360.dart';
import 'package:intl/intl.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:pinch_zoom/pinch_zoom.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:s4s_mobileapp/widgets/custom_horizontal_picker/custom_horizontal_picker.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

bool is360 = false;
bool isPriceChart = false;
bool is360Able = false;
String deviceOrientation = '';
bool deviceOrientationChange = false;

List<ImageProvider> imageList360 = [];
List<dynamic> cacheFileList = [];

bool isRaffles = false;
bool isRetail = true;
bool isResell = false;

int like = 0;
int dislike = 0;

Map raffleDetail = {};
Map retailDetail = {};
Map resellDetail = {};

List cUSSizes = [];
List cUKSizes = [];
List cEUSizes = [];
List cPricesPerSize = [];

String calendarProductSelectedSize = "";
Map calendarProductDetail = {};
bool fromTrend = false;

List cDetailsPerSize = [];

class CalendarDetailWidget extends StatefulWidget {
  const CalendarDetailWidget({Key? key}) : super(key: key);

  @override
  State<CalendarDetailWidget> createState() => _CalendarDetailWidgetState();
}

class _CalendarDetailWidgetState extends State<CalendarDetailWidget> {
  List detailsPerSize = [];
  bool isCalendarFav = false;
  bool tapButtonClicked = false;
  bool isproductDetail = false;
  List<ScrollController> scrollControllers = [
    ScrollController(),
    ScrollController(),
    ScrollController(),
  ];
  ScrollController scrollController = ScrollController();
  final PageController itemDetailController = PageController(initialPage: 1);
  bool showProductDetailCard = false;
  int calProductLike = 0;
  int calProductDislike = 0;
  bool sortPrice = false;
  bool sortShop = false;
  bool sortRating = false;

  bool sortRetailShops = false;
  bool sortRetailPrice = false;

  bool sortRaffleShops = false;
  bool sortRaffleDate = false;
  bool sortRaffleLocation = false;
  bool sortRaffleShipping = false;
  bool sortRaffleMark = false;
  bool isLoading = false;

  List<String> shopMarks = [];
  late List<Map> priceHistory = [];
  String preferredSize = prefs.getString("preferredSize") ?? "";

  syncUserShopMarkInfo() {
    List<String> shopMarkStrList = prefs.getStringList("shopMarks") ?? [];
    setState(() {
      shopMarks = shopMarkStrList;
    });
  }

  Future<void> checkIsFav() async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    try {
      if (wishlist.isNotEmpty) {
        for (var el in wishlist) {
          if (el.contains(calendarProductDetail['ProductSKU'])) {
            setState(() {
              isCalendarFav = true;
            });

            return;
          }
        }
      }
      // ignore: empty_catches
    } catch (e) {}

    setState(() {
      isCalendarFav = false;
    });

    return;
  }

  getCalendarProductDetail() async {
    calendarProductSelectedSize = "";
    checkIsFav();
    raffleDetail = await getRaffles(calendarProductDetail['ProductSKU']);
    calProductLike = raffleDetail["ProductLike"];
    calProductDislike = raffleDetail["ProductDislike"];
    retailDetail = await getRetails(calendarProductDetail['ProductSKU']);
    resellDetail = await getResells(calendarProductDetail['ProductSKU']);
    cUSSizes = getMainSizeData(
      resellDetail['ProductSizeBest'],
      resellDetail['sizeSlider'],
    );
    cUKSizes = getUKSize(cUSSizes, resellDetail['sizeSlider']);
    cEUSizes = getEUSize(cUSSizes, resellDetail['sizeSlider']);
    cPricesPerSize = cUSSizes
        .map((e) => getPricePerSize(e, resellDetail['ProductSizeBest']))
        .toList();
    cDetailsPerSize = [];

    if (cUSSizes.isNotEmpty) {
      String userPreferedSize = prefs.getString("preferredSize") ?? "";
      double userSize =
          double.parse(userPreferedSize.split("/")[0].replaceAll("US ", ""));
      int initialItem;
      if (cUSSizes.isNotEmpty && resellDetail['ProductSize'].isNotEmpty) {
        List temp = cUSSizes.where((element) {
          return double.parse(element
                  .toString()
                  .replaceAll('Y', '')
                  .replaceAll('C', '')
                  .replaceAll('K', '')) <=
              userSize;
        }).toList();
        initialItem = temp.isNotEmpty ? temp.length - 1 : 0;

        detailsPerSize = getProductsPerSize(
          cUSSizes[initialItem],
          resellDetail['ProductSize'],
        );
      }
      if (mounted) {
        setState(() {});
      }
    }

    is360Able = calendarProductDetail['360Pictures'];
    imageList360 = [];
    if (is360Able) {
      get360Images();
    }
    is360 = false;
    isproductDetail = true;
    showProductDetailCard = false;
    isRetail = true;
    isRaffles = false;
    isResell = false;
    incrementProductHit(calendarProductDetail['ProductSKU']);
    fromTrend = false;
    resetSort();
    await getPriceHistoryData(calendarProductDetail['ProductSKU']);
    setState(() {});
  }

  syncScrollControllers() {
    // scrollController.addListener(() {
    //   if (scrollController.offset > 150) {
    //     setState(() {
    //       showProductDetailCard = true;
    //     });
    //   } else {
    //     setState(() {
    //       showProductDetailCard = false;
    //     });
    //   }
    // });

    scrollControllers[0].addListener(() {
      if (scrollControllers[0].offset > 150) {
        setState(() {
          showProductDetailCard = true;
        });
      } else {
        setState(() {
          showProductDetailCard = false;
        });
      }
    });

    scrollControllers[1].addListener(() {
      if (scrollControllers[1].offset > 150) {
        setState(() {
          showProductDetailCard = true;
        });
      } else {
        setState(() {
          showProductDetailCard = false;
        });
      }
    });

    scrollControllers[2].addListener(() {
      if (scrollControllers[2].offset > 150) {
        setState(() {
          showProductDetailCard = true;
        });
      } else {
        setState(() {
          showProductDetailCard = false;
        });
      }
    });
  }

  @override
  void initState() {
    getCalendarProductDetail();
    syncScrollControllers();

    if (cDetailsPerSize.isNotEmpty) {
      setState(() {
        detailsPerSize = cDetailsPerSize;
      });
    }

    syncUserShopMarkInfo();

    imageList360 = [];

    super.initState();
  }

  getPriceHistoryData(String productSKU) async {
    List<Map> priceHistoryData = await getPriceHistory(productSKU);
    setState(() {
      priceHistory = priceHistoryData;
    });
  }

  void increaseOrDecreaseLike(String productSKU, int type) async {
    Map result = await likeOrDislike(productSKU, type);
    if (result.isNotEmpty) {
      if (mounted) {
        setState(() {
          calProductLike = result["product_like"];
          calProductDislike = result["product_dislike"];
        });
      }
    }
  }

  get360Images() async {
    List<ImageProvider> temp = [];
    EdgeInsets devicePadding = MediaQuery.of(context).padding;
    for (var el in raffleDetail['ProductImage360']) {
      try {
        bool error = false;
        var cachedFile =
            await DefaultCacheManager().downloadFile(el).catchError((e) {
          error = true;
        });
        cacheFileList.add(cachedFile);

        if (error) {
          continue;
        } else {
          temp.add(ResizeImage(
            FileImage(File(cachedFile.file.path)),
            // ignore: use_build_context_synchronously
            height: (MediaQuery.of(context).size.height -
                    devicePadding.top -
                    devicePadding.bottom -
                    30)
                .toInt(),
          ));
        }
        // ignore: empty_catches
      } catch (ex) {}
    }
    if (mounted) {
      setState(() {
        imageList360 = temp;
      });
    }
  }

  checkValueISNullOrZero(var value) {
    value = value.toString().replaceAll("-", "");
    if (value.isEmpty) {
      return false;
    }
    if (value == "0") {
      return false;
    }
    if (value == "-") {
      return false;
    }

    return true;
  }

  Widget returnCalendarItemRafflesContainer(Map raffle) {
    if (kDebugMode) {
      print(raffle);
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: const Alignment(-0.85, 0),
              child: InkWell(
                onTap: () {
                  setState(() {
                    sortRaffleShops = !sortRaffleShops;
                  });
                  sortRaffleWithSortField("sortRaffleShops", sortRaffleShops);
                  // sortDetailsPerSize('price', sortPrice);
                },
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context).calDetail_shops,
                        style: w600Gray16,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            sortRaffleShops
                                ? FontAwesomeIcons.arrowDown
                                : FontAwesomeIcons.arrowUp,
                            size: 10,
                            color: const Color(0x7F757D90),
                          ),
                          Text(
                            AppLocalizations.of(context).calDetail_links,
                            style: w400Gray8,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(-0.4, 0),
              child: InkWell(
                onTap: () {
                  setState(() {
                    sortRaffleDate = !sortRaffleDate;
                  });
                  sortRaffleWithSortField('sortRaffleDate', sortRaffleDate);
                },
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context).calDetail_date,
                        style: w600Gray16,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            sortRaffleDate
                                ? FontAwesomeIcons.arrowDown
                                : FontAwesomeIcons.arrowUp,
                            size: 10,
                            color: const Color(0x7F757D90),
                          ),
                          Text(
                            AppLocalizations.of(context).calDetail_close,
                            style: w400Gray8,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(0.05, 0),
              child: InkWell(
                onTap: () {
                  setState(() {
                    sortRaffleLocation = !sortRaffleLocation;
                  });
                  sortRaffleWithSortField(
                    'sortRaffleLocation',
                    sortRaffleLocation,
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context).calDetail_location,
                        style: w600Gray16,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            sortRaffleLocation
                                ? FontAwesomeIcons.arrowDown
                                : FontAwesomeIcons.arrowUp,
                            size: 10,
                            color: const Color(0x7F757D90),
                          ),
                          Text(
                            AppLocalizations.of(context).calDetail_euandus,
                            style: w400Gray8,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(0.58, 0),
              child: InkWell(
                onTap: () {
                  setState(() {
                    sortRaffleShipping = !sortRaffleShipping;
                  });
                  sortRaffleWithSortField(
                    'sortRaffleShipping',
                    sortRaffleShipping,
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context).calDetail_shipping,
                        style: w600Gray16,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            sortRaffleShipping
                                ? FontAwesomeIcons.arrowDown
                                : FontAwesomeIcons.arrowUp,
                            size: 10,
                            color: const Color(0x7F757D90),
                          ),
                          Text(
                            AppLocalizations.of(context).calDetail_method,
                            style: w400Gray8,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(0.95, 0),
              child: InkWell(
                onTap: () {
                  setState(() {
                    sortRaffleMark = !sortRaffleMark;
                  });
                  sortRaffleWithSortField('sortRaffleMark', sortRaffleMark);
                },
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppLocalizations.of(context).calDetail_mark,
                        style: w600Gray16,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            sortRaffleMark
                                ? FontAwesomeIcons.arrowDown
                                : FontAwesomeIcons.arrowUp,
                            size: 10,
                            color: const Color(0x7F757D90),
                          ),
                          Text(AppLocalizations.of(context).calDetail_done,
                              style: w400Gray8),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        if (raffleDetail['ShopShipping'] != null)
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  for (int index = 0;
                      index < raffleDetail['ShopShipping'].length;
                      index++)
                    renderRaffleShopDetail(index),
                  renderSpecificationsSection(),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget returnCalendarItemRetailContainer(Map retailDetail) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Stack(alignment: Alignment.center, children: [
          Align(
            alignment: const Alignment(-0.8, 0),
            child: InkWell(
              onTap: () {
                setState(() {
                  sortRetailShops = !sortRetailShops;
                });
                sortRetailWithSortField('sortRetailShops', sortRetailShops);
              },
              child: Padding(
                padding: const EdgeInsets.all(0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      sortRetailShops
                          ? FontAwesomeIcons.arrowDown
                          : FontAwesomeIcons.arrowUp,
                      size: 12,
                      color: const Color(0xFF757D90),
                    ),
                    Text(
                      AppLocalizations.of(context).calDetail_shops,
                      style: w600Gray16,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: InkWell(
              onTap: () {
                setState(() {
                  sortRetailPrice = !sortRetailPrice;
                });
                sortRetailWithSortField('sortRetailPrice', sortRetailPrice);
              },
              child: Padding(
                padding: const EdgeInsets.all(0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      sortRetailPrice
                          ? FontAwesomeIcons.arrowDown
                          : FontAwesomeIcons.arrowUp,
                      size: 12,
                      color: const Color(0xFF757D90),
                    ),
                    Text(
                      AppLocalizations.of(context).calDetail_prices,
                      style: w600Gray16,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: const Alignment(0.7, 0),
            child: Text(
              AppLocalizations.of(context).calDetail_links,
              style: w600Gray16,
            ),
          ),
        ]),
        const SizedBox(
          height: 10,
        ),
        if (retailDetail['Shops'] != null)
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  for (int x = 0; x < retailDetail['Shops'].length; x++)
                    InkWell(
                      onTap: () {
                        urlLauncher(retailDetail['Shops'][x]['_ShopLink']);
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Text(
                              checkValueISNullOrZero(
                                retailDetail['Shops'][x]['_ShopPrice'],
                              )
                                  ? getPriceWithCurrency(
                                      retailDetail['Shops'][x]['_ShopPrice'],
                                    )
                                  : "TBC",
                              style: robotoStyle(
                                FontWeight.w600,
                                const Color.fromARGB(255, 49, 48, 54),
                                16,
                                null,
                              ),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(-0.7, 0),
                            child: SizedBox(
                              width: 50,
                              child: retailDetail['Shops'][x]['ShopLogo'] !=
                                          null &&
                                      retailDetail['Shops'][x]['ShopLogo']
                                          .contains('.svg')
                                  ? SvgPicture.network(
                                      retailDetail['Shops'][x]['ShopLogo'],
                                      width: 50,
                                      height: 50,
                                      fit: BoxFit.scaleDown,
                                      placeholderBuilder: (context) =>
                                          Image.asset(
                                        'assets/etc/NoImage-trans.png',
                                        fit: BoxFit.contain,
                                      ),
                                    )
                                  : CachedNetworkImage(
                                      imageUrl: retailDetail['Shops'][x]
                                              ['ShopLogo'] ??
                                          "",
                                      errorWidget:
                                          (context, error, stackTrace) {
                                        return Image.asset(
                                          'assets/etc/NoImage-trans.png',
                                          fit: BoxFit.contain,
                                        );
                                      },
                                    ),
                            ),
                          ),
                          Align(
                            alignment: const Alignment(0.7, 0),
                            child: InkWell(
                              onTap: () {
                                urlLauncher(
                                  retailDetail['Shops'][x]['_ShopLink'],
                                );
                              },
                              child: const Icon(
                                CupertinoIcons.link,
                                size: 25,
                                color: Color.fromARGB(255, 255, 35, 35),
                              ),
                            ),
                          ),
                          const SizedBox(height: 60),
                        ],
                      ),
                    ),
                  renderSpecificationsSection(),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget returnCalendarItemResellContainer(Map list) {
    if (kDebugMode) {
      print(list);
    }

    String resellValuePourcent =
        calendarProductDetail['ResellValuePourcent'].toString();
    String resellValuePourcentStr = resellValuePourcent.toString();
    String resellValuePourcentStrFormat =
        calendarProductDetail['ResellValuePourcent']
            .toString()
            .replaceAll('%', '');

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (cUSSizes.isNotEmpty)
          Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(35, 0, 35, 0),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  color: const Color(0xffF6F6F6),
                ),
                padding: const EdgeInsets.only(
                  left: 15,
                  right: 15,
                ),
                child: HorizontalPicker(
                  height: 70,
                  prefix: "US ",
                  subLeftPrefix: "EU",
                  subRightPrefix: "UK",
                  showCursor: false,
                  initialPosition: InitialPosition.user,
                  backgroundColor: Colors.transparent,
                  activeItemTextColor: const Color.fromARGB(255, 49, 48, 54),
                  passiveItemsTextColor: Colors.grey.withOpacity(0.5),
                  mainData: cUSSizes,
                  subDataRight: cUKSizes,
                  subDataLeft: cEUSizes,
                  sizePrice: cPricesPerSize,
                  sizeType: resellDetail['sizeSlider'],
                  onChanged: (value) {
                    calendarProductSelectedSize = value;
                    detailsPerSize =
                        getProductsPerSize(value, resellDetail['ProductSize']);
                    resetSort();
                    setState(() {
                      preferredSize = value;
                    });
                  },
                ),
              ),
            ),
          ),
        Container(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    sortPrice = !sortPrice;
                  });
                  sortDetailsPerSize('price', sortPrice);
                },
                child: Padding(
                  padding: const EdgeInsets.all(7),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        sortPrice
                            ? FontAwesomeIcons.arrowDown
                            : FontAwesomeIcons.arrowUp,
                        size: 12,
                        color: const Color(0xFF757D90),
                      ),
                      Text(
                        AppLocalizations.of(context).calDetail_prices,
                        style: w600Gray16,
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  setState(() {
                    sortShop = !sortShop;
                  });
                  sortDetailsPerSize('shop', sortShop);
                },
                child: Padding(
                  padding: const EdgeInsets.all(7),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        sortShop
                            ? FontAwesomeIcons.arrowDown
                            : FontAwesomeIcons.arrowUp,
                        size: 12,
                        color: const Color(0xFF757D90),
                      ),
                      Text(
                        AppLocalizations.of(context).calDetail_shops,
                        style: w600Gray16,
                      ),
                    ],
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  setState(() {
                    sortRating = !sortRating;
                  });
                  sortDetailsPerSize('rating', sortRating);
                },
                child: Padding(
                  padding: const EdgeInsets.all(7),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        sortRating
                            ? FontAwesomeIcons.arrowDown
                            : FontAwesomeIcons.arrowUp,
                        size: 12,
                        color: const Color(0xFF757D90),
                      ),
                      Text(
                        AppLocalizations.of(context).calDetail_reviews,
                        style: w600Gray16,
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(7),
                child: SizedBox(
                  child: Text(
                    AppLocalizations.of(context).calDetail_links,
                    style: w600Gray16,
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                ListView.builder(
                  padding: const EdgeInsets.only(
                    bottom: 0,
                    top: 10,
                  ),
                  physics: const NeverScrollableScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemCount: detailsPerSize.length,
                  itemBuilder: (BuildContext ctx, int index) {
                    return InkWell(
                      onTap: () {
                        urlLauncher(detailsPerSize[index]['Link']);
                      },
                      child: Container(
                        color: index == 0
                            ? const Color(0xffF6F6F6)
                            : Colors.transparent,
                        child: Padding(
                          padding: const EdgeInsets.only(
                            left: 40,
                            right: 40,
                            top: 10,
                            bottom: 10,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                getPriceWithCurrency(
                                  detailsPerSize[index]['Price'],
                                ),
                                style: TextStyle(
                                  color: index == 0
                                      ? const Color(0xFF21ED8B)
                                      : const Color(0xff313036),
                                  fontSize: 22,
                                  fontWeight: index == 0
                                      ? FontWeight.bold
                                      : FontWeight.w400,
                                ),
                              ),
                              SizedBox(
                                width: 50,
                                child: detailsPerSize[index]['ShopLogo'] != null
                                    ? detailsPerSize[index]['ShopLogo']
                                            .contains('.svg')
                                        ? SvgPicture.network(
                                            detailsPerSize[index]['ShopLogo'],
                                            width: 50,
                                            height: 50,
                                            fit: BoxFit.scaleDown,
                                            placeholderBuilder: (context) =>
                                                Image.asset(
                                              'assets/etc/NoImage-trans.png',
                                              fit: BoxFit.contain,
                                            ),
                                          )
                                        : CachedNetworkImage(
                                            imageUrl: detailsPerSize[index]
                                                ['ShopLogo'],
                                            fit: BoxFit.contain,
                                            errorWidget:
                                                (context, error, stackTrace) {
                                              return Image.asset(
                                                'assets/etc/NoImage-trans.png',
                                                fit: BoxFit.fill,
                                              );
                                            },
                                          )
                                    : Image.asset(
                                        'assets/etc/NoImage-trans.png',
                                        fit: BoxFit.fill,
                                      ),
                              ),
                              JustTheTooltip(
                                backgroundColor: Colors.black26,
                                content: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  padding: const EdgeInsets.all(10),
                                  child: Text(
                                    'Notation come from Trustpilot',
                                    style: w700White14,
                                  ),
                                ),
                                child: RatingBarIndicator(
                                  rating:
                                      detailsPerSize[index]['ShopScore'] != null
                                          ? detailsPerSize[index]['ShopScore']
                                              .toDouble()
                                          : 0,
                                  itemBuilder: (context, index) => const Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                                  itemCount: 5,
                                  itemSize: 15.0,
                                ),
                              ),
                              JustTheTooltip(
                                backgroundColor: Colors.black26,
                                onDismiss: () {
                                  Clipboard.setData(
                                    ClipboardData(
                                      text: detailsPerSize[index]['Link'],
                                    ),
                                  );
                                },
                                content: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  padding: const EdgeInsets.all(10),
                                  child: Text(
                                    'Link copied to our clipboard',
                                    style: w700White14,
                                  ),
                                ),
                                child: const Icon(
                                  CupertinoIcons.link,
                                  size: 28,
                                  color: Color(0xffFF2323),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      InkWell(
                        onTap: (() {
                          setState(() {
                            isPriceChart = true;
                          });
                        }),
                        child: Container(
                          height: 55,
                          width: MediaQuery.of(context).size.width - 120,
                          padding: const EdgeInsets.fromLTRB(15, 7, 15, 7),
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 246, 246, 246),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Container(
                                constraints: const BoxConstraints(maxWidth: 80),
                                child: Text(
                                  AppLocalizations.of(context)
                                      .calDetail_marketAnalysis,
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  style: w800Black16,
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: resellValuePourcentStr != 'TBC' &&
                                        resellValuePourcentStr != ""
                                    ? [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Column(
                                              children: [
                                                Text(
                                                  AppLocalizations.of(context)
                                                      .search_margin,
                                                  style: robotoStyle(
                                                    FontWeight.w400,
                                                    returnColorCalendarCote(
                                                      resellValuePourcentStrFormat,
                                                    ),
                                                    16,
                                                    null,
                                                  ),
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Text(
                                                      (returnSignCalendarCote(
                                                            resellValuePourcentStrFormat,
                                                          ) +
                                                          resellValuePourcentStr +
                                                          (resellValuePourcentStr
                                                                  .contains('%')
                                                              ? ""
                                                              : "%")),
                                                      style: w800Color16(
                                                        returnColorCalendarCote(
                                                          resellValuePourcentStrFormat,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                            Icon(
                                              isNumber(resellValuePourcentStr) &&
                                                      int.parse(
                                                              resellValuePourcentStrFormat) >=
                                                          0
                                                  ? Icons.trending_up_rounded
                                                  : Icons.trending_down_rounded,
                                              size: 18,
                                              color: returnColorCalendarCote(
                                                resellValuePourcentStrFormat,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ]
                                    : [
                                        const Text(
                                          'TBC',
                                          style: TextStyle(
                                            // color: Color(0xff313036),
                                            color: Color.fromARGB(
                                              255,
                                              221,
                                              220,
                                              222,
                                            ),
                                            fontSize: 24,
                                          ),
                                        ),
                                      ],
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: calendarProductDetail[
                                                'ResellValuePourcent'] !=
                                            null &&
                                        resellValuePourcentStr != 'TBC' &&
                                        resellValuePourcentStr != ""
                                    ? [
                                        Text(
                                          "Profit",
                                          style: w400Color16(
                                            returnColorCalendarCote(
                                              resellValuePourcentStrFormat,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          "> ${calendarProductDetail['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(calendarProductDetail['ResellValueProfit'])}",
                                          style: robotoStyle(
                                            FontWeight.w800,
                                            returnColorCalendarCote(
                                              resellValuePourcentStrFormat,
                                            ),
                                            16,
                                            null,
                                          ),
                                        ),
                                      ]
                                    : [
                                        const Text(
                                          '',
                                          style: TextStyle(
                                            // color: Color(0xff313036),
                                            color: Color.fromARGB(
                                              255,
                                              221,
                                              220,
                                              222,
                                            ),
                                            fontSize: 24,
                                          ),
                                        ),
                                      ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: 55,
                        width: 55,
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 246, 246, 246),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: InkWell(
                          onTap: () async {
                            String deepLink = await createDynamicLink(
                              "/CalendarDetail?sku=${calendarProductDetail['ProductSKU']}",
                            );
                            s4sSocialShare(deepLink);
                            // showSocialShareDialog();
                          },
                          child: Image.asset(
                            "assets/etc/share-gray.gif",
                            width: 50,
                            height: 50,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // renderPriceHistoryChart(MediaQuery.of(context).size.width,
                //     210, priceHistory, preferredSize),
                renderSpecificationsSection(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget renderSpecificationsSection() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(20, 15, 20, 5),
          child: Text(
            AppLocalizations.of(context).calDetail_specifications,
            textAlign: TextAlign.center,
            style: robotoStyle(
              FontWeight.w600,
              const Color.fromARGB(255, 49, 48, 54),
              20,
              null,
            ),
          ),
        ),
        Center(
          child: Container(
            height: 4,
            width: 130,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20.0),
              color: const Color.fromARGB(255, 255, 35, 35),
            ),
          ),
        ),
        const SizedBox(
          height: 30,
        ),
        Center(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "${AppLocalizations.of(context).calDetail_retailPrice} :  ",
                    style: w400Gray16,
                  ),
                  Text(
                    getPriceWithCurrency(raffleDetail['RetailPrice']),
                    style: w700Gray16,
                  ),
                ],
              ),
              const SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "SKU :  ",
                    style: w400Gray16,
                  ),
                  InkWell(
                    onTap: () {
                      String productSKU = raffleDetail['ProductSKU'].toString();
                      Clipboard.setData(ClipboardData(text: productSKU));
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          launchSnackbar(
                            'Product SKU copied to clipboard',
                            Icons.check,
                            AppColors.white,
                            AppColors.red,
                            Colors.white,
                          ),
                        );
                      }
                    },
                    child: Text(
                      raffleDetail['ProductSKU'].toString(),
                      style: robotoStyle(FontWeight.w700, Colors.red, 16, null),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "${AppLocalizations.of(context).calDetail_releaseDate} :  ",
                    style: w400Gray16,
                  ),
                  Text(
                    raffleDetail['ReleaseDate'].toString(),
                    style: w700Gray16,
                  ),
                ],
              ),
              const SizedBox(
                height: 5,
              ),
              FittedBox(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                  child: Text(
                    textAlign: TextAlign.center,
                    raffleDetail['ColorWay'].toString(),
                    style: robotoStyle(
                      FontWeight.w400,
                      const Color.fromARGB(255, 101, 101, 101),
                      16,
                      null,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(
          height: 50,
        ),
      ],
    );
  }

  resize360ImageList() {
    List<ImageProvider> temp = [];
    for (var el in cacheFileList) {
      temp.add(ResizeImage(
        FileImage(File(el.file.path)),
        height: (MediaQuery.of(context).size.height -
                MediaQuery.of(context).padding.top -
                MediaQuery.of(context).padding.bottom -
                30)
            .toInt(),
      ));
    }
    if (mounted) {
      setState(() {
        imageList360 = temp;
      });
    }
  }

  void animateToPage(int pageIndex) {
    if (itemDetailController.hasClients) {
      itemDetailController.animateToPage(
        pageIndex,
        duration: const Duration(milliseconds: 50),
        curve: Curves.easeInOut,
      );
    }
    Future.delayed(const Duration(milliseconds: 200), () {
      tapButtonClicked = false;
    });
  }

  getShopCloseString(String text) {
    try {
      return text != '-' && DateTime.parse(text).isBefore(DateTime.now())
          ? "closed"
          : "close";
    } catch (e) {
      return "close";
    }
  }

  Widget renderRaffleShopDetail(int index) {
    String locationArea = prefs.getString("locationArea") ?? "";
    List<String> euCountrys = [
      "malta",
      "luxembourg",
      "norway",
      "portugal",
      "netherlands",
      "poland",
      "romania",
      "sweden",
      "ukraine",
      "united-kingdom",
      "switzerland",
      "france",
      "bulgaria",
      "england",
      "european-union",
      "finland",
      "czech-republic",
      "spain",
      "denmark",
      "estonia",
      "greece",
      "germany",
      "ireland",
      "austria",
      "hungary",
      "italy",
      "turkey",
      "belgium",
      "iceland",
    ];
    if (locationArea.isNotEmpty) {
      locationArea = locationArea.split(' ')[1];
    }
    bool isFiltered = false;
    String countryName = "";
    String localAreaStr = locationArea.toLowerCase();

    if (raffleDetail['ShopLocationLogo'].length > index) {
      String regionFlagStr = raffleDetail['ShopLocationLogo'][index];
      countryName = regionFlagStr.split("/").last;
    }
    if (localAreaStr == "worldwide") {
      isFiltered = true;
    }
    if (localAreaStr == "canada") {
      if (raffleDetail['ShopLocation'][index] == "CA" ||
          countryName.contains("canada")) {
        isFiltered = true;
      }
    }
    if (localAreaStr == "china") {
      if (raffleDetail['ShopLocation'][index] == "CN" ||
          countryName.contains("china")) {
        isFiltered = true;
      }
    }
    if (localAreaStr == "japan") {
      if (raffleDetail['ShopLocation'][index] == "JP" ||
          countryName.contains("japan")) {
        isFiltered = true;
      }
    }
    if (localAreaStr == "usa") {
      if (raffleDetail['ShopLocation'][index] == "US" ||
          countryName.contains("united-states-of-america")) {
        isFiltered = true;
      }
    }
    if (localAreaStr == "europe") {
      if (raffleDetail['ShopLocation'][index] == "EU") {
        isFiltered = true;
      }
      for (var i = 0; i < euCountrys.length; i++) {
        if (countryName.contains(euCountrys[i])) {
          isFiltered = true;
        }
      }
    }

    return isFiltered
        ? Stack(alignment: Alignment.centerLeft, children: [
            Align(
              alignment: Alignment.centerLeft,
              child: InkWell(
                onTap: () {
                  urlLauncher(raffleDetail['ShopRaffeLink'][index]);
                },
                child: SizedBox(
                  width: MediaQuery.of(context).size.width - 70,
                  child: Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Align(
                        alignment: const Alignment(-0.85, 0),
                        child: SizedBox(
                          width: 40,
                          child: raffleDetail['ShopLogo'][index]
                                  .contains('.svg')
                              ? SvgPicture.network(
                                  raffleDetail['ShopLogo'][index],
                                  width: 40,
                                  height: 40,
                                  fit: BoxFit.scaleDown,
                                  placeholderBuilder: (context) => Image.asset(
                                      'assets/etc/NoImage-trans.png',
                                      fit: BoxFit.contain))
                              : CachedNetworkImage(
                                  imageUrl: raffleDetail['ShopLogo'][index],
                                  fit: BoxFit.fitWidth,
                                  errorWidget: (context, error, stackTrace) {
                                    return Image.asset(
                                        'assets/etc/NoImage-trans.png',
                                        fit: BoxFit.contain);
                                  }),
                        ),
                      ),
                      Align(
                        alignment: const Alignment(-0.3, 0),
                        child: Container(
                          width: 100,
                          alignment: Alignment.center,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                getShopCloseString(
                                  raffleDetail['ShopCloseTime'][index],
                                ),
                                style: robotoStyle(
                                  FontWeight.w400,
                                  getShopCloseFlag(
                                          raffleDetail['ShopCloseTime'][index])
                                      ? const Color.fromARGB(255, 119, 131, 143)
                                      : const Color.fromARGB(255, 49, 48, 54)
                                          .withOpacity(0.5),
                                  12,
                                  null,
                                ),
                              ),
                              Text(
                                raffleDetail['ShopCloseTime'][index],
                                style: robotoStyle(
                                  FontWeight.w800,
                                  getShopCloseFlag(
                                          raffleDetail['ShopCloseTime'][index])
                                      ? const Color.fromARGB(255, 119, 131, 143)
                                      : const Color.fromARGB(255, 49, 48, 54)
                                          .withOpacity(0.5),
                                  12,
                                  null,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: const Alignment(0.3, 0),
                        child: raffleDetail['ShopLocationLogo'].length > index
                            ? CachedNetworkImage(
                                imageUrl: raffleDetail['ShopLocationLogo']
                                    [index],
                                width: 25,
                                height: 25,
                                fit: BoxFit.cover,
                              )
                            : Container(),
                      ),
                      Align(
                        alignment: const Alignment(0.8, 0),
                        child: raffleDetail['ShopShipping'][index] != 'instore'
                            ? Icon(FontAwesomeIcons.truck,
                                color: getShopCloseFlag(
                                        raffleDetail['ShopCloseTime'][index])
                                    ? const Color.fromARGB(255, 119, 131, 143)
                                    : const Color.fromARGB(255, 49, 48, 54)
                                        .withOpacity(0.5),
                                size: 25)
                            : Icon(FontAwesomeIcons.mapPin,
                                color: getShopCloseFlag(
                                        raffleDetail['ShopCloseTime'][index])
                                    ? const Color.fromARGB(255, 119, 131, 143)
                                    : const Color.fromARGB(255, 49, 48, 54)
                                        .withOpacity(0.5),
                                size: 30),
                      ),
                      const SizedBox(height: 60),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(1, 0),
              child: InkWell(
                onTap: () {
                  changeMarkFlag(
                    raffleDetail['ProductSKU'],
                    raffleDetail['ShopRaffeLink'][index],
                  );
                },
                child: SizedBox(
                  width: 70,
                  height: 60,
                  child: getMarkWidget(
                    raffleDetail['ShopCloseTime'][index],
                    raffleDetail['ShopRaffeLink'][index],
                    raffleDetail['ProductSKU'],
                  ),
                ),
              ),
            ),
          ])
        : Container();
  }

  void sortDetailsPerSize(String type, bool direction) {
    if (type == 'price') {
      if (direction) {
        detailsPerSize.sort((a, b) => a['Price'].compareTo(b['Price']));
      } else {
        detailsPerSize.sort((a, b) => b['Price'].compareTo(a['Price']));
      }
    }
    if (type == 'shop') {
      if (direction) {
        detailsPerSize.sort((a, b) =>
            a['ShopLogo'].toLowerCase().compareTo(b['ShopLogo'].toLowerCase()));
      } else {
        detailsPerSize.sort((a, b) =>
            b['ShopLogo'].toLowerCase().compareTo(a['ShopLogo'].toLowerCase()));
      }
    }
    if (type == 'rating') {
      if (direction) {
        detailsPerSize.sort((a, b) => a['ShopScore'].compareTo(b['ShopScore']));
      } else {
        detailsPerSize.sort((a, b) => b['ShopScore'].compareTo(a['ShopScore']));
      }
    }
  }

  void sortRaffleWithSortField(String type, bool direction) {
    Map raffleDetailTemp = raffleDetail;

    for (int i = 0; i < raffleDetailTemp["ShopLocation"].length - 1; i++) {
      for (int j = (i + 1); j < raffleDetailTemp["ShopLocation"].length; j++) {
        bool isSwap = false;
        if (type == 'sortRaffleShops') {
          if (direction) {
            if (raffleDetailTemp["ShopLogo"][i]
                    .toString()
                    .compareTo(raffleDetailTemp["ShopLogo"][j].toString()) >
                0) {
              isSwap = true;
            }
          } else {
            if (raffleDetailTemp["ShopLogo"][i]
                    .toString()
                    .compareTo(raffleDetailTemp["ShopLogo"][j].toString()) <
                0) {
              isSwap = true;
            }
          }
        }
        if (type == 'sortRaffleDate') {
          if (direction) {
            if (raffleDetailTemp["ShopCloseTime"][i].toString().compareTo(
                      raffleDetailTemp["ShopCloseTime"][j].toString(),
                    ) >
                0) {
              isSwap = true;
            }
          } else {
            if (raffleDetailTemp["ShopCloseTime"][i].toString().compareTo(
                      raffleDetailTemp["ShopCloseTime"][j].toString(),
                    ) <
                0) {
              isSwap = true;
            }
          }
        }
        if (type == 'sortRaffleLocation') {
          if (direction) {
            if (raffleDetailTemp["ShopLocationLogo"][i].toString().compareTo(
                      raffleDetailTemp["ShopLocationLogo"][j].toString(),
                    ) >
                0) {
              isSwap = true;
            }
          } else {
            if (raffleDetailTemp["ShopLocationLogo"][i].toString().compareTo(
                      raffleDetailTemp["ShopLocationLogo"][j].toString(),
                    ) <
                0) {
              isSwap = true;
            }
          }
        }
        if (type == 'sortRaffleShipping') {
          if (direction) {
            if (raffleDetailTemp["ShopShipping"][i]
                    .toString()
                    .compareTo(raffleDetailTemp["ShopShipping"][j].toString()) >
                0) {
              isSwap = true;
            }
          } else {
            if (raffleDetailTemp["ShopShipping"][i]
                    .toString()
                    .compareTo(raffleDetailTemp["ShopShipping"][j].toString()) <
                0) {
              isSwap = true;
            }
          }
        }
        if (type == 'sortRaffleMark') {
          if (direction) {
            if ((!checkShopLinkMarkedOrNot(
                  raffleDetailTemp["ProductSKU"],
                  raffleDetailTemp['ShopRaffeLink'][i],
                )) &&
                (checkShopLinkMarkedOrNot(
                  raffleDetailTemp["ProductSKU"],
                  raffleDetailTemp['ShopRaffeLink'][j],
                ))) {
              isSwap = true;
            }
          } else {
            if ((checkShopLinkMarkedOrNot(
                  raffleDetailTemp["ProductSKU"],
                  raffleDetailTemp['ShopRaffeLink'][i],
                )) &&
                (!checkShopLinkMarkedOrNot(
                  raffleDetailTemp["ProductSKU"],
                  raffleDetailTemp['ShopRaffeLink'][j],
                ))) {
              isSwap = true;
            }
          }
        }

        if (isSwap) {
          var shopLocationTemp = raffleDetailTemp["ShopLocation"][i];
          raffleDetailTemp["ShopLocation"][i] =
              raffleDetailTemp["ShopLocation"][j];
          raffleDetailTemp["ShopLocation"][j] = shopLocationTemp;
          var shopLogoTemp = raffleDetailTemp["ShopLogo"][i];
          raffleDetailTemp["ShopLogo"][i] = raffleDetailTemp["ShopLogo"][j];
          raffleDetailTemp["ShopLogo"][j] = shopLogoTemp;
          var shopShippingTemp = raffleDetailTemp["ShopShipping"][i];
          raffleDetailTemp["ShopShipping"][i] =
              raffleDetailTemp["ShopShipping"][j];
          raffleDetailTemp["ShopShipping"][j] = shopShippingTemp;
          var shopRaffleMethodTemp = raffleDetailTemp["ShopRaffleMethod"][i];
          raffleDetailTemp["ShopRaffleMethod"][i] =
              raffleDetailTemp["ShopRaffleMethod"][j];
          raffleDetailTemp["ShopRaffleMethod"][j] = shopRaffleMethodTemp;
          var shopRaffleAccountTemp = raffleDetailTemp["ShopRaffleAccount"][i];
          raffleDetailTemp["ShopRaffleAccount"][i] =
              raffleDetailTemp["ShopRaffleAccount"][j];
          raffleDetailTemp["ShopRaffleAccount"][j] = shopRaffleAccountTemp;
          var shopOpenTimeTemp = raffleDetailTemp["ShopOpenTime"][i];
          raffleDetailTemp["ShopOpenTime"][i] =
              raffleDetailTemp["ShopOpenTime"][j];
          raffleDetailTemp["ShopOpenTime"][j] = shopOpenTimeTemp;
          var shopCloseTimeTemp = raffleDetailTemp["ShopCloseTime"][i];
          raffleDetailTemp["ShopCloseTime"][i] =
              raffleDetailTemp["ShopCloseTime"][j];
          raffleDetailTemp["ShopCloseTime"][j] = shopCloseTimeTemp;
          var shopRaffeLinkTemp = raffleDetailTemp["ShopRaffeLink"][i];
          raffleDetailTemp["ShopRaffeLink"][i] =
              raffleDetailTemp["ShopRaffeLink"][j];
          raffleDetailTemp["ShopRaffeLink"][j] = shopRaffeLinkTemp;
          // var regionLogoTemp = raffleDetailTemp["RegionLogo"][i];
          // raffleDetailTemp["RegionLogo"][i] = raffleDetailTemp["RegionLogo"][j];
          // raffleDetailTemp["RegionLogo"][j] = regionLogoTemp;
          var shopLocationLogoTemp = raffleDetailTemp["ShopLocationLogo"][i];
          raffleDetailTemp["ShopLocationLogo"][i] =
              raffleDetailTemp["ShopLocationLogo"][j];
          raffleDetailTemp["ShopLocationLogo"][j] = shopLocationLogoTemp;
        }
      }
    }
    setState(() {
      raffleDetail = raffleDetailTemp;
    });
  }

  void sortRetailWithSortField(String type, bool direction) {
    Map retailDetailTemp = retailDetail;

    for (int i = 0; i < retailDetailTemp["Shops"].length - 1; i++) {
      for (int j = (i + 1); j < retailDetailTemp["Shops"].length; j++) {
        bool isSwap = false;
        if (type == 'sortRetailShops') {
          if (direction) {
            if (retailDetailTemp["Shops"][i]["ShopLogo"].toString().compareTo(
                      retailDetailTemp["Shops"][j]["ShopLogo"].toString(),
                    ) >
                0) {
              isSwap = true;
            }
          } else {
            if (retailDetailTemp["Shops"][i]["ShopLogo"].toString().compareTo(
                      retailDetailTemp["Shops"][j]["ShopLogo"].toString(),
                    ) <
                0) {
              isSwap = true;
            }
          }
        }
        if (type == 'sortRetailPrice') {
          if (direction) {
            if (retailDetailTemp["Shops"][i]["_ShopPrice"].toString().compareTo(
                      retailDetailTemp["Shops"][j]["_ShopPrice"].toString(),
                    ) >
                0) {
              isSwap = true;
            }
          } else {
            if (retailDetailTemp["Shops"][i]["_ShopPrice"].toString().compareTo(
                      retailDetailTemp["Shops"][j]["_ShopPrice"].toString(),
                    ) <
                0) {
              isSwap = true;
            }
          }
        }

        if (isSwap) {
          var temp = retailDetailTemp["Shops"][i];
          retailDetailTemp["Shops"][i] = retailDetailTemp["Shops"][j];
          retailDetailTemp["Shops"][j] = temp;
        }
      }
    }
    setState(() {
      retailDetail = retailDetailTemp;
    });
  }

  Future<void> addProductToWishList() async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    String defaultSize = prefs.getString('preferredSize') ?? '';
    if (defaultSize.isNotEmpty) {
      defaultSize = defaultSize.split("/")[0];
    }
    var price;
    if (calendarProductSelectedSize != "") {
      for (var element in resellDetail['ProductSizeBest']) {
        if (element['Size'] == calendarProductSelectedSize) {
          price = element['Product']['Price'];
        }
      }
    } else {
      price = raffleDetail['RetailPrice'];
    }
    String productChangeArrow = "";

    if (calendarProductDetail['ResellValuePourcent'] != null) {
      productChangeArrow =
          isNumber(calendarProductDetail['ResellValuePourcent'].toString()) &&
                  int.parse(calendarProductDetail['ResellValuePourcent']
                          .toString()
                          .replaceAll('%', '')) >=
                      0
              ? 'green'
              : 'red';
    }
    DateFormat format = DateFormat('yyyyMMddHHmmss');
    Map wishProduct = {
      'productSku': resellDetail['ProductSKU'],
      'productImage': raffleDetail['ProductImage'],
      'productName': resellDetail['ProductName'],
      'size': calendarProductSelectedSize != ""
          ? 'US $calendarProductSelectedSize'
          : defaultSize,
      'price': price,
      'productChangeArrow': productChangeArrow,
      'addTime': format.format(DateTime.now()),
    };
    wishlist.add(jsonEncode(wishProduct));
    Map userData = {
      'email': prefs.getString('email') ?? '',
      'wishlist': wishlist,
    };

    String result =
        await postRequest('https://api.sneaks4sure.com/user', userData);
    if (!result.contains('ERROR')) {
      prefs.setStringList('wishlist', wishlist);

      // ignore: use_build_context_synchronously
      Navigator.of(context).pushNamed('/Wishlist');
    }
  }

  Future<void> removeProductFromWishList() async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    if (wishlist.isNotEmpty) {
      for (var el in wishlist) {
        if (el.contains(calendarProductDetail['ProductSKU'])) {
          wishlist.remove(el);
          break;
        }
      }
      Map userData = {
        'email': prefs.getString('email') ?? '',
        'wishlist': wishlist,
      };

      String result =
          await postRequest('https://api.sneaks4sure.com/user', userData);
      if (!result.contains('ERROR')) {
        prefs.setStringList('wishlist', wishlist);
      }
    }
  }

  void resetSort() {
    setState(() {
      sortPrice = false;
      sortShop = false;
      sortRating = false;

      sortRetailShops = false;
      sortRetailPrice = false;

      sortRaffleShops = false;
      sortRaffleDate = false;
      sortRaffleLocation = false;
      sortRaffleShipping = false;
      sortRaffleMark = false;
    });
  }

  changeMarkFlag(String productSKU, String shopLink) async {
    try {
      if (checkShopLinkMarkedOrNot(productSKU, shopLink)) {
        for (var el in shopMarks) {
          if (el.contains(productSKU) && el.contains(shopLink)) {
            shopMarks.remove(el);
            break;
          }
        }
      } else {
        Map shopMark = {"productSKU": productSKU, "shopLink": shopLink};
        shopMarks.add(jsonEncode(shopMark));
      }
      setState(() {
        shopMarks = shopMarks;
      });
      Map userData = {
        'email': prefs.getString('email') ?? '',
        'shopMarks': shopMarks,
      };

      await postRequest('https://api.sneaks4sure.com/user', userData);
      prefs.setStringList('shopMarks', shopMarks);
      // ignore: empty_catches
    } catch (e) {}
  }

  getMarkWidget(String closeTime, String shopLink, String productSKU) {
    if (!getShopCloseFlag(closeTime)) {
      return const Icon(
        FontAwesomeIcons.lock,
        color: Color.fromARGB(255, 119, 131, 143),
        size: 25,
      );
    } else {
      if (checkShopLinkMarkedOrNot(productSKU, shopLink)) {
        return const Icon(
          FontAwesomeIcons.squareCheck,
          color: Color.fromARGB(255, 49, 48, 54),
          size: 25,
        );
      } else {
        return const Icon(
          FontAwesomeIcons.square,
          color: Color.fromARGB(255, 49, 48, 54),
          size: 25,
        );
      }
    }
  }

  checkShopLinkMarkedOrNot(String productSKU, String shopLink) {
    if (shopMarks.isNotEmpty) {
      for (var el in shopMarks) {
        if (el.contains(productSKU) && el.contains(shopLink)) {
          return true;
        }
      }
    }

    return false;
  }

  getShopCloseFlag(String text) {
    try {
      return text != '-' && DateTime.parse(text).isAfter(DateTime.now());
    } catch (e) {
      return true;
    }
  }

  onClick360ViewButton() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }
    if (imageList360.length != raffleDetail['ProductImage360'].length) {
      await get360Images();
    }
    if (mounted) {
      setState(() {
        isLoading = false;
        is360 = true;
      });
    }
    if (mounted) {
      setState(() {
        isLoading = false;
        is360 = true;
      });
    }
  }

  getCalendarDetailPage() {
    var orientationStr = MediaQuery.of(context).orientation.toString();
    if (deviceOrientation != '' && deviceOrientation != orientationStr) {
      deviceOrientation = orientationStr;
      deviceOrientationChange = true;
    } else {
      deviceOrientation = orientationStr;
      deviceOrientationChange = false;
    }
    if (deviceOrientationChange && is360) {
      resize360ImageList();
    }

    if (isRaffles) {
      animateToPage(0);
    } else if (isRetail) {
      animateToPage(1);
    } else {
      animateToPage(2);
    }
    final List<Widget> detailWidgets = [
      returnCalendarItemRafflesContainer(raffleDetail),
      returnCalendarItemRetailContainer(retailDetail),
      returnCalendarItemResellContainer(resellDetail),
    ];

    returnDetailMainSection(index) {
      return Column(
        children: [
          showProductDetailCard
              ? Container(
                  height: 150,
                  padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Material(
                            elevation: 10,
                            // padding: EdgeInsets.all(4),
                            borderRadius:
                                const BorderRadius.all(Radius.circular(20)),
                            child: Container(
                              width: 130,
                              height: 130,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  getCalendarIcon(
                                      raffleDetail['ReleaseDate'] ?? "",
                                      Colors.black,
                                      "black"),
                                  Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(5, 10, 5, 0),
                                    child: InkWell(
                                      onTap: () async {
                                        String productName =
                                            raffleDetail['ProductName']
                                                .toString();
                                        await Clipboard.setData(
                                            ClipboardData(text: productName));
                                        if (mounted) {
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(launchSnackbar(
                                                  'Product name copied to clipboard',
                                                  Icons.check,
                                                  AppColors.white,
                                                  AppColors.red,
                                                  Colors.white));
                                        }
                                      },
                                      child: Text(
                                        raffleDetail['ProductName'],
                                        textAlign: TextAlign.center,
                                        maxLines: 3,
                                        overflow: TextOverflow.ellipsis,
                                        style: robotoStyle(FontWeight.w800,
                                            Colors.black, 16, null),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const Padding(padding: EdgeInsets.only(left: 15)),
                          Container(
                            width: (MediaQuery.of(context).size.width - 215),
                            height: 120,
                            child: is360Able
                                ? GestureDetector(
                                    child: Stack(
                                      children: [
                                        Center(
                                          child: ClipRRect(
                                            child: SizedBox(
                                              width: 300,
                                              height: 200,
                                              child: raffleDetail[
                                                          'ProductImage'] !=
                                                      ''
                                                  ? CachedNetworkImage(
                                                      imageUrl: raffleDetail[
                                                          'ProductImage'],
                                                      fit: BoxFit.fitWidth,
                                                      errorWidget: (context,
                                                          error, stackTrace) {
                                                        return Image.asset(
                                                          'assets/etc/NoImage-trans.png',
                                                          fit: BoxFit.contain,
                                                        );
                                                      },
                                                    )
                                                  : Image.asset(
                                                      'assets/etc/NoImage-trans.png',
                                                      fit: BoxFit.fitWidth,
                                                    ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 0),
                                          child: Align(
                                            alignment:
                                                const Alignment(0.8, -0.8),
                                            child: Image.asset(
                                              'assets/icons/360view.gif',
                                              width: 50,
                                              height: 50,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    onTap: () {
                                      onClick360ViewButton();
                                    },
                                  )
                                : Center(
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20.0),
                                      child: SizedBox(
                                        width: 300,
                                        child:
                                            raffleDetail['ProductImage'] != ''
                                                ? CachedNetworkImage(
                                                    imageUrl: raffleDetail[
                                                        'ProductImage'],
                                                    fit: BoxFit.contain,
                                                    errorWidget: (context,
                                                        error, stackTrace) {
                                                      return Image.asset(
                                                        'assets/etc/NoImage-trans.png',
                                                        fit: BoxFit.fitWidth,
                                                      );
                                                    },
                                                  )
                                                : Image.asset(
                                                    'assets/etc/NoImage-trans.png',
                                                    fit: BoxFit.cover,
                                                  ),
                                      ),
                                    ),
                                  ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Container(
                        decoration: const BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: Color.fromARGB(255, 109, 108, 108),
                              width: 2,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                )
              : Container(),
          Expanded(
            child: SingleChildScrollView(
              controller: scrollControllers[index],
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  // mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.fromLTRB(40, 10, 40, 10),
                      child: InkWell(
                        onTap: () async {
                          String productName =
                              raffleDetail['ProductName'].toString();
                          await Clipboard.setData(
                              ClipboardData(text: productName));
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                                launchSnackbar(
                                    'Product name copied to clipboard',
                                    Icons.check,
                                    AppColors.white,
                                    AppColors.red,
                                    Colors.white));
                          }
                        },
                        child: Text(
                          raffleDetail['ProductName'] ?? "",
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: robotoStyle(FontWeight.w900,
                              const Color.fromARGB(255, 49, 48, 54), 32, null),
                        ),
                      ),
                    ),
                    is360Able
                        ? GestureDetector(
                            child: Stack(
                              children: [
                                Center(
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20.0),
                                    child: SizedBox(
                                      width: 330,
                                      height: 210,
                                      child: raffleDetail['ProductImage'] != ''
                                          ? CachedNetworkImage(
                                              imageUrl:
                                                  raffleDetail['ProductImage'],
                                              fit: BoxFit.contain,
                                              errorWidget:
                                                  (context, error, stackTrace) {
                                                return Image.asset(
                                                  'assets/etc/NoImage-trans.png',
                                                  fit: BoxFit.contain,
                                                );
                                              },
                                            )
                                          : Image.asset(
                                              'assets/etc/NoImage-trans.png',
                                              fit: BoxFit.fitWidth,
                                            ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Align(
                                    alignment: const Alignment(0.6, 0),
                                    child: Image.asset(
                                      'assets/icons/360view.gif',
                                      width: 50,
                                      height: 50,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            onTap: () {
                              onClick360ViewButton();
                            },
                          )
                        : Center(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(20.0),
                              child: SizedBox(
                                width: 300,
                                child: raffleDetail['ProductImage'] != ''
                                    ? CachedNetworkImage(
                                        imageUrl:
                                            raffleDetail['ProductImage'] ?? "",
                                        fit: BoxFit.contain,
                                        errorWidget:
                                            (context, error, stackTrace) {
                                          return Image.asset(
                                            'assets/etc/NoImage-trans.png',
                                            fit: BoxFit.fitWidth,
                                          );
                                        },
                                      )
                                    : Image.asset(
                                        'assets/etc/NoImage-trans.png',
                                        fit: BoxFit.cover,
                                      ),
                              ),
                            ),
                          ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height - 360,
                      child: Column(
                        children: [
                          Expanded(
                            child: Center(
                              child: detailWidgets[index],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      );
    }

    EdgeInsets devicePadding = MediaQuery.of(context).padding;

    return Stack(
      children: [
        is360
            ? Container(
                padding: EdgeInsets.only(
                  top: devicePadding.top,
                  bottom: devicePadding.bottom,
                ),
                alignment: Alignment.center,
                child: PinchZoom(
                  // resetDuration: const Duration(milliseconds: 50),
                  maxScale: 5,
                  onZoomStart: () {},
                  onZoomEnd: () {},
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      imageList360.isNotEmpty
                          ? ImageView360(
                              key: UniqueKey(),
                              imageList: imageList360,
                              swipeSensitivity: 2,
                              rotationDirection:
                                  RotationDirection.anticlockwise,
                              // frameChangeDuration: const Duration(milliseconds: 0),
                            )
                          : Center(
                              child: Text('Sorry, there is no image.'),
                            ),
                    ],
                  ),
                ),
              )
            : Container(
                child: !isPriceChart
                    ? Column(
                        children: [
                          SizedBox(
                            height: devicePadding.top,
                          ),
                          Stack(
                            alignment: Alignment.center,
                            children: [
                              Align(
                                alignment: const Alignment(-0.9, 0),
                                child: IconButton(
                                  icon: const Icon(
                                      Icons.arrow_circle_left_outlined),
                                  color: const Color(0xFF313036),
                                  iconSize: 40,
                                  onPressed: () {
                                    _onBackPressed();
                                  },
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: SizedBox(
                                  height: 25,
                                  child: Image.asset(
                                    'assets/etc/splash-cropped.png',
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: const Alignment(0.85, 0),
                                child: Column(
                                  children: [
                                    Text(
                                      "Resell Value",
                                      style: w700Gray10,
                                    ),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          ">${calendarProductDetail['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(calendarProductDetail['ResellValueProfit'])}",
                                          style: robotoStyle(
                                              FontWeight.w700,
                                              returnColorCalendarCote(
                                                  calendarProductDetail[
                                                          'ResellValuePourcent']
                                                      .toString()
                                                      .replaceAll('%', '')),
                                              14,
                                              null),
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          "${(returnSignCalendarCote(calendarProductDetail['ResellValuePourcent'].toString().replaceAll('%', '')) + calendarProductDetail['ResellValuePourcent'].toString() + (calendarProductDetail['ResellValuePourcent'].toString().contains('%') ? "" : "%"))}",
                                          style: robotoStyle(
                                              FontWeight.w700,
                                              returnColorCalendarCote(
                                                  calendarProductDetail[
                                                          'ResellValuePourcent']
                                                      .toString()
                                                      .replaceAll('%', '')),
                                              14,
                                              null),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                // child: InkWell(
                                //   child: Container(
                                //     width: 71,
                                //     height: 26,
                                //     decoration: BoxDecoration(
                                //       color: const Color(0xFF313036),
                                //       borderRadius: BorderRadius.circular(10),
                                //     ),
                                //     child: Center(
                                //       child: Text(
                                //         "Size Guide",
                                //         style: w500White12,
                                //       ),
                                //     ),
                                //   ),
                                //   onTap: () {
                                //     Navigator.pushNamed(context, '/SizeGuide');
                                //   },
                                // ),
                              ),
                            ],
                          ),
                          //page navigator header
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                buildFloatingButtonProductCalendar(
                                    context,
                                    AppLocalizations.of(context)
                                        .calDetail_raffles,
                                    isRaffles,
                                    isRaffles ? Colors.white : Colors.grey, () {
                                  tapButtonClicked = true;
                                  setState(() {
                                    isRaffles = true;
                                    isRetail = false;
                                    isResell = false;
                                  });
                                }),
                                SizedBox(
                                  width: 10,
                                ),
                                buildFloatingButtonProductCalendar(
                                    context,
                                    AppLocalizations.of(context)
                                        .calDetail_retail,
                                    isRetail,
                                    isRetail ? Colors.white : Colors.grey, () {
                                  tapButtonClicked = true;
                                  setState(() {
                                    isRaffles = false;
                                    isRetail = true;
                                    isResell = false;
                                  });
                                }),
                                SizedBox(
                                  width: 10,
                                ),
                                buildFloatingButtonProductCalendar(
                                    context,
                                    AppLocalizations.of(context)
                                        .calDetail_resell,
                                    isResell,
                                    isResell ? Colors.white : Colors.grey, () {
                                  tapButtonClicked = true;
                                  setState(() {
                                    isRaffles = false;
                                    isRetail = false;
                                    isResell = true;
                                  });
                                }),
                              ],
                            ),
                          ),
                          Expanded(
                            child: PageView.builder(
                              controller: itemDetailController,
                              itemCount: detailWidgets.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  child: Center(
                                      child: returnDetailMainSection(index)),
                                );
                              },
                              onPageChanged: (value) {
                                for (var i = 0; i < 3; i++) {
                                  scrollControllers[i].animateTo(
                                    0,
                                    duration: const Duration(milliseconds: 50),
                                    curve: Curves.easeInOut,
                                  );
                                }
                                setState(() {
                                  if (!tapButtonClicked) {
                                    isRaffles = value == 0;
                                    isRetail = value == 1;
                                    isResell = value == 2;
                                  }
                                  if (mounted) {
                                    showProductDetailCard = false;
                                  }
                                });
                              },
                            ),
                          )
                          //page navigator
                        ],
                      )
                    : Container(
                        padding: EdgeInsets.only(
                          top: devicePadding.top,
                          bottom: devicePadding.bottom,
                        ),
                        alignment: Alignment.center,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: IconButton(
                                    icon: const Icon(
                                        Icons.arrow_circle_left_outlined),
                                    color: const Color(0xFF313036),
                                    iconSize: 40,
                                    onPressed: () {
                                      setState(() {
                                        isPriceChart = false;
                                        showProductDetailCard = false;
                                      });
                                    },
                                  ),
                                )
                              ],
                            ),
                            Expanded(
                              child: Container(
                                child: Column(
                                  children: [
                                    if (cUSSizes.isNotEmpty)
                                      Center(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              35, 0, 35, 0),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                              color: const Color(0xffF6F6F6),
                                            ),
                                            padding: const EdgeInsets.only(
                                              left: 15,
                                              right: 15,
                                            ),
                                            child: HorizontalPicker(
                                              height: 70,
                                              prefix: "US ",
                                              subLeftPrefix: "EU",
                                              subRightPrefix: "UK",
                                              showCursor: false,
                                              initialPosition:
                                                  InitialPosition.user,
                                              backgroundColor:
                                                  Colors.transparent,
                                              activeItemTextColor:
                                                  const Color.fromARGB(
                                                      255, 49, 48, 54),
                                              passiveItemsTextColor:
                                                  Colors.grey.withOpacity(0.5),
                                              mainData: cUSSizes,
                                              subDataRight: cUKSizes,
                                              subDataLeft: cEUSizes,
                                              sizePrice: cPricesPerSize,
                                              sizeType:
                                                  resellDetail['sizeSlider'],
                                              onChanged: (value) {
                                                calendarProductSelectedSize =
                                                    value;
                                                detailsPerSize =
                                                    getProductsPerSize(
                                                        value,
                                                        resellDetail[
                                                            'ProductSize']);
                                                resetSort();
                                                setState(() {
                                                  preferredSize = value;
                                                });
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    InkWell(
                                      onTap: (() {
                                        // setState(() {
                                        //   isPriceChart = true;
                                        // });
                                      }),
                                      child: Container(
                                        height: 55,
                                        width:
                                            MediaQuery.of(context).size.width -
                                                120,
                                        padding: const EdgeInsets.fromLTRB(
                                            15, 7, 15, 7),
                                        decoration: BoxDecoration(
                                          color: const Color.fromARGB(
                                              255, 246, 246, 246),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            Container(
                                              constraints: const BoxConstraints(
                                                  maxWidth: 80),
                                              child: Text(
                                                "Market Analysis",
                                                textAlign: TextAlign.center,
                                                maxLines: 2,
                                                style: robotoStyle(
                                                    FontWeight.w800,
                                                    Colors.black54,
                                                    16,
                                                    null),
                                              ),
                                            ),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: calendarProductDetail[
                                                              'ResellValuePourcent'] !=
                                                          null &&
                                                      calendarProductDetail[
                                                                  'ResellValuePourcent']
                                                              .toString() !=
                                                          'TBC' &&
                                                      calendarProductDetail[
                                                                  'ResellValuePourcent']
                                                              .toString() !=
                                                          ""
                                                  ? [
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Column(
                                                            children: [
                                                              Text(
                                                                "Margin",
                                                                style: robotoStyle(
                                                                    FontWeight
                                                                        .w400,
                                                                    returnColorCalendarCote(calendarProductDetail[
                                                                            'ResellValuePourcent']
                                                                        .toString()
                                                                        .replaceAll(
                                                                            '%',
                                                                            '')),
                                                                    16,
                                                                    null),
                                                              ),
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  Text(
                                                                    (returnSignCalendarCote(calendarProductDetail['ResellValuePourcent'].toString().replaceAll(
                                                                            '%',
                                                                            '')) +
                                                                        calendarProductDetail['ResellValuePourcent']
                                                                            .toString() +
                                                                        (calendarProductDetail['ResellValuePourcent'].toString().contains('%')
                                                                            ? ""
                                                                            : "%")),
                                                                    style: robotoStyle(
                                                                        FontWeight
                                                                            .w800,
                                                                        returnColorCalendarCote(calendarProductDetail['ResellValuePourcent'].toString().replaceAll(
                                                                            '%',
                                                                            '')),
                                                                        16,
                                                                        null),
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                          ),
                                                          Icon(
                                                            isNumber(calendarProductDetail[
                                                                            'ResellValuePourcent']
                                                                        .toString()) &&
                                                                    int.parse(calendarProductDetail['ResellValuePourcent'].toString().replaceAll(
                                                                            '%',
                                                                            '')) >=
                                                                        0
                                                                ? Icons
                                                                    .trending_up_rounded
                                                                : Icons
                                                                    .trending_down_rounded,
                                                            size: 18,
                                                            color: returnColorCalendarCote(
                                                                calendarProductDetail[
                                                                        'ResellValuePourcent']
                                                                    .toString()
                                                                    .replaceAll(
                                                                        '%',
                                                                        '')),
                                                          ),
                                                        ],
                                                      ),
                                                    ]
                                                  : [
                                                      const Text(
                                                        'TBC',
                                                        style: TextStyle(
                                                          // color: Color(0xff313036),
                                                          color: Color.fromARGB(
                                                              255,
                                                              221,
                                                              220,
                                                              222),
                                                          fontSize: 24,
                                                        ),
                                                      ),
                                                    ],
                                            ),
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: calendarProductDetail[
                                                              'ResellValuePourcent'] !=
                                                          null &&
                                                      calendarProductDetail[
                                                                  'ResellValuePourcent']
                                                              .toString() !=
                                                          'TBC' &&
                                                      calendarProductDetail[
                                                                  'ResellValuePourcent']
                                                              .toString() !=
                                                          ""
                                                  ? [
                                                      Text(
                                                        AppLocalizations.of(
                                                                context)
                                                            .search_profit,
                                                        style: robotoStyle(
                                                            FontWeight.w400,
                                                            returnColorCalendarCote(
                                                                calendarProductDetail[
                                                                        'ResellValuePourcent']
                                                                    .toString()
                                                                    .replaceAll(
                                                                        '%',
                                                                        '')),
                                                            16,
                                                            null),
                                                      ),
                                                      Text(
                                                        "> ${calendarProductDetail['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(calendarProductDetail['ResellValueProfit'])}",
                                                        style: robotoStyle(
                                                            FontWeight.w800,
                                                            returnColorCalendarCote(
                                                                calendarProductDetail[
                                                                        'ResellValuePourcent']
                                                                    .toString()
                                                                    .replaceAll(
                                                                        '%',
                                                                        '')),
                                                            16,
                                                            null),
                                                      ),
                                                    ]
                                                  : [
                                                      const Text(
                                                        'TBC',
                                                        style: TextStyle(
                                                          // color: Color(0xff313036),
                                                          color: Color.fromARGB(
                                                              255,
                                                              221,
                                                              220,
                                                              222),
                                                          fontSize: 24,
                                                        ),
                                                      ),
                                                    ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    renderPriceHistoryChart(
                                        MediaQuery.of(context).size.width,
                                        210,
                                        priceHistory,
                                        preferredSize,
                                        context),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
        if (isLoading)
          Container(
            padding: const EdgeInsets.only(
              left: 100,
              right: 100,
            ),
            alignment: Alignment.center,
            color: AppColors.white,
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Image.asset(
              'assets/etc/loading.gif',
              fit: BoxFit.fitWidth,
            ),
          ),
      ],
    );
  }

  Future<bool> _onBackPressed() {
    Navigator.pop(context);

    return Future.value(false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: getCalendarDetailPage(),
      floatingActionButtonLocation:
          is360 ? FloatingActionButtonLocation.endTop : null,
      floatingActionButton: is360
          ? Padding(
              padding: const EdgeInsets.only(top: 20),
              child: IconButton(
                onPressed: () {
                  setState(() {
                    is360 = false;
                    showProductDetailCard = false;
                  });
                },
                icon: const Icon(Icons.close_rounded),
                iconSize: 35,
                color: const Color.fromARGB(255, 255, 35, 35),
              ),
            )
          : null,
      bottomNavigationBar: SizedBox(
        height: 70,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            InkWell(
              onTap: () async {
                String deepLink = await createDynamicLink(
                  "/CalendarDetail?sku=${calendarProductDetail['ProductSKU']}",
                );
                s4sSocialShare(deepLink);
              },
              child: Container(
                width: 65,
                height: 50,
                padding: const EdgeInsets.fromLTRB(10, 3, 10, 3),
                decoration: BoxDecoration(
                  color: const Color(0xFFF6F6F6),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Image.asset(
                  "assets/etc/share-gray.gif",
                  width: 50,
                  height: 50,
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            likeAndDislikeWidget(
              raffleDetail["ProductSKU"] ?? "",
              calProductLike,
              calProductDislike,
              increaseOrDecreaseLike,
            ),
            const SizedBox(
              width: 10,
            ),
            InkWell(
              onTap: () {
                if (!isCalendarFav) {
                  setState(() {
                    isCalendarFav = true;
                  });
                  addProductToWishList();
                } else {
                  setState(() {
                    isCalendarFav = false;
                  });
                  removeProductFromWishList();
                }
              },
              child: Container(
                width: 65,
                height: 50,
                padding: const EdgeInsets.fromLTRB(10, 3, 10, 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: isCalendarFav
                      ? const Color(0xFFFF2323)
                      : const Color(0xFFF6F6F6),
                ),
                child: Image.asset(
                  isCalendarFav
                      ? "assets/etc/heart-full.gif"
                      : "assets/etc/heart.gif",
                  width: 45,
                  height: 45,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
