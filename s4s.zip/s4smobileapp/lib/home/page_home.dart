import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/restock/restock_widget.dart';
import 'package:s4s_mobileapp/tools/bottom_navbar.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:s4s_mobileapp/tools/bottom_search_button.dart';
import 'package:s4s_mobileapp/trend/trend_widget.dart';
import 'package:upgrader/upgrader.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

bool dataLoaded = false;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  bool isNotificatinoDialogShowing = false;
  late AnimationController _resizableController;
  Timer? timer;
  bool _dataLoaded = dataLoaded;

  late VideoPlayerController _splashVideoController;
  bool _visible = false;
  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  setSplashVideoSetting() {
    VideoPlayerOptions videoPlayerOptions =
        VideoPlayerOptions(mixWithOthers: true);
    _splashVideoController = VideoPlayerController.asset(
      "assets/S4S_MobileApp_Launch.mp4",
      videoPlayerOptions: videoPlayerOptions,
    );
    _splashVideoController.setLooping(true);
    _splashVideoController.initialize().then((_) {
      setState(() {
        _splashVideoController.play();
        _visible = true;
      });
    });
  }

  handleMessage(RemoteMessage message) {
    String title = message.toMap()['notification']['title'];
    String content = message.toMap()['notification']['body'];
    String linkUrl = message.toMap()['data']['linkUrl'];
    String productSku = message.toMap()['data']['productSku'];
    if (linkUrl.isNotEmpty) {
      urlLauncher(linkUrl);
    }
    notificationProductSku = productSku;
    Navigator.of(context).pushNamed(
      '/Restock',
    );
  }

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          if (kDebugMode) {
            print('Data connection is available.');
          }
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          if (kDebugMode) {
            print('You are disconnected from the internet.');
          }
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    initDynamicLinks(context);
    createDynamicLink("/Home");
    getCurrencyRate();

    checkNetworkStatus();
    // checkIsJailBroken(context);

    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      if (message != null) {
        handleMessage(message);
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      handleMessage(message);
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      String title = message.toMap()['notification']['title'];
      String content = message.toMap()['notification']['body'];
      String linkUrl = message.toMap()['data']['linkUrl'];
      String productSku = message.toMap()['data']['productSku'];
      bool notifFlag = prefs.getBool("notifFlag") ?? false;
      if (!isNotificatinoDialogShowing && notifFlag) {
        isNotificatinoDialogShowing = true;
        if (mounted) {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text(title),
                content: Text(content),
                actions: [
                  TextButton(
                    onPressed: () {
                      isNotificatinoDialogShowing = false;
                      Navigator.of(context).pop();
                      if (linkUrl.isNotEmpty) {
                        urlLauncher(linkUrl);
                      } else {
                        notificationProductSku = productSku;
                        Navigator.of(context).pushNamed(
                          '/Restock',
                        );
                      }
                    },
                    child: const Text('Go to link'),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      isNotificatinoDialogShowing = false;
                    },
                    child: const Text('Cancel'),
                  ),
                ],
              );
            },
          );
        }
      }
    });

    setSplashVideoSetting();

    // ignore: unnecessary_new
    _resizableController = new AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1000,
      ),
    );
    _resizableController.addStatusListener((animationStatus) {
      switch (animationStatus) {
        case AnimationStatus.completed:
          _resizableController.reverse();
          break;
        case AnimationStatus.dismissed:
          _resizableController.forward();
          break;
        case AnimationStatus.forward:
          break;
        case AnimationStatus.reverse:
          break;
      }
    });
    _resizableController.forward();

    if (!_dataLoaded) {
      getMainData();
    }

    timer = Timer.periodic(const Duration(hours: 4), (Timer timer) {
      getCurrencyRate();
    });

    super.initState();
  }

  getMainData() async {
    heats = await getListHeats();
    recently = await getListRecently();
    news = await getListNews();
    tops = await getListTops();
    setState(() {
      _dataLoaded = true;
      _splashVideoController.dispose();
    });
    dataLoaded = true;

    upcoming = await getUpcomings();
    past = await getPasts();
    restocks = await getRestock();
    instores = await getInstore();
  }

  getCurrencyRate() async {
    var result = await getData(
      'https://api.sneaks4sure.com/currency',
    );
    Map responseData = jsonDecode(result)['data'];
    currencyRate = responseData[responseData.keys.toList()[0]];
  }

  _getVideoBackground() {
    return AnimatedOpacity(
      opacity: _visible ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 1000),
      child: VideoPlayer(_splashVideoController),
    );
  }

  _getLogo() {
    return AnimatedOpacity(
      opacity: _visible ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 1000),
      child: Align(
        alignment: const Alignment(0, 0.8),
        child: Image.asset(
          'assets/etc/splash-cropped.png',
          height: 50,
        ),
      ),
    );
  }

  DateTime currentBackPressTime = DateTime.now();
  Future<bool> _onBackPressed() {
    if (Navigator.canPop(context)) {
      Navigator.pop(context);
    }
    DateTime now = DateTime.now();
    if (now.difference(currentBackPressTime) > const Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(msg: 'Press Back Button Again to Exit');

      return Future.value(false);
    }
    exit(0);
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return WillPopScope(
      onWillPop: _onBackPressed,
      child: !_dataLoaded
          ? Scaffold(
              body: Center(
                child: Stack(
                  children: <Widget>[
                    // _getBackgroundColor(),
                    _getVideoBackground(),
                    _getLogo(),
                  ],
                ),
              ),
            )
          : Scaffold(
              extendBody: true,
              resizeToAvoidBottomInset: false,
              appBar: null,
              backgroundColor: Colors.white,
              body: UpgradeAlert(
                child: const SafeArea(
                  child: TrendWidget(),
                ),
              ),
              bottomNavigationBar: const BottomNavBar(0),
              floatingActionButton: const BottomSearchButton(false),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.miniCenterDocked,
            ),
    );
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    _resizableController.dispose();
    timer?.cancel();
    _splashVideoController.dispose();
    super.dispose();
  }
}
