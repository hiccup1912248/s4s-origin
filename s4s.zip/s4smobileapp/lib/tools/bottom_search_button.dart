import 'package:flutter/material.dart';
import 'package:s4s_mobileapp/search/search_widget.dart';

final ValueNotifier<bool> searchFilterSideDrawMenuOpen = ValueNotifier(false);
bool searchPageVisited = false;

class BottomSearchButton extends StatefulWidget {
  final bool isSearch;
  const BottomSearchButton(this.isSearch, {Key? key}) : super(key: key);

  @override
  State<BottomSearchButton> createState() => _BottomSearchButton();
}

class _BottomSearchButton extends State<BottomSearchButton>
    with TickerProviderStateMixin {
  late AnimationController _resizableController;

  @override
  void initState() {
    _resizableController = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1000,
      ),
    );
    _resizableController.addStatusListener((animationStatus) {
      switch (animationStatus) {
        case AnimationStatus.completed:
          _resizableController.reverse();
          break;
        case AnimationStatus.dismissed:
          _resizableController.forward();
          break;
        case AnimationStatus.forward:
          break;
        case AnimationStatus.reverse:
          break;
      }
    });
    _resizableController.forward();

    super.initState();
  }

  @override
  void dispose() {
    _resizableController.dispose();
    super.dispose();
  }

  getSearchButtonBackgroundColor() {
    return widget.isSearch
        ? const Color.fromARGB(255, 255, 35, 35)
        : Colors.white;
  }

  getSearchButtonForgroundColor() {
    return widget.isSearch
        ? Colors.white
        : const Color.fromARGB(255, 255, 35, 35);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: AnimatedBuilder(
        animation: _resizableController,
        builder: (context, child) {
          return ValueListenableBuilder<bool>(
            builder: (context, value, child) => !value
                ? Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color.fromARGB(255, 88, 29, 29)
                              .withOpacity(0.5),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset:
                              const Offset(0, 0), // changes position of shadow
                        ),
                      ],
                      borderRadius:
                          const BorderRadius.all(Radius.circular(300)),
                      border: Border.all(
                        color: const Color.fromARGB(255, 239, 100, 90),
                        width: _resizableController.value * 3,
                      ),
                    ),
                    child: GestureDetector(
                      child: FloatingActionButton(
                        elevation: 4.0,
                        backgroundColor: getSearchButtonBackgroundColor(),
                        onPressed: () {
                          if (mounted) {
                            autoFocus = searchPageVisited;
                            searchPageVisited = true;
                            Navigator.of(context).pushNamed(
                              '/Search',
                            );
                          }
                        },
                        child: Icon(
                          Icons.search,
                          color: getSearchButtonForgroundColor(),
                          size: 40,
                        ),
                      ),
                    ),
                  )
                : Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      boxShadow: [
                        BoxShadow(
                          color: const Color.fromARGB(255, 94, 92, 92)
                              .withOpacity(0.5),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset:
                              const Offset(0, 0), // changes position of shadow
                        ),
                      ],
                      borderRadius:
                          const BorderRadius.all(Radius.circular(300)),
                      border: Border.all(
                        color: const Color.fromARGB(180, 143, 142, 142),
                        width: _resizableController.value * 3,
                      ),
                    ),
                    child: GestureDetector(
                      child: const FloatingActionButton(
                        elevation: 4.0,
                        backgroundColor: Color.fromARGB(255, 143, 142, 142),
                        onPressed: null,
                        child: Icon(
                          Icons.search,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                    ),
                  ),
            valueListenable: searchFilterSideDrawMenuOpen,
          );
        },
      ),
    );
  }
}
