import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:twitter_login/twitter_login.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'dart:convert';

class FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  Future<void> syncUserData(String email) async {
    String jwtToken = await _auth.currentUser!.getIdToken();
    prefs.setString('jwtToken', jwtToken);
    debugPrint("S4S: user jwt token ====> $jwtToken");

    var result = await getData('https://api.sneaks4sure.com/getuser/$email');
    var userInfos = jsonDecode(result)['data']['userInfo'];
    if (userInfos.length > 0) {
      var userData = userInfos[0];
      await prefs.setString('createdDate', userData['create_date'] ?? '');
      await prefs.setString('city', userData['Shipping'][0]['city'] ?? '');
      await prefs.setString(
        'country',
        userData['Shipping'][0]['country'] ?? '',
      );
      await prefs.setString(
        'countryCode',
        userData['Shipping'][0]['country_code'] ?? '',
      );
      await prefs.setString(
        'countryFlag',
        userData['Shipping'][0]['country_flag'] ?? '',
      );
      await prefs.setString('username', userData['username'] ?? '');
      await prefs.setString(
        'preferredSize',
        userData['General']['prefered_size'] ?? '',
      );
      await prefs.setString(
        'defaultCurrency',
        userData['General']['default_currency'] ?? '',
      );
      await prefs.setString(
        'locationArea',
        userData['General']['location_area'] ?? '',
      );
      await prefs.setString('email', userData['email'] ?? '');
      await prefs.setString('firstname', userData['first_name'] ?? '');
      await prefs.setString('lastname', userData['last_name'] ?? '');
      await prefs.setString('phone', userData['phone_number'] ?? '');
      await prefs.setString(
        'shippingAddr1',
        userData['Shipping'][0]['address_line1'] ?? '',
      );
      await prefs.setString(
        'shippingAddr2',
        userData['Shipping'][0]['address_line2'] ?? '',
      );
      await prefs.setString(
        'zipcode',
        userData['Shipping'][0]['zip_code'] ?? '',
      );
      await prefs.setString('state', userData['Shipping'][0]['state'] ?? '');
      await prefs.setString('fcmtoken', userData['fcmtoken'] ?? '');
      await prefs.setBool("notifFlag", userData['notif_flag'] == true);
      await prefs.setBool("savedProfile", userData['savedProfile'] == true);
      if (userData['resellLow'] != null) {
        await prefs.setBool("resellLow", userData['resellLow'] == true);
      }
      if (userData['resellMid'] != null) {
        await prefs.setBool("resellMid", userData['resellMid'] == true);
      }

      if (userData['resellHigh'] != null) {
        await prefs.setBool("resellHigh", userData['resellHigh'] == true);
      }

      String userProfilePicture = userData["profile_picture"] ?? "";
      if (userProfilePicture.isNotEmpty) {
        await prefs.setString("photo", userProfilePicture);
      }

      if (userData['shops'] != null) {
        await prefs.setStringList(
          "shops",
          userData['shops']
              ?.map((e) {
                return e;
              })
              .toList()
              .cast<String>(),
        );
      }
      if (userData['brands'] != null) {
        await prefs.setStringList(
          "brands",
          userData['brands']
              ?.map((e) {
                return e;
              })
              .toList()
              .cast<String>(),
        );
      }
      if (userData['wishlist'] != null) {
        await prefs.setStringList(
          'wishlist',
          userData['wishlist']
              ?.map((e) {
                return e;
              })
              .toList()
              .cast<String>(),
        );
      }
      if (userData['shopMarks'] != null) {
        await prefs.setStringList(
          'shopMarks',
          userData['shopMarks']
              ?.map((e) {
                return e;
              })
              .toList()
              .cast<String>(),
        );
      }
      if (userData['sizes'] != null) {
        await prefs.setStringList(
          "sizes",
          userData['sizes']
              ?.map((e) {
                return e;
              })
              .toList()
              .cast<String>(),
        );
      }
      if (userData['regions'] != null) {
        await prefs.setStringList(
          "regions",
          userData['regions']
              ?.map((e) {
                return e;
              })
              .toList()
              .cast<String>(),
        );
      }

      var token = await FirebaseMessaging.instance.getToken();
      prefs.setString("fcmtoken", token.toString());
      //update fcmtoken whenever new login
      Map data = {
        'email': userData['email'] ?? '',
        'fcmtoken': token,
      };
      postRequest('https://api.sneaks4sure.com/user', data);
    } else {
      await prefs.setBool("savedProfile", false);
    }
  }

  Future<String> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleSignInAccount =
          await _googleSignIn.signIn();
      print('google sigin account ===> ${googleSignInAccount}');
      final GoogleSignInAuthentication googleSignInAuthentication =
          await googleSignInAccount!.authentication;
      print('google signin authentication ===> ${googleSignInAuthentication}');
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );
      print('google signin auth credential ===> ${credential}');
      UserCredential userCredit = await _auth.signInWithCredential(credential);
      print('google signin successed !! ${userCredit}');
      if (userCredit.user?.displayName != null) {
        if (userCredit.additionalUserInfo?.profile?['email'] != null &&
            userCredit.additionalUserInfo?.profile != null &&
            userCredit.additionalUserInfo != null) {
          await prefs.setString(
              'email', userCredit.additionalUserInfo?.profile?['email'] ?? '');
          await prefs.setString(
              'username', userCredit.additionalUserInfo?.username ?? '');
          await prefs.setString('firstname',
              userCredit.additionalUserInfo?.profile?['given_name'] ?? '');
          await prefs.setString('lastname',
              userCredit.additionalUserInfo?.profile?['family_name'] ?? '');
          await prefs.setString('photo',
              userCredit.additionalUserInfo?.profile?['picture'] ?? '');
          await prefs.setString('phone', userCredit.user?.phoneNumber ?? '');
          await prefs.setBool('loggedin', true);

          await syncUserData(
              userCredit.additionalUserInfo?.profile?['email'] ?? '');
          return 'SUCCESS';
        }
        return 'UNKOWN_ACCOUNT';
      } else {
        return 'FAILED';
      }
    } on FirebaseAuthException {
      rethrow;
    }
  }

  Future<String> signInWithFacebook() async {
    try {
      final LoginResult result = await FacebookAuth.instance.login();
      print('firebase login result ===> ${result}');
      print('firebase login result status ===> ${result.status}');
      switch (result.status) {
        case LoginStatus.success:
          final AuthCredential facebookCredential =
              FacebookAuthProvider.credential(result.accessToken!.token);
          print('facebookCredential ===> ${facebookCredential}');
          UserCredential userCredit =
              await _auth.signInWithCredential(facebookCredential);
          print('facebook user Credential ===> ${userCredit}');
          // userCredit.additionalUserInfo!.profile!['email'];
          // if (userCredit.additionalUserInfo?.profile?['email'] != null &&
          //     userCredit.additionalUserInfo?.profile != null &&
          //     userCredit.additionalUserInfo != null) {
          await prefs.setString(
              'email', userCredit.additionalUserInfo?.profile?['email'] ?? '');
          await prefs.setString(
              'username', userCredit.additionalUserInfo?.username ?? '');
          await prefs.setString('firstname',
              userCredit.additionalUserInfo?.profile?['first_name'] ?? '');
          await prefs.setString('lastname',
              userCredit.additionalUserInfo?.profile?['last_name'] ?? '');
          await prefs.setString('photo', userCredit.user?.photoURL ?? '');
          await prefs.setString('phone', userCredit.user?.phoneNumber ?? '');
          await prefs.setBool('loggedin', true);
          print('facebook signin successed !! ${userCredit}');
          // }
          await syncUserData(
              userCredit.additionalUserInfo?.profile?['email'] ?? '');
          return 'SUCCESS';
        case LoginStatus.cancelled:
          return 'CANCELLED';
        case LoginStatus.failed:
          return 'FAILED';
        default:
          return 'null';
      }
    } catch (e) {
      print(e);
      rethrow;
    }
  }

  Future<String> signInWithTwitter() async {
    try {
      final twitterLogin = TwitterLogin(
        apiKey: "Qhq0WKgzISbG2tACTy6L52IPM",
        apiSecretKey: "JrqjGZriznGybrGdXHdFFyanoVqj7wrQi4rm6e38J1gYhSgrQQ",
        redirectURI: "s4smobile://",
      );
      print('twitter login credential ===> ${twitterLogin}');
      var authResult = await twitterLogin.loginV2();
      print('twitter login result ===> ${authResult}');
      print('twitter login result status ===> ${authResult.status}');
      switch (authResult.status) {
        case TwitterLoginStatus.loggedIn:
          final AuthCredential twitterAuthCredential =
              TwitterAuthProvider.credential(
                  accessToken: authResult.authToken!,
                  secret: authResult.authTokenSecret!);
          print('twitter credential ===> ${twitterAuthCredential}');
          UserCredential userCredit =
              await _auth.signInWithCredential(twitterAuthCredential);
          print('twitter user credential ===> ${userCredit}');
          await prefs.setString('email', userCredit.user?.email ?? '');
          await prefs.setString(
              'username', userCredit.additionalUserInfo?.username ?? '');
          await prefs.setString('firstname', '');
          await prefs.setString('lastname', '');
          await prefs.setString('photo', userCredit.user?.photoURL ?? '');
          await prefs.setString('phone', userCredit.user?.phoneNumber ?? '');
          await prefs.setBool('loggedin', true);
          print('twitter signin successed !! ${userCredit}');
          await syncUserData(userCredit.user?.email ?? '');
          return 'SUCCESS';
        case TwitterLoginStatus.cancelledByUser:
          return 'CANCELLED_BY_USER';
        case TwitterLoginStatus.error:
          return 'ERROR';
        default:
          return 'null';
      }
    } catch (e) {
      print(e);
      rethrow;
    }
  }

  Future<String> signInWithApple() async {
    try {
      final appleIdCredential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
        webAuthenticationOptions: WebAuthenticationOptions(
          clientId: "sneaks4sure-signin-with-apple",
          redirectUri: Uri.parse(
              "https://icy-delightful-memory.glitch.me/callbacks/sign_in_with_apple"),
        ),
      );
      print("appleID credential ====> ${appleIdCredential}");

      final credential = OAuthProvider("apple.com").credential(
        idToken: appleIdCredential.identityToken,
        accessToken: appleIdCredential.authorizationCode,
      );

      UserCredential userCredit = await _auth.signInWithCredential(credential);
      final firebaseUser = userCredit.user!;
      final familyName = appleIdCredential.familyName;
      final givenName = appleIdCredential.givenName;
      final displayName = '${givenName} ${familyName}';
      firebaseUser.updateDisplayName(displayName);

      print('apple signin successed !! ${userCredit}');
      if (userCredit.additionalUserInfo?.profile != null) {
        if (userCredit.additionalUserInfo?.profile?['email'] != null &&
            userCredit.additionalUserInfo?.profile != null &&
            userCredit.additionalUserInfo != null) {
          await prefs.setString(
              'email', userCredit.additionalUserInfo?.profile?['email'] ?? '');
          await prefs.setString(
              'username', userCredit.additionalUserInfo?.username ?? '');
          await prefs.setString('firstname', givenName ?? 'first name');
          await prefs.setString('lastname', familyName ?? 'last name');
          await prefs.setString('photo',
              userCredit.additionalUserInfo?.profile?['picture'] ?? '');
          await prefs.setString('phone', userCredit.user?.phoneNumber ?? '');
          await prefs.setBool('loggedin', true);

          await syncUserData(
              userCredit.additionalUserInfo?.profile?['email'] ?? '');
          return 'SUCCESS';
        }
        return 'UNKOWN_ACCOUNT';
      } else {
        return 'FAILED';
      }
    } on FirebaseAuthException {
      rethrow;
    }
  }

  // "UserCredential(
  //     additionalUserInfo: AdditionalUserInfo(
  //        isNewUser: true,
  //        profile: {
  //           entities: {
  //               description: {
  //                  urls: []
  //               }
  //           },
  //           verified: false,
  //           listed_count: 0,
  //           statuses_count: 0,
  //           profile_text_color: 333333,
  //           description: ,
  //           friends_count: 3,
  //           suspended: false,
  //           profile_sidebar_border_color: C0DEED,
  //           id_str: 1576141150465003522,
  //           profile_background_image_url: null,
  //           geo_enabled: false,
  //           profile_image_url_https: https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png,
  //           protected: false,
  //           translator_type: none,
  //           followers_count: 0,
  //           default_profile: true,
  //           profile_image_url: http://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png,
  //           profile_use_background_image: true,
  //           screen_name: giantbrain0216,
  //           id: 1576141150465003522,
  //           url: null,
  //           lang: null,
  //           name: giantbrain,
  //           time_zone: null,
  //           favourites_count: 0,
  //           has_extended_profile: true,
  //           profile_sidebar_fill_color: DDEEF6,
  //           default_profile_image: true,
  //           is_translator: false,
  //           follow_request_sent: false,
  //           profile_background_image_url_https: null,
  //           contributors_enabled: false,
  //           following: false,
  //           profile_background_tile: false,
  //           notifications: false,
  //           created_at: Sat Oct 01 09:25:24 +0000 2022,
  //           profile_link_color: 1DA1F2,
  //           profile_background_color: F5F8FA,
  //           needs_phone_verification: false,
  //           is_translation_enabled: false,
  //           utc_offset: null,
  //           withheld_in_countries: [],
  //           location:
  //        },
  //        providerId: twitter.com,
  //        username: giantbrain0216
  //    ),
  //    credential: AuthCredential(
  //        providerId: twitter.com,
  //        signInMethod: twitter.com,
  //        token: 84296957,
  //        accessToken: 1576141150465003522-e3gsW0FjJaGB22FUZNdzg11lczNPJk
  //    ),
  //    user: User(
  //        displayName: giantbrain,
  //        email: null,
  //        emailVerified: false,
  //        isAnonymous: false,
  //        metadata: UserMetadata(
  //            creationTime: 2022-10-14 06:05:37.128Z,
  //            lastSignInTime: 2022-10-14 06:05:37.129Z
  //        ),
  //        phoneNumber: null,
  //        photoURL: https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png,
  //        providerData,
  //        [
  //           UserInfo(
  //              displayName: giantbrain,
  //              email: null,
  //              phoneNumber: null,
  //              photoURL: https://abs.twimg.com/sticky/default_profile_images/default_profile_normal.png,
  //              providerId: twitter.com,
  //              uid: 1576141150465003522
  //           )
  //        ],
  //        refreshToken: ,
  //        tenantId: null,
  //        uid: ioHN964fKGVPKLFgcHOI9EyhwhY2
  //    )
  // )"

  Future<String> registerWithEmail(params) async {
    try {
      await _auth.createUserWithEmailAndPassword(
          email: params['email'], password: params['password']);
      return 'NEED_EMAIL_VERIFY';
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        return 'WEAK';
      } else if (e.code == 'email-already-in-use') {
        return 'DUPLICATED';
      }
      return 'FAILED';
    } catch (e) {
      rethrow;
    }
  }

  emailVerify() async {
    User? user = _auth.currentUser;
    if (user != null && !user.emailVerified) {
      await user.sendEmailVerification();
      return 'SENT_VERIFY';
    } else {
      return null;
    }
  }

  Future<void> signOut() async {
    await prefs.setString('email', '');
    await prefs.setString('username', '');
    await prefs.setString('firstname', '');
    await prefs.setString('lastname', '');
    await prefs.setString('photo', '');
    await prefs.setString('phone', '');
    await prefs.setBool('loggedin', false);
    await _auth.signOut();
  }

  Future<void> deleteUser() async {
    prefs.clear();
    User? user = _auth.currentUser;
    if (user != null) {
      user.delete();
    }
  }

  // Future<void> signOutFromFacebook() async {
  //   await _facebookLogin.logOut();
  //   await _auth.signOut();
  // }

  // User getCurrentUser() {
  //   User _user = FirebaseAuth.instance.currentUser!;
  //   return _user;
  // }

  Future<String> signInWithEmail(
      {required String email, required String password}) async {
    try {
      UserCredential credential = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      await _auth.currentUser?.reload();
      if (_auth.currentUser?.emailVerified == true) {
        await prefs.setString('email', email);
        await prefs.setBool('loggedin', true);
        await syncUserData(email);
        return 'VERIFIED';
      } else {
        return 'NOT_VERIFIED';
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        return 'USER_NOT_FOUND';
      } else if (e.code == 'wrong-password') {
        return 'WRONG_PASSWORD';
      } else if (e.code == 'invalid-email') {
        return 'INVALID_EMAIL';
      } else if (e.code == 'user-disabled') {
        return 'USER_DISABLED';
      } else {
        return 'FAILED';
      }
    }
    // return null;
  }

  Future<String> resetPassword({required String email}) async {
    await _auth.sendPasswordResetEmail(email: email);
    return 'EMAIL_SENT';
  }

  // Future<String> checkVerify() async {
  //   await _auth.currentUser?.reload();
  //   if (_auth.currentUser?.emailVerified == true) {
  //     return 'VERIFIED';
  //   } else {
  //     return 'NOT_VERIFIED';
  //   }
  // }
  //
  // checkUser() async {
  //   try {
  //     await _auth.currentUser?.reload();
  //     return _auth.currentUser;
  //   } on FirebaseAuthException catch (e) {
  //     if (e.code == 'user-not-found') {
  //       return 'USER_NOT_FOUND';
  //     } else if (e.code == 'wrong-password') {
  //       return 'WRONG_PASSWORD';
  //     } else if (e.code == 'invalid-email') {
  //       return 'INVALID_EMAIL';
  //     } else if (e.code == 'user-disabled') {
  //       return 'USER_DISABLED';
  //     }
  //   }
  // }
}
