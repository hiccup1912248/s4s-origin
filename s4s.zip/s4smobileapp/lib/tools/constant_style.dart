import 'package:flutter/material.dart';
import 'package:s4s_mobileapp/tools/functions.dart';

TextStyle w900Black30 =
    robotoStyle(FontWeight.w900, const Color(0xFF313036), 30, null);

TextStyle w700Black25 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 25, null);

TextStyle w800Black22 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 22, null);

TextStyle w500Black22 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 22, null);

TextStyle w900Black20 =
    robotoStyle(FontWeight.w900, const Color(0xFF313036), 20, null);

TextStyle w800Black20 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 20, null);

TextStyle w700Black20 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 20, null);

TextStyle w400Black20 =
    robotoStyle(FontWeight.w400, const Color(0xFF313036), 20, null);

TextStyle w900Black18 =
    robotoStyle(FontWeight.w900, const Color(0xFF313036), 18, null);

TextStyle w800Black18 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 18, null);

TextStyle w700Black18 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 18, null);

TextStyle w500Black18 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 18, null);

TextStyle w700Black17 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 17, null);

TextStyle w400Black17 =
    robotoStyle(FontWeight.w400, const Color(0xFF313036), 17, null);

TextStyle w800Black16 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 16, null);

TextStyle w700Black16 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 16, null);

TextStyle w500Black16 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 16, null);

TextStyle w400Black16 =
    robotoStyle(FontWeight.w400, const Color(0xFF313036), 16, null);

TextStyle w800Black15 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 15, null);

TextStyle w700Black15 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 15, null);

TextStyle w500Black15 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 15, null);

TextStyle w700Black14 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 14, null);

TextStyle w800Black14 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 14, null);

TextStyle w500Black14 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 14, null);

TextStyle w400Black14 =
    robotoStyle(FontWeight.w400, const Color(0xFF313036), 14, null);

TextStyle w300Black14 =
    robotoStyle(FontWeight.w300, const Color(0xFF313036), 14, null);

TextStyle w800Black12 =
    robotoStyle(FontWeight.w800, const Color(0xFF313036), 12, null);

TextStyle w700Black12 =
    robotoStyle(FontWeight.w700, const Color(0xFF313036), 12, null);

TextStyle w600Black12 =
    robotoStyle(FontWeight.w600, const Color(0xFF313036), 12, null);

TextStyle w500Black12 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 12, null);

TextStyle w400Black12 =
    robotoStyle(FontWeight.w400, const Color(0xFF313036), 12, null);

TextStyle w400Black11 =
    robotoStyle(FontWeight.w400, const Color(0xFF313036), 11, null);

TextStyle w500Black10 =
    robotoStyle(FontWeight.w500, const Color(0xFF313036), 10, null);

TextStyle w500Blue10 =
    robotoStyle(FontWeight.w500, const Color(0xFF588FED), 10, null);

TextStyle w700Gray20 =
    robotoStyle(FontWeight.w700, const Color(0xFF757D90), 20, null);

TextStyle w600Gray20 =
    robotoStyle(FontWeight.w600, const Color(0xFF757D90), 20, null);

TextStyle w700Gray17 =
    robotoStyle(FontWeight.w700, const Color(0xFF757D90), 17, null);

TextStyle w600Gray17 =
    robotoStyle(FontWeight.w600, const Color(0xFF757D90), 17, null);

TextStyle w900Gray16 =
    robotoStyle(FontWeight.w900, const Color(0xFF757D90), 16, null);

TextStyle w700Gray16 =
    robotoStyle(FontWeight.w700, const Color(0xFF757D90), 16, null);

TextStyle w600Gray16 =
    robotoStyle(FontWeight.w600, const Color(0xFF757D90), 16, null);

TextStyle w400Gray16 =
    robotoStyle(FontWeight.w400, const Color(0xFF757D90), 16, null);

TextStyle w600Gray14 =
    robotoStyle(FontWeight.w600, const Color(0xFF757D90), 14, null);

TextStyle w400Gray14 =
    robotoStyle(FontWeight.w400, const Color(0xFF757D90), 14, null);

TextStyle w300Gray14 =
    robotoStyle(FontWeight.w300, const Color(0xFF757D90), 14, null);

TextStyle w500Gray11 =
    robotoStyle(FontWeight.w500, const Color(0xFF757D90), 11, null);

TextStyle w400Gray11 =
    robotoStyle(FontWeight.w400, const Color(0xFF757D90), 11, null);

TextStyle w700Gray10 =
    robotoStyle(FontWeight.w700, const Color(0xFF757D90), 10, null);

TextStyle w400Gray8 =
    robotoStyle(FontWeight.w400, const Color(0xFF757D90), 8, null);

TextStyle w900White30 = robotoStyle(FontWeight.w900, Colors.white, 30, null);

TextStyle w900White23 = robotoStyle(FontWeight.w900, Colors.white, 23, null);

TextStyle w500White22 = robotoStyle(FontWeight.w500, Colors.white, 22, null);

TextStyle w900White21 = robotoStyle(FontWeight.w900, Colors.white, 21, null);

TextStyle w900White20 = robotoStyle(FontWeight.w900, Colors.white, 20, null);

TextStyle w900White18 = robotoStyle(FontWeight.w900, Colors.white, 18, null);

TextStyle w800White18 = robotoStyle(FontWeight.w800, Colors.white, 18, null);

TextStyle w400White18 = robotoStyle(FontWeight.w400, Colors.white, 18, null);

TextStyle w700White16 = robotoStyle(FontWeight.w700, Colors.white, 16, null);

TextStyle w500White16 = robotoStyle(FontWeight.w600, Colors.white, 16, null);

TextStyle w900White14 = robotoStyle(FontWeight.w900, Colors.white, 14, null);

TextStyle w800White14 = robotoStyle(FontWeight.w800, Colors.white, 14, null);

TextStyle w700White14 = robotoStyle(FontWeight.w700, Colors.white, 14, null);

TextStyle w600White14 = robotoStyle(FontWeight.w600, Colors.white, 14, null);

TextStyle w400White14 = robotoStyle(FontWeight.w400, Colors.white, 14, null);

TextStyle w900White12 = robotoStyle(FontWeight.w900, Colors.white, 12, null);

TextStyle w600White12 = robotoStyle(FontWeight.w600, Colors.white, 12, null);

TextStyle w500White12 = robotoStyle(FontWeight.w500, Colors.white, 12, null);

TextStyle w400White12 = robotoStyle(FontWeight.w400, Colors.white, 12, null);

TextStyle w900White10 = robotoStyle(FontWeight.w900, Colors.white, 10, null);

TextStyle w800White10 = robotoStyle(FontWeight.w800, Colors.white, 10, null);

TextStyle w600White10 = robotoStyle(FontWeight.w600, Colors.white, 10, null);

TextStyle w600White9 = robotoStyle(FontWeight.w600, Colors.white, 9, null);

TextStyle w900White8 = robotoStyle(FontWeight.w900, Colors.white, 8, null);

TextStyle w300White7 = robotoStyle(FontWeight.w300, Colors.white, 7, null);

TextStyle w900Red23 = robotoStyle(FontWeight.w900, Colors.red, 23, null);

TextStyle w900Red20 = robotoStyle(FontWeight.w900, Colors.red, 20, null);

TextStyle w600Red17 = robotoStyle(FontWeight.w600, Colors.red, 17, null);

TextStyle w700Red16 = robotoStyle(FontWeight.w700, Colors.red, 16, null);

TextStyle w600Blue12 = robotoStyle(FontWeight.w600, Colors.blue, 12, null);

TextStyle w400Color16(Color color) {
  return robotoStyle(FontWeight.w400, color, 16, null);
}

TextStyle w800Color16(Color color) {
  return robotoStyle(FontWeight.w800, color, 16, null);
}
