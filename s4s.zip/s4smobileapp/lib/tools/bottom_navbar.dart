import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:s4s_mobileapp/tools/bottom_search_button.dart';
import 'functions.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class BottomNavBar extends StatefulWidget {
  final int currentIndex;
  const BottomNavBar(this.currentIndex, {Key? key}) : super(key: key);

  @override
  State<BottomNavBar> createState() => _BottomNavBar();
}

class _BottomNavBar extends State<BottomNavBar> {
  void onBottomBarButtonTapped(int index) {
    if (mounted) {
      searchPageVisited = false;
      searchFilterSideDrawMenuOpen.value = false;
      switch (index) {
        case 0:
          Navigator.of(context).pushNamed('/Home');
          break;
        case 1:
          Navigator.of(context).pushNamed('/Calendar');
          break;
        case 2:
          Navigator.of(context).pushNamed('/Search');
          break;
        case 3:
          Navigator.of(context).pushNamed('/Restock');
          break;
        case 4:
          Navigator.of(context).pushNamed('/Account');
          break;
        default:
          {
            Navigator.of(context).pushNamed('/Home');
          }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      color: Colors.white,
      shape: const CircularNotchedRectangle(),
      notchMargin: 5.0,
      clipBehavior: Clip.antiAlias,
      child: SizedBox(
        height: kBottomNavigationBarHeight,
        child: Wrap(
          children: [
            BottomNavigationBar(
              type: BottomNavigationBarType.fixed,
              iconSize: 28,
              elevation: 0.0,
              currentIndex: widget.currentIndex,
              selectedLabelStyle: robotoStyle(
                FontWeight.w500,
                const Color.fromARGB(255, 49, 48, 54),
                null,
                null,
              ),
              showUnselectedLabels: true,
              unselectedLabelStyle: robotoStyle(
                FontWeight.w500,
                const Color(0xff313036),
                null,
                null,
              ),
              unselectedItemColor: const Color(0xff313036),
              selectedItemColor: const Color(0xff313036),
              selectedIconTheme: const IconThemeData(color: Color(0xffff2323)),
              onTap: onBottomBarButtonTapped,
              backgroundColor: Colors.white,
              items: <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  activeIcon: Icon(
                    Icons.signal_cellular_alt_rounded,
                    color: Color(0xffff2323),
                  ),
                  icon: Icon(
                    Icons.signal_cellular_alt_rounded,
                    color: Color(0xff313036),
                  ),
                  label: AppLocalizations.of(context).menu_trend,
                ),
                BottomNavigationBarItem(
                  activeIcon: Icon(
                    CupertinoIcons.calendar,
                    color: Color(0xffff2323),
                  ),
                  icon: Icon(
                    CupertinoIcons.calendar,
                    color: Color(0xff313036),
                  ),
                  label: AppLocalizations.of(context).menu_calendar,
                ),
                BottomNavigationBarItem(
                  activeIcon: Icon(
                    Icons.search_rounded,
                    color: Colors.transparent,
                  ),
                  icon: Icon(
                    Icons.search_rounded,
                    color: Colors.transparent,
                  ),
                  label: "",
                ),
                BottomNavigationBarItem(
                  activeIcon: Icon(
                    CupertinoIcons.arrow_2_circlepath,
                    color: Color(0xffff2323),
                  ),
                  icon: Icon(
                    CupertinoIcons.arrow_2_circlepath,
                    color: Color(0xff313036),
                  ),
                  label: AppLocalizations.of(context).menu_restock,
                ),
                BottomNavigationBarItem(
                  activeIcon: Icon(
                    Icons.account_circle,
                    color: Color(0xffff2323),
                  ),
                  icon: Icon(
                    Icons.account_circle,
                    color: Color(0xff313036),
                  ),
                  label: AppLocalizations.of(context).menu_account,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
