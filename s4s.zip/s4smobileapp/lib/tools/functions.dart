// ignore_for_file: unnecessary_brace_in_string_interps
import 'dart:io';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_web_browser/flutter_web_browser.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:s4s_mobileapp/account/account_profile_widget.dart';
import 'package:s4s_mobileapp/calendar/calendar_detail_widget.dart';
import 'package:s4s_mobileapp/search/search_widget.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/product/product_detail_widget.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
// ignore: depend_on_referenced_packages
import 'package:path_provider/path_provider.dart';
import 'package:safe_device/safe_device.dart';
import 'dart:math' as math;
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

bool securityAlert = false;

List<Map> xAxisData = [];

double roundDouble(double value, int places) {
  num mod = pow(10.0, places);

  return ((value * mod).round().toDouble() / mod);
}

double getScreenHeight(BuildContext context) {
  return MediaQuery.of(context).size.height;
}

double getScreenWidth(BuildContext context) {
  return MediaQuery.of(context).size.width;
}

TextStyle robotoStyle(
  FontWeight font,
  Color? col,
  double? size,
  TextDecoration? deco,
) {
  return GoogleFonts.roboto(
    fontWeight: font,
    color: col,
    fontSize: size,
    decoration: deco,
  );
}

Widget buildIconButton(
  Icon icon,
  String title,
  String description,
  void Function() func, {
  double width = 300,
}) {
  final buttonStyle = ButtonStyle(
    elevation: MaterialStateProperty.all<double>(0.0),
    foregroundColor: MaterialStateProperty.all<Color>(
      const Color.fromARGB(255, 49, 48, 54),
    ),
    backgroundColor: MaterialStateProperty.all<Color>(
      const Color.fromARGB(255, 235, 235, 235),
    ),
    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
    ),
  );
  final text = Text(
    title,
    style: robotoStyle(
      FontWeight.w700,
      const Color.fromARGB(255, 49, 48, 54),
      16,
      null,
    ),
    textAlign: TextAlign.center,
  );
  final descript = Text(
    description,
    style: robotoStyle(
        FontWeight.w400, const Color.fromARGB(255, 49, 48, 54), null, null),
    textAlign: TextAlign.left,
    overflow: TextOverflow.ellipsis,
  );

  return Container(
    padding: const EdgeInsets.only(bottom: 15, top: 5),
    width: width,
    height: 80,
    child: ElevatedButton(
      style: buttonStyle,
      onPressed: func,
      child: Stack(
        children: [
          Align(alignment: const Alignment(-1, -0.4), child: text),
          Align(
            alignment: const Alignment(-1, 0.4),
            child: Container(width: width - 60, child: descript),
          ),
          Align(alignment: Alignment.centerRight, child: icon),
        ],
      ),
    ),
  );
}

Widget buildSimpleButton(
  String title,
  void Function() func, {
  double width = 150,
}) {
  final buttonStyle = ButtonStyle(
    elevation: MaterialStateProperty.all<double>(0.0),
    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFF55E5E)),
    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(100.0),
      ),
    ),
  );
  final text = Text(
    title,
    style: robotoStyle(FontWeight.w900, Colors.white, 16, null),
    textAlign: TextAlign.center,
  );

  return Container(
    padding: const EdgeInsets.only(bottom: 25, top: 5),
    width: width,
    height: 75,
    child: ElevatedButton(
      onPressed: func,
      style: buttonStyle,
      child: text,
    ),
  );
}

Widget buildFloatingButtonMainCalendar(
  String title,
  Color backgroundColor,
  Color textColor,
  void Function() func, {
  double width = 115,
}) {
  final buttonStyle = ButtonStyle(
    elevation: MaterialStateProperty.all<double>(5.0),
    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    backgroundColor: MaterialStateProperty.all<Color>(backgroundColor),
    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(27),
      ),
    ),
  );
  final buttonText = Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text(
        title,
        style: robotoStyle(
          textColor == const Color(0xFF757D90)
              ? FontWeight.w400
              : FontWeight.w900,
          textColor,
          18,
          null,
        ),
        textAlign: TextAlign.center,
      ),
      Container(
        height: 5,
        width: getTextWidth(
          title,
          robotoStyle(
            textColor == const Color(0xFF757D90)
                ? FontWeight.w400
                : FontWeight.w900,
            textColor,
            18,
            null,
          ),
        ),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: textColor == const Color(0xFF757D90)
                  ? const Color(0x7F757D90)
                  : textColor,
              width: 3,
            ),
          ),
        ),
      ),
    ],
  );

  return Container(
    padding: const EdgeInsets.all(1),
    width: width,
    height: 42,
    child: ElevatedButton(
      onPressed: func,
      style: buttonStyle,
      child: buttonText,
    ),
  );
}

Widget buildFloatingButtonProductCalendar(
  BuildContext context,
  String title,
  bool isActive,
  Color textColor,
  void Function() func, {
  double width = 96,
}) {
  if (kDebugMode) {
    print(context);
    print(textColor);
    print(width);
  }

  final buttonStyle = ButtonStyle(
    elevation: MaterialStateProperty.all<double>(0),
    backgroundColor: MaterialStateProperty.all<Color>(
      isActive ? const Color(0xFFF55E5E) : const Color(0xFFF6F6F6),
    ),
    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    ),
  );
  final text = Text(
    title,
    style: TextStyle(
      fontWeight: isActive ? FontWeight.w900 : FontWeight.w400,
      fontSize: 18,
      color: isActive ? Colors.white : const Color(0xFF757D90),
      overflow: TextOverflow.ellipsis,
    ),
    textAlign: TextAlign.center,
  );

  return Stack(
    alignment: Alignment.center,
    children: <Widget>[
      SizedBox(
        width: 96,
        height: 36,
        child: ElevatedButton(
          onPressed: func,
          style: buttonStyle,
          child: text,
        ),
      ),
    ],
  );
}

Widget buildImageButton(
  String image,
  double imageSize,
  String title,
  double spaces,
  void Function() func, {
  double width = 265,
}) {
  if (kDebugMode) {
    print(width);
  }

  return Container(
    padding: const EdgeInsets.only(bottom: 15, top: 5),
    width: 265,
    height: 75,
    child: InkWell(
      customBorder: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(100),
      ),
      onTap: func,
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100.0),
          color: const Color.fromARGB(255, 235, 235, 235),
        ),
        child: Padding(
          padding:
              const EdgeInsets.only(bottom: 15, top: 15, right: 20, left: 40),
          child: Wrap(
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Image.asset(
                image,
                height: imageSize,
              ),
              SizedBox(width: spaces),
              SizedBox(
                width: 265 - spaces - 65 - imageSize,
                child: Text(
                  title,
                  style:
                      robotoStyle(FontWeight.w500, Colors.grey[700], 15, null),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

Widget buildTextFieldCountryReadOnly(
  String title,
  String titleFlag,
  Icon prefixIcon,
  String prefixFlag,
  Icon suffixIcon,
  void Function() func,
) {
  return TextField(
    onTap: func,
    readOnly: true,
    textAlign: TextAlign.left,
    decoration: InputDecoration(
      filled: true,
      fillColor: Colors.white,
      prefixIcon: prefixFlag != ""
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  prefixFlag,
                  package: 'country_calling_code_picker',
                  width: 25,
                ),
              ],
            )
          : prefixIcon,
      suffixIcon: suffixIcon,
      hintText: titleFlag != "" ? titleFlag : title,
      contentPadding: const EdgeInsets.all(15),
      border: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.circular(30),
      ),
    ),
  );
}

Widget returnCheckingIcon(List list) {
  if (list[0] == 1) {
    return const Icon(Icons.error,
        color: Color.fromARGB(255, 255, 35, 35), size: 30);
  } else if (list[1] == 1) {
    return const Icon(Icons.check,
        color: Color.fromARGB(255, 33, 237, 91), size: 30);
  }

  return const Icon(Icons.check, color: Colors.grey, size: 30);
}

Widget buildTextFieldEmailReadOnly(String title, Icon prefixIcon) {
  return TextField(
    keyboardType: TextInputType.emailAddress,
    readOnly: true,
    textAlign: TextAlign.left,
    decoration: InputDecoration(
      filled: true,
      fillColor: const Color.fromARGB(255, 215, 215, 215),
      prefixIcon: prefixIcon,
      hintText: title,
      hintStyle: const TextStyle(color: Colors.grey),
      contentPadding: const EdgeInsets.all(15),
      border: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.circular(30),
      ),
    ),
  );
}

Widget buildTextFieldEmail(
  String title,
  Icon prefixIcon,
  TextEditingController txtController,
) {
  return TextFormField(
    readOnly: true,
    keyboardType: TextInputType.emailAddress,
    inputFormatters: [
      FilteringTextInputFormatter.deny(RegExp('[A-Z]')),
    ],
    textAlign: TextAlign.left,
    decoration: InputDecoration(
      filled: true,
      fillColor: const Color(0xFFECEBEB),
      // fillColor: Colors.white,
      prefixIcon: prefixIcon,
      hintText: title,
      contentPadding: const EdgeInsets.all(15),
      border: OutlineInputBorder(
        borderSide: BorderSide.none,
        borderRadius: BorderRadius.circular(30),
      ),
    ),
    controller: txtController,
  );
}

bool isAlphaNum(String string) {
  if (string.isEmpty || string.length < 3) return false;
  final alphanumRegex = RegExp(r'^[ a-zA-Z0-9]+$');

  return alphanumRegex.hasMatch(string);
}

bool isEmail(String string) {
  if (string.isEmpty || string.length < 3) return false;
  final emailRegex = RegExp(
    r"^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$",
  );

  return emailRegex.hasMatch(string);
}

bool isPassword(String string) {
  RegExp numReg = RegExp(r".*[0-9].*");

  return string.isNotEmpty ||
      string.length < 8 ||
      string.contains(" ") ||
      !numReg.hasMatch(string);
}

bool isAlphabetics(String string) {
  if (string.isEmpty || string.length < 3) return false;
  final alphaRegex = RegExp(r'^[- a-zA-Z]+$');

  return alphaRegex.hasMatch(string);
}

bool isNumerics(String string) {
  if (string.isEmpty || string.length < 3) return false;
  final numericRegex = RegExp(r'^[+0-9]+$');

  return numericRegex.hasMatch(string);
}

bool isNumber(String string) {
  final numericRegex = RegExp(r'[+-]?([0-9]*[.])?[0-9]+');

  return numericRegex.hasMatch(string);
}

SnackBar launchSnackbar(
  String title,
  IconData icon,
  Color iconcolor,
  Color backgroundcolor,
  Color textcolor,
) {
  return SnackBar(
    behavior: SnackBarBehavior.floating,
    content: Row(
      children: [
        Icon(
          icon,
          color: iconcolor,
          size: 30,
        ),
        const SizedBox(width: 15),
        Expanded(
          child: Text(
            title,
            style: robotoStyle(FontWeight.w500, textcolor, 15, null),
          ),
        ),
      ],
    ),
    backgroundColor: backgroundcolor,
    duration: const Duration(seconds: 3),
  );
}

urlLauncher(String theUrl) async {
  var url = Uri.parse(theUrl);
  String urlStr = url.toString();
  try {
    bool linkSetting = prefs.getBool("linkSetting") ?? true;
    if (linkSetting) {
      if (urlStr.contains("mailto")) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        await FlutterWebBrowser.openWebPage(url: urlStr);
      }
    } else {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  } catch (e) {
    if (urlStr.contains("mailto")) {
      await Clipboard.setData(
        ClipboardData(text: urlStr.replaceAll("mailto:", "")),
      );

      return "mailto error";
    } else {
      throw 'Could not launch $url';
    }
  }
}

Widget myDropDownButton(
  Icon icon,
  String title,
  List<String> list,
  String? defaultValue,
  double? dropDownWidth,
  void Function(Object? value) func,
) {
  return DropdownButtonHideUnderline(
    child: DropdownButton2(
      isExpanded: true,
      hint: Row(
        children: [
          icon,
          const SizedBox(
            width: 10,
          ),
          Expanded(
            child: Text(
              title,
              style: robotoStyle(FontWeight.w400,
                  const Color.fromARGB(255, 107, 107, 107), null, null),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
      items: list
          .map(
            (item) => DropdownMenuItem<String>(
              value: item,
              child: Row(
                children: [
                  icon,
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Text(
                      getCurrencyRate(item),
                      style: robotoStyle(FontWeight.w400,
                          const Color.fromARGB(255, 107, 107, 107), null, null),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
      value: defaultValue,
      onChanged: (value) {
        func(value);
      },
      icon: const Icon(
        Icons.arrow_drop_down_rounded,
        size: 30,
        color: Color.fromARGB(255, 49, 48, 54),
      ),
      buttonHeight: 50,
      buttonWidth: dropDownWidth ?? 260,
      buttonPadding: const EdgeInsets.only(left: 10, right: 10),
      buttonDecoration: BoxDecoration(
        borderRadius: BorderRadius.circular(100),
        color: Colors.white,
      ),
      buttonElevation: 0,
      itemHeight: 40,
      dropdownMaxHeight: 200,
      dropdownWidth: dropDownWidth ?? 260,
      dropdownDecoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      scrollbarRadius: const Radius.circular(40),
      scrollbarThickness: 5,
      scrollbarAlwaysShow: false,
    ),
  );
}

Color returnColorCalendarCote(String element) {
  int e = isNumber(element) ? int.parse(element) : -999;
  // int e = int.parse(element);
  if (e < -100) {
    return const Color(0xffC4C4C4);
  } else if (e >= -100 && e < 15) {
    return const Color(0xFFF55E5E);
  } else if (e >= 15 && e < 25) {
    return const Color(0xFFFFC654);
  } else {
    return const Color(0xFF45D6A8);
  }
}

int returnResellState(String element) {
  int e = isNumber(element) ? int.parse(element) : -999;
  // int e = int.parse(element);
  if (e < -100) {
    return -1;
  } else if (e >= -100 && e < 15) {
    return 0;
  } else if (e >= 15 && e < 25) {
    return 1;
  } else {
    return 2;
  }
}

String returnSignCalendarCote(String element) {
  int e = isNumber(element) ? int.parse(element) : -999;

  return e.isNegative ? "" : "+";
}

void initFilterTabsOne(
  List<List<List<dynamic>>> defaultTab,
  List<List<List<dynamic>>> filterTab,
  Color color,
) {
  for (int x = 0; x < defaultTab.length; x++) {
    for (int y = 0, count = 0; y < defaultTab[x].length; y++) {
      if (returnColorCalendarCote(defaultTab[x][y][2]) == color) {
        if (count == 0) {
          filterTab[x][count] = defaultTab[x][y];
        } else {
          filterTab[x].add(defaultTab[x][y]);
        }
        count++;
      }
    }
  }
}

void initFilterTabsTwo(
  List<List<List<dynamic>>> defaultTab,
  List<List<List<dynamic>>> filterTab,
  Color color1,
  Color color2,
) {
  for (int x = 0; x < defaultTab.length; x++) {
    for (int y = 0, count = 0; y < defaultTab[x].length; y++) {
      Color tempColor = returnColorCalendarCote(defaultTab[x][y][2]);
      if (tempColor == color1 || tempColor == color2) {
        if (count == 0) {
          filterTab[x][count] = defaultTab[x][y];
        } else {
          filterTab[x].add(defaultTab[x][y]);
        }
        count++;
      }
    }
  }
}

void loadMorefilterTabsOne(
  List<List<dynamic>> dayTab,
  List<List<List<dynamic>>> filterTab,
  Color color,
) {
  for (int y = 0; y < dayTab.length; y++) {
    if (returnColorCalendarCote(dayTab[y][2]) == color) {
      filterTab.add(dayTab);
    } else {
      filterTab.add([
        ["", "", "", "", "", ""],
      ]);
    }
  }
}

void loadMorefilterTabsTwo(List<List<dynamic>> dayTab,
    List<List<List<dynamic>>> filterTab, Color color1, Color color2) {
  for (int y = 0; y < dayTab.length; y++) {
    Color tempColor = returnColorCalendarCote(dayTab[y][2]);
    if (tempColor == color1 || tempColor == color2) {
      filterTab.add(dayTab);
    } else {
      filterTab.add([
        ["", "", "", "", "", ""],
      ]);
    }
  }
}

List<List<List<dynamic>>> goodListCalendar(
    bool low,
    bool medium,
    bool high,
    List<List<List<dynamic>>> tabLow,
    List<List<List<dynamic>>> tabMedium,
    List<List<List<dynamic>>> tabHigh,
    List<List<List<dynamic>>> tabLowMedium,
    List<List<List<dynamic>>> tabLowHigh,
    List<List<List<dynamic>>> tabMediumHigh,
    List<List<List<dynamic>>> tabDefault) {
  if (low && !medium && !high) {
    return tabLow;
  } else if (low && medium && !high) {
    return tabLowMedium;
  } else if (low && medium && high) {
    return tabDefault;
  } else if (!low && medium && !high) {
    return tabMedium;
  } else if (!low && medium && high) {
    return tabMediumHigh;
  } else if (!low && !medium && high) {
    return tabHigh;
  } else if (low && !medium && high) {
    return tabLowHigh;
  } else {
    return tabDefault;
  }
}

String getCurrentDayLetterUpcoming(int n) {
  var dayLetter =
      DateFormat("EEEE").format(DateTime.now().add(Duration(days: n)));

  return dayLetter.toString();
}

String getCurrentDayNbUpcoming(int n) {
  var dayNb = DateFormat("d").format(DateTime.now().add(Duration(days: n)));

  return dayNb.toString();
}

String getCurrentMonthUpcoming(int n) {
  var month = DateFormat("MMMM").format(DateTime.now().add(Duration(days: n)));

  return month.toString();
}

String getCurrentYearUpcoming(int n) {
  var year = DateFormat("yyyy").format(DateTime.now().add(Duration(days: n)));

  return year.toString();
}

String getCurrentMonthNbUpcoming(int n) {
  var month = DateFormat("M").format(DateTime.now().add(Duration(days: n)));

  return month.toString();
}

String createCalendarAPICallDateFormatUpcoming(int n) {
  String month = getCurrentMonthNbUpcoming(n);
  String day = getCurrentDayNbUpcoming(n);

  if (int.parse(month) < 10) month = "0$month";
  if (int.parse(day) < 10) day = "0$day";
  String format = "${getCurrentYearUpcoming(n)}-$month-$day";

  return format;
}

Widget calendarDateBarUpcoming(Map upcoming) {
  List<String> keysStrList = upcoming.keys.first.toString().split(',');
  TextStyle keyStyle = robotoStyle(FontWeight.w400, Colors.white, 24, null);
  TextStyle keyStyleBold = robotoStyle(FontWeight.w900, Colors.white, 24, null);

  return Container(
    height: 40,
    decoration: const BoxDecoration(
      color: Color(0xff757D90),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          keysStrList[0],
          style: keyStyle,
        ),
        Text(
          '${keysStrList[1]},',
          style: keyStyleBold,
        ),
        Text(
          upcoming.keys.first.toString().split(',')[2],
          style: keyStyle,
        ),
      ],
    ),
  );
}

String getCurrentDayLetterPast(int n) {
  var dayLetter =
      DateFormat("EEEE").format(DateTime.now().subtract(Duration(days: n)));

  return dayLetter.toString();
}

String getCurrentDayNbPast(int n) {
  var dayNb =
      DateFormat("d").format(DateTime.now().subtract(Duration(days: n)));

  return dayNb.toString();
}

String getCurrentMonthPast(int n) {
  var month =
      DateFormat("MMMM").format(DateTime.now().subtract(Duration(days: n)));

  return month.toString();
}

String getCurrentYearPast(int n) {
  var year =
      DateFormat("yyyy").format(DateTime.now().subtract(Duration(days: n)));

  return year.toString();
}

String getCurrentMonthNbPast(int n) {
  var month =
      DateFormat("M").format(DateTime.now().subtract(Duration(days: n)));

  return month.toString();
}

String createCalendarAPICallDateFormatPast(int n) {
  String month = getCurrentMonthNbPast(n);
  String day = getCurrentDayNbPast(n);

  if (int.parse(month) < 10) month = "0$month";
  if (int.parse(day) < 10) day = "0$day";
  String format = "${getCurrentYearPast(n)}-$month-$day";

  return format;
}

Widget calendarDateBarPast(int n) {
  TextStyle thinStyle = robotoStyle(FontWeight.w400, Colors.white, 20, null);
  TextStyle thickStyle = robotoStyle(FontWeight.w900, Colors.white, 20, null);

  return Container(
    height: 40,
    decoration: const BoxDecoration(
      color: Color.fromARGB(255, 120, 130, 150),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          getCurrentDayLetterPast(n),
          style: thinStyle,
        ),
        Text(
          " ${getCurrentMonthPast(n)}",
          style: thickStyle,
        ),
        Text(
          " ${getCurrentDayNbPast(n)}",
          style: thickStyle,
        ),
        Text(
          ", ${getCurrentYearPast(n)}",
          style: thinStyle,
        ),
      ],
    ),
  );
}

Widget getCalendarIcon(String date, Color color, String backType) {
  DateFormat formatter = DateFormat("MMM.yy-dd");
  String yearMonth = "";
  String day = "";

  try {
    String formatedString = formatter.format(DateTime.parse(date));
    List<String> formatedStringList = formatedString.split("-");
    yearMonth = formatedStringList[0];
    day = formatedStringList[1];
    // ignore: empty_catches
  } catch (e) {}

  return SizedBox(
    width: 45,
    height: 45,
    child: Stack(
      alignment: Alignment.center,
      children: [
        Image.asset(
          backType == "black"
              ? "assets/etc/calendar_back.png"
              : "assets/etc/calendar_back_gray.png",
          width: 45,
          height: 45,
        ),
        Align(
          alignment: const Alignment(0, -0.4),
          child: Text(
            day,
            style: robotoStyle(FontWeight.bold, color, 24, null),
          ),
        ),
        Align(
          alignment: const Alignment(0, 0.7),
          child: Text(
            yearMonth,
            style: robotoStyle(FontWeight.w700, color, 12, null),
          ),
        ),
      ],
    ),
  );
}

String returnRestockDate(String completeDate) {
  final notifTime = DateTime.parse(completeDate.split(".")[0]);
  final nowTime = DateTime.now();
  Duration duration = nowTime.difference(notifTime);
  final difference = duration.inMinutes;
  if (difference < 0) {
    return "${difference.toString().replaceAll("-", "")} min(s) after";
  } else if (difference == 0) {
    return "Now";
  } else if (difference > 0 && difference < 60) {
    return "$difference min(s) ago";
  } else if (difference >= 60 && difference < 1440) {
    final diffHour = duration.inHours;

    return "$diffHour hour(s) ago";
  } else {
    return "Yesterday";
  }
}

AlignmentGeometry returnAlignment(double nb) {
  if (nb >= 51) {
    return const Alignment(-0.5, 0);
  } else if (nb < 50) {
    return const Alignment(0.5, 0);
  } else {
    return Alignment.center;
  }
}

double returnByBrands1(int x, bool jordan, bool nike, bool nb) {
  if (x == 0) {
    return jordan ? 1 : 0;
  } else if (x == 1) {
    return nike ? 1 : 0;
  } else {
    return nb ? 1 : 0;
  }
}

double returnByBrands2(int x, bool adidas, bool yeezy) {
  return x == 0
      ? adidas
          ? 1
          : 0
      : yeezy
          ? 1
          : 0;
}

int checkRestockFilterConditions(bool jordan, bool nike, bool nb, bool adidas,
    bool yeezy, List<List<dynamic>> list, int position) {
  if (!jordan && !nike && !nb && !adidas && !yeezy) {
    return 1;
  } else {
    if (list[position][6] == "Jordan" && jordan) {
      return 1;
    } else if (list[position][6] == "Nike" && nike) {
      return 1;
    } else if (list[position][6] == "NewBalance" && nb) {
      return 1;
    } else if (list[position][6] == "Adidas" && adidas) {
      return 1;
    } else if (list[position][6] == "Yeezy" && yeezy) {
      return 1;
    } else {
      return 0;
    }
  }
}

FloatingActionButtonLocation? returnFloatingButtonLocationCalendar(
  int calendarPage,
  bool is360,
  bool isProductDetail,
) {
  if (is360 && isProductDetail) {
    return FloatingActionButtonLocation.endTop;
  }

  return calendarPage == 0 || calendarPage == 1
      ? FloatingActionButtonLocation.centerFloat
      : null;
}

int returnFloatingButtonCalendar(
  int calendarPage,
  bool is360,
  bool isProductDetail,
) {
  if (kDebugMode) {
    print(calendarPage);
  }

  return isProductDetail
      ? is360
          ? 1
          : 2
      : 0;
}

checkIsJailBroken(BuildContext context) async {
  bool isJailBroken = await SafeDevice.isJailBroken;

  String errorMsg =
      "We're sorry, but it appears that your device has been jailbroken or rooted. For security reasons, our app cannot be used on devices that have been modified in this way. Please restore your device to its original, unmodified state in order to use our app. If you have any questions or concerns, please contact our support team for assistance.";
  if (isJailBroken && !securityAlert) {
    securityAlert = true;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Error"),
          content: Text(errorMsg),
          actions: [
            TextButton(
              onPressed: () {
                securityAlert = false;
                Navigator.of(context).pop();
                exit(0);
              },
              child: const Text('Ok'),
            ),
          ],
        );
      },
    );
  }
}

void showMessage(
  context,
  String s, {
  title = 'ERROR',
  action = const Text(''),
}) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text(title),
        content: Text(s),
        actions: [
          action,
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('Ok'),
          ),
        ],
      );
    },
  );
}

showConfirmDialog(
  BuildContext context,
  String title,
  String content,
  Function() confirmAction,
) {
  // set up the buttons
  Widget cancelButton = TextButton(
    child: const Text("Cancel"),
    onPressed: () {
      Navigator.of(context).pop();
    },
  );
  Widget continueButton = TextButton(
    child: const Text("Confirm"),
    onPressed: () {
      confirmAction();
    },
  );
  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text(title),
    content: Text(content),
    actions: [
      cancelButton,
      continueButton,
    ],
  );
  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}

Future getData(String url) async {
  String jwtToken = prefs.getString("jwtToken") ?? "";
  try {
    var response = await http.get(Uri.parse(url), headers: {"Token": jwtToken});

    if (response.statusCode == 200) {
      return response.body;
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
  } catch (e) {
    rethrow;
  }
}

double extractNumberFromPrice(String string) {
  final numericRegex = RegExp(r'[+-]?([0-9]*[.])?[0-9]+');

  return numericRegex.firstMatch(string) != null
      ? double.parse(numericRegex.firstMatch(string)![0].toString())
      : 0.0;
}

String extractUnitFromPrice(String string) {
  final numericRegex = RegExp(r'[+-]?([0-9]*[.])?[0-9]+');

  return string.replaceAll(numericRegex.firstMatch(string)![0].toString(), '');
}

getListHeats() async {
  List<Map> listHeats = [];

  var result = await getData('https://api.sneaks4sure.com/heats');
  listHeats = jsonDecode(result)['data']['heats']
      .map((e) {
        return {
          "ProductSKU": e['ProductSKU'],
          "ProductName": e['ProductName'],
          "MonthDay": e['MonthDay'],
          "ResellValuePourcent": e['ResellValuePourcent'],
          "ProductImage": e['ProductImage'],
        };
      })
      .toList()
      .cast<Map>();

  return listHeats;
}

getListRecently() async {
  List<Map> listRecently = [];

  var result = await getData('https://api.sneaks4sure.com/recent');
  listRecently = jsonDecode(result)['data']['recentlyDropped']
      .map((e) {
        return {
          "ProductSKU": e['ProductSKU'],
          "ProductName": e['ProductName'],
          "xxShops": e['xxShops'],
          "ProductMarketValue": e['ProductMarketValue'],
          "ResellValuePourcent": e['ResellValuePourcent'],
          "ProductResellArrow": e['ProductResellArrow'],
          "ProductImage": e['ProductImage'],
        };
      })
      .toList()
      .cast<Map>();

  return listRecently;
}

getListNews() async {
  List<String> listNews = [];

  var result = await getData('https://api.sneaks4sure.com/s4snews');
  listNews = jsonDecode(result)['data']['s4sNews']
      .map((e) {
        return e.toString();
      })
      .toList()
      .cast<String>();

  return listNews;
}

getListTops() async {
  List<Map> listTops = [];
  var result = await getData('https://api.sneaks4sure.com/top');
  listTops = jsonDecode(result)['data']['topClicked']
      .map((e) {
        return {
          'ProductSKU': e['ProductSKU'],
          'ProductImage': e['ProductImage'],
          'ProductName': e['ProductName'],
          'product_change_arrow': e['product_change_arrow'],
          'xxShops': e['xxShops'],
          'ProductMarketValue': e['ProductMarketValue'],
          'ProductResellArrow': e['ProductResellArrow'],
        };
      })
      .toList()
      .cast<Map>();

  return listTops;
}

getRaffles(String sku) async {
  List<Map> raffle = [];
  var result = await getData('https://api.sneaks4sure.com/raffles/$sku');
  raffle = jsonDecode(result)['data']['raffles']
      .map((e) {
        return {
          'ProductSKU': e['ProductSKU'] ?? '',
          'ProductImage': e['ProductImage'],
          'ProductName': e['ProductName'],
          'ShopLocation': e['ShopLocation'],
          'ShopLogo': e['ShopLogo'],
          'ShopShipping': e['ShopShipping'],
          'ShopRaffleMethod': e['ShopRaffleMethod'],
          'ShopRaffleAccount': e['ShopRaffleAccount'],
          'ShopOpenTime': e['ShopOpenTime'],
          'ShopCloseTime': e['ShopCloseTime'],
          'ShopRaffeLink': e['ShopRaffeLink'],
          'RegionLogo': e['RegionLogo'],
          'ShopLocationLogo': e['ShopLocationLogo'],
          'RetailPrice': e['RetailPrice'],
          'ReleaseDate': e['ReleaseDate'],
          'ColorWay': e['ColorWay'],
          'ProductImage360': e['ProductImage360'],
          'ProductLike': e['ProductLike'],
          'ProductDislike': e['ProductDislike'],
          'StoreCountrys': e['StoreCountrys'],
        };
      })
      .toList()
      .cast<Map>();

  return raffle[0];
}

getRetails(String sku) async {
  List<Map> retail = [];
  var result = await getData('https://api.sneaks4sure.com/retail/$sku');
  retail = jsonDecode(result)['data']['retail']
      .map((e) {
        return {
          'ProductSKU': e['ProductSKU'],
          'ProductImage': e['ProductImage'],
          'ProductName': e['ProductName'],
          'ProductImage360': e['ProductImage360'],
          'Shops': e['Shops'],
        };
      })
      .toList()
      .cast<Map>();

  return retail[0];
}

getResells(String sku) async {
  List<Map> resell = [];
  var result = await getData('https://api.sneaks4sure.com/resell/$sku');
  resell = jsonDecode(result)['data']['resell']
      .map((e) {
        return {
          'ProductSKU': e['ProductSKU'],
          'ProductName': e['ProductName'],
          'ProductSize': e['ProductSize'],
          'ProductSizeBest': e['ProductSizeBest'],
          'sizeSlider': e['sizeSlider'],
        };
      })
      .toList()
      .cast<Map>();

  return resell[0];
}

isBrandMatch(List<String> checkedBrands, String brand) {
  for (var i = 0; i < checkedBrands.length; i++) {
    if (checkedBrands[i].toLowerCase() == brand.toLowerCase()) {
      return true;
    }
  }

  return false;
}

getUpcomings() async {
  List upcomings = [];
  var result = await getData('https://api.sneaks4sure.com/upcoming');
  List<String> checkedBrands =
      prefs.getStringList("upcomingFilterBrands") ?? [];
  List temp = [];
  jsonDecode(result)['data']['upcomings'].forEach((key, value) {
    if (checkedBrands.isEmpty) {
      temp.add({key: value});
    } else {
      List tempArray = [];
      for (var i = 0; i < value.length; i++) {
        if (isBrandMatch(
          checkedBrands,
          value[i]['ProductBrand'].toString().toLowerCase(),
        )) {
          tempArray.add(value[i]);
        }
      }
      if (tempArray.isNotEmpty) {
        temp.add({key: tempArray});
      }
    }
  });
  upcomings = temp;

  return upcomings;
}

getAllBrandsData() async {
  List<String> brands = [];
  var result = await getData('https://api.sneaks4sure.com/upcoming');
  jsonDecode(result)['data']['upcomings'].forEach((key, value) {
    for (var i = 0; i < value.length; i++) {
      brands.add(value[i]['ProductBrand']);
    }
  });

  var pasts = await getData('https://api.sneaks4sure.com/past');
  jsonDecode(pasts)['data']['pastProducts'].forEach((key, value) {
    for (var i = 0; i < value.length; i++) {
      brands.add(value[i]['ProductBrand']);
    }
  });

  brands = brands.toSet().toList();
  for (var i = 0; i < brands.length; i++) {
    if (brands[i].toLowerCase() == 'adidas') {
      brands[i] = 'Adidas';
    }
    if (brands[i].toLowerCase() == 'asics') {
      brands[i] = 'Asics';
    }
    if (brands[i].toLowerCase() == 'converse') {
      brands[i] = 'Converse';
    }
    if (brands[i].toLowerCase() == 'jordan') {
      brands[i] = 'Jordan';
    }
    if (brands[i].toLowerCase() == 'new balance') {
      brands[i] = 'New Balance';
    }
    if (brands[i].toLowerCase() == 'nike') {
      brands[i] = 'Nike';
    }
    if (brands[i].toLowerCase() == 'off white') {
      brands[i] = 'Off White';
    }
    if (brands[i].toLowerCase() == 'puma') {
      brands[i] = 'Puma';
    }
    if (brands[i].toLowerCase() == 'reebok') {
      brands[i] = 'Reebok';
    }
    if (brands[i].toLowerCase() == 'travis scott') {
      brands[i] = 'Travis Scott';
    }
    if (brands[i].toLowerCase() == 'yeezy') {
      brands[i] = 'Yeezy';
    }
  }

  return brands;
}

getPasts() async {
  List pasts = [];
  var result = await getData('https://api.sneaks4sure.com/past');
  List<String> checkedBrands =
      prefs.getStringList("upcomingFilterBrands") ?? [];
  List temp = [];
  jsonDecode(result)['data']['pastProducts'].forEach((key, value) {
    if (checkedBrands.isEmpty) {
      temp.add({key: value});
    } else {
      List tempArray = [];
      for (var i = 0; i < value.length; i++) {
        if (isBrandMatch(
          checkedBrands,
          value[i]['ProductBrand'].toString().toLowerCase(),
        )) {
          tempArray.add(value[i]);
        }
      }
      if (tempArray.isNotEmpty) {
        temp.add({key: tempArray});
      }
    }
  });
  pasts = temp;

  return pasts;
}

checkRestockDataWithFilter(
  String shopName,
  String brand,
  String productSKU,
  String resellValuePourcent,
) {
  resellValuePourcent = resellValuePourcent.toString().replaceAll('%', '');
  List<String> shops = prefs.getStringList('shops') ?? [];
  List<String> brands = prefs.getStringList('brands') ?? [];
  List<String> wishProducts = prefs.getStringList("wishProducts") ?? [];
  bool isResellLow = prefs.getBool("resellLow") ?? false;
  bool isResellMid = prefs.getBool("resellMid") ?? false;
  bool isResellHigh = prefs.getBool("resellHigh") ?? false;

  int resellStatus = returnResellState(resellValuePourcent);

  if (shops.isEmpty && brands.isEmpty) {
    if (!isResellHigh && !isResellMid && !isResellLow) {
      return true;
    } else {
      if ((isResellLow && (resellStatus <= 0)) ||
          (isResellMid && (resellStatus == 1)) ||
          (isResellHigh && (resellStatus == 2))) {
        return true;
      }
    }
  }
  if ((!shops.indexOf(shopName).isNegative) &&
      (!brands.indexOf(brand).isNegative) &&
      ((isResellLow && (resellStatus <= 0)) ||
          (isResellMid && (resellStatus == 1)) ||
          (isResellHigh && (resellStatus == 2)))) {
    return true;
  }
  if (wishProducts.isNotEmpty) {
    for (var i = 0; i < wishProducts.length; i++) {
      if (wishProducts[i].contains(productSKU)) {
        return true;
      }
    }
  }

  return false;
}

checkStoreCountryName(String country, List<String> countrys) {
  for (var i = 0; i < countrys.length; i++) {
    if (countrys[i].toString().toLowerCase() == country) {
      return true;
    } else if (country == "united-states-of-america") {
      if (countrys[i] == "US") {
        return true;
      }
    } else if (country == "canada") {
      if (countrys[i] == "CA") {
        return true;
      }
    }
  }

  return false;
}

checkInstoreDataWithFilter(
  String storeCountry,
  List<dynamic> productSizes,
  String resellValuePourcent,
) {
  resellValuePourcent = resellValuePourcent.toString().replaceAll('%', '');
  List<String> countrys = prefs.getStringList('regions') ?? [];
  List<String> sizes = prefs.getStringList('sizes') ?? [];
  int resellStatus = returnResellState(resellValuePourcent);

  bool isResellLow = prefs.getBool("resellLow") ?? false;
  bool isResellMid = prefs.getBool("resellMid") ?? false;
  bool isResellHigh = prefs.getBool("resellHigh") ?? false;

  if (countrys.isEmpty && sizes.isEmpty) {
    if (!isResellHigh && !isResellMid && !isResellLow) {
      return true;
    } else {
      if ((isResellLow && (resellStatus <= 0)) ||
          (isResellMid && (resellStatus == 1)) ||
          (isResellHigh && (resellStatus == 2))) {
        return true;
      }
    }
  }
  if (checkStoreCountryName(storeCountry, countrys)) {
    for (var size in productSizes) {
      List<String> filtered = sizes
          .where(
            (element) => element.contains("EU ${size.toString()}"),
          )
          .toList();
      if (filtered.isNotEmpty) {
        if ((isResellLow && (resellStatus <= 0)) ||
            (isResellMid && (resellStatus == 1)) ||
            (isResellHigh && (resellStatus == 2))) {
          return true;
        }
      }
    }
  }

  return false;
}

getRestock() async {
  List<Map> restock = [];
  var result = await getData('https://api.sneaks4sure.com/restock');
  restock = jsonDecode(result)['data']['restock']
      .map((e) {
        return {
          'DateTime': e['DateTime'],
          'ProductSKU': e['ProductSKU'],
          'ProductName': e['ProductName'] ?? "",
          'ShopName': e['ShopName'] ?? "",
          'ProductImage': e['ProductImage'],
          'Url_Link': e['Url_Link'] ?? {},
          'Brand': e['Brand'],
          'RegionName': e['RegionName'],
          'ProductATCSize': e['product_shortened_size_atc'] ?? {},
          'ResellValuePourcent': e['ResellValuePourcent'],
          'ResellValueProfit': e['ResellValueProfit'],
        };
      })
      .toList()
      .cast<Map>();
  restock = restock
      .where((element) => checkRestockDataWithFilter(
            element['RegionName'] + '_' + element['ShopName'],
            element['Brand'],
            element["ProductSKU"],
            element["ResellValuePourcent"].toString(),
          ))
      .toList();

  return restock;
}

getInstore() async {
  List<Map> instore = [];
  var result = await getData('https://api.sneaks4sure.com/instore');
  instore = jsonDecode(result)['data']['instore']
      .map((e) {
        return {
          'DateTime': e['DateTime'],
          'ProductSKU': e['ProductSKU'],
          'ProductName': e['ProductName'] ?? "",
          'StoreCountry': e['StoreCountry'] ?? "",
          'StoreCountyFlag': e['StoreCountyFlag'] ?? "",
          'StoreName': e['StoreName'] ?? "",
          'StoreAddress': e['StoreAddress'] ?? "",
          'StoreLocation': e['StoreLocation'] ?? "",
          'ProductImage': e['ProductImage'],
          'ProductPrice': e['ProductPrice'] ?? "",
          'ProductStockxURL': e['ProductStockxURL'] ?? "",
          'ProductSize': e['ProductSize'] ?? "",
          'ResellValuePourcent': e['ResellValuePourcent'],
          'ResellValueProfit': e['ResellValueProfit'],
        };
      })
      .toList()
      .cast<Map>();

  instore = instore
      .where((element) => checkInstoreDataWithFilter(
            element['StoreCountry'],
            element['ProductSize'],
            element["ResellValuePourcent"].toString(),
          ))
      .toList();

  return instore;
}

List<Map> regularSizes = [
  {
    '3.5': ['3', '35.5', '22.5'],
  },
  {
    '4': ['3.5', '36', '23'],
  },
  {
    '4.5': ['4', '36.5', '23.5'],
  },
  {
    '5': ['4.5', '37.5', '23.5'],
  },
  {
    '5.5': ['5', '38', '24'],
  },
  {
    '6': ['5.5', '38.5', '24'],
  },
  {
    '6.5': ['6', '39', '24.5'],
  },
  {
    '7': ['6', '40', '25'],
  },
  {
    '7.5': ['6.5', '40.5', '25.5'],
  },
  {
    '8': ['7', '41', '26'],
  },
  {
    '8.5': ['7.5', '42', '26.5'],
  },
  {
    '9': ['8', '42.5', '27'],
  },
  {
    '9.5': ['8.5', '43', '27.5'],
  },
  {
    '10': ['9', '44', '28'],
  },
  {
    '10.5': ['9.5', '44.5', '28.5'],
  },
  {
    '11': ['10', '45', '29'],
  },
  {
    '11.5': ['10.5', '45.5', '29.5'],
  },
  {
    '12': ['11', '46', '30'],
  },
  {
    '12.5': ['11.5', '47', '30.5'],
  },
  {
    '13': ['12', '47.5', '31'],
  },
  {
    '13.5': ['12.5', '48', '31.5'],
  },
  {
    '14': ['13', '48.5', '32'],
  },
];

List<Map> nikeAndJordanSizes = [
  {
    '3.5': ['3', '35.5', '22.5'],
  },
  {
    '4': ['3.5', '36', '23'],
  },
  {
    '4.5': ['4', '36.5', '23.5'],
  },
  {
    '5': ['4.5', '37.5', '23.5'],
  },
  {
    '5.5': ['5', '38', '24'],
  },
  {
    '6': ['5.5', '38.5', '24'],
  },
  {
    '6.5': ['6', '39', '24.5'],
  },
  {
    '7': ['6', '40', '25'],
  },
  {
    '7.5': ['6.5', '40.5', '25.5'],
  },
  {
    '8': ['7', '41', '26'],
  },
  {
    '8.5': ['7.5', '42', '26.5'],
  },
  {
    '9': ['8', '42.5', '27'],
  },
  {
    '9.5': ['8.5', '43', '27.5'],
  },
  {
    '10': ['9', '44', '28'],
  },
  {
    '10.5': ['9.5', '44.5', '28.5'],
  },
  {
    '11': ['10', '45', '29'],
  },
  {
    '11.5': ['10.5', '45.5', '29.5'],
  },
  {
    '12': ['11', '46', '30'],
  },
  {
    '12.5': ['11.5', '47', '30.5'],
  },
  {
    '13': ['12', '47.5', '31'],
  },
  {
    '13.5': ['12.5', '48', '31.5'],
  },
  {
    '14': ['13', '48.5', '32'],
  },
];

List<Map> nikeAndJordanWomenSizes = [
  {
    '5': ['3', '35.5', '22.5'],
  },
  {
    '5.5': ['3.5', '36', '23'],
  },
  {
    '6': ['4', '36.5', '23.5'],
  },
  {
    '6.5': ['4.5', '37.5', '23.5'],
  },
  {
    '7': ['5', '38', '24'],
  },
  {
    '7.5': ['5.5', '38.5', '24'],
  },
  {
    '8': ['6', '39', '24.5'],
  },
  {
    '8.5': ['6', '40', '25'],
  },
  {
    '9': ['6.5', '40.5', '25.5'],
  },
  {
    '9.5': ['7', '41', '26'],
  },
  {
    '10': ['7.5', '42', '26.5'],
  },
  {
    '10.5': ['8', '42.5', '27'],
  },
  {
    '11': ['8.5', '43', '27.5'],
  },
  {
    '11.5': ['9', '44', '28'],
  },
  {
    '12': ['9.5', '44.5', '28.5'],
  },
  {
    '12.5': ['10', '45', '29'],
  },
  {
    '13': ['10.5', '45.5', '29.5'],
  },
  {
    '13.5': ['11', '46', '30'],
  },
  {
    '14': ['11.5', '47', '30.5'],
  },
  {
    '14.5': ['12', '47.5', '31'],
  },
  {
    '15': ['12.5', '48', '31.5'],
  },
  {
    '15.5': ['13', '48.5', '32'],
  },
];

List<Map> nikeAndJordanGSSizes = [
  {
    '3.5Y': ['3', '35.5', '22.5'],
  },
  {
    '4Y': ['3.5', '36', '23'],
  },
  {
    '4.5Y': ['4', '36.5', '23.5'],
  },
  {
    '5Y': ['4.5', '37.5', '23.5'],
  },
  {
    '5.5Y': ['5', '38', '24'],
  },
  {
    '6Y': ['5.5', '38.5', '24'],
  },
  {
    '6.5Y': ['6', '39', '24.5'],
  },
  {
    '7Y': ['6', '40', '25'],
  },
  {
    '7.5Y': ['6.5', '40.5', '25.5'],
  },
  {
    '8Y': ['7', '41', '26'],
  },
  {
    '8.5Y': ['7.5', '42', '26.5'],
  },
  {
    '9Y': ['8', '42.5', '27'],
  },
  {
    '9.5Y': ['8.5', '43', '27.5'],
  },
  {
    '10Y': ['9', '44', '28'],
  },
  {
    '10.5Y': ['9.5', '44.5', '28.5'],
  },
];

List<Map> nikeAndJordanPSSizes = [
  {
    '10.5C': ['10', '27.5', '17.2'],
  },
  {
    '11C': ['10.5', '28', '17.6'],
  },
  {
    '11.5C': ['11', '28.5', '18'],
  },
  {
    '12C': ['11.5', '29.5', '18.4'],
  },
  {
    '12.5C': ['12', '30', '18.8'],
  },
  {
    '13C': ['12.5', '31', '19.3'],
  },
  {
    '13.5C': ['13', '31.5', '19.7'],
  },
  {
    '1Y': ['13.5', '32', '20.1'],
  },
  {
    '1.5Y': ['1', '33', '20.5'],
  },
  {
    '2Y': ['1.5', '33.5', '20.9'],
  },
  {
    '2.5Y': ['2', '34', '21.4'],
  },
  {
    '3Y': ['2.5', '35', '21.8'],
  },
];

List<Map> nikeAndJordanTDSizes = [
  {
    '1C': ['0.5', '16', '9.1'],
  },
  {
    '2C': ['1.5', '17', '10'],
  },
  {
    '3C': ['2.5', '18.5', '10.8'],
  },
  {
    '4C': ['3.5', '19.5', '11.6'],
  },
  {
    '5C': ['4.5', '21', '12.5'],
  },
  {
    '6C': ['5.5', '22', '13.3'],
  },
  {
    '7C': ['6.5', '23.5', '14.2'],
  },
  {
    '8C': ['7.5', '25', '15'],
  },
  {
    '9C': ['8.5', '26', '15.9'],
  },
  {
    '10C': ['9.5', '27', '16.7'],
  },
];

List<Map> adidasYeezySizes = [
  {
    '3.5': ['3', '35 1/3', '21.5'],
  },
  {
    '4': ['3.5', '36', '22.1'],
  },
  {
    '4.5': ['4', '36 2/3', '22.5'],
  },
  {
    '5': ['4.5', '37 1/3', '22.9'],
  },
  {
    '5.5': ['5', '38', '23.3'],
  },
  {
    '6': ['5.5', '38 2/3', '23.8'],
  },
  {
    '6.5': ['6', '39 1/3', '24.2'],
  },
  {
    '7': ['6.5', '40', '24.6'],
  },
  {
    '7.5': ['7', '40 2/3', '25'],
  },
  {
    '8': ['7.5', '41 1/3', '25.5'],
  },
  {
    '8.5': ['8', '42', '25.9'],
  },
  {
    '9': ['8.5', '42 2/3', '26.3'],
  },
  {
    '9.5': ['9', '43 1/3', '26.7'],
  },
  {
    '10': ['9.5', '44', '27.1'],
  },
  {
    '10.5': ['10', '44 2/3', '27.6'],
  },
  {
    '11': ['10.5', '45 1/3', '28'],
  },
  {
    '11.5': ['11', '46', '28.4'],
  },
  {
    '12': ['11.5', '46 2/3', '28.8'],
  },
  {
    '12.5': ['12', '47 1/3', '29.3'],
  },
  {
    '13': ['12.5', '48', '29.7'],
  },
  {
    '13.5': ['13', '48 2/3', '30.1'],
  },
  {
    '14': ['13.5', '49 1/3', '30.5'],
  },
];

List<Map> adidasYeezyWomenSizes = [
  {
    '5': ['3.5', '36', '22.1'],
  },
  {
    '5.5': ['4', '36 2/3', '22.5'],
  },
  {
    '6': ['4.5', '37 1/3', '22.9'],
  },
  {
    '6.5': ['5', '38', '23.3'],
  },
  {
    '7': ['5.5', '38 2/3', '23.8'],
  },
  {
    '7.5': ['6', '39 1/3', '24.2'],
  },
  {
    '8': ['6.5', '40', '24.6'],
  },
  {
    '8.5': ['7', '40 2/3', '25'],
  },
  {
    '9': ['7.5', '41 1/3', '25.5'],
  },
  {
    '9.5': ['8', '42', '25.9'],
  },
  {
    '10': ['8.5', '42 2/3', '26.3'],
  },
  {
    '10.5': ['9', '43 1/3', '26.7'],
  },
  {
    '11': ['9.5', '44', '27.1'],
  },
  {
    '11.5': ['10', '44 2/3', '27.6'],
  },
  {
    '12': ['10.5', '45 1/3', '28'],
  },
  {
    '12.5': ['11', '46', '28.4'],
  },
  {
    '13': ['11.5', '46 2/3', '28.8'],
  },
  {
    '13.5': ['12', '47 1/3', '29.3'],
  },
  {
    '14': ['12.5', '48', '29.7'],
  },
  {
    '14.5': ['13', '48 2/3', '30.1'],
  },
  {
    '15': ['13.5', '49 1/3', '30.5'],
  },
  {
    '15.5': ['14', '50', '31'],
  },
];

List<Map> adidasYeezyKidsSizes = [
  {
    '10.5K': ['10K', '28', '16.6'],
  },
  {
    '11K': ['10.5K', '28.5', '17'],
  },
  {
    '11.5K': ['11K', '29', '17.4'],
  },
  {
    '12K': ['11.5K', '30', '17.8'],
  },
  {
    '12.5K': ['12K', '30.5', '18.3'],
  },
  {
    '13K': ['12.5K', '31', '18.7'],
  },
  {
    '13.5K': ['13K', '31.5', '19.1'],
  },
  {
    '1': ['13.5K', '32', '19.5'],
  },
  {
    '1.5': ['1', '33', '20'],
  },
  {
    '2': ['1.5', '33.5', '20.4'],
  },
  {
    '2.5': ['2', '34', '20.8'],
  },
  {
    '3': ['2.5', '35', '21.2'],
  },
  {
    '3.5': ['3', '35.5', '21.6'],
  },
];

List<Map> adidasYeezyInfantsSizes = [
  {
    '1K': ['0K', '16', '8.1'],
  },
  {
    '2K': ['1K', '17', '9'],
  },
  {
    '3K': ['2K', '18', '9.8'],
  },
  {
    '4K': ['3K', '19', '10.6'],
  },
  {
    '5K': ['4K', '20', '11.5'],
  },
  {
    '5.5K': ['5K', '21', '12.3'],
  },
  {
    '6K': ['5.5K', '22', '12.8'],
  },
  {
    '6.5K': ['6K', '23', '13.2'],
  },
  {
    '7K': ['6.5K', '23.5', '13.6'],
  },
  {
    '7.5K': ['7K', '24', '14'],
  },
  {
    '8K': ['7.5K', '25', '14.5'],
  },
  {
    '8.5K': ['8K', '25.5', '14.9'],
  },
  {
    '9K': ['8.5K', '26', '15.3'],
  },
  {
    '9.5K': ['9.5K', '27', '16.1'],
  },
  {
    '10K': ['9K', '26.5', '15.7'],
  },
];

List<Map> newBalanceSizes = [
  {
    '4': ['3.5', '36', '22'],
  },
  {
    '4.5': ['4', '36.5', '22.5'],
  },
  {
    '5': ['4.5', '37.5', '23'],
  },
  {
    '5.5': ['5', '38', '23.5'],
  },
  {
    '6': ['5.5', '38.5', '24'],
  },
  {
    '6.5': ['6', '39', '24.5'],
  },
  {
    '7': ['6.5', '40', '25'],
  },
  {
    '7.5': ['7', '40.5', '25.5'],
  },
  {
    '8': ['7.5', '41', '26'],
  },
  {
    '8.5': ['8', '42', '26.5'],
  },
  {
    '9': ['8.5', '42.5', '27'],
  },
  {
    '9.5': ['9', '43', '27.5'],
  },
  {
    '10': ['9.5', '44', '28'],
  },
  {
    '10.5': ['10', '44.5', '28.5'],
  },
  {
    '11': ['10.5', '45', '29'],
  },
  {
    '11.5': ['11', '45.5', '29.5'],
  },
  {
    '12': ['11.5', '46', '30'],
  },
  {
    '12.5': ['12', '47', '30.5'],
  },
  {
    '13': ['12.5', '47.5', '31'],
  },
];

List<Map> newBalanceWomenSizes = [
  {
    '4': ['3', '34', '21'],
  },
  {
    '4.5': ['3.5', '34.5', '21.5'],
  },
  {
    '5': ['4', '35', '22'],
  },
  {
    '5.5': ['4.5', '35.5', '22.5'],
  },
  {
    '6': ['5', '36', '23'],
  },
  {
    '6.5': ['5.5', '36.5', '23.5'],
  },
  {
    '7': ['6', '37.5', '24'],
  },
  {
    '7.5': ['6', '38', '24.5'],
  },
  {
    '8': ['6.5', '38.5', '25'],
  },
  {
    '8.5': ['7', '39', '25.5'],
  },
  {
    '9': ['7.5', '40', '26'],
  },
  {
    '9.5': ['8', '40.5', '26.5'],
  },
  {
    '10': ['8.5', '41', '27'],
  },
  {
    '10.5': ['9', '42', '27.5'],
  },
  {
    '11': ['9.5', '42.5', '28'],
  },
  {
    '11.5': ['10', '43', '28.5'],
  },
  {
    '12': ['10.5', '44', '29'],
  },
  {
    '12.5': ['11', '45', '29.5'],
  },
  {
    '13': ['11.5', '45.5', '30'],
  },
  {
    '13.5': ['12', '46', '30.5'],
  },
  {
    '14': ['12.5', '46.5', '31'],
  },
  {
    '15': ['13', '48', '32'],
  },
];

List<Map> newBalanceGSSizes = [
  {
    '3.5Y': ['3', '35.5', '9.1'],
  },
  {
    '4Y': ['3.5', '36', '10'],
  },
  {
    '4.5Y': ['4', '37', '10.8'],
  },
  {
    '5Y': ['4.5', '37.5', '11.6'],
  },
  {
    '5.5Y': ['5', '38', '12.5'],
  },
  {
    '6Y': ['5.5', '38.5', '13.3'],
  },
  {
    '6.5Y': ['6', '39.5', '14.2'],
  },
  {
    '7Y': ['6.5', '39.5', '15'],
  },
];

List<Map> newBalancePSSizes = [
  {
    '10.5': ['10', '28', '9.1'],
  },
  {
    '11C': ['10.5', '28.5', '10'],
  },
  {
    '11.5C': ['11', '29', '10.8'],
  },
  {
    '12C': ['11.5', '30', '11.6'],
  },
  {
    '12.5C': ['12', '30.5', '12.5'],
  },
  {
    '13': ['12.5', '31', '13.3'],
  },
  {
    '13.5C': ['13', '32', '14.2'],
  },
  {
    '1Y': ['13.5', '32.5', '15'],
  },
  {
    '1.5Y': ['1', '33', '15.9'],
  },
  {
    '2Y': ['1.5', '33.5', '16.7'],
  },
  {
    '2.5Y': ['2', '34.5', '17.2'],
  },
  {
    '3Y': ['2.5', '35', '17.6'],
  },
];

List<Map> newBalanceTDSizes = [
  {
    '1C': ['0.5', '16', '21'],
  },
  {
    '1.5C': ['1', '16.5', '21.5'],
  },
  {
    '2C': ['1.5', '17', '22'],
  },
  {
    '2.5C': ['2', '18', '22.5'],
  },
  {
    '3C': ['2.5', '18.5', '23'],
  },
  {
    '3.5C': ['3', '19', '23.5'],
  },
  {
    '4C': ['3.5', '20', '24'],
  },
  {
    '4.5C': ['4', '20.5', '24.5'],
  },
  {
    '5C': ['4.5', '21', '25'],
  },
  {
    '5.5C': ['5', '21.5', '25.5'],
  },
  {
    '6C': ['5.5', '22.5', '26'],
  },
  {
    '6.5C': ['6', '23', '26.5'],
  },
  {
    '7C': ['6.5', '23.5', '27'],
  },
  {
    '7.5C': ['7', '24', '27.5'],
  },
  {
    '8C': ['7.5', '25', '28'],
  },
  {
    '8.5C': ['8', '25.5', '28.5'],
  },
  {
    '9C': ['8.5', '26', '29'],
  },
  {
    '9.5C': ['9', '26.5', '29.5'],
  },
  {
    '10C': ['9.5', '27', '30'],
  },
];

bool isContainSizeList(String size, String sizeSlider) {
  List<Map> sizes = [];
  switch (sizeSlider) {
    case 'Regular':
      sizes = regularSizes;
      break;
    case 'Nike&Jordan':
      sizes = nikeAndJordanSizes;
      break;
    case 'Nike&JordanWomen':
      sizes = nikeAndJordanWomenSizes;
      break;
    case 'Nike&Jordan(GS)':
      sizes = nikeAndJordanGSSizes;
      break;
    case 'Nike&Jordan(PS)':
      sizes = nikeAndJordanPSSizes;
      break;
    case 'Nike&Jordan(TD)':
      sizes = nikeAndJordanTDSizes;
      break;
    case 'Adidas&Yeezy':
      sizes = adidasYeezySizes;
      break;
    case 'Adidas&YeezyWomen':
      sizes = adidasYeezyWomenSizes;
      break;
    case 'Adidas&YeezyKids':
      sizes = adidasYeezyKidsSizes;
      break;
    case 'Adidas&YeezyInfants':
      sizes = adidasYeezyInfantsSizes;
      break;
    case 'NewBalance':
      sizes = newBalanceSizes;
      break;
    case 'NewBalanceWomen':
      sizes = newBalanceWomenSizes;
      break;
    case 'NewBalance(GS)':
      sizes = newBalanceGSSizes;
      break;
    case 'NewBalance(TD)':
      sizes = newBalanceTDSizes;
      break;
    case 'NewBalance(PS)':
      sizes = newBalancePSSizes;
      break;
    default:
      {
        sizes = regularSizes;
      }
      break;
  }
  for (var s in sizes) {
    if (s.keys.first
            .toString()
            .replaceAll('Y', '')
            .replaceAll('C', '')
            .replaceAll('K', '') ==
        size) {
      return true;
    }
  }

  return false;
}

String searchSize(String type, String key, String sizeSlider) {
  List<Map> sizes = [];
  switch (sizeSlider) {
    case 'Regular':
      sizes = regularSizes;
      break;
    case 'Nike&Jordan':
      sizes = nikeAndJordanSizes;
      break;
    case 'Nike&JordanWomen':
      sizes = nikeAndJordanWomenSizes;
      break;
    case 'Nike&Jordan(GS)':
      sizes = nikeAndJordanGSSizes;
      break;
    case 'Nike&Jordan(PS)':
      sizes = nikeAndJordanPSSizes;
      break;
    case 'Nike&Jordan(TD)':
      sizes = nikeAndJordanTDSizes;
      break;
    case 'Adidas&Yeezy':
      sizes = adidasYeezySizes;
      break;
    case 'Adidas&YeezyWomen':
      sizes = adidasYeezyWomenSizes;
      break;
    case 'Adidas&YeezyKids':
      sizes = adidasYeezyKidsSizes;
      break;
    case 'Adidas&YeezyInfants':
      sizes = adidasYeezyInfantsSizes;
      break;
    case 'NewBalance':
      sizes = newBalanceSizes;
      break;
    case 'NewBalanceWomen':
      sizes = newBalanceWomenSizes;
      break;
    case 'NewBalance(GS)':
      sizes = newBalanceGSSizes;
      break;
    case 'NewBalance(TD)':
      sizes = newBalanceTDSizes;
      break;
    case 'NewBalance(PS)':
      sizes = newBalancePSSizes;
      break;
    default:
      {
        sizes = regularSizes;
      }
      break;
  }

  Iterable<dynamic> temp =
      sizes.firstWhere((element) => element.keys.first == key).values;

  return type == 'UK'
      ? temp.first[0].toString()
      : type == 'EU'
          ? temp.first[1].toString()
          : temp.first[2].toString();
}

String getUSSize(String size, String sizeSlider) {
  List<Map> sizes = [];
  switch (sizeSlider) {
    case 'Regular':
      sizes = regularSizes;
      break;
    case 'Nike&Jordan':
      sizes = nikeAndJordanSizes;
      break;
    case 'Nike&JordanWomen':
      sizes = nikeAndJordanWomenSizes;
      break;
    case 'Nike&Jordan(GS)':
      sizes = nikeAndJordanGSSizes;
      break;
    case 'Nike&Jordan(PS)':
      sizes = nikeAndJordanPSSizes;
      break;
    case 'Nike&Jordan(TD)':
      sizes = nikeAndJordanTDSizes;
      break;
    case 'Adidas&Yeezy':
      sizes = adidasYeezySizes;
      break;
    case 'Adidas&YeezyWomen':
      sizes = adidasYeezyWomenSizes;
      break;
    case 'Adidas&YeezyKids':
      sizes = adidasYeezyKidsSizes;
      break;
    case 'Adidas&YeezyInfants':
      sizes = adidasYeezyInfantsSizes;
      break;
    case 'NewBalance':
      sizes = newBalanceSizes;
      break;
    case 'NewBalanceWomen':
      sizes = newBalanceWomenSizes;
      break;
    case 'NewBalance(GS)':
      sizes = newBalanceGSSizes;
      break;
    case 'NewBalance(TD)':
      sizes = newBalanceTDSizes;
      break;
    case 'NewBalance(PS)':
      sizes = newBalancePSSizes;
      break;
    default:
      {
        sizes = regularSizes;
      }
      break;
  }
  for (var s in sizes) {
    String keyStr = s.keys.first.toString();
    if (keyStr.replaceAll('Y', '').replaceAll('C', '').replaceAll('K', '') ==
        size) {
      return keyStr;
    }
  }

  return "";
}

List getMainSizeData(List data, String sizeSlider) => cleanList(data
    .map((e) => e.isNotEmpty &&
            e['Size'] != null &&
            isNumber(e['Size']) &&
            isContainSizeList(e['Size'], sizeSlider)
        ? getUSSize(e["Size"], sizeSlider)
        : "")
    .toList());

List getUKSize(List data, String sizeSlider) {
  return data.map((e) => searchSize('UK', e, sizeSlider)).toList();
}

List getEUSize(List data, String sizeSlider) {
  return data.map((e) => searchSize('EU', e, sizeSlider)).toList();
}

List cleanList(List data) {
  List temp = [];
  for (var element in data) {
    if (element == '' || element == null || element == {} || element == []) {
      continue;
    } else {
      temp.add(element);
    }
  }

  return temp;
}

String getPricePerSize(String size, List data) {
  String result = '';
  for (var element in data) {
    if (element['Size'] ==
        size.replaceAll('Y', '').replaceAll('C', '').replaceAll('K', '')) {
      result = element['Product']['Price'].toString();
    }
  }

  return result;
}

List getProductsPerSize(String size, List productSizes) {
  selectedSize = size;
  // calendarProductSelectedSize = size;
  List result = [];
  for (var element in productSizes) {
    if (element['Size'] ==
        size.replaceAll('Y', '').replaceAll('C', '').replaceAll('K', '')) {
      result = element['Products'];
      break;
    } else {
      continue;
    }
  }
  result.sort((a, b) => a['Price'].compareTo(b['Price']));

  return result;
}

getProductDetail(String sku) async {
  List<Map> productDetail = [];
  var result = await getData('https://api.sneaks4sure.com/productpage/$sku');
  productDetail = jsonDecode(result)['data']['products']
      .map((e) {
        return {
          'ProductSKU': e['ProductSKU'],
          'ProductName': e['ProductName'],
          'ProductImage': e['ProductImage'],
          'ProductBrand': e['ProductBrand'],
          'ProductCat': e['ProductCat'],
          'ProductRetailPrice': e['ProductRetailPrice'],
          'ProductReleaseDate': e['ProductReleaseDate'],
          'ProductColorWay': e['ProductColorWay'],
          'ProductImageOOTD': e['ProductImageOOTD'],
          'ProductSize': e['ProductSize'],
          'ProductSizeBest': e['ProductSizeBest'],
          'ProductImage360': e['ProductImage360'],
          '360Pictures': e['ProductImage360'] != Null,
          'ResellValuePourcent': e['ResellValuePourcent'],
          'ResellValueProfit': e['ResellValueProfit'],
          'ResellValueState': e['ResellValueState'],
          'sizeSlider': e['sizeSlider'],
          'ProductLike': e['ProductLike'],
          'ProductDislike': e['ProductDislike'],
        };
      })
      .toList()
      .cast<Map>();

  return productDetail.isNotEmpty ? productDetail[0] : {};
}

void scrollDown(ScrollController controller, double position) {
  SchedulerBinding.instance.addPostFrameCallback((_) {
    controller.jumpTo(position);
  });
}

double calendarOffset = 0.0;

Future<String?> uploadImage(filepath, url) async {
  var request = http.MultipartRequest('POST', Uri.parse(url));
  request.files.add(await http.MultipartFile.fromPath('image', filepath));
  var res = await request.send();

  return res.reasonPhrase;
}

Future<String> postRequest(
  String url,
  Map data, [
  String contentType = 'application/json',
]) async {
  Uri uri = Uri.parse(url);
  String body = jsonEncode(data);
  String jwtToken = prefs.getString("jwtToken") ?? "";
  // try {
  var response = await http.post(
    uri,
    headers: {
      'Content-Type': contentType,
      'Token': jwtToken,
    },
    body: body,
  );

  return response.statusCode == 200
      ? response.body
      : 'ERROR->${response.statusCode}';
}

class AppColors {
  AppColors._();
  static const Color lightblack = Color(0xff313036);
  static const Color red = Color(0xffFF2323);
  static const Color white = Color(0xffffffff);
  static const Color lightgrey = Color(0xffE5E5E5);
  static const Color black = Color(0xff000000);
  static const Color lightred = Color(0xffF55E5E);
  static const Color green = Color(0xFF21ED8B);
  static const Color darkgrey = Color(0xffE4E4E4);
}

Future<String> fileUpload(
  String url,
  String filePath, [
  Map fieldData = const {},
]) async {
  Uri uri = Uri.parse(url);
  Map<String, String> headers = {"Token": prefs.getString("jwtToken") ?? ""};
  var request = http.MultipartRequest(
    'POST',
    uri,
  );
  request.headers.addAll(headers);
  request.files.add(http.MultipartFile(
    '',
    File(filePath).readAsBytes().asStream(),
    File(filePath).lengthSync(),
    filename: filePath.split("/").last,
  ));
  for (var element in fieldData.keys) {
    request.fields[element] = fieldData[element];
  }

  var response = await http.Response.fromStream(await request.send());

  return response.statusCode == 200
      ? response.body
      : 'ERROR->${response.statusCode}';
}

Future<File> getImageFileFromAssets(String path) async {
  final byteData = await rootBundle.load('assets/$path');

  Directory appDocDir = await getApplicationDocumentsDirectory();
  String imagesAppDirectory = appDocDir.path;
  final file = await File('$imagesAppDirectory/$path').create(recursive: true);

  await file.writeAsBytes(byteData.buffer
      .asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));

  return file;
}

Future<void> incrementProductHit(String productSku) async {
  await getData(
    'https://api.sneaks4sure.com/incrementHitCount/$productSku',
  );
}

String getPriceWithCurrency(var euPrice) {
  String userDefaultCurrency =
      prefs.getString("defaultCurrency") ?? listCurrencies[0];
  String euPriceStr = euPrice.toString();
  euPriceStr = euPriceStr
      .replaceAll(".00", "")
      .replaceAll("-", "")
      .replaceAll("£", "")
      .replaceAll("€", "")
      .replaceAll(r"$", "")
      .replaceAll("¥", "");

  var formatter = NumberFormat('#,###');
  if (euPriceStr.isEmpty || euPrice == null || euPriceStr == "null") {
    return "";
  }

  switch (userDefaultCurrency) {
    case '€ - EUR':
      return '€ ${formatter.format(int.parse(euPrice.toString())).replaceAll(',', ' ')}';
    case r'$ - USD':
      return r'$ ' +
          formatter
              .format((double.parse(euPrice.toString()) *
                      (currencyRate["USD"] / currencyRate["EUR"]))
                  .round())
              .replaceAll(',', ' ');
    case r'$ - CAD':
      return r'$ ' +
          formatter
              .format((double.parse(euPrice.toString()) *
                      (currencyRate["CAD"] / currencyRate["EUR"]))
                  .round())
              .replaceAll(',', ' ');
    case '£ - GBP':
      return '£ ${formatter.format((double.parse(euPrice.toString()) * (currencyRate["GBP"] / currencyRate["EUR"])).round()).replaceAll(',', ' ')}';
    case '¥ - YEN':
      return '¥ ${formatter.format((double.parse(euPrice.toString()) * (currencyRate["JPY"] / currencyRate["EUR"])).round()).replaceAll(',', ' ')}';
    case '¥ - CNY':
      return '¥ ${formatter.format((double.parse(euPrice.toString()) * (currencyRate["CNY"] / currencyRate["EUR"])).round()).replaceAll(',', ' ')}';
  }

  return '€ ${formatter.format(int.parse(euPrice)).replaceAll(',', ' ')}';
}

String getCurrencyRate(String type) {
  switch (type) {
    case '€ - EUR':
      return '$type ${currencyRate["EUR"]}';
    case r'$ - USD':
      return '$type ${currencyRate["USD"]}';
    case r'$ - CAD':
      return '$type ${currencyRate["CAD"]}';
    case '£ - GBP':
      return '$type ${currencyRate["GBP"]}';
    case '¥ - YEN':
      return '$type ${currencyRate["JPY"]}';
    case '¥ - CNY':
      return '$type ${currencyRate["CNY"]}';
  }

  return type;
}

List<Color> gradientColors = [
  Colors.red,
  Colors.white,
];

Widget leftTitleWidgets(double value, TitleMeta meta) {
  if (kDebugMode) {
    print(meta);
  }
  const style = TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: 10,
    color: Colors.black54,
  );
  String text;
  text = (value.toInt() % 150 == 0) ? getPriceWithCurrency(value.toInt()) : "";

  return Text(text, style: style, textAlign: TextAlign.left);
}

Widget bottomTitleWidgets(double value, TitleMeta meta) {
  DateFormat format = DateFormat('MM.dd');
  const style = TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: 10,
    color: Colors.black54,
  );
  Widget text = const Text('', style: style);
  try {
    for (Map i in xAxisData) {
      if ((value.toDouble() - double.parse(i["xVal"].toString())).abs() <
          0.05) {
        text = Text(
          format.format(DateTime.parse(i["date"].toString())),
          style: style,
        );
      }
    }
    // ignore: empty_catches
  } catch (e) {}

  return SideTitleWidget(
    axisSide: meta.axisSide,
    child: text,
  );
}

getSuitableIndex(double price, List<Map> sizeData) {
  List<double> diffArray = [];
  for (var i = 0; i < sizeData.length; i++) {
    var diffVal = (double.parse(sizeData[i]['Price'].toString()) - price).abs();
    diffArray.add(diffVal);
  }
  diffArray.sort((a, b) => a.compareTo(b));
  for (var i = 0; i < sizeData.length; i++) {
    double dataPrice = double.parse(sizeData[i]['Price'].toString());
    if ((dataPrice - (price + diffArray.first)).abs() < 0.1 ||
        (dataPrice - (price - diffArray.first)).abs() < 0.1) {
      return i;
    }
  }
}

LineChartData chartMainData(List<Map> sizeData) {
  List<FlSpot> spotData = [];
  xAxisData = [];
  sizeData = sizeData
      .where((e) => e['Price'] != null && e['Price'].toString() != "")
      .toList()
      .cast<Map<dynamic, dynamic>>();
  sizeData.sort(
    (a, b) {
      return int.tryParse(a['Price'].toString()) != null &&
              int.tryParse(b['Price'].toString()) != null
          ? double.parse(a['Price'].toString())
              .compareTo(double.parse(b['Price'].toString()))
          : -1;
    },
  );
  String firstValueStr = sizeData.first['Price'].toString();
  String lastValueStr = sizeData.last['Price'].toString();
  //filter medium 5 values
  double diff = double.parse(lastValueStr) - double.parse(firstValueStr);
  diff = diff / 5;
  double maxY = 0;
  double minY = 0;
  try {
    minY = double.parse(firstValueStr) - 30;
    maxY = double.parse(lastValueStr) + 30;
  } catch (e) {}

  List<Map> filteredSizeData = [];
  if (sizeData.length > 5) {
    for (var i = 0; i < 5; i++) {
      if (i == 0) {
        filteredSizeData.add(sizeData[0]);
        continue;
      }
      if (i == 4) {
        filteredSizeData.add(sizeData[sizeData.length - 1]);
        continue;
      }
      int index = getSuitableIndex(
        double.parse(sizeData.first['Price'].toString()) + (i * diff),
        sizeData,
      );
      filteredSizeData.add(sizeData[index]);
    }
    sizeData = filteredSizeData;
  }

  sizeData.sort(((a, b) {
    return a['PriceHistoryDate']
        .toString()
        .compareTo(b['PriceHistoryDate'].toString());
  }));

  final first = DateTime.parse(sizeData[0]["PriceHistoryDate"]);
  final last =
      DateTime.parse(sizeData[sizeData.length - 1]["PriceHistoryDate"]);

  final difference = last.difference(first).inDays;

  for (var i = 0; i < sizeData.length; i++) {
    try {
      double y = double.parse(sizeData[i]["Price"]);
      double x = 0;
      final temp = DateTime.parse(sizeData[i]["PriceHistoryDate"]);
      final diff = temp.difference(first).inDays;
      x = difference == 0 ? 0 : (10 / difference) * diff;
      spotData.add(FlSpot(x, y));
      xAxisData.add({"xVal": x, "date": sizeData[i]["PriceHistoryDate"]});
      // ignore: empty_catches
    } catch (e) {}
  }

  return LineChartData(
    gridData: FlGridData(
      show: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      rightTitles: AxisTitles(
        sideTitles: SideTitles(showTitles: false),
      ),
      topTitles: AxisTitles(
        sideTitles: SideTitles(showTitles: false),
      ),
      leftTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          interval: 1,
          getTitlesWidget: leftTitleWidgets,
          reservedSize: 35,
        ),
      ),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          reservedSize: 30,
          interval: 0.1,
          getTitlesWidget: bottomTitleWidgets,
        ),
      ),
    ),
    borderData: FlBorderData(
      show: false,
    ),
    minX: 0,
    maxX: 10,
    minY: minY,
    maxY: maxY,
    lineBarsData: [
      LineChartBarData(
        spots: spotData,
        isCurved: false,
        color: Colors.red,
        barWidth: 2,
        isStrokeCapRound: true,
        dotData: FlDotData(
          show: false,
        ),
        belowBarData: BarAreaData(
          show: true,
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors:
                gradientColors.map((color) => color.withOpacity(0.3)).toList(),
          ),
        ),
      ),
    ],
    lineTouchData: LineTouchData(
      touchTooltipData: LineTouchTooltipData(
        tooltipBgColor: Colors.white,
        getTooltipItems: (List<LineBarSpot> touchedBarSpots) {
          return touchedBarSpots.map((barSpot) {
            final flSpot = barSpot;
            DateFormat format = DateFormat('MM.dd');
            String dateStr = "";
            for (Map i in xAxisData) {
              if (flSpot.x.toDouble() == double.parse(i["xVal"].toString())) {
                dateStr = format.format(DateTime.parse(i["date"].toString()));
              }
            }

            return LineTooltipItem(
              getPriceWithCurrency(flSpot.y.toInt().toString()),
              const TextStyle(),
              children: [TextSpan(text: "\n $dateStr")],
            );
          }).toList();
        },
      ),
    ),
  );
}

getPriceHistory(String productSKU) async {
  List<Map> historyData = [];
  var result = await getData('https://api.sneaks4sure.com/history/$productSKU');
  historyData = jsonDecode(result)['data']['history']
      .map((e) {
        return {
          'DateTime': e['DateTime'],
          'ProductSKU': e['ProductSKU'],
          'History': e['History'],
        };
      })
      .toList()
      .cast<Map>();

  return historyData;
}

Widget renderPriceHistoryChart(
  double width,
  double height,
  List<Map> apiData,
  String selectedSize,
  BuildContext context,
) {
  selectedSize = selectedSize
      .split("/")[0]
      .replaceAll(" ", "")
      .replaceAll("US", "")
      .replaceAll("Y", "")
      .replaceAll("K", "")
      .replaceAll("C", "");
  if (apiData.isNotEmpty) {
    List<Map> sizeData = apiData[0]["History"]
        .map((e) {
          String price = "";
          for (var i = 0; i < e["PriceHistorySize"].length; i++) {
            if (selectedSize == e["PriceHistorySize"][i][0].toString()) {
              price = e["PriceHistorySize"][i][1].toString();
            }
          }

          return {
            "PriceHistoryDate": e["PriceHistoryDate"],
            "product_lowest_price": e["product_lowest_price"],
            "Price": price.toString(),
          };
        })
        .toList()
        .cast<Map>();

    sizeData = sizeData.toSet().toList();

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Stack(
        children: [
          Align(
            child: Container(
              width: width,
              height: height,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 246, 246, 246),
                borderRadius: BorderRadius.circular(20),
              ),
              child: AspectRatio(
                aspectRatio: 1.7,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15, 30, 30, 10),
                  child: LineChart(
                    chartMainData(sizeData),
                  ),
                ),
              ),
            ),
          ),
          Align(
            alignment: const Alignment(-0.68, -0.5),
            child: Container(
              padding: const EdgeInsets.only(top: 15),
              constraints: const BoxConstraints(maxWidth: 80),
              child: Text(
                AppLocalizations.of(context).saerch_priceHistory,
                textAlign: TextAlign.center,
                style: robotoStyle(FontWeight.w900, Colors.black26, 12, null),
                maxLines: 2,
                softWrap: true,
              ),
            ),
          ),
        ],
      ),
    );
  } else {
    return Container();
  }
}

likeOrDislike(String sku, int type) async {
  Map result = {};
  List<String> likeOrDisLikeList = prefs.getStringList("likeOrDislike") ?? [];
  if (likeOrDisLikeList.indexOf("$sku:type:${type.toString()}").isNegative) {
    if (likeOrDisLikeList
        .indexOf("$sku:type:${(type - 1).abs().toString()}")
        .isNegative) {
      //increase
      likeOrDisLikeList.add("$sku:type:${type.toString()}");
      prefs.setStringList("likeOrDislike", likeOrDisLikeList);
      var response = await getData(
        "https://api.sneaks4sure.com/like-dislike?sku=${sku}&type=${type}",
      );
      result = jsonDecode(response)['data'];
      if (result["product_like"] == null) {
        result["product_like"] = 0;
      }
      if (result["product_dislike"] == null) {
        result["product_dislike"] = 0;
      }
    } else {
      //recover type - 1
      likeOrDisLikeList.remove("$sku:type:${(type - 1).abs()}");
      prefs.setStringList("likeOrDislike", likeOrDisLikeList);
      var response = await getData(
        "https://api.sneaks4sure.com/recover-like-dislike?sku=${sku}&type=${(type - 1).abs()}",
      );
      result = jsonDecode(response)['data'];
      if (result["product_like"] == null) {
        result["product_like"] = 0;
      }
      if (result["product_dislike"] == null) {
        result["product_dislike"] = 0;
      }
    }
  }

  return result;
}

Widget likeAndDislikeWidget(
  // ignore: non_constant_identifier_names
  String ProductSKU,
  int like,
  int dislike,
  Function increaseProductLike,
) {
  String likeStr =
      like == 0 ? "0%" : "${((like * 100) / (like + dislike)).ceil()}%";
  String dislikeStr =
      dislike == 0 ? "0%" : "${((dislike * 100) / (like + dislike)).ceil()}%";

  TextStyle thickStyle = robotoStyle(FontWeight.w900, Colors.white, 20, null);

  return Container(
    padding: const EdgeInsets.only(top: 10, bottom: 10),
    width: 180,
    child: Stack(
      alignment: Alignment.center,
      children: [
        like < dislike
            ? Align(
                alignment: const Alignment(-0.7, 0),
                child: InkWell(
                  onTap: () {
                    increaseProductLike(ProductSKU, 0);
                  },
                  child: Container(
                    width: 110,
                    padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFF21ED8B),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Transform(
                          alignment: Alignment.center,
                          transform: Matrix4.rotationY(math.pi),
                          child: const Icon(
                            FontAwesomeIcons.thumbsUp,
                            size: 22,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          likeStr,
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: thickStyle,
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : Align(
                alignment: const Alignment(0.7, 0),
                child: InkWell(
                  onTap: () {
                    increaseProductLike(ProductSKU, 1);
                  },
                  child: Container(
                    width: 110,
                    padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                    decoration: BoxDecoration(
                      color: const Color(0xffF55E5E),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          dislikeStr,
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: thickStyle,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        const Icon(
                          FontAwesomeIcons.thumbsDown,
                          size: 22,
                          color: Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
        !(like < dislike)
            ? Align(
                alignment: const Alignment(-0.7, 0),
                child: InkWell(
                  onTap: () {
                    increaseProductLike(ProductSKU, 0);
                  },
                  child: Container(
                    width: 110,
                    padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFF21ED8B),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Transform(
                          alignment: Alignment.center,
                          transform: Matrix4.rotationY(math.pi),
                          child: const Icon(
                            FontAwesomeIcons.thumbsUp,
                            size: 22,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          likeStr,
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: thickStyle,
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : Align(
                alignment: const Alignment(0.7, 0),
                child: InkWell(
                  onTap: () {
                    increaseProductLike(ProductSKU, 1);
                  },
                  child: Container(
                    width: 110,
                    padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                    decoration: BoxDecoration(
                      color: const Color(0xffF55E5E),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          dislikeStr,
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: thickStyle,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        const Icon(
                          FontAwesomeIcons.thumbsDown,
                          size: 22,
                          color: Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      ],
    ),
  );
}

s4sSocialShare(String deepLink) {
  Share.share(deepLink, subject: "Sneaks4Sure");
}

Widget returnOfflineWidget(BuildContext context) {
  return Scaffold(
    body: Column(
      children: [
        Expanded(
          child: Column(
            children: [
              SizedBox(height: MediaQuery.of(context).padding.top + 20),
              Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      height: 40,
                      child: Image.asset(
                        'assets/etc/splash-cropped.png',
                        fit: BoxFit.fitHeight,
                      ),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Column(
                        children: [
                          SizedBox(
                            height: 70,
                            child: Text(
                              "Oops!",
                              style: robotoStyle(
                                  FontWeight.w900,
                                  const Color.fromARGB(255, 49, 48, 54),
                                  50,
                                  null),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(top: 10),
                            child: Text(
                              "There is no Internet connection",
                              style: robotoStyle(
                                FontWeight.w400,
                                const Color.fromARGB(255, 49, 48, 54),
                                16,
                                null,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(top: 25, bottom: 25),
                            child: Image.asset(
                              'assets/etc/no-signal.png',
                              height: 120,
                              fit: BoxFit.fitHeight,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                              top: 10,
                              left: 50,
                              right: 50,
                            ),
                            child: Text(
                              "Please check your Internet connection",
                              textAlign: TextAlign.center,
                              style: robotoStyle(
                                FontWeight.w900,
                                const Color.fromARGB(255, 49, 48, 54),
                                28,
                                null,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                              top: 30,
                            ),
                            child: buildSimpleButton(
                              "Try Again",
                              () {
                                if (kDebugMode) {
                                  print("try again clicked!");
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

void navigateToTargetPage(BuildContext context, String path) {
  Navigator.pushNamed(
    context,
    path,
  );
}

void handleDynamicPath(BuildContext context, String path, String? sku) async {
  switch (path) {
    case "/Home":
      navigateToTargetPage(context, path);
      break;
    case "/Calendar":
      navigateToTargetPage(context, path);
      break;
    case "/Search":
      navigateToTargetPage(context, path);
      break;
    case "/Restock":
      navigateToTargetPage(context, path);
      break;
    case "/Account":
      navigateToTargetPage(context, path);
      break;
    case "/SizeGuide":
      navigateToTargetPage(context, path);
      break;
    case "/MapView":
      navigateToTargetPage(context, path);
      break;
    case "/AboutUS":
      navigateToTargetPage(context, path);
      break;
    case "/CalendarDetail":
      calendarProductDetail = await getProductDetail(sku ?? "");
      navigateToTargetPage(context, path);
      break;
    case "/ProductDetail":
      productDetail = await getProductDetail(sku ?? "");
      navigateToTargetPage(context, path);
      break;
  }
}

void initDynamicLinks(BuildContext context) async {
  await Future.delayed(Duration(seconds: 3));
  var data = await FirebaseDynamicLinks.instance.getInitialLink();
  var deepLink = data?.link;
  final queryParams = deepLink!.queryParameters;
  String path = deepLink.path;
  print("deepLink =====> ${path}");
  String? sku;
  if (queryParams.length > 0) {
    sku = queryParams["sku"];
    print("sku ====> ${sku}");
  }
  handleDynamicPath(context, path, sku);

  FirebaseDynamicLinks.instance.onLink.listen((dynamicLink) {
    var deepLink = dynamicLink?.link;
    debugPrint('DynamicLinks onLink ${deepLink!.path}');
    final queryParams = deepLink!.queryParameters;
    String? sku;
    if (queryParams.length > 0) {
      sku = queryParams["sku"];
      print("sku ====> ${sku}");
    }
    String path = deepLink.path;
    handleDynamicPath(context, path, sku);
  });
}

Future<String> createDynamicLink(String path) async {
  DynamicLinkParameters parameters = DynamicLinkParameters(
    uriPrefix: "https://s4smobileapp.page.link",
    link: Uri.parse("https://sneaks4sure.com$path"),
    androidParameters: const AndroidParameters(
      packageName: "com.alx.s4s_mobileapp",
    ),
    iosParameters: const IOSParameters(
      bundleId: "com.alx.sneaks4sure",
      appStoreId: "6445998208",
    ),
  );
  var dynamicLink =
      await FirebaseDynamicLinks.instance.buildShortLink(parameters);

  if (kDebugMode) {
    print("dynamic link ===>${path} ===>  ${dynamicLink.shortUrl}");
  }

  return dynamicLink.shortUrl.toString();
}
