// ignore_for_file: unused_local_variable

import 'dart:async';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

final List<String> listLanguages = [
  'English',
  'French',
];

class LanguageSelect extends StatefulWidget {
  const LanguageSelect({Key? key}) : super(key: key);

  @override
  State<LanguageSelect> createState() => _LanguageSelectState();
}

class _LanguageSelectState extends State<LanguageSelect> {
  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;
  late VideoPlayerController _splashVideoController;
  String? defaultLanguage;

  setSplashVideoSetting() {
    VideoPlayerOptions videoPlayerOptions =
        VideoPlayerOptions(mixWithOthers: true);
    _splashVideoController = VideoPlayerController.asset(
      "assets/Launch_Page_Translation.mp4",
      videoPlayerOptions: videoPlayerOptions,
    );
    _splashVideoController.setLooping(true);
    _splashVideoController.initialize().then((_) {
      _splashVideoController.play();
    });
  }

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          print('Data connection is available.');
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          print('You are disconnected from the internet.');
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  _getVideoBackground() {
    return Align(
      alignment: Alignment.center,
      child: AnimatedOpacity(
        opacity: 1.0,
        duration: const Duration(milliseconds: 1000),
        child: AspectRatio(
          aspectRatio: 9 / 16,
          child: VideoPlayer(_splashVideoController),
        ),
      ),
    );
  }

  Widget myLanguageSelectDropDownButton(
    Icon icon,
    String title,
    List<String> list,
    String? defaultValue,
    double? dropDownWidth,
    void Function(Object? value) func,
  ) {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        isExpanded: true,
        hint: Row(
          children: [
            icon,
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: Text(
                title,
                style: robotoStyle(
                  FontWeight.w900,
                  const Color(0xFF313036),
                  18,
                  null,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        items: list
            .map(
              (item) => DropdownMenuItem<String>(
                value: item,
                child: Row(
                  children: [
                    // icon,
                    const SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Text(
                        item,
                        style: robotoStyle(
                            FontWeight.w400,
                            const Color.fromARGB(255, 107, 107, 107),
                            null,
                            null),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
        value: defaultValue,
        onChanged: (value) {
          func(value);
        },
        icon: const Icon(
          Icons.arrow_drop_down_rounded,
          size: 30,
          color: Color.fromARGB(255, 49, 48, 54),
        ),
        buttonHeight: 50,
        buttonWidth: dropDownWidth ?? 260,
        buttonPadding: const EdgeInsets.only(left: 10, right: 10),
        buttonDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100),
          color: Colors.white,
        ),
        buttonElevation: 0,
        itemHeight: 40,
        dropdownMaxHeight: 200,
        dropdownWidth: dropDownWidth ?? 260,
        dropdownDecoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
        ),
        scrollbarRadius: const Radius.circular(40),
        scrollbarThickness: 5,
        scrollbarAlwaysShow: false,
      ),
    );
  }

  _getLangugeSelector() {
    return Align(
      alignment: Alignment.center,
      child: Container(
        width: 235,
        height: 190,
        padding: EdgeInsets.only(
          left: 25,
          right: 25,
        ),
        decoration: BoxDecoration(
          color: Color(0xFFF55E5E),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Language",
              textAlign: TextAlign.center,
              style: robotoStyle(
                FontWeight.w900,
                Colors.white,
                30,
                null,
              ),
            ),
            Text(
              "What's your preference?",
              textAlign: TextAlign.center,
              style: robotoStyle(
                FontWeight.w400,
                Colors.white,
                12,
                null,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            myLanguageSelectDropDownButton(
              const Icon(
                Icons.language,
                size: 25,
                color: Color(0xFF313036),
              ),
              "Select",
              listLanguages,
              defaultLanguage,
              180,
              (value) {
                setState(() {
                  defaultLanguage = value as String;
                });
                int languageIndex = listLanguages.indexOf(value as String);
                globalCurrentLocale.value =
                    AppLocalizations.supportedLocales[languageIndex];
                prefs.setBool('setLanguage', true);
                prefs.setString("language", value.toString());
                String nextRoute = prefs.getBool('loggedin') != true
                    ? '/Landing'
                    : prefs.getBool('savedProfile') == true
                        ? '/Home'
                        : '/SaveProfile';
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  nextRoute,
                  (route) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    checkNetworkStatus();
    setSplashVideoSetting();
    super.initState();
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(color: Colors.black),
        child: Stack(
          children: <Widget>[
            _getVideoBackground(),
            _getLangugeSelector(),
          ],
        ),
      ),
    );
  }
}
