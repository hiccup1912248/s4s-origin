import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

import '../tools/functions.dart';

String storeAddress = "";
double latitude = 0.0;
double longitude = 0.0;

class GoolgMapView extends StatefulWidget {
  const GoolgMapView({Key? key}) : super(key: key);

  @override
  State<GoolgMapView> createState() => _GoolgMapView();
}

class _GoolgMapView extends State<GoolgMapView> {
  Completer<GoogleMapController> _controller = Completer();

  void _onMapCreated(GoogleMapController controller) {
    _controller.complete(controller);
  }

  final CameraPosition _initialPosition = CameraPosition(
    target: LatLng(latitude, longitude),
    zoom: 18,
  );

  final Set<Marker> _markers = Set();

  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          print('Data connection is available.');
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          print('You are disconnected from the internet.');
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    checkNetworkStatus();
    setState(() {
      _markers.add(
        Marker(
          markerId: MarkerId(storeAddress),
          position: LatLng(latitude, longitude),
          infoWindow: InfoWindow(
            title: storeAddress,
          ),
        ),
      );
    });
    super.initState();
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }
    return Scaffold(
        appBar: AppBar(
          title: Text(storeAddress),
          centerTitle: true,
        ),
        body: Stack(
          children: <Widget>[
            GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: _initialPosition,
              markers: _markers,
            ),
          ],
        ));
  }
}
