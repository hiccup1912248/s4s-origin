import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:s4s_mobileapp/calendar/calendar_detail_widget.dart';
import 'package:s4s_mobileapp/calendar/calendar_widget.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:assorted_layout_widgets/assorted_layout_widgets.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:cached_network_image/cached_network_image.dart';
import "dart:async";
import 'package:s4s_mobileapp/product/product_detail_widget.dart';
import 'package:video_player/video_player.dart';
import 'package:slide_countdown/slide_countdown.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'dart:ui';

class TrendWidget extends StatefulWidget {
  const TrendWidget({Key? key}) : super(key: key);

  @override
  State<TrendWidget> createState() => _TrendWidgetState();
}

class _TrendWidgetState extends State<TrendWidget> {
  final ScrollController scrollTrend = ScrollController();
  final PageController controllerNews = PageController();
  int max = 2;
  List listHeats = [];
  List listRecently = [];
  List listNews = [];
  List listTops = [];
  Timer? timer;
  Timer? heatsScrollTimer;
  String logoPath = '';
  int lastday = 0;
  final ScrollController heatsScrollController = ScrollController();
  int browseMoreClick = 1;
  List<Widget> videoPlayerList = [];
  List<VideoPlayerController> videoPlayerControllerList = [];

  @override
  void initState() {
    listHeats = heats;
    listRecently = recently;
    listNews = news;
    listTops = tops;

    heatsScrollTimer = Timer.periodic(const Duration(seconds: 20), (timer) {
      double currentPage = controllerNews.page ?? 0;
      double nextPage =
          (currentPage + 1.0) > (listNews.length - 1) ? 0 : (currentPage + 1);
      controllerNews.animateToPage(
        nextPage.floor(),
        duration: const Duration(milliseconds: 50),
        curve: Curves.easeInOut,
      );
    });

    controllerNews.addListener(() {
      int currnetPage = (controllerNews.page ?? 0).toInt();
      for (var i = 0; i < listNews.length; i++) {
        if (i == currnetPage) {
          videoPlayerControllerList[i].play();
        } else {
          videoPlayerControllerList[i].pause();
        }
      }
    });

    timer = Timer.periodic(const Duration(minutes: 3), (Timer timer) {
      // setState(() {
      getListHeats().then((e) {
        if (mounted) {
          setState(() {
            listHeats = e;
          });
        }
      });
      getListRecently().then((e) {
        if (mounted) {
          setState(() {
            listRecently = e;
          });
        }
      });
      getListNews().then((e) {
        if (mounted) {
          setState(() {
            listNews = e;
          });
        }
      });
      getListTops().then((e) {
        if (mounted) {
          setState(() {
            listTops = e;
          });
        }
      });
    });

    getImageFileFromAssets('MobileAppLogo.png').then((e) {
      if (mounted) {
        setState(() {
          logoPath = e.path;
        });
      }
    });

    setState(() {
      browseMoreClick = 1;
    });

    setNewsVideoPlayer();

    super.initState();
  }

  setNewsVideoPlayer() {
    VideoPlayerOptions videoPlayerOptions =
        VideoPlayerOptions(mixWithOthers: true);
    for (var i = 0; i < listNews.length; i++) {
      videoPlayerControllerList.add(
        VideoPlayerController.network(
          listNews[i],
          httpHeaders: {
            "Token": prefs.getString("jwtToken") ?? "",
          },
          videoPlayerOptions: videoPlayerOptions,
        ),
      );
      videoPlayerControllerList[i].initialize().then((value) {
        if (i == 0) {
          videoPlayerControllerList[i].play();
        } else {
          videoPlayerControllerList[i].pause();
        }
        videoPlayerControllerList[i].setLooping(true);
      });

      videoPlayerList.add(VideoPlayer(videoPlayerControllerList[i]));
    }
    setState(() {});
  }

  disposeAllVideoController() {
    for (var i = 0; i < listNews.length; i++) {
      videoPlayerControllerList[i].dispose();
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    heatsScrollTimer?.cancel();
    disposeAllVideoController();
    super.dispose();
  }

  Widget getNewsWidget(String url, int position) {
    return !url.indexOf("mp4").isNegative
        ? ClipRRect(
            borderRadius: BorderRadius.circular(20.0),
            child: Container(
              decoration: const BoxDecoration(color: Colors.black),
              width: MediaQuery.of(context).size.width,
              height: 258,
              child: FittedBox(
                fit: BoxFit.cover,
                alignment: Alignment.center,
                child: SizedBox(
                  width: 426,
                  height: 240,
                  child: AspectRatio(
                      aspectRatio:
                          videoPlayerControllerList[position].value.aspectRatio,
                      child: videoPlayerList[position]),
                ),
              ),
            ),
          )
        : ClipRRect(
            borderRadius: BorderRadius.circular(20.0),
            child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 270,
                child: CachedNetworkImage(
                    imageUrl: url,
                    fit: BoxFit.cover,
                    errorWidget: (context, error, stackTrace) {
                      return Image.asset('assets/etc/NoImage.png',
                          fit: BoxFit.contain);
                    })));
  }

  Widget getHeatsProductDay(String day) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '${day}',
          style:
              robotoStyle(FontWeight.w800, const Color(0xFF313036), 10, null),
          maxLines: max,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
        ),
        Text(
          int.parse(day) == 1
              ? 'st'
              : int.parse(day) == 2
                  ? 'nd'
                  : int.parse(day) == 3
                      ? 'rd'
                      : 'th',
          style: robotoStyle(FontWeight.w400, const Color(0xFF313036), 8, null),
          maxLines: max,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  double getTextLines(String text, TextStyle style, double width) {
    final span = TextSpan(text: text, style: style);
    final tp = TextPainter(text: span, textDirection: TextDirection.ltr);
    tp.layout(maxWidth: width);
    int numLines = tp.computeLineMetrics().length;
    if (numLines == 1) {
      return 5;
    }
    if (numLines == 2) {
      return 3;
    }
    return 2;
  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(context, designSize: designSize);
    MediaQueryData mediaQuery = MediaQuery.of(context);
    double pixelRatio = mediaQuery.devicePixelRatio;

    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    double actualWindow = window.physicalSize.width;

    print(
        "viewport width ===> ${width} actualWindow ====> ${actualWindow}  height ====> ${height}  pixelRatio ===> ${pixelRatio}");
    double defaultFontSize = 12.2;
    double defaultTopClickFontSize = 14.0;

    if (pixelRatio > 1) {
      defaultFontSize = 16.2;
      defaultTopClickFontSize = 18;
    }
    if (pixelRatio > 2) {
      defaultFontSize = 14.2;
      defaultTopClickFontSize = 16;
    }
    if (pixelRatio > 2.5) {
      defaultFontSize = 13.6;
      defaultTopClickFontSize = 15;
    }
    if (pixelRatio > 3) {
      defaultFontSize = 12.2;
      defaultTopClickFontSize = 14;
    }
    TextStyle productNameStyle = GoogleFonts.roboto(
      fontWeight: FontWeight.w700,
      color: const Color(
        0xFF313036,
      ),
      fontSize: ScreenUtil().setSp(defaultFontSize),
    );

    TextStyle topClickProductNameStyle = GoogleFonts.roboto(
      fontWeight: FontWeight.w800,
      fontSize: defaultTopClickFontSize.sp,
      color: const Color(0xff757D90),
    );

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        //key: const PageStorageKey<String>('ScrollView Default'),
        controller: scrollTrend,
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).padding.top + 5,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
              child: Container(
                height: 200,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(20.0)),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 255, 35, 35),
                      Color.fromARGB(255, 255, 135, 135),
                      Color.fromARGB(221, 255, 190, 190),
                      Color.fromARGB(255, 252, 232, 232),
                    ],
                  ),
                ),
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 18,
                      ),
                      child: ListView.builder(
                        physics: const AlwaysScrollableScrollPhysics(),
                        //key: const PageStorageKey<String>('Listview Heats'),
                        controller: heatsScrollController,
                        scrollDirection: Axis.horizontal,
                        itemCount: listHeats.length,
                        itemBuilder: (context, position) {
                          return InkWell(
                            onTap: () async {
                              calendarProductDetail = await getProductDetail(
                                  listHeats[position]['ProductSKU']);
                              Navigator.of(context)
                                  .pushNamed("/CalendarDetail");
                            },
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(5, 0, 5, 5),
                              child: Container(
                                color: Colors.transparent,
                                child: Center(
                                  child: Container(
                                    color: Colors.transparent,
                                    child: ColumnSuper(
                                      alignment: Alignment.center,
                                      innerDistance: -10,
                                      invert: true,
                                      children: [
                                        SizedBox(
                                          width: 140,
                                          height: 92,
                                          child: listHeats[position]
                                                      ['ProductImage'] !=
                                                  ''
                                              ? CachedNetworkImage(
                                                  imageUrl: listHeats[position]
                                                      ['ProductImage'],
                                                  fit: BoxFit.contain,
                                                  errorWidget: (context, error,
                                                      stackTrace) {
                                                    return Image.asset(
                                                      'assets/etc/NoImage-trans.png',
                                                      fit: BoxFit.contain,
                                                    );
                                                  },
                                                )
                                              : Image.asset(
                                                  'assets/etc/NoImage-trans.png',
                                                  fit: BoxFit.contain,
                                                ),
                                        ),
                                        Material(
                                          elevation: 5,
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(18.0),
                                          ),
                                          child: Container(
                                            height: 75,
                                            width: 128,
                                            decoration: const BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(18.0),
                                              ),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      8, 8, 8, 5),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  SizedBox(
                                                    height: getTextLines(
                                                      listHeats[position]
                                                          ['ProductName'],
                                                      productNameStyle,
                                                      129.0,
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: Center(
                                                      child: Text(
                                                        listHeats[position]
                                                            ['ProductName'],
                                                        style: productNameStyle,
                                                        textScaleFactor: 1.sp,
                                                        maxLines: 3,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        textAlign:
                                                            TextAlign.center,
                                                      ),
                                                    ),
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Text(
                                                            '${listHeats[position]['MonthDay'].split(',')[0]},',
                                                            style: robotoStyle(
                                                              FontWeight.w500,
                                                              const Color(
                                                                  0xFF313036),
                                                              10,
                                                              null,
                                                            ),
                                                            maxLines: max,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.start,
                                                          ),
                                                          getHeatsProductDay(
                                                            listHeats[position]
                                                                    ['MonthDay']
                                                                .split(',')[1],
                                                          ),
                                                        ],
                                                      ),
                                                      const SizedBox(
                                                        width: 2,
                                                      ),
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Text(
                                                            "Resell   ",
                                                            style: robotoStyle(
                                                                FontWeight.w500,
                                                                returnColorCalendarCote(
                                                                  listHeats[position]
                                                                          [
                                                                          'ResellValuePourcent']
                                                                      .replaceAll(
                                                                          '%',
                                                                          ''),
                                                                ),
                                                                10,
                                                                null),
                                                            maxLines: max,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign: TextAlign
                                                                .center,
                                                          ),
                                                          Text(
                                                            listHeats[position][
                                                                    'ResellValuePourcent']
                                                                .toString(),
                                                            style: robotoStyle(
                                                                FontWeight.w900,
                                                                returnColorCalendarCote(
                                                                  listHeats[position]
                                                                          [
                                                                          'ResellValuePourcent']
                                                                      .replaceAll(
                                                                          '%',
                                                                          ''),
                                                                ),
                                                                11,
                                                                null),
                                                            maxLines: max,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign: TextAlign
                                                                .center,
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    Positioned(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 5, 0, 0),
                            child: ColumnSuper(
                              children: [
                                Container(
                                  color: Colors.transparent,
                                  child: ColumnSuper(
                                    alignment: Alignment.bottomLeft,
                                    innerDistance: -10,
                                    children: [
                                      Text(
                                        textAlign: TextAlign.start,
                                        style: robotoStyle(FontWeight.w900,
                                            Colors.white, 25, null),
                                        AppLocalizations.of(context)
                                            .trend_Heats,
                                      ),
                                      Text(
                                        style: robotoStyle(FontWeight.w400,
                                            Colors.white, 25, null),
                                        AppLocalizations.of(context)
                                            .trend_ofTheWeeks,
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                          InkWell(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                right: 20,
                              ),
                              child: Text(
                                style: robotoStyle(FontWeight.w300,
                                    Colors.white, 20, TextDecoration.underline),
                                AppLocalizations.of(context).trend_seeMore,
                              ),
                            ),
                            onTap: () {
                              setState(() {
                                isUpcoming = true;
                                isPast = false;
                                positionCalendarPage = 0;
                              });
                              Navigator.pushReplacementNamed(
                                context,
                                '/Calendar',
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(5, 5, 5, 0),
              child: Container(
                height: 258,
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(20.0)),
                    color: Colors.transparent),
                child: PageIndicatorContainer(
                  // key: key,
                  //key: const PageStorageKey<String>('Pageview News'),
                  align: IndicatorAlign.bottom,
                  length: listNews.length,
                  indicatorSpace: 12.0,
                  padding: const EdgeInsets.all(10),
                  indicatorSelectorColor: Colors.white,
                  indicatorColor: const Color.fromARGB(255, 49, 48, 54),
                  shape: IndicatorShape.circle(size: 8),
                  child: PageView.builder(
                    //key: const PageStorageKey<String>('Pageview News'),
                    itemCount: listNews.length,
                    controller: controllerNews,
                    itemBuilder: (BuildContext context, int position) {
                      return InkWell(
                        child: Stack(
                          children: [
                            getNewsWidget(listNews[position], position),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(30, 10, 0, 0),
                              child: Text(
                                style: robotoStyle(
                                    FontWeight.w900, Colors.white, 25, null),
                                AppLocalizations.of(context).trend_S4S,
                              ),
                            ),
                            Positioned(
                              top: 30.0,
                              left: 30.0,
                              child: Text(
                                style: robotoStyle(
                                    FontWeight.w400, Colors.white, 25, null),
                                AppLocalizations.of(context).trend_News,
                              ),
                            ),
                            Positioned(
                              top: 22.0,
                              right: 32.0,
                              child: InkWell(
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      padding: EdgeInsets.all(3),
                                      child: const Icon(Icons.share,
                                          size: 20, color: Colors.white),
                                    ),
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    SlideCountdown(
                                      separatorType: SeparatorType.symbol,
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(6)),
                                      duration: Duration(
                                          seconds: (DateTime(
                                                  DateTime.now().year,
                                                  DateTime.now().month + 1,
                                                  0)
                                              .difference(DateTime.now())
                                              .inSeconds)),
                                    )
                                  ],
                                ),
                                onTap: () async {
                                  String deepLink = await createDynamicLink(
                                    "/Home",
                                  );
                                  s4sSocialShare(deepLink);
                                },
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(5, 5, 5, 25),
              child: Container(
                height: 210,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(20.0)),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 110, 120, 140),
                      Color.fromARGB(255, 190, 196, 208),
                      Color.fromARGB(255, 216, 221, 229),
                      Color.fromARGB(255, 231, 234, 239),
                    ],
                  ),
                ),
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 18,
                      ),
                      child: ListView.builder(
                        physics: const AlwaysScrollableScrollPhysics(),
                        //key: const PageStorageKey<String>('Listview Drops'),
                        scrollDirection: Axis.horizontal,
                        itemCount: listRecently.length,
                        itemBuilder: (context, position) {
                          return InkWell(
                            onTap: () async {
                              productDetail = await getProductDetail(
                                  listRecently[position]['ProductSKU']);

                              Navigator.of(context).pushNamed("/ProductDetail");
                            },
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(5, 0, 5, 5),
                              child: Container(
                                color: Colors.transparent,
                                child: Center(
                                  child: ColumnSuper(
                                    children: [
                                      Container(
                                        color: Colors.transparent,
                                        child: ColumnSuper(
                                          alignment: Alignment.center,
                                          innerDistance: -10,
                                          invert: true,
                                          children: [
                                            SizedBox(
                                              width: 140,
                                              height: 85,
                                              child: listRecently[position]
                                                          ['ProductImage'] !=
                                                      ''
                                                  ? CachedNetworkImage(
                                                      imageUrl:
                                                          listRecently[position]
                                                              ['ProductImage'],
                                                      fit: BoxFit.contain,
                                                      errorWidget: (context,
                                                          error, stackTrace) {
                                                        return Image.asset(
                                                          'assets/etc/NoImage-trans.png',
                                                          fit: BoxFit.contain,
                                                        );
                                                      },
                                                      // height: 108,
                                                    )
                                                  : Image.asset(
                                                      'assets/etc/NoImage-trans.png',
                                                      fit: BoxFit.contain,
                                                    ),
                                            ),
                                            Material(
                                              elevation: 5,
                                              borderRadius:
                                                  const BorderRadius.all(
                                                Radius.circular(18.0),
                                              ),
                                              child: Container(
                                                height: 80,
                                                width: 128,
                                                decoration: const BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.all(
                                                    Radius.circular(18.0),
                                                  ),
                                                ),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          8, 12, 8, 5),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      SizedBox(
                                                        height: getTextLines(
                                                            listRecently[
                                                                    position]
                                                                ['ProductName'],
                                                            productNameStyle,
                                                            129.0),
                                                      ),
                                                      Expanded(
                                                        child: Center(
                                                          child: Text(
                                                            listRecently[
                                                                    position]
                                                                ['ProductName'],
                                                            style:
                                                                productNameStyle,
                                                            textScaleFactor:
                                                                1.sp,
                                                            maxLines: 3,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign: TextAlign
                                                                .center,
                                                          ),
                                                        ),
                                                      ),
                                                      Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              Text(
                                                                listRecently[
                                                                            position]
                                                                        [
                                                                        'xxShops']
                                                                    .toString(),
                                                                style: robotoStyle(
                                                                    FontWeight
                                                                        .w600,
                                                                    const Color(
                                                                        0xFF313036),
                                                                    11,
                                                                    null),
                                                                maxLines: max,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                              Text(
                                                                style: robotoStyle(
                                                                    FontWeight
                                                                        .w600,
                                                                    const Color(
                                                                        0xFF313036),
                                                                    9,
                                                                    null),
                                                                maxLines: max,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                AppLocalizations.of(
                                                                        context)
                                                                    .calendar_shops,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                            ],
                                                          ),
                                                          const SizedBox(
                                                            width: 5,
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              Text(
                                                                getPriceWithCurrency(
                                                                    listRecently[
                                                                            position]
                                                                        [
                                                                        'ProductMarketValue']),
                                                                style: robotoStyle(
                                                                    FontWeight
                                                                        .w700,
                                                                    listRecently[position]['ProductResellArrow'] ==
                                                                            'Down'
                                                                        ? const Color(
                                                                            0xFFF55E5E)
                                                                        : const Color(
                                                                            0xFF45D6A8),
                                                                    12,
                                                                    null),
                                                                maxLines: max,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                              ),
                                                              const SizedBox(
                                                                width: 1,
                                                              ),
                                                              Icon(
                                                                listRecently[position]
                                                                            [
                                                                            'ProductResellArrow'] ==
                                                                        "Up"
                                                                    ? Icons
                                                                        .trending_up_rounded
                                                                    : Icons
                                                                        .trending_down_rounded,
                                                                color: listRecently[position]
                                                                            [
                                                                            'ProductResellArrow'] ==
                                                                        "Up"
                                                                    ? const Color(
                                                                        0xFF45D6A8)
                                                                    : const Color(
                                                                        0xFFF55E5E),
                                                                size: 15,
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    Positioned(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 5, 0, 0),
                            child: Container(
                              color: Colors.transparent,
                              child: ColumnSuper(
                                alignment: Alignment.bottomLeft,
                                innerDistance: -10,
                                children: [
                                  Text(
                                    textAlign: TextAlign.start,
                                    style: robotoStyle(FontWeight.w900,
                                        Colors.white, 25, null),
                                    AppLocalizations.of(context).trend_Recently,
                                  ),
                                  Text(
                                    style: robotoStyle(FontWeight.w400,
                                        Colors.white, 25, null),
                                    AppLocalizations.of(context).trend_Dropped,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          InkWell(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                right: 20,
                              ),
                              child: Text(
                                style: robotoStyle(FontWeight.w300,
                                    Colors.white, 20, TextDecoration.underline),
                                AppLocalizations.of(context).trend_seeMore,
                              ),
                            ),
                            onTap: () {
                              setState(() {
                                isUpcoming = false;
                                isPast = true;
                                positionCalendarPage = 1;
                              });
                              Navigator.pushNamed(context, '/Calendar');
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: const Alignment(-0.75, 0),
              child: ColumnSuper(
                children: [
                  Container(
                    color: Colors.transparent,
                    child: ColumnSuper(
                      alignment: Alignment.bottomLeft,
                      innerDistance: -10,
                      children: [
                        Text(
                          style: robotoStyle(FontWeight.w900,
                              const Color(0xFF313036), 25, null),
                          AppLocalizations.of(context).trend_Tops,
                        ),
                        Text(
                          style: robotoStyle(FontWeight.w400,
                              const Color(0xFF313036), 25, null),
                          AppLocalizations.of(context).trend_ByUsers,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            // const SizedBox(
            //   height: 5,
            // ),
            Wrap(
              children: [
                for (int index = 0;
                    index <
                        ((16 * browseMoreClick) < listTops.length &&
                                browseMoreClick < 3
                            ? (16 * browseMoreClick)
                            : listTops.length);
                    index++)
                  InkWell(
                    onTap: () async {
                      productDetail =
                          await getProductDetail(listTops[index]['ProductSKU']);
                      Navigator.of(context).pushNamed("/ProductDetail");
                    },
                    child: SizedBox(
                      width:
                          (MediaQuery.of(context).size.width ~/ 2).toDouble(),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 0,
                              left: 15,
                              right: 10,
                              bottom: 0,
                            ),
                            child: SizedBox(
                              width: 172,
                              height: 110,
                              child: listTops[index]['ProductImage'] != ''
                                  ? CachedNetworkImage(
                                      imageUrl: listTops[index]['ProductImage'],
                                      fit: BoxFit.contain,
                                      errorWidget:
                                          (context, error, stackTrace) {
                                        return Image.asset(
                                          'assets/etc/NoImage.png',
                                          fit: BoxFit.contain,
                                        );
                                      },
                                    )
                                  : Image.asset(
                                      'assets/etc/NoImage.png',
                                      fit: BoxFit.fitWidth,
                                    ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 0,
                              left: 30,
                              right: 30,
                              bottom: 0,
                            ),
                            child: Container(
                              height: 42,
                              alignment: Alignment.center,
                              child: Text(
                                '${listTops[index]['ProductName']}',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2,
                                textAlign: TextAlign.center,
                                style: topClickProductNameStyle,
                                textScaleFactor: 1.sp,
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '${listTops[index]['xxShops']}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xff757D90),
                                ),
                              ),
                              Text(
                                AppLocalizations.of(context).calendar_shops,
                                style: TextStyle(
                                  color: Color(0xff757D90),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                getPriceWithCurrency(
                                    listTops[index]['ProductMarketValue']),
                                // '€${listTops[index]['ProductMarketValue']} ',
                                style: TextStyle(
                                  color: listTops[index]
                                              ['ProductResellArrow'] ==
                                          "Up"
                                      ? const Color(0xFF21ED8B)
                                      : const Color(0xffF55E5E),
                                  fontSize: 13.sp,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              Icon(
                                listTops[index]['ProductResellArrow'] == "Up"
                                    ? Icons.trending_up_rounded
                                    : Icons.trending_down_rounded,
                                size: 16.sp,
                                color: listTops[index]['ProductResellArrow'] ==
                                        "Up"
                                    ? const Color(0xFF21ED8B)
                                    : const Color(0xffF55E5E),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            // ),
            const SizedBox(
              height: 30,
            ),
            InkWell(
              child: Text(
                textAlign: TextAlign.center,
                style: robotoStyle(
                  FontWeight.w500,
                  const Color.fromARGB(255, 255, 35, 35),
                  20,
                  TextDecoration.underline,
                ),
                AppLocalizations.of(context).trend_browseMore,
              ),
              onTap: () {
                if (browseMoreClick < 3) {
                  setState(() {
                    browseMoreClick = browseMoreClick + 1;
                  });
                } else {
                  Navigator.pushNamed(context, '/Search');
                }
              },
            ),
            const SizedBox(height: 75),
          ],
        ),
      ),
    );
  }
}
