import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:s4s_mobileapp/widgets/custom_horizontal_picker/custom_horizontal_picker.dart';
import 'package:imageview360/imageview360.dart';
import 'package:pinch_zoom/pinch_zoom.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'dart:io';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

bool is360 = false;
bool isPriceChart = false;
bool is360Possible = false;
String deviceOrientation = '';
bool deviceOrientationChange = false;

List<ImageProvider> imageList360 = [];
List<dynamic> cacheFileList = [];

Map productDetail = {};

// ignore: non_constant_identifier_names
List USSizes = [];
// ignore: non_constant_identifier_names
List UKSizes = [];
// ignore: non_constant_identifier_names
List EUSizes = [];
List pricesPerSize = [];

String selectedSize = "";
List detailsPerSize = [];

class ProductDetailWidget extends StatefulWidget {
  const ProductDetailWidget({Key? key}) : super(key: key);

  @override
  State<ProductDetailWidget> createState() => ProductDetailWidgetState();
}

class ProductDetailWidgetState extends State<ProductDetailWidget> {
  bool isFav = false;

  bool isLoading = false;
  bool sizeGuideChanged = false;
  ScrollController scrollController = ScrollController();
  bool showProductDetailCard = false;
  int productLike = 0;
  int productDislike = 0;
  bool sortPrice = false;
  bool sortShop = false;
  bool sortRating = false;

  late List<Map> priceHistory = [];

  String preferredSize = prefs.getString("preferredSize") ?? "";

  @override
  void initState() {
    getProductDetailInfo();
    sizeGuideChanged = false;
    scrollController.addListener(() {
      if (scrollController.offset > 120) {
        if (mounted) {
          setState(() {
            showProductDetailCard = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            showProductDetailCard = false;
          });
        }
      }
    });

    super.initState();
  }

  getPriceHistoryData(String productSKU) async {
    List<Map> priceHistoryData = await getPriceHistory(productSKU);
    setState(() {
      priceHistory = priceHistoryData;
    });
  }

  getProductDetailInfo() {
    selectedSize = "";
    FocusManager.instance.primaryFocus?.unfocus();
    String productSKU = productDetail["ProductSKU"];
    // productDetail['productChangeArrow'] = product["productChangeArrow"];
    // productDetail['showprice'] = product["showprice"];
    USSizes = getMainSizeData(
      productDetail['ProductSizeBest'],
      productDetail['sizeSlider'],
    );
    UKSizes = getUKSize(USSizes, productDetail['sizeSlider']);
    EUSizes = getEUSize(USSizes, productDetail['sizeSlider']);
    pricesPerSize = USSizes.map(
      (e) => getPricePerSize(e, productDetail['ProductSizeBest']),
    ).toList();
    is360Possible = productDetail['ProductImage360'] != null &&
        productDetail['ProductImage360'].length != 0;
    productLike = productDetail['ProductLike'];
    productDislike = productDetail['ProductDislike'];
    // ignore: use_build_context_synchronously
    imageList360 = [];
    if (is360Possible) {
      get360Images();
    }
    getPriceHistoryData(productSKU);
    incrementProductHit(productDetail['ProductSKU']);
    checkIsFav();
    if (mounted) {
      setState(
        () {},
      );
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  resize360ImageList() {
    List<ImageProvider> temp = [];
    for (var el in cacheFileList) {
      temp.add(ResizeImage(
        FileImage(File(el.file.path)),
        height: (MediaQuery.of(context).size.height -
                MediaQuery.of(context).padding.top -
                MediaQuery.of(context).padding.bottom -
                30)
            .toInt(),
      ));
    }
    if (mounted) {
      setState(() {
        imageList360 = temp;
      });
    }
  }

  Future<void> checkIsFav() async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    if (wishlist.isNotEmpty) {
      for (var el in wishlist) {
        if (el.contains(productDetail['ProductSKU'])) {
          setState(() {
            isFav = true;
          });

          return;
        }
      }
    }
    setState(() {
      isFav = false;
    });

    return;
  }

  Future<void> addProductToWishList() async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    // ignore: prefer_typing_uninitialized_variables
    var price;
    for (var element in productDetail['ProductSizeBest']) {
      if (element['Size'] == selectedSize) {
        price = element['Product']['Price'];
      }
    }

    DateFormat format = DateFormat('yyyyMMddHHmmss');
    Map wishProduct = {
      'productSku': productDetail['ProductSKU'],
      'productImage': productDetail['ProductImage'],
      'productName': productDetail['ProductName'],
      'size': 'US $selectedSize',
      'price': price,
      'productChangeArrow': productDetail['productChangeArrow'],
      'addTime': format.format(DateTime.now()),
    };
    wishlist.add(jsonEncode(wishProduct));

    Map userData = {
      'email': prefs.getString('email') ?? '',
      'wishlist': wishlist,
    };

    String result =
        await postRequest('https://api.sneaks4sure.com/user', userData);
    if (!result.contains('ERROR')) {
      prefs.setStringList('wishlist', wishlist);

      // ignore: use_build_context_synchronously
      Navigator.of(context).pushNamed('/Wishlist');
    }
  }

  Future<void> removeProductFromWishList() async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    if (wishlist.isNotEmpty) {
      for (var el in wishlist) {
        if (el.contains(productDetail['ProductSKU'])) {
          wishlist.remove(el);
          break;
        }
      }
      Map userData = {
        'email': prefs.getString('email') ?? '',
        'wishlist': wishlist,
      };

      String result =
          await postRequest('https://api.sneaks4sure.com/user', userData);
      if (!result.contains('ERROR')) {
        prefs.setStringList('wishlist', wishlist);
      }
    }
  }

  void resetSort() {
    setState(() {
      sortPrice = false;
      sortShop = false;
      sortRating = false;
    });
  }

  void sortDetailsPerSize(String type, bool direction) {
    if (type == 'price') {
      if (direction) {
        detailsPerSize.sort((a, b) => a['Price'].compareTo(b['Price']));
      } else {
        detailsPerSize.sort((a, b) => b['Price'].compareTo(a['Price']));
      }
    }
    if (type == 'shop') {
      if (direction) {
        detailsPerSize.sort((a, b) =>
            a['ShopLogo'].toLowerCase().compareTo(b['ShopLogo'].toLowerCase()));
      } else {
        detailsPerSize.sort((a, b) =>
            b['ShopLogo'].toLowerCase().compareTo(a['ShopLogo'].toLowerCase()));
      }
    }
    if (type == 'rating') {
      if (direction) {
        detailsPerSize.sort((a, b) => a['ShopScore'].compareTo(b['ShopScore']));
      } else {
        detailsPerSize.sort((a, b) => b['ShopScore'].compareTo(a['ShopScore']));
      }
    }
  }

  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 16,
      color: Colors.white30,
    );
    Widget text;
    switch (value.toInt()) {
      case 2:
        text = const Text('MAR', style: style);
        break;
      case 5:
        text = const Text('JUN', style: style);
        break;
      case 8:
        text = const Text('SEP', style: style);
        break;
      default:
        text = const Text('', style: style);
        break;
    }

    return SideTitleWidget(
      axisSide: meta.axisSide,
      child: text,
    );
  }

  Widget leftTitleWidgets(double value, TitleMeta meta) {
    if (kDebugMode) {
      print(meta);
    }
    const style = TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 15,
      color: Colors.white30,
    );
    String text;
    switch (value.toInt()) {
      case 1:
        text = '10K';
        break;
      case 3:
        text = '30k';
        break;
      case 5:
        text = '50k';
        break;
      default:
        return Container();
    }

    return Text(text, style: style, textAlign: TextAlign.left);
  }

  void increaseOrDecreaseLike(String productSKU, int type) async {
    Map result = await likeOrDislike(productSKU, type);
    if (result.isNotEmpty) {
      if (mounted) {
        setState(() {
          productLike = result["product_like"];
          productDislike = result["product_dislike"];
        });
      }
    }
  }

  onClick360ViewButton() async {
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }
    if (imageList360.length != productDetail['ProductImage360'].length) {
      await get360Images();
    }
    if (mounted) {
      setState(() {
        isLoading = false;
        is360 = true;
      });
    }
    if (mounted) {
      setState(() {
        isLoading = false;
        is360 = true;
      });
    }
  }

  get360Images() async {
    List<ImageProvider> temp = [];
    for (var el in productDetail['ProductImage360']) {
      try {
        bool error = false;
        var cachedFile =
            await DefaultCacheManager().downloadFile(el).catchError((e) {
          error = true;
        });
        cacheFileList.add(cachedFile);

        if (error) {
          continue;
        } else {
          temp.add(ResizeImage(
            FileImage(File(cachedFile.file.path)),
            height: (MediaQuery.of(context).size.height -
                    MediaQuery.of(context).padding.top -
                    MediaQuery.of(context).padding.bottom -
                    30)
                .toInt(),
          ));
        }
        // ignore: empty_catches
      } catch (ex) {}
    }
    if (mounted) {
      setState(() {
        imageList360 = temp;
      });
    }
  }

  getProductDetailPage() {
    var orientationStr = MediaQuery.of(context).orientation.toString();
    if (deviceOrientation != '' && deviceOrientation != orientationStr) {
      deviceOrientation = orientationStr;
      deviceOrientationChange = true;
    } else {
      deviceOrientation = orientationStr;
      deviceOrientationChange = false;
    }
    if (deviceOrientationChange && is360) {
      resize360ImageList();
    }

    if (!sizeGuideChanged) {
      String userPreferedSize = prefs.getString("preferredSize") ?? "";
      double userSize =
          double.parse(userPreferedSize.split("/")[0].replaceAll("US ", ""));
      int initialItem;
      if (USSizes.isNotEmpty && productDetail['ProductSize'].isNotEmpty) {
        List temp = USSizes.where((element) {
          return double.parse(element
                  .toString()
                  .replaceAll('Y', '')
                  .replaceAll('C', '')
                  .replaceAll('K', '')) <=
              userSize;
        }).toList();
        initialItem = temp.isNotEmpty ? temp.length - 1 : 0;
        detailsPerSize = getProductsPerSize(
          USSizes[initialItem],
          productDetail['ProductSize'],
        );
      }
      setState(() {
        sizeGuideChanged = true;
      });
    }

    return Stack(
      children: [
        !is360
            ? Container(
                child: !isPriceChart
                    ? Column(
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).padding.top,
                          ),
                          Stack(
                            alignment: Alignment.center,
                            children: [
                              Align(
                                alignment: const Alignment(-0.9, 0),
                                child: IconButton(
                                  icon: const Icon(
                                      Icons.arrow_circle_left_outlined),
                                  color: const Color(0xFF313036),
                                  iconSize: 40,
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: SizedBox(
                                  height: 25,
                                  // width: 130,
                                  child: Image.asset(
                                    'assets/etc/splash-cropped.png',
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: const Alignment(0.9, 0),
                                child: Column(
                                  children: [
                                    Text(
                                      "Resell Value",
                                      style: w700Gray10,
                                    ),
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          ">${productDetail['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(productDetail['ResellValueProfit'])}",
                                          style: robotoStyle(
                                              FontWeight.w700,
                                              returnColorCalendarCote(
                                                  productDetail[
                                                          'ResellValuePourcent']
                                                      .toString()
                                                      .replaceAll('%', '')),
                                              14,
                                              null),
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          "(${(returnSignCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')) + productDetail['ResellValuePourcent'].toString() + '%')})",
                                          style: robotoStyle(
                                              FontWeight.w700,
                                              returnColorCalendarCote(
                                                  productDetail[
                                                          'ResellValuePourcent']
                                                      .toString()
                                                      .replaceAll('%', '')),
                                              14,
                                              null),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                // child: InkWell(
                                //   child: Container(
                                //     width: 71,
                                //     height: 26,
                                //     decoration: BoxDecoration(
                                //       color: const Color(0xFF313036),
                                //       borderRadius: BorderRadius.circular(10),
                                //     ),
                                //     child: Center(
                                //       child: Text(
                                //         "Size Guide",
                                //         style: w500White12,
                                //       ),
                                //     ),
                                //   ),
                                //   onTap: () {
                                //     Navigator.pushNamed(context, '/SizeGuide');
                                //   },
                                // ),
                              ),
                            ],
                          ),
                          (!showProductDetailCard)
                              ? Container(
                                  padding:
                                      const EdgeInsets.fromLTRB(40, 10, 40, 20),
                                  child: InkWell(
                                    onTap: () async {
                                      String productName =
                                          productDetail['ProductName']
                                              .toString();
                                      await Clipboard.setData(
                                          ClipboardData(text: productName));
                                      if (mounted) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(launchSnackbar(
                                                'Product name copied to clipboard',
                                                Icons.check,
                                                AppColors.white,
                                                AppColors.red,
                                                Colors.white));
                                      }
                                    },
                                    child: Text(
                                      productDetail['ProductName'],
                                      textAlign: TextAlign.center,
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis,
                                      style: robotoStyle(
                                          FontWeight.w900,
                                          const Color.fromARGB(255, 49, 48, 54),
                                          32,
                                          null),
                                    ),
                                  ),
                                )
                              : Container(),
                          showProductDetailCard
                              ? Container(
                                  height: 150,
                                  padding:
                                      const EdgeInsets.fromLTRB(30, 0, 30, 0),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Material(
                                            elevation: 10,
                                            // padding: EdgeInsets.all(4),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(20)),
                                            child: Container(
                                              width: 130,
                                              height: 130,
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      10, 0, 10, 0),
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  getCalendarIcon(
                                                      productDetail[
                                                          'ProductReleaseDate'],
                                                      Colors.black,
                                                      "black"),
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(5, 10, 5, 0),
                                                    child: InkWell(
                                                      onTap: () async {
                                                        String productName =
                                                            productDetail[
                                                                    'ProductName']
                                                                .toString();
                                                        await Clipboard.setData(
                                                            ClipboardData(
                                                                text:
                                                                    productName));
                                                        if (mounted) {
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                                  launchSnackbar(
                                                                      'Product name copied to clipboard',
                                                                      Icons
                                                                          .check,
                                                                      AppColors
                                                                          .white,
                                                                      AppColors
                                                                          .red,
                                                                      Colors
                                                                          .white));
                                                        }
                                                      },
                                                      child: Text(
                                                        productDetail[
                                                            'ProductName'],
                                                        textAlign:
                                                            TextAlign.center,
                                                        maxLines: 3,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: robotoStyle(
                                                            FontWeight.w800,
                                                            Colors.black,
                                                            16,
                                                            null),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          const Padding(
                                              padding:
                                                  EdgeInsets.only(left: 15)),
                                          Container(
                                            width: (MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                215),
                                            height: 120,
                                            child: is360Possible
                                                ? GestureDetector(
                                                    child: Stack(
                                                      children: [
                                                        Center(
                                                          child: ClipRRect(
                                                            child: SizedBox(
                                                              width: 300,
                                                              height: 200,
                                                              child: productDetail[
                                                                          'ProductImage'] !=
                                                                      ''
                                                                  ? CachedNetworkImage(
                                                                      imageUrl:
                                                                          productDetail[
                                                                              'ProductImage'],
                                                                      fit: BoxFit
                                                                          .contain,
                                                                      errorWidget: (context,
                                                                          error,
                                                                          stackTrace) {
                                                                        return Image
                                                                            .asset(
                                                                          'assets/etc/NoImage-trans.png',
                                                                          fit: BoxFit
                                                                              .contain,
                                                                        );
                                                                      },
                                                                    )
                                                                  : Image.asset(
                                                                      'assets/etc/NoImage-trans.png',
                                                                      fit: BoxFit
                                                                          .fitWidth,
                                                                    ),
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(top: 0),
                                                          child: Align(
                                                            alignment:
                                                                const Alignment(
                                                                    0.8, -0.8),
                                                            child: Image.asset(
                                                              'assets/icons/360view.gif',
                                                              width: 50,
                                                              height: 50,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    onTap: () {
                                                      onClick360ViewButton();
                                                    },
                                                  )
                                                : Center(
                                                    child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20.0),
                                                      child: SizedBox(
                                                        width: 300,
                                                        child: productDetail[
                                                                    'ProductImage'] !=
                                                                ''
                                                            ? CachedNetworkImage(
                                                                imageUrl:
                                                                    productDetail[
                                                                        'ProductImage'],
                                                                fit: BoxFit
                                                                    .contain,
                                                                errorWidget:
                                                                    (context,
                                                                        error,
                                                                        stackTrace) {
                                                                  return Image
                                                                      .asset(
                                                                    'assets/etc/NoImage-trans.png',
                                                                    fit: BoxFit
                                                                        .fitWidth,
                                                                  );
                                                                },
                                                              )
                                                            : Image.asset(
                                                                'assets/etc/NoImage-trans.png',
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                      ),
                                                    ),
                                                  ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      Container(
                                        decoration: const BoxDecoration(
                                          border: Border(
                                            bottom: BorderSide(
                                              color: Color.fromARGB(
                                                  255, 109, 108, 108),
                                              width: 2,
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Container(),
                          Expanded(
                            child: SingleChildScrollView(
                              controller: scrollController,
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    is360Possible
                                        ? GestureDetector(
                                            child: Stack(
                                              children: [
                                                Center(
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20.0),
                                                    child: SizedBox(
                                                      width: 330,
                                                      height: 210,
                                                      child: productDetail[
                                                                  'ProductImage'] !=
                                                              ''
                                                          ? CachedNetworkImage(
                                                              imageUrl:
                                                                  productDetail[
                                                                      'ProductImage'],
                                                              fit: BoxFit
                                                                  .contain,
                                                              errorWidget:
                                                                  (context,
                                                                      error,
                                                                      stackTrace) {
                                                                return Image
                                                                    .asset(
                                                                  'assets/etc/NoImage.png',
                                                                  fit: BoxFit
                                                                      .contain,
                                                                );
                                                              },
                                                            )
                                                          : Image.asset(
                                                              'assets/etc/NoImage.png',
                                                              fit: BoxFit
                                                                  .fitWidth,
                                                            ),
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding:
                                                      EdgeInsets.only(top: 10),
                                                  child: Align(
                                                    alignment:
                                                        Alignment(0.6, 0),
                                                    child: Image.asset(
                                                      'assets/icons/360view.gif',
                                                      width: 50,
                                                      height: 50,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            onTap: () {
                                              onClick360ViewButton();
                                            },
                                          )
                                        : Center(
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              child: SizedBox(
                                                width: 300,
                                                child: productDetail[
                                                            'ProductImage'] !=
                                                        ''
                                                    ? CachedNetworkImage(
                                                        imageUrl: productDetail[
                                                            'ProductImage'],
                                                        fit: BoxFit.contain,
                                                        errorWidget: (context,
                                                            error, stackTrace) {
                                                          return Image.asset(
                                                            'assets/etc/NoImage.png',
                                                            fit:
                                                                BoxFit.fitWidth,
                                                          );
                                                        },
                                                      )
                                                    : Image.asset(
                                                        'assets/etc/NoImage.png',
                                                        fit: BoxFit.cover,
                                                      ),
                                              ),
                                            ),
                                          ),
                                    SizedBox(
                                      height: MediaQuery.of(context)
                                              .size
                                              .height -
                                          310 -
                                          MediaQuery.of(context).padding.top,
                                      child: Column(
                                        children: [
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              if (USSizes.isNotEmpty)
                                                Center(
                                                  child: Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(35, 0, 35, 0),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(50),
                                                        color: const Color(
                                                            0xffF6F6F6),
                                                      ),
                                                      padding:
                                                          const EdgeInsets.only(
                                                        left: 15,
                                                        right: 15,
                                                      ),
                                                      child: HorizontalPicker(
                                                        height: 70,
                                                        prefix: "US ",
                                                        subLeftPrefix: "EU",
                                                        subRightPrefix: "UK",
                                                        showCursor: false,
                                                        initialPosition:
                                                            InitialPosition
                                                                .user,
                                                        backgroundColor:
                                                            Colors.transparent,
                                                        activeItemTextColor:
                                                            const Color
                                                                    .fromARGB(
                                                                255,
                                                                49,
                                                                48,
                                                                54),
                                                        passiveItemsTextColor:
                                                            Colors.grey
                                                                .withOpacity(
                                                                    0.5),
                                                        mainData: USSizes,
                                                        subDataRight: UKSizes,
                                                        subDataLeft: EUSizes,
                                                        sizePrice:
                                                            pricesPerSize,
                                                        sizeType: productDetail[
                                                            'sizeSlider'],
                                                        onChanged: (value) {
                                                          detailsPerSize =
                                                              getProductsPerSize(
                                                                  value,
                                                                  productDetail[
                                                                      'ProductSize']);
                                                          setState(() {
                                                            sizeGuideChanged =
                                                                true;
                                                            preferredSize =
                                                                value;
                                                          });
                                                          resetSort();
                                                        },
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              Container(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        30, 10, 30, 0),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  children: [
                                                    InkWell(
                                                      onTap: () {
                                                        setState(() {
                                                          sortPrice =
                                                              !sortPrice;
                                                        });
                                                        sortDetailsPerSize(
                                                            'price', sortPrice);
                                                      },
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(7),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Icon(
                                                              sortPrice
                                                                  ? FontAwesomeIcons
                                                                      .arrowDown
                                                                  : FontAwesomeIcons
                                                                      .arrowUp,
                                                              size: 12,
                                                            ),
                                                            Text(
                                                              AppLocalizations.of(
                                                                      context)
                                                                  .calDetail_prices,
                                                              style: TextStyle(
                                                                color: Colors
                                                                    .black54,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    InkWell(
                                                      onTap: () {
                                                        setState(() {
                                                          sortShop = !sortShop;
                                                        });
                                                        sortDetailsPerSize(
                                                            'shop', sortShop);
                                                      },
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(7),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Icon(
                                                              sortShop
                                                                  ? FontAwesomeIcons
                                                                      .arrowDown
                                                                  : FontAwesomeIcons
                                                                      .arrowUp,
                                                              size: 12,
                                                            ),
                                                            Text(
                                                              AppLocalizations.of(
                                                                      context)
                                                                  .calDetail_shops,
                                                              style: TextStyle(
                                                                color: Colors
                                                                    .black54,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    InkWell(
                                                      onTap: () {
                                                        setState(() {
                                                          sortRating =
                                                              !sortRating;
                                                        });
                                                        sortDetailsPerSize(
                                                            'rating',
                                                            sortRating);
                                                      },
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(7),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Icon(
                                                              sortRating
                                                                  ? FontAwesomeIcons
                                                                      .arrowDown
                                                                  : FontAwesomeIcons
                                                                      .arrowUp,
                                                              size: 12,
                                                            ),
                                                            Text(
                                                              AppLocalizations.of(
                                                                      context)
                                                                  .search_notations,
                                                              style: TextStyle(
                                                                color: Colors
                                                                    .black54,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsets.all(7),
                                                      child: SizedBox(
                                                        width: 45,
                                                        child: Text(
                                                          AppLocalizations.of(
                                                                  context)
                                                              .search_links,
                                                          style: TextStyle(
                                                            color:
                                                                Colors.black54,
                                                            fontSize: 14,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                          Expanded(
                                            child: SingleChildScrollView(
                                              child: Column(
                                                children: [
                                                  if (USSizes.isNotEmpty)
                                                    ListView.builder(
                                                      padding:
                                                          const EdgeInsets.only(
                                                        bottom: 20,
                                                        top: 10,
                                                      ),
                                                      physics:
                                                          const NeverScrollableScrollPhysics(),
                                                      scrollDirection:
                                                          Axis.vertical,
                                                      shrinkWrap: true,
                                                      itemCount:
                                                          detailsPerSize.length,
                                                      itemBuilder:
                                                          (BuildContext ctx,
                                                              int index) {
                                                        return InkWell(
                                                          onTap: () {
                                                            urlLauncher(
                                                                detailsPerSize[
                                                                        index]
                                                                    ['Link']);
                                                          },
                                                          child: Container(
                                                            color: index == 0
                                                                ? const Color(
                                                                    0xffF6F6F6)
                                                                : Colors
                                                                    .transparent,
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      left: 40,
                                                                      right: 40,
                                                                      top: 10,
                                                                      bottom:
                                                                          10),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  Text(
                                                                    getPriceWithCurrency(detailsPerSize[index]
                                                                            [
                                                                            'Price']
                                                                        .toString()),
                                                                    // '€${detailsPerSize[index]['Price'].toString()}',
                                                                    style:
                                                                        TextStyle(
                                                                      color: index ==
                                                                              0
                                                                          ? const Color(
                                                                              0xFF21ED8B)
                                                                          : const Color(
                                                                              0xff313036),
                                                                      fontSize:
                                                                          22,
                                                                      fontWeight: index == 0
                                                                          ? FontWeight
                                                                              .bold
                                                                          : FontWeight
                                                                              .w400,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    width: 50,
                                                                    height: 40,
                                                                    child: detailsPerSize[index]['ShopLogo'] !=
                                                                            null
                                                                        ? detailsPerSize[index]['ShopLogo'].contains(
                                                                                '.svg')
                                                                            ? SvgPicture
                                                                                .network(
                                                                                detailsPerSize[index]['ShopLogo'],
                                                                                width: 50,
                                                                                height: 50,
                                                                                fit: BoxFit.scaleDown,
                                                                                placeholderBuilder: (context) => Image.asset(
                                                                                  'assets/etc/NoImage-trans.png',
                                                                                  fit: BoxFit.contain,
                                                                                ),
                                                                              )
                                                                            : CachedNetworkImage(
                                                                                imageUrl: detailsPerSize[index]['ShopLogo'],
                                                                                fit: BoxFit.contain,
                                                                                errorWidget: (context, error, stackTrace) {
                                                                                  return Image.asset(
                                                                                    'assets/etc/NoImage-trans.png',
                                                                                    fit: BoxFit.fill,
                                                                                  );
                                                                                },
                                                                              )
                                                                        : Image
                                                                            .asset(
                                                                            'assets/etc/NoImage-trans.png',
                                                                            fit:
                                                                                BoxFit.fill,
                                                                          ),
                                                                  ),
                                                                  JustTheTooltip(
                                                                    backgroundColor:
                                                                        Colors
                                                                            .black26,
                                                                    child:
                                                                        RatingBarIndicator(
                                                                      rating: detailsPerSize[index]['ShopScore'] !=
                                                                              null
                                                                          ? detailsPerSize[index]['ShopScore']
                                                                              .toDouble()
                                                                          : 0,
                                                                      itemBuilder:
                                                                          (context, index) =>
                                                                              const Icon(
                                                                        Icons
                                                                            .star,
                                                                        color: Colors
                                                                            .amber,
                                                                      ),
                                                                      itemCount:
                                                                          5,
                                                                      itemSize:
                                                                          15.0,
                                                                    ),
                                                                    content: Container(
                                                                        decoration: BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(10),
                                                                        ),
                                                                        padding: EdgeInsets.all(10),
                                                                        child: Text(
                                                                          'Notation come from Trustpilot',
                                                                          style: robotoStyle(
                                                                              FontWeight.w700,
                                                                              Colors.white,
                                                                              14,
                                                                              null),
                                                                        )),
                                                                  ),
                                                                  JustTheTooltip(
                                                                    backgroundColor:
                                                                        Colors
                                                                            .black26,
                                                                    onDismiss:
                                                                        () async {
                                                                      await Clipboard.setData(ClipboardData(
                                                                          text: detailsPerSize[index]
                                                                              [
                                                                              'Link']));
                                                                    },
                                                                    child: Icon(
                                                                      CupertinoIcons
                                                                          .link,
                                                                      size: 28,
                                                                      color: Color(
                                                                          0xffFF2323),
                                                                    ),
                                                                    content:
                                                                        Container(
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        borderRadius:
                                                                            BorderRadius.circular(10),
                                                                      ),
                                                                      padding:
                                                                          const EdgeInsets.all(
                                                                              10),
                                                                      child:
                                                                          Text(
                                                                        'Link copied to our clipboard',
                                                                        style: robotoStyle(
                                                                            FontWeight.w700,
                                                                            Colors.white,
                                                                            14,
                                                                            null),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                    ),
                                                  Container(
                                                    padding: const EdgeInsets
                                                            .fromLTRB(
                                                        20, 10, 20, 0),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        InkWell(
                                                          onTap: (() {
                                                            setState(() {
                                                              isPriceChart =
                                                                  true;
                                                            });
                                                          }),
                                                          child: Container(
                                                            height: 55,
                                                            width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width -
                                                                120,
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    15,
                                                                    7,
                                                                    15,
                                                                    7),
                                                            decoration:
                                                                BoxDecoration(
                                                              color: const Color
                                                                      .fromARGB(
                                                                  255,
                                                                  246,
                                                                  246,
                                                                  246),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10),
                                                            ),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceAround,
                                                              children: [
                                                                Container(
                                                                  constraints:
                                                                      const BoxConstraints(
                                                                          maxWidth:
                                                                              80),
                                                                  child: Text(
                                                                    AppLocalizations.of(
                                                                            context)
                                                                        .calDetail_marketAnalysis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 2,
                                                                    style: robotoStyle(
                                                                        FontWeight
                                                                            .w800,
                                                                        Colors
                                                                            .black54,
                                                                        16,
                                                                        null),
                                                                  ),
                                                                ),
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .center,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  children: productDetail['ResellValuePourcent'] != null &&
                                                                          productDetail['ResellValuePourcent'] !=
                                                                              'TBC' &&
                                                                          productDetail['ResellValuePourcent'] !=
                                                                              "" &&
                                                                          productDetail['ResellValueProfit']
                                                                              is! String
                                                                      ? [
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.center,
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            children: [
                                                                              Column(
                                                                                children: [
                                                                                  Text(
                                                                                    AppLocalizations.of(context).search_margin,
                                                                                    style: robotoStyle(FontWeight.w400, returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')), 16, null),
                                                                                  ),
                                                                                  Row(
                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    children: [
                                                                                      Text(
                                                                                        (returnSignCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')) + productDetail['ResellValuePourcent'].toString() + '%'),
                                                                                        style: robotoStyle(FontWeight.w800, returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')), 16, null),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              Icon(
                                                                                isNumber(productDetail['ResellValuePourcent'].toString()) && int.parse(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')) >= 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded,
                                                                                size: 18,
                                                                                color: returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ]
                                                                      : [
                                                                          const Text(
                                                                            'TBC',
                                                                            style:
                                                                                TextStyle(
                                                                              // color: Color(0xff313036),
                                                                              color: Color.fromARGB(255, 221, 220, 222),
                                                                              fontSize: 24,
                                                                            ),
                                                                          ),
                                                                        ],
                                                                ),
                                                                Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .center,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  children: productDetail['ResellValuePourcent'] != null &&
                                                                          productDetail['ResellValuePourcent'] !=
                                                                              'TBC' &&
                                                                          productDetail['ResellValuePourcent'] !=
                                                                              "" &&
                                                                          productDetail['ResellValueProfit']
                                                                              is! String
                                                                      ? [
                                                                          Text(
                                                                            AppLocalizations.of(context).search_profit,
                                                                            style: robotoStyle(
                                                                                FontWeight.w400,
                                                                                returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')),
                                                                                16,
                                                                                null),
                                                                          ),
                                                                          Text(
                                                                            "> ${productDetail['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(productDetail['ResellValueProfit'])}",
                                                                            style: robotoStyle(
                                                                                FontWeight.w800,
                                                                                returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%', '')),
                                                                                16,
                                                                                null),
                                                                          ),
                                                                        ]
                                                                      : [
                                                                          const Text(
                                                                            'TBC',
                                                                            style:
                                                                                TextStyle(
                                                                              // color: Color(0xff313036),
                                                                              color: Color.fromARGB(255, 221, 220, 222),
                                                                              fontSize: 24,
                                                                            ),
                                                                          ),
                                                                        ],
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          height: 55,
                                                          width: 55,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: const Color
                                                                    .fromARGB(
                                                                255,
                                                                246,
                                                                246,
                                                                246),
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                          ),
                                                          child: InkWell(
                                                            onTap: () async {
                                                              String deepLink =
                                                                  await createDynamicLink(
                                                                "/ProductDetail?sku=${productDetail['ProductSKU']}",
                                                              );
                                                              s4sSocialShare(
                                                                  deepLink);
                                                            },
                                                            child: Image.asset(
                                                                "assets/etc/share-gray.gif",
                                                                width: 50,
                                                                height: 50),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  const SizedBox(
                                                    height: 10,
                                                  ),
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                            .size
                                                            .width,
                                                    height: 250,
                                                    child: DefaultTabController(
                                                      length: 2,
                                                      initialIndex: 0,
                                                      child: Column(
                                                        children: [
                                                          TabBar(
                                                            labelColor:
                                                                Color.fromARGB(
                                                                    255,
                                                                    14,
                                                                    14,
                                                                    14),
                                                            labelStyle: robotoStyle(
                                                                FontWeight.w600,
                                                                const Color
                                                                        .fromARGB(
                                                                    255,
                                                                    49,
                                                                    48,
                                                                    54),
                                                                20,
                                                                null),
                                                            indicatorColor:
                                                                Color(
                                                                    0xFFFF0000),
                                                            tabs: [
                                                              Tab(
                                                                text: AppLocalizations.of(
                                                                        context)
                                                                    .calDetail_specifications,
                                                              ),
                                                              Tab(
                                                                text: AppLocalizations.of(
                                                                        context)
                                                                    .search_images,
                                                              ),
                                                            ],
                                                          ),
                                                          Expanded(
                                                            child: TabBarView(
                                                              children: [
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceEvenly,
                                                                  children: [
                                                                    const SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    Center(
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            children: [
                                                                              Text(
                                                                                "${AppLocalizations.of(context).calDetail_retailPrice} :  ",
                                                                                style: robotoStyle(FontWeight.w400, const Color.fromARGB(255, 101, 101, 101), 16, null),
                                                                              ),
                                                                              Text(
                                                                                getPriceWithCurrency(productDetail['ProductRetailPrice']),
                                                                                style: robotoStyle(FontWeight.w700, const Color.fromARGB(255, 101, 101, 101), 16, null),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          const SizedBox(
                                                                            height:
                                                                                5,
                                                                          ),
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            children: [
                                                                              Text(
                                                                                "SKU :  ",
                                                                                style: robotoStyle(FontWeight.w400, const Color.fromARGB(255, 101, 101, 101), 16, null),
                                                                              ),
                                                                              InkWell(
                                                                                onTap: () async {
                                                                                  String productSKU = productDetail['ProductSKU'].toString();
                                                                                  await Clipboard.setData(ClipboardData(text: productSKU));
                                                                                  if (mounted) {
                                                                                    ScaffoldMessenger.of(context).showSnackBar(launchSnackbar('Product SKU copied to clipboard', Icons.check, AppColors.white, AppColors.red, Colors.white));
                                                                                  }
                                                                                },
                                                                                child: Text(
                                                                                  productDetail['ProductSKU'].toString(),
                                                                                  style: robotoStyle(FontWeight.w700, Colors.red, 16, null),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                          const SizedBox(
                                                                            height:
                                                                                5,
                                                                          ),
                                                                          Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            children: [
                                                                              Text(
                                                                                "${AppLocalizations.of(context).search_filterReleaseDate} :  ",
                                                                                style: robotoStyle(FontWeight.w400, const Color.fromARGB(255, 101, 101, 101), 16, null),
                                                                              ),
                                                                              Text(
                                                                                productDetail['ProductReleaseDate'].toString(),
                                                                                style: robotoStyle(FontWeight.w700, const Color.fromARGB(255, 101, 101, 101), 16, null),
                                                                              )
                                                                            ],
                                                                          ),
                                                                          const SizedBox(
                                                                            height:
                                                                                5,
                                                                          ),
                                                                          FittedBox(
                                                                            child:
                                                                                Padding(
                                                                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                                                                              child: Text(
                                                                                textAlign: TextAlign.center,
                                                                                productDetail['ProductColorWay'].toString(),
                                                                                style: robotoStyle(FontWeight.w400, const Color.fromARGB(255, 101, 101, 101), 16, null),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                PhotoViewGallery
                                                                    .builder(
                                                                  scrollPhysics:
                                                                      const BouncingScrollPhysics(),
                                                                  builder: (BuildContext
                                                                          context,
                                                                      int index) {
                                                                    return PhotoViewGalleryPageOptions(
                                                                        imageProvider: NetworkImage(productDetail['ProductImageOOTD'][index]
                                                                            [
                                                                            'img_url']),
                                                                        initialScale:
                                                                            PhotoViewComputedScale.contained);
                                                                  },
                                                                  itemCount:
                                                                      productDetail[
                                                                              'ProductImageOOTD']
                                                                          .length,
                                                                  backgroundDecoration:
                                                                      const BoxDecoration(
                                                                    color: AppColors
                                                                        .white,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          const SizedBox(
                                                            height: 50,
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    : Container(
                        padding: EdgeInsets.only(
                          top: MediaQuery.of(context).padding.top,
                          bottom: MediaQuery.of(context).padding.bottom,
                        ),
                        alignment: Alignment.center,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: IconButton(
                                    icon: const Icon(
                                        Icons.arrow_circle_left_outlined),
                                    color: const Color(0xFF313036),
                                    iconSize: 40,
                                    onPressed: () {
                                      setState(() {
                                        isPriceChart = false;
                                        showProductDetailCard = false;
                                      });
                                    },
                                  ),
                                )
                              ],
                            ),
                            Expanded(
                              child: Container(
                                // color: Colors.grey,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    if (USSizes.isNotEmpty)
                                      Center(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              35, 0, 35, 0),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                              color: const Color(0xffF6F6F6),
                                            ),
                                            padding: const EdgeInsets.only(
                                              left: 15,
                                              right: 15,
                                            ),
                                            child: HorizontalPicker(
                                              height: 70,
                                              prefix: "US ",
                                              subLeftPrefix: "EU",
                                              subRightPrefix: "UK",
                                              showCursor: false,
                                              initialPosition:
                                                  InitialPosition.user,
                                              backgroundColor:
                                                  Colors.transparent,
                                              activeItemTextColor:
                                                  const Color.fromARGB(
                                                      255, 49, 48, 54),
                                              passiveItemsTextColor:
                                                  Colors.grey.withOpacity(0.5),
                                              mainData: USSizes,
                                              subDataRight: UKSizes,
                                              subDataLeft: EUSizes,
                                              sizePrice: pricesPerSize,
                                              sizeType:
                                                  productDetail['sizeSlider'],
                                              onChanged: (value) {
                                                detailsPerSize =
                                                    getProductsPerSize(
                                                        value,
                                                        productDetail[
                                                            'ProductSize']);
                                                setState(() {
                                                  sizeGuideChanged = true;
                                                  preferredSize = value;
                                                });
                                                resetSort();
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        InkWell(
                                          onTap: (() {
                                            // setState(() {
                                            //   isPriceChart = true;
                                            // });
                                          }),
                                          child: Container(
                                            height: 55,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                120,
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 7, 15, 7),
                                            decoration: BoxDecoration(
                                              color: const Color.fromARGB(
                                                  255, 246, 246, 246),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Container(
                                                  constraints:
                                                      const BoxConstraints(
                                                          maxWidth: 80),
                                                  child: Text(
                                                    AppLocalizations.of(context)
                                                        .calDetail_marketAnalysis,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 2,
                                                    style: robotoStyle(
                                                        FontWeight.w800,
                                                        Colors.black54,
                                                        16,
                                                        null),
                                                  ),
                                                ),
                                                Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: productDetail[
                                                                  'ResellValuePourcent'] !=
                                                              null &&
                                                          productDetail[
                                                                  'ResellValuePourcent'] !=
                                                              'TBC' &&
                                                          productDetail[
                                                                  'ResellValuePourcent'] !=
                                                              "" &&
                                                          productDetail[
                                                                  'ResellValueProfit']
                                                              is! String
                                                      ? [
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              Column(
                                                                children: [
                                                                  Text(
                                                                    AppLocalizations.of(
                                                                            context)
                                                                        .search_margin,
                                                                    style: robotoStyle(
                                                                        FontWeight
                                                                            .w400,
                                                                        returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll(
                                                                            '%',
                                                                            '')),
                                                                        16,
                                                                        null),
                                                                  ),
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    children: [
                                                                      Text(
                                                                        (returnSignCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%',
                                                                                '')) +
                                                                            productDetail['ResellValuePourcent'].toString() +
                                                                            '%'),
                                                                        style: robotoStyle(
                                                                            FontWeight
                                                                                .w800,
                                                                            returnColorCalendarCote(productDetail['ResellValuePourcent'].toString().replaceAll('%',
                                                                                '')),
                                                                            16,
                                                                            null),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                              Icon(
                                                                isNumber(productDetail['ResellValuePourcent']
                                                                            .toString()) &&
                                                                        int.parse(productDetail['ResellValuePourcent'].toString().replaceAll('%',
                                                                                '')) >=
                                                                            0
                                                                    ? Icons
                                                                        .trending_up_rounded
                                                                    : Icons
                                                                        .trending_down_rounded,
                                                                size: 18,
                                                                color: returnColorCalendarCote(productDetail[
                                                                        'ResellValuePourcent']
                                                                    .toString()
                                                                    .replaceAll(
                                                                        '%',
                                                                        '')),
                                                              ),
                                                            ],
                                                          ),
                                                        ]
                                                      : [
                                                          const Text(
                                                            'TBC',
                                                            style: TextStyle(
                                                              // color: Color(0xff313036),
                                                              color: Color
                                                                  .fromARGB(
                                                                      255,
                                                                      221,
                                                                      220,
                                                                      222),
                                                              fontSize: 24,
                                                            ),
                                                          ),
                                                        ],
                                                ),
                                                Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: productDetail[
                                                                  'ResellValuePourcent'] !=
                                                              null &&
                                                          productDetail[
                                                                  'ResellValuePourcent'] !=
                                                              'TBC' &&
                                                          productDetail[
                                                                  'ResellValuePourcent'] !=
                                                              "" &&
                                                          productDetail[
                                                                  'ResellValueProfit']
                                                              is! String
                                                      ? [
                                                          Text(
                                                            AppLocalizations.of(
                                                                    context)
                                                                .search_profit,
                                                            style: robotoStyle(
                                                                FontWeight.w400,
                                                                returnColorCalendarCote(productDetail[
                                                                        'ResellValuePourcent']
                                                                    .toString()
                                                                    .replaceAll(
                                                                        '%',
                                                                        '')),
                                                                16,
                                                                null),
                                                          ),
                                                          Text(
                                                            "> ${productDetail['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(productDetail['ResellValueProfit'])})",
                                                            style: robotoStyle(
                                                                FontWeight.w800,
                                                                returnColorCalendarCote(productDetail[
                                                                        'ResellValuePourcent']
                                                                    .toString()
                                                                    .replaceAll(
                                                                        '%',
                                                                        '')),
                                                                16,
                                                                null),
                                                          ),
                                                        ]
                                                      : [
                                                          const Text(
                                                            'TBC',
                                                            style: TextStyle(
                                                              // color: Color(0xff313036),
                                                              color: Color
                                                                  .fromARGB(
                                                                      255,
                                                                      221,
                                                                      220,
                                                                      222),
                                                              fontSize: 24,
                                                            ),
                                                          ),
                                                        ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    renderPriceHistoryChart(
                                      MediaQuery.of(context).size.width,
                                      210,
                                      priceHistory,
                                      preferredSize,
                                      context,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
              )
            : Container(
                padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top,
                  bottom: MediaQuery.of(context).padding.bottom,
                ),
                alignment: Alignment.center,
                child: PinchZoom(
                  // resetDuration: const Duration(milliseconds: 50),
                  maxScale: 5,
                  onZoomStart: () {},
                  onZoomEnd: () {},
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      imageList360.isNotEmpty
                          ? ImageView360(
                              key: UniqueKey(),
                              imageList: imageList360,
                              swipeSensitivity: 2,
                              rotationDirection:
                                  RotationDirection.anticlockwise,
                            )
                          : Center(
                              child: Text('Sorry, there is no image.'),
                            ),
                    ],
                  ),
                ),
              ),
        if (isLoading)
          Container(
            padding: const EdgeInsets.only(
              left: 100,
              right: 100,
            ),
            alignment: Alignment.center,
            color: AppColors.white,
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Image.asset('assets/etc/loading.gif'),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: getProductDetailPage(),
      floatingActionButtonLocation:
          is360 ? FloatingActionButtonLocation.endTop : null,
      floatingActionButton: is360
          ? Padding(
              padding: const EdgeInsets.only(top: 20),
              child: IconButton(
                onPressed: () {
                  setState(() {
                    is360 = false;
                    showProductDetailCard = false;
                  });
                },
                icon: const Icon(Icons.close_rounded),
                iconSize: 35,
                color: const Color.fromARGB(255, 255, 35, 35),
              ),
            )
          : null,
      bottomNavigationBar: SizedBox(
        height: 70,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            InkWell(
              onTap: () async {
                String deepLink = await createDynamicLink(
                  "/ProductDetail?sku=${productDetail['ProductSKU']}",
                );
                s4sSocialShare(deepLink);
              },
              child: Container(
                width: 65,
                height: 50,
                padding: const EdgeInsets.fromLTRB(10, 3, 10, 3),
                decoration: BoxDecoration(
                  color: const Color(0xFFF6F6F6),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Image.asset(
                  "assets/etc/share-gray.gif",
                  width: 50,
                  height: 50,
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            likeAndDislikeWidget(
              productDetail['ProductSKU'],
              productLike,
              productDislike,
              increaseOrDecreaseLike,
            ),
            const SizedBox(
              width: 10,
            ),
            InkWell(
              onTap: () {
                if (!isFav) {
                  addProductToWishList();
                } else {
                  removeProductFromWishList();
                }
                setState(() {
                  isFav = !isFav;
                });
              },
              child: Container(
                width: 65,
                height: 50,
                padding: const EdgeInsets.fromLTRB(10, 3, 10, 3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color:
                      isFav ? const Color(0xFFFF2323) : const Color(0xFFF6F6F6),
                ),
                child: Image.asset(
                  isFav ? "assets/etc/heart-full.gif" : "assets/etc/heart.gif",
                  width: 45,
                  height: 45,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
