import 'dart:async';
import 'dart:convert';
import 'package:cupertino_back_gesture/cupertino_back_gesture.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/account/aboutus_page.dart';
import 'package:s4s_mobileapp/account/account_page.dart';
import 'package:s4s_mobileapp/account/account_profile_page.dart';
import 'package:s4s_mobileapp/account/wishlist_page.dart';
import 'package:s4s_mobileapp/calendar/calendar.dart';
import 'package:s4s_mobileapp/calendar/calendar_detail.dart';
import 'package:s4s_mobileapp/calendar/page_size_guide.dart';
import 'package:s4s_mobileapp/login/page_login.dart';
import 'package:s4s_mobileapp/login/page_login_signup_with_email.dart';
import 'package:s4s_mobileapp/home/page_home.dart';
import 'package:s4s_mobileapp/map/page_map.dart';
import 'package:s4s_mobileapp/product/product_detail_page.dart';
import 'package:s4s_mobileapp/restock/restock_page.dart';
import 'package:s4s_mobileapp/search/search_page.dart';
import 'package:s4s_mobileapp/splash/language_select.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:s4s_mobileapp/tools/firebase_service.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:s4s_mobileapp/firebase_options.dart';
import 'package:encrypted_shared_preferences/encrypted_shared_preferences.dart';
import 'package:s4s_mobileapp/account/save_profile.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

List<Map> heats = [];
List<Map> recently = [];
List<String> news = [];
List<Map> tops = [];
List upcoming = [];
List past = [];
List<Map> restocks = [];
List<Map> instores = [];

late final SharedPreferences prefs;
late EncryptedSharedPreferences encriptedPrefs;

Size designSize = const Size(412, 846);

Map<String, dynamic> currencyRate = {};

final ValueNotifier<Locale> globalCurrentLocale = ValueNotifier(Locale("en"));

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await setupFlutterNotifications();
  Map messageObj = message.toMap();
  if (kDebugMode) {
    print(messageObj);
  }
}

/// Create a AndroidNotificationChannel for heads up notifications
late AndroidNotificationChannel channel;

bool isFlutterLocalNotificationsInitialized = false;

Future<void> setupFlutterNotifications() async {
  if (isFlutterLocalNotificationsInitialized) {
    return;
  }

  channel = const AndroidNotificationChannel(
    'high_importance_channel', // id
    'High Importance Notifications', // title
    description:
        'This channel is used for important notifications.', // description
    importance: Importance.max,
  );

  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );
  isFlutterLocalNotificationsInitialized = true;
}

/// Initialize the FlutterLocalNotificationsPlugin package.
late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

getCurrencyRate() async {
  var result = await getData(
    'https://api.sneaks4sure.com/currency',
  );
  Map responseData = jsonDecode(result)['data'];
  currencyRate = responseData[responseData.keys.toList()[0]];
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  encriptedPrefs = EncryptedSharedPreferences(prefs: prefs);
  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  NotificationSettings settings =
      await FirebaseMessaging.instance.requestPermission(
    alert: true,
    announcement: false,
    badge: true,
    carPlay: false,
    criticalAlert: false,
    provisional: false,
    sound: true,
  );
  if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    if (kDebugMode) {
      print("User granted permission");
    }
  } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
    if (kDebugMode) {
      print("User granted provisional permission");
    }
  } else {
    if (kDebugMode) {
      print("User declined or has not accepteed permission");
    }
  }

  // Set the background messaging handler early on, as a named top-level function
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await setupFlutterNotifications();

  getCurrencyRate();

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  MyApp({Key? key}) : super(key: key);
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    final FirebaseAnalytics analytics = FirebaseAnalytics.instance;

    return BackGestureWidthTheme(
      backGestureWidth: BackGestureWidth.fraction(1 / 2),
      child: ScreenUtilInit(
        minTextAdapt: true,
        splitScreenMode: true,
        designSize: designSize,
        builder: (context, child) {
          return ValueListenableBuilder<Locale>(
            valueListenable: globalCurrentLocale,
            builder: (context, locale, child) => MaterialApp(
              title: 'Sneaks4Sure',
              locale: locale,
              localizationsDelegates: AppLocalizations.localizationsDelegates,
              supportedLocales: AppLocalizations.supportedLocales,
              debugShowCheckedModeBanner: false,
              initialRoute: prefs.getBool('setLanguage') != true
                  ? '/MuliLanguage'
                  : prefs.getBool('loggedin') != true
                      ? '/Landing'
                      : prefs.getBool('savedProfile') == true
                          ? '/Home'
                          : '/SaveProfile',
              // initialRoute: '/' ,
              theme: ThemeData(
                colorScheme: ColorScheme.fromSwatch().copyWith(
                  primary: const Color.fromARGB(255, 255, 35, 35),
                ),
                fontFamily: 'Roboto',
                textTheme:
                    Typography.englishLike2018.apply(fontSizeFactor: 1.sp),
                pageTransitionsTheme: const PageTransitionsTheme(
                  builders: {
                    TargetPlatform.android: CupertinoPageTransitionsBuilder(),
                    TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
                  },
                ),
              ),
              navigatorObservers: [
                FirebaseAnalyticsObserver(analytics: analytics)
              ],
              routes: {
                '/MuliLanguage': (context) => const LanguageSelect(),
                '/Landing': (context) => const LandingPage(),
                '/LoginSignupWithEmail': (context) =>
                    const LoginSignupWithEmailPage(),
                '/Login': (context) => const LoginPage(),
                '/Home': (context) => const HomePage(),
                '/Calendar': (context) => const Calendar(),
                '/Search': (context) => const SearchPage(),
                '/Restock': (context) => const RestockPage(),
                '/SizeGuide': (context) => const SizeGuidePage(),
                '/MapView': (context) => const GoolgMapView(),
                '/Account': (context) => const AccountPage(),
                '/AboutUS': (context) => const AboutUSPage(),
                '/Wishlist': (context) => const WishlistPage(),
                '/AccountProfile': (context) => const AccountProfilePage(),
                '/SaveProfile': (context) => const SaveProfile(),
                '/CalendarDetail': (context) => const CalendarDetail(),
                '/ProductDetail': (context) => const ProductDetailPage(),
              },
            ),
          );
        },
      ),
    );
  }
}

class LandingPage extends StatefulWidget {
  const LandingPage({Key? key}) : super(key: key);

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  FirebaseService service = FirebaseService();

  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          if (kDebugMode) {
            print('Data connection is available.');
          }
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          if (kDebugMode) {
            print('You are disconnected from the internet.');
          }
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    checkNetworkStatus();
    // FlutterNativeSplash.remove();
    initDynamicLinks(context);
    super.initState();
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // checkIsJailBroken(context);
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(
                      height: MediaQuery.of(context).padding.top,
                    ),
                    SizedBox(
                      height: 230,
                      child: Image.asset(
                        'assets/etc/aj1.png',
                        fit: BoxFit.fitHeight,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.only(
                        top: 20,
                        bottom: 30,
                        left: 65,
                        right: 65,
                      ),
                      child: Image.asset(
                        'assets/etc/splash-cropped.png',
                        fit: BoxFit.fitWidth,
                      ),
                    ),
                    buildImageButton(
                      "assets/icons/google.png",
                      25,
                      AppLocalizations.of(context).signinWithGoogle,
                      10,
                      () async {
                        try {
                          String result = await service.signInWithGoogle();
                          if (result == 'SUCCESS') {
                            if (mounted)
                              // ignore: curly_braces_in_flow_control_structures
                              prefs.getBool('savedProfile') == true
                                  ? Navigator.of(context).pushAndRemoveUntil(
                                      MaterialPageRoute(
                                        builder: (context) => HomePage(),
                                      ),
                                      (route) => false,
                                    )
                                  : Navigator.pushNamedAndRemoveUntil(
                                      context,
                                      '/SaveProfile',
                                      (route) => false,
                                    );
                          } else {
                            // ignore: use_build_context_synchronously
                            showMessage(context, result);
                          }
                        } catch (e) {
                          if (e is FirebaseAuthException) {
                            showMessage(context, e.message!);
                          }
                        }
                      },
                    ),
                    buildImageButton(
                      "assets/icons/apple.png",
                      25,
                      AppLocalizations.of(context).signinWithApple,
                      10,
                      () async {
                        try {
                          String result = await service.signInWithApple();
                          if (result == 'SUCCESS') {
                            if (mounted) {
                              prefs.getBool('savedProfile') == true
                                  ? Navigator.of(context).pushAndRemoveUntil(
                                      MaterialPageRoute(
                                        builder: (context) => HomePage(),
                                      ),
                                      (route) => false,
                                    )
                                  : Navigator.pushNamedAndRemoveUntil(
                                      context,
                                      '/SaveProfile',
                                      (route) => false,
                                    );
                            }
                          } else {
                            // ignore: use_build_context_synchronously
                            showMessage(context, result);
                          }
                        } catch (e) {
                          if (e is FirebaseAuthException) {
                            showMessage(context, e.message!);
                          }
                        }
                      },
                    ),
                    // buildImageButton(
                    //   "assets/icons/facebook.png",
                    //   25,
                    //   "  Sign in with Facebook",
                    //   10,
                    //   () async {
                    //     try {
                    //       // Giantbrain212!
                    //       String result = await service.signInWithFacebook();
                    //       if (result == 'SUCCESS') {
                    //         prefs.getBool('savedProfile') == true
                    //             // ignore: use_build_context_synchronously
                    //             ? Navigator.of(context).pushAndRemoveUntil(
                    //                 MaterialPageRoute(
                    //                     builder: (context) =>
                    //                         HomePage(pages, 0, null)),
                    //                 (route) => false)
                    //             // ignore: use_build_context_synchronously
                    //             : Navigator.pushNamedAndRemoveUntil(
                    //                 context, '/SaveProfile', (route) => false);
                    //       } else {
                    //         // ignore: use_build_context_synchronously
                    //         showMessage(context, result);
                    //       }
                    //     } catch (e) {
                    //       if (e is FirebaseAuthException) {
                    //         showMessage(context, e.message!);
                    //       }
                    //     }
                    //   },
                    // ),
                    buildImageButton(
                      "assets/icons/twitter.png",
                      25,
                      AppLocalizations.of(context).signinWithTwitter,
                      10,
                      () async {
                        try {
                          String result = await service.signInWithTwitter();
                          if (result == 'SUCCESS') {
                            prefs.getBool('savedProfile') == true
                                // ignore: use_build_context_synchronously
                                ? Navigator.of(context).pushAndRemoveUntil(
                                    MaterialPageRoute(
                                      builder: (context) => HomePage(),
                                    ),
                                    (route) => false,
                                  )
                                // ignore: use_build_context_synchronously
                                : Navigator.pushNamedAndRemoveUntil(
                                    context,
                                    '/SaveProfile',
                                    (route) => false,
                                  );
                          } else {
                            // ignore: use_build_context_synchronously
                            showMessage(context, result);
                          }
                        } catch (e) {
                          if (e is FirebaseAuthException) {
                            showMessage(context, e.message!);
                          }
                        }
                      },
                    ),
                    buildImageButton(
                      "assets/icons/mail.png",
                      25,
                      AppLocalizations.of(context).signinWithEmail,
                      10,
                      () {
                        Navigator.pushNamed(context, '/LoginSignupWithEmail');
                      },
                    ),
                    Container(
                      padding: const EdgeInsets.only(top: 30, bottom: 30),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              AppLocalizations.of(context).doYouHaveAnyProblem,
                              style: robotoStyle(
                                FontWeight.w500,
                                Colors.grey[700],
                                14,
                                null,
                              ),
                            ),
                            GestureDetector(
                              onTap: () async {
                                String result = await urlLauncher(
                                  "mailto:contact@sneaks4sure.com",
                                );
                                if (result == "mailto error") {
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      launchSnackbar(
                                          'Contact address copied to clipboard. In your device there is no mail composer. Please install gmail composer or the others and try again.',
                                          Icons.check,
                                          AppColors.white,
                                          AppColors.red,
                                          Colors.white),
                                    );
                                  }
                                }
                              },
                              child: Text(
                                AppLocalizations.of(context).contactUS,
                                style: robotoStyle(
                                  FontWeight.w500,
                                  const Color(0xFFF55E5E),
                                  14,
                                  null,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
