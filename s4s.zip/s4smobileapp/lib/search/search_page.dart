import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/restock/restock_widget.dart';
import 'package:s4s_mobileapp/search/search_widget.dart';
import 'package:s4s_mobileapp/tools/bottom_navbar.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:s4s_mobileapp/tools/bottom_search_button.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> with TickerProviderStateMixin {
  bool isNotificatinoDialogShowing = false;
  late AnimationController _resizableController;
  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  handleMessage(RemoteMessage message) {
    String title = message.toMap()['notification']['title'];
    String content = message.toMap()['notification']['body'];
    String linkUrl = message.toMap()['data']['linkUrl'];
    String productSku = message.toMap()['data']['productSku'];
    if (linkUrl.isNotEmpty) {
      urlLauncher(linkUrl);
    }
    notificationProductSku = productSku;
    Navigator.of(context).pushNamed(
      '/Restock',
    );
  }

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          if (kDebugMode) {
            print('Data connection is available.');
          }
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          if (kDebugMode) {
            print('You are disconnected from the internet.');
          }
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    checkNetworkStatus();
    createDynamicLink("/Search");
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      if (message != null) {
        handleMessage(message);
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      handleMessage(message);
    });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      String title = message.toMap()['notification']['title'];
      String content = message.toMap()['notification']['body'];
      String linkUrl = message.toMap()['data']['linkUrl'];
      String productSku = message.toMap()['data']['productSku'];
      bool notifFlag = prefs.getBool("notifFlag") ?? false;
      if (!isNotificatinoDialogShowing && notifFlag) {
        isNotificatinoDialogShowing = true;
        if (mounted) {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text(title),
                content: Text(content),
                actions: [
                  TextButton(
                    onPressed: () {
                      isNotificatinoDialogShowing = false;
                      Navigator.of(context).pop();
                      if (linkUrl.isNotEmpty) {
                        urlLauncher(linkUrl);
                      } else {
                        notificationProductSku = productSku;
                        Navigator.of(context).pushNamed(
                          '/Restock',
                        );
                      }
                    },
                    child: const Text('Go to link'),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      isNotificatinoDialogShowing = false;
                    },
                    child: const Text('Cancel'),
                  ),
                ],
              );
            },
          );
        }
      }
    });

    // ignore: unnecessary_new
    _resizableController = new AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1000,
      ),
    );
    _resizableController.addStatusListener((animationStatus) {
      switch (animationStatus) {
        case AnimationStatus.completed:
          _resizableController.reverse();
          break;
        case AnimationStatus.dismissed:
          _resizableController.forward();
          break;
        case AnimationStatus.forward:
          break;
        case AnimationStatus.reverse:
          break;
      }
    });
    _resizableController.forward();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return const Scaffold(
      extendBody: true,
      resizeToAvoidBottomInset: false,
      appBar: null,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SearchPageWidget(),
      ),
      bottomNavigationBar: BottomNavBar(2),
      floatingActionButton: BottomSearchButton(true),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.miniCenterDocked,
    );
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    _resizableController.dispose();
    super.dispose();
  }
}
