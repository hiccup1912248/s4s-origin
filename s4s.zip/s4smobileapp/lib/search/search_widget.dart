import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:s4s_mobileapp/models/product.dart';
import 'package:http/http.dart' as http;
import 'package:pagination_view/pagination_view.dart';
import 'package:s4s_mobileapp/product/product_detail_widget.dart';
import 'package:s4s_mobileapp/tools/bottom_search_button.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:s4s_mobileapp/widgets/custom_expansion_tile.dart';
import 'package:flutter_multi_select_items/flutter_multi_select_items.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_speech/flutter_speech.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

const List productColorMap = [
  {'white': Color(0xffffffff)},
  {'black': Color(0xff000000)},
  {'grey': Color(0xff808080)},
  {'silver': Color(0xffc0c0c0)},
  {'blue': Color(0xff0000ff)},
  {'navyblue': Color(0xff000080)},
  {'purple': Color(0xff6a0dad)},
  {'pink': Color(0xffffc0cb)},
  {'red': Color(0xffff0000)},
  {'orange': Color(0xffff7f00)},
  {'yellow': Color(0xffffff00)},
  {'gold': Color(0xffa57c00)},
  {'brown': Color(0xff88540b)},
  {'green': Color(0xff00ff00)},
  {'multicolor': Colors.transparent},
];

enum SortOptions {
  relevance,
  mostView,
  releaseDate,
  priceAsc,
  priceDsc,
}

enum GenderOptions {
  men,
  women,
  kids,
}

List<Map> listJordan = [
  {"key": "Jordan", "image": "", "searchKey": "Jordan"},
  {
    "key": "Jordan 1",
    "image": "assets/brands/category/Jordan 1.png",
    "searchKey": "Jordan 1",
  },
  {
    "key": "Jordan 3",
    "image": "assets/brands/category/Jordan 3.png",
    "searchKey": "Jordan 3",
  },
  {
    "key": "Jordan 4",
    "image": "assets/brands/category/Jordan 4.png",
    "searchKey": "Jordan 4",
  },
  {
    "key": "Jordan 5",
    "image": "assets/brands/category/Jordan 5.png",
    "searchKey": "Jordan 5",
  },
  {
    "key": "Jordan 6",
    "image": "assets/brands/category/Jordan 6.png",
    "searchKey": "Jordan 6",
  },
  {
    "key": "Jordan 11",
    "image": "assets/brands/category/Jordan 11.png",
    "searchKey": "Jordan 11",
  },
];

List<Map> listNike = [
  {"key": "Nike", "image": "", "searchKey": "Nike"},
  {
    "key": "Dunk",
    "image": "assets/brands/category/Nike Dunk.png",
    "searchKey": "Dunk",
  },
  {
    "key": "Air Force",
    "image": "assets/brands/category/Nike Air Force.png",
    "searchKey": "Air Force",
  },
  {
    "key": "Sacai",
    "image": "assets/brands/category/Nike Sacai.png",
    "searchKey": "Sacai",
  },
  {
    "key": "Air Max",
    "image": "assets/brands/category/Nike Air Max.png",
    "searchKey": "Air Max",
  },
  {
    "key": "Blazer",
    "image": "assets/brands/category/Nike Blazer.png",
    "searchKey": "Blazer",
  },
];

List<Map> listAdidas = [
  {"key": "Adidas", "image": "", "searchKey": "Adidas"},
  {
    "key": "Foam",
    "image": "assets/brands/category/Yeezy Foam.png",
    "searchKey": "Yeezy Foam",
  },
  {
    "key": "Slide",
    "image": "assets/brands/category/Yeezy Slide.png",
    "searchKey": "Yeezy Slide",
  },
  {
    "key": "350",
    "image": "assets/brands/category/Yeezy 350.png",
    "searchKey": "Yeezy 350",
  },
  {
    "key": "500",
    "image": "assets/brands/category/Yeezy 500.png",
    "searchKey": "Yeezy 500",
  },
  {
    "key": "700",
    "image": "assets/brands/category/Yezzy 700.png",
    "searchKey": "Yeezy 700",
  },
  {
    "key": "Forum",
    "image": "assets/brands/category/Adidas Forum.png",
    "searchKey": "Forum",
  },
];

List<Map> listNewBalance = [
  {"key": "New Balance", "image": "", "searchKey": "New Balance"},
  {
    "key": "2002",
    "image": "assets/brands/category/New Balance 2002.png",
    "searchKey": "New Balance 2002",
  },
  {
    "key": "9060",
    "image": "assets/brands/category/New Balance 9060.png",
    "searchKey": "New Balance 9060",
  },
  {
    "key": "990",
    "image": "assets/brands/category/New Balance 990.png",
    "searchKey": "New Balance 990",
  },
  {
    "key": "1906",
    "image": "assets/brands/category/New Balance 1906.png",
    "searchKey": "New Balance 1906",
  },
  {
    "key": "550",
    "image": "assets/brands/category/New Balance 550.png",
    "searchKey": "New Balance 550",
  },
];

bool autoFocus = false;

String colorQuery = '';

bool isMatchAnd = false;
bool startedSearchGlobal = false;

String getQueryParams(Map filter) {
  String query = '';
  // color filter
  List color = filter['filter']['color'];
  // String colorQuery = '';
  colorQuery = '';
  for (var e in color) {
    // colorQuery = '&filter%5Bcolor%5D%5B%5D=$e$colorQuery';
    colorQuery = '$colorQuery%20$e';
  }

  var gender = filter['filter']['gender'];
  String genderQuery = '';
  for (var e in gender) {
    if (e != '') {
      genderQuery = '&filter%5Bgender%5D%5B%5D=$e$genderQuery';
    }
  }

  var underretail = filter['filter']['underretail'];
  String underretailQuery = '';
  if (underretail.toString().isNotEmpty && underretail != null) {
    underretailQuery = '&filter%5Bunderretail%5D%5B%5D=$underretail';
  }

  String sortQuery = '';
  switch (filter['sort']) {
    case 'relevance':
      {
        sortQuery = '';
      }
      break;
    case 'most_view':
      {
        sortQuery = '&sort%5B0%5D%5Bproduct_rank%5D=desc';
      }
      break;
    case 'latest_release_date':
      {
        sortQuery = '&sort%5B0%5D%5Bproduct_release_date%5D=desc';
      }
      break;
    case 'price_asc':
      {
        sortQuery = '&sort%5B0%5D%5Bprice%5D=asc';
      }
      break;
    case 'price_desc':
      {
        sortQuery = '&sort%5B0%5D%5Bprice%5D=desc';
      }
      break;
    default:
      {
        sortQuery = '';
      }
      break;
  }
  // price filter
  String priceQuery =
      '&filter%5Bprice%5D%5Bgte%5D=${filter['filter']['price']['gte']}&filter%5Bprice%5D%5Blt%5D=${filter['filter']['price']['lte']}';

  // query = '$colorQuery$brandQuery$genderQuery$sortQuery$priceQuery';
  query = '$genderQuery$sortQuery$priceQuery$underretailQuery';

  return query;
}

Future fetchProduct(query, filter) async {
  String filters = getQueryParams(filter);
  var response = await http.get(
    Uri.parse(
      'https://eu1-search.doofinder.com/5/search?hashid=30a5f46195133e966f269146a6805518&query=$query%20$colorQuery&${isMatchAnd ? '' : 'query_name=match_and&'}page=${filter['page']}$filters',
    ),
    headers: {'Authorization': 'c59dadc5d822ca2b134fb8c7048274a7ec68e170'},
  );

  if (response.statusCode == 200) {
    // log(prettyJson(jsonDecode(response.body)));
    return response.body;
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load data');
  }
}

double getTextWidth(String text, TextStyle style) {
  final span = TextSpan(text: text, style: style);

  final tp = TextPainter(
    text: span,
    textDirection: TextDirection.ltr,
  );
  tp.layout();

  return tp.width;
}

class SearchPageWidget extends StatefulWidget {
  const SearchPageWidget({Key? key}) : super(key: key);

  @override
  State<SearchPageWidget> createState() => _SearchPageWidgetState();
}

class _SearchPageWidgetState extends State<SearchPageWidget> {
  late SpeechRecognition _speech;
  bool _speechRecognitionAvailable = false;
  bool _isListening = false;
  String transcription = '';

  final TextEditingController? searchKeywordController =
      TextEditingController();

  int totalProducts = 0;

  Map filter = {
    'page': 1,
    'sort': 'most_view',
    'filter': {
      'color': [],
      'brand': '',
      'gender': ['', '', ''],
      'underretail': '',
      'price': {
        'gte': 1.0,
        'lte': 1000000.0,
      },
    },
  };

  SortOptions _sortBy = SortOptions.mostView;

  double priceFrom = 0;
  double priceTo = 2550;
  RangeLabels rangeLabels = const RangeLabels('0', '2550');
  RangeValues rangeValues = const RangeValues(0, 2550);

  int _amount4Men = 0;
  int _amount4Women = 0;
  int _amount4Kids = 0;

  bool _startedSearch = false;

  late GlobalKey<PaginationViewState> paginationViewKey;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // bool autoFocus = false;
  final SpeechToText _speechToText = SpeechToText();
  ScrollController searchResultScrollController = ScrollController();

  bool searchClick = false;
  bool showHeaderBar = true;

  @override
  void initState() {
    startedSearchGlobal = false;
    // paginationViewKey = GlobalKey<PaginationViewState>();
    // activateSpeechRecognizer();
    searchKeywordController?.addListener(_triggerChanged);

    if (autoFocus) {
      setState(() {
        searchClick = true;
      });
    }
    _initSpeech();

    searchResultScrollController.addListener(() {
      if (searchResultScrollController.offset > 500 && _startedSearch) {
        setState(() {
          showHeaderBar = false;
        });
      } else {
        setState(() {
          showHeaderBar = true;
        });
      }
    });

    super.initState();
  }

  /// This has to happen only once per app
  void _initSpeech() async {
    _speechRecognitionAvailable = await _speechToText.initialize();
    setState(() {});
  }

  /// Each time to start a speech recognition session
  void _startListening() async {
    await _speechToText.listen(onResult: _onSpeechResult);
    setState(() {});
  }

  void _stopListening() async {
    await _speechToText.stop();
    setState(() {});
  }

  void _onSpeechResult(SpeechRecognitionResult result) {
    if (result.recognizedWords != '') {
      setState(() {
        searchKeywordController!.text = result.recognizedWords;
        _isListening = false;
      });
    } else {
      setState(() {
        _isListening = false;
      });
    }
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the widget tree.
    searchKeywordController?.dispose();
    super.dispose();
  }

  void _triggerChanged() {
    if (searchKeywordController?.value.text != '') {
      _startedSearch = true;
      startedSearchGlobal = _startedSearch;
      paginationViewKey = GlobalKey<PaginationViewState>();
      setState(() {});
    }
  }

  void start() => _speech.activate(Platform.localeName).then((_) {
        return _speech.listen().then((result) {
          setState(() {
            _isListening = result;
          });
        });
      });

  void cancel() {
    _speech.cancel().then((_) => setState(() => _isListening = false));
  }

  void stop() => _speech.stop().then((_) {
        setState(() => _isListening = false);
      });

  Future fetchFacet() async {
    var response = await http.get(
      Uri.parse(
        'https://eu1-search.doofinder.com/5/search?hashid=30a5f46195133e966f269146a6805518',
      ),
      headers: {'Authorization': 'c59dadc5d822ca2b134fb8c7048274a7ec68e170'},
    );
    if (response.statusCode == 200) {
      // log(prettyJson(jsonDecode(response.body)));
      return jsonDecode(response.body)['facets'];
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
  }

  double getTextLines(String text, TextStyle style, double width) {
    final span = TextSpan(text: text, style: style);
    final tp = TextPainter(text: span, textDirection: TextDirection.ltr);
    tp.layout(maxWidth: width);
    int numLines = tp.computeLineMetrics().length;
    if (numLines == 1) {
      return 5;
    }
    if (numLines == 2) {
      return 3;
    }

    return 0;
  }

  Future<List<Product>> getProductWithPage(int offset) async {
    filter['page'] = (offset / 10).ceil() + 1;
    var result = await fetchProduct(searchKeywordController!.text, filter);

    List<Product> searchedProducts = jsonDecode(result)['results']
        ?.map((e) {
          return Product.fromJson(e);
        })
        .toList()
        .cast<Product>();

    totalProducts = jsonDecode(result)['total_found'];
    List temp = jsonDecode(result)['facets']['gender']['terms']['buckets'];

    for (var element in temp) {
      switch (element['key']) {
        case 'MEN':
          _amount4Men = element['doc_count'];
          break;
        case 'WOMEN':
          _amount4Women = element['doc_count'];
          break;
        case 'KIDS':
          _amount4Kids = element['doc_count'];
          break;
      }
    }
    if (mounted) setState(() {});

    return searchedProducts;
  }

  Widget searchPage(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        showHeaderBar
            ? Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 30),
                      child: InkWell(
                        onTap: () {
                          autoFocus = false;
                          Navigator.of(context).pushReplacementNamed(
                            '/Search',
                          );
                        },
                        child: const Image(
                          height: 35,
                          image: AssetImage('./assets/etc/splash-cropped.png'),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: const Alignment(0.48, 0),
                    child: SizedBox(
                      width: 45,
                      height: 60,
                      child: GestureDetector(
                        onTap: () {
                          _scaffoldKey.currentState?.openEndDrawer();
                        },
                        child: Align(
                          alignment: Alignment.center,
                          child: Image.asset(
                            'assets/etc/slider.gif',
                            width: 50,
                            height: 50,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: const Alignment(0.85, 0),
                    child: SizedBox(
                      width: 45,
                      height: 60,
                      child: GestureDetector(
                        onTap: () {
                          if (_speechRecognitionAvailable && !_isListening) {
                            // start();
                            _startListening();
                            setState(() {
                              searchClick = true;
                              _isListening = !_isListening;
                            });
                          }
                        },
                        child: Align(
                          alignment: Alignment.center,
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                color:
                                    _speechRecognitionAvailable && !_isListening
                                        ? Colors.white
                                        : Colors.red,
                                borderRadius: BorderRadius.circular(100),
                                border: Border.all(
                                    color: _speechRecognitionAvailable &&
                                            !_isListening
                                        ? Colors.black38
                                        : Colors.white,
                                    width: 1)),
                            child: Icon(
                              Icons.mic,
                              color:
                                  _speechRecognitionAvailable && !_isListening
                                      ? Colors.red
                                      : Colors.white,
                              size: 30,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : const SizedBox(),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 5, 20, 0),
          child: Material(
            elevation: 7,
            borderRadius: const BorderRadius.all(Radius.circular(15.0)),
            child: Container(
              height: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  width: 0.5,
                  color: Colors.white,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(15, 8, 15, 8),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    const SizedBox(
                      width: 30,
                      height: 30,
                      child: Icon(
                        Icons.search_rounded,
                        color: Color(0xff757D90),
                        size: 30,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.fromLTRB(15, 8, 0, 8),
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.black26,
                            width: 1,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 18,
                    ),
                    Expanded(
                      child: !searchClick
                          ? InkWell(
                              onTap: (() {
                                setState(() {
                                  searchClick = true;
                                  autoFocus = true;
                                });
                              }),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    AppLocalizations.of(context)
                                        .search_searchSneakers,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                    ),
                                  ),
                                  Text(
                                    AppLocalizations.of(context)
                                        .search_modelBrandColors,
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.w400,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  5, 0, 0, 0),
                              child: TextFormField(
                                maxLines: 1,
                                controller: searchKeywordController,
                                enableInteractiveSelection: true,
                                obscureText: false,
                                autofocus: autoFocus,
                                onChanged: (_) => EasyDebounce.debounce(
                                  'tFMemberController',
                                  const Duration(milliseconds: 500),
                                  () {},
                                ),
                                decoration: const InputDecoration(
                                  isCollapsed: true,
                                  labelText: '',
                                  labelStyle: TextStyle(
                                    color: Color(0xff757D90),
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                  ),
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Color(0x00000000),
                                      width: 1,
                                    ),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(4.0),
                                      topRight: Radius.circular(4.0),
                                    ),
                                  ),
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Color(0x00000000),
                                      width: 1,
                                    ),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(4.0),
                                      topRight: Radius.circular(4.0),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                    ),
                    _startedSearch
                        ? InkWell(
                            onTap: () {
                              searchKeywordController?.text = '';
                              filter = {
                                'page': 1,
                                'sort': 'most_view',
                                'filter': {
                                  'color': [],
                                  'brand': '',
                                  'gender': ['', '', ''],
                                  'price': {
                                    'gte': 1.0,
                                    'lte': 1000000.0,
                                  },
                                },
                              };
                              colorQuery = '';
                              _startedSearch = false;
                              startedSearchGlobal = _startedSearch;
                              searchClick = false;
                              autoFocus = false;
                              setState(() {});
                            },
                            child: const Icon(
                              CupertinoIcons.clear_circled,
                              color: Color(0xff757D90),
                              size: 32,
                            ),
                          )
                        : Container(),
                  ],
                ),
              ),
            ),
          ),
        ),
        _startedSearch
            ? Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(50, 15, 50, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '${AppLocalizations.of(context).search_results}: $totalProducts',
                      style: const TextStyle(
                        color: Color(0xff757D90),
                        fontWeight: FontWeight.w700,
                        fontSize: 18,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        _scaffoldKey.currentState?.openEndDrawer();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            AppLocalizations.of(context).search_filters,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Color(0xff757D90),
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          Image.asset(
                            'assets/etc/slider.gif',
                            fit: BoxFit.fitHeight,
                            width: 30,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            : const SizedBox(
                width: 0,
                height: 0,
              ),
        _startedSearch
            ? Expanded(
                key: paginationViewKey,
                child: PaginationView<Product>(
                  scrollController: searchResultScrollController,
                  padding: const EdgeInsets.only(left: 12, right: 12),
                  pullToRefresh: true,
                  paginationViewType: PaginationViewType.gridView,
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemBuilder:
                      (BuildContext context, Product product, int index) {
                    return GridTile(
                      child: Container(
                        height: 10,
                        decoration: BoxDecoration(
                          border: index % 2 == 0
                              ? index == 0
                                  ? const Border(
                                      right: BorderSide(
                                        color: Color(0xffC4C4C4),
                                        width: 0.2,
                                      ),
                                    )
                                  : const Border(
                                      right: BorderSide(
                                        color: Color(0xffC4C4C4),
                                        width: 0.2,
                                      ),
                                      top: BorderSide(
                                        color: Color(0xffC4C4C4),
                                        width: 0.2,
                                      ),
                                    )
                              : index == 1
                                  ? const Border(
                                      top: BorderSide(
                                        color: Colors.transparent,
                                        width: 0,
                                      ),
                                    )
                                  : const Border(
                                      top: BorderSide(
                                        color: Color(0xffC4C4C4),
                                        width: 0.2,
                                      ),
                                    ),
                        ),
                        child: InkWell(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Stack(
                                children: [
                                  Align(
                                    child: Container(
                                      height: 100,
                                      alignment: Alignment.bottomCenter,
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              30, 0, 30, 0),
                                      child: CachedNetworkImage(
                                        imageUrl: product.imageLink,
                                        fit: BoxFit.contain,
                                        errorWidget:
                                            (context, error, stackTrace) {
                                          return CachedNetworkImage(
                                            imageUrl: product.imageLink,
                                            fit: BoxFit.contain,
                                            errorWidget:
                                                (context, error, stackTrace) {
                                              return Image.asset(
                                                'assets/etc/NoImage.png',
                                                fit: BoxFit.contain,
                                              );
                                            },
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: const Alignment(0.75, 0.1),
                                    child: product.underretail == 'yes'
                                        ? Padding(
                                            padding: EdgeInsets.only(top: 5),
                                            child: Container(
                                              width: 36,
                                              height: 24,
                                              decoration: const BoxDecoration(
                                                color: Color(0xFFF55E5E),
                                                borderRadius:
                                                    const BorderRadius.all(
                                                  Radius.circular(5.0),
                                                ),
                                              ),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    'Under',
                                                    textAlign: TextAlign.center,
                                                    style: w900White8,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 1,
                                                  ),
                                                  Text(
                                                    'Retail',
                                                    textAlign: TextAlign.center,
                                                    style: w900White8,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          )
                                        : Container(),
                                  ),
                                ],
                              ),
                              Expanded(
                                flex: 1,
                                child: Flex(
                                  direction: Axis.vertical,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      product.title,
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.roboto(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 16,
                                        color: const Color(0xff757D90),
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 2,
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: Flex(
                                  direction: Axis.vertical,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0, 0, 0, 0),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            '${product.shopfoundsearch}${AppLocalizations.of(context).calendar_shops}',
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w400,
                                              color: Color(0xff757D90),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(0),
                                      child: Align(
                                        alignment:
                                            const AlignmentDirectional(0.2, 0),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            RichText(
                                              // key: _priceKey,
                                              textAlign: TextAlign.left,
                                              maxLines: 1,
                                              text: TextSpan(
                                                children: [
                                                  TextSpan(
                                                    text: getPriceWithCurrency(
                                                      product.showprice
                                                          .replaceAll('€', ''),
                                                    ),
                                                    style: GoogleFonts.roboto(
                                                      fontSize: 16,
                                                      color:
                                                          product.productChangeArrow !=
                                                                  'Red'
                                                              ? const Color(
                                                                  0xFF21ED8B)
                                                              : const Color(
                                                                  0xffF55E5E),
                                                      fontWeight:
                                                          FontWeight.w400,
                                                    ),
                                                  ),
                                                  WidgetSpan(
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 10),
                                                      child:
                                                          product.productChangeArrow !=
                                                                  'Red'
                                                              ? const Icon(
                                                                  Icons
                                                                      .trending_up_rounded,
                                                                  color: Color(
                                                                      0xFF21ED8B),
                                                                  size: 18,
                                                                )
                                                              : const Icon(
                                                                  Icons
                                                                      .trending_down_rounded,
                                                                  color: Color(
                                                                      0xffF55E5E),
                                                                  size: 18,
                                                                ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          onTap: () async {
                            productDetail = await getProductDetail(product.id);
                            Navigator.of(context).pushNamed("/ProductDetail");
                          },
                        ),
                      ),
                    );
                  },

                  // ),
                  pageFetch: getProductWithPage,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1.03,
                  ),
                  physics: const BouncingScrollPhysics(),
                  onError: (dynamic error) => const Center(
                    child: Text('Some error occurred'),
                  ),
                  onEmpty: const Center(
                    child: Text('Sorry! This is empty'),
                  ),
                  bottomLoader: const Center(
                    child: CircularProgressIndicator(),
                  ),
                  initialLoader: const Center(
                    child: CircularProgressIndicator(),
                  ),
                ),
              )
            : Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  children: [
                    Container(
                      height: 110,
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: listJordan.length,
                        itemBuilder: (context, position) {
                          return InkWell(
                            onTap: () {
                              setState(() {
                                searchClick = true;
                              });
                              searchKeywordController?.text =
                                  listJordan[position]['searchKey'];
                            },
                            child: (position == 0)
                                ? const Image(
                                    image: AssetImage(
                                        'assets/brands/black/Jordan.png'),
                                    width: 70,
                                  )
                                : Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(8, 5, 8, 10),
                                    child: Material(
                                      elevation: 5,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(14.0)),
                                      child: Container(
                                        width: 150,
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(14.0)),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              3, 0, 3, 0),
                                          child: Stack(
                                            children: [
                                              Align(
                                                alignment:
                                                    const Alignment(0, 0),
                                                child: Image(
                                                  image: AssetImage(
                                                      listJordan[position]
                                                          ['image']),
                                                  width: 150,
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    const Alignment(-0.8, -0.8),
                                                child: Text(
                                                  listJordan[position]['key'],
                                                  style: const TextStyle(
                                                    fontFamily: 'Roboto',
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color.fromARGB(
                                                        255, 105, 104, 105),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                          );
                        },
                      ),
                    ),
                    Container(
                      height: 110,
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: listNike.length,
                        itemBuilder: (context, position) {
                          return InkWell(
                            onTap: () {
                              setState(() {
                                searchClick = true;
                              });
                              searchKeywordController?.text =
                                  listNike[position]['searchKey'];
                            },
                            child: (position == 0)
                                ? const Image(
                                    image: AssetImage(
                                        'assets/brands/black/Nike.png'),
                                    width: 70,
                                  )
                                : Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(8, 5, 8, 10),
                                    child: Material(
                                      elevation: 5,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(14.0)),
                                      child: Container(
                                        width: 150,
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(14.0)),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              3, 0, 3, 0),
                                          child: Stack(
                                            children: [
                                              Align(
                                                alignment:
                                                    const Alignment(0, 0),
                                                child: Image(
                                                  image: AssetImage(
                                                      listNike[position]
                                                          ['image']),
                                                  width: 150,
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    const Alignment(-0.8, -0.8),
                                                child: Text(
                                                  listNike[position]['key'],
                                                  style: const TextStyle(
                                                    fontFamily: 'Roboto',
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color.fromARGB(
                                                        255, 105, 104, 105),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                          );
                        },
                      ),
                    ),
                    Container(
                      height: 110,
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: listAdidas.length,
                        itemBuilder: (context, position) {
                          return InkWell(
                            onTap: () {
                              setState(() {
                                searchClick = true;
                              });
                              searchKeywordController?.text =
                                  listAdidas[position]['searchKey'];
                            },
                            child: (position == 0)
                                ? const Image(
                                    image: AssetImage(
                                        'assets/brands/black/Adidas.png'),
                                    width: 70,
                                  )
                                : Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(8, 5, 8, 10),
                                    child: Material(
                                      elevation: 5,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(14.0)),
                                      child: Container(
                                        width: 150,
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(14.0)),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              3, 0, 3, 0),
                                          child: Stack(
                                            children: [
                                              Align(
                                                alignment:
                                                    const Alignment(0, 0),
                                                child: Image(
                                                  image: AssetImage(
                                                      listAdidas[position]
                                                          ['image']),
                                                  width: 150,
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    const Alignment(-0.8, -0.8),
                                                child: Text(
                                                  listAdidas[position]['key'],
                                                  style: const TextStyle(
                                                    fontFamily: 'Roboto',
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color.fromARGB(
                                                        255, 105, 104, 105),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                          );
                        },
                      ),
                    ),
                    Container(
                      height: 110,
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: listNewBalance.length,
                        itemBuilder: (context, position) {
                          return InkWell(
                            onTap: () {
                              setState(() {
                                searchClick = true;
                              });
                              searchKeywordController?.text =
                                  listNewBalance[position]['searchKey'];
                            },
                            child: (position == 0)
                                ? const Image(
                                    image: AssetImage(
                                        'assets/brands/black/New Balance.png'),
                                    width: 70,
                                  )
                                : Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(8, 5, 8, 10),
                                    child: Material(
                                      elevation: 5,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(14.0)),
                                      child: Container(
                                        width: 150,
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(14.0)),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              3, 0, 3, 0),
                                          child: Stack(
                                            children: [
                                              Align(
                                                alignment:
                                                    const Alignment(0, 0),
                                                child: Image(
                                                  image: AssetImage(
                                                      listNewBalance[position]
                                                          ['image']),
                                                  width: 150,
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    const Alignment(-0.8, -0.8),
                                                child: Text(
                                                  listNewBalance[position]
                                                      ['key'],
                                                  style: const TextStyle(
                                                    fontFamily: 'Roboto',
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.bold,
                                                    color: Color.fromARGB(
                                                        255, 105, 104, 105),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                          );
                        },
                      ),
                    ),
                    // Padding(
                    //   padding: const EdgeInsets.fromLTRB(20, 5, 20, 5),
                    //   child: Column(
                    //     mainAxisAlignment: MainAxisAlignment.center,
                    //     crossAxisAlignment: CrossAxisAlignment.center,
                    //     mainAxisSize: MainAxisSize.min,
                    //     children: const [
                    //       Text(
                    //         'Genders',
                    //         style: TextStyle(
                    //           // fontFamily: 'Roboto',
                    //           fontSize: 26,
                    //           fontWeight: FontWeight.bold,
                    //         ),
                    //       ),
                    //       Text(
                    //         'Adjust for specific gender',
                    //         style: TextStyle(
                    //           fontSize: 11,
                    //           color: Color(0xff757D90),
                    //         ),
                    //       ),
                    //     ],
                    //   ),
                    // ),
                    const SizedBox(
                      height: 10,
                    ),
                    const Padding(
                      padding: EdgeInsets.fromLTRB(40, 0, 40, 0),
                      child: Divider(
                        color: Colors.black12,
                        height: 0,
                        thickness: 2,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(30, 20, 30, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          InkWell(
                            onTap: () {
                              searchKeywordController?.text = ' ';
                              filter['filter']['gender'] = ['', '', ''];
                              _startedSearch = true;
                              startedSearchGlobal = _startedSearch;
                              isMatchAnd = true;
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                              setState(() {});
                            },
                            child: Material(
                              elevation: 5,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(14.0)),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(14.0)),
                                ),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(3, 5, 3, 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 45,
                                        padding: const EdgeInsets.all(5),
                                        child: const Image(
                                          image: AssetImage(
                                              'assets/icons/unisex.png'),
                                        ),
                                      ),
                                      Text(
                                        AppLocalizations.of(context)
                                            .search_unisex,
                                        style: TextStyle(
                                            color: Color(0xff757d90),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              searchKeywordController?.text = 'MEN';
                              filter['filter']['gender'][0] = 'MEN';
                              _startedSearch = true;
                              startedSearchGlobal = _startedSearch;
                              isMatchAnd = true;
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                              setState(() {});
                            },
                            child: Material(
                              elevation: 5,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(14.0)),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(14.0)),
                                ),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(3, 5, 3, 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 45,
                                        padding: const EdgeInsets.all(5),
                                        child: const Image(
                                          image: AssetImage(
                                              'assets/icons/men.png'),
                                        ),
                                      ),
                                      Text(
                                        AppLocalizations.of(context).search_men,
                                        style: TextStyle(
                                            color: Color(0xff757d90),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              searchKeywordController?.text = '(W)';
                              filter['filter']['gender'][0] = 'WOMEN';
                              _startedSearch = true;
                              startedSearchGlobal = _startedSearch;
                              isMatchAnd = true;
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                              setState(() {});
                            },
                            child: Material(
                              elevation: 5,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(14.0)),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(14.0)),
                                ),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(3, 5, 3, 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 45,
                                        padding: const EdgeInsets.all(5),
                                        child: const Image(
                                          image: AssetImage(
                                              'assets/icons/women.png'),
                                        ),
                                      ),
                                      Text(
                                        AppLocalizations.of(context)
                                            .search_women,
                                        style: TextStyle(
                                            color: Color(0xff757d90),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              searchKeywordController?.text = '(PS)';
                              filter['filter']['gender'][0] = 'KIDS';
                              _startedSearch = true;
                              startedSearchGlobal = _startedSearch;
                              isMatchAnd = true;
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                              setState(() {});
                            },
                            child: Material(
                              elevation: 5,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(14.0)),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(14.0)),
                                ),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(3, 5, 3, 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 45,
                                        padding: const EdgeInsets.all(5),
                                        child: const Image(
                                          image: AssetImage(
                                              'assets/icons/kids.png'),
                                        ),
                                      ),
                                      Text(
                                        AppLocalizations.of(context)
                                            .search_kids,
                                        style: TextStyle(
                                            color: Color(0xff757d90),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () {
                              searchKeywordController?.text = '(TD)';
                              filter['filter']['gender'][0] = 'KIDS';
                              _startedSearch = true;
                              startedSearchGlobal = _startedSearch;
                              isMatchAnd = true;
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                              setState(() {});
                            },
                            child: Material(
                              elevation: 5,
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(14.0)),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(14.0)),
                                ),
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(3, 5, 3, 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        height: 45,
                                        padding: const EdgeInsets.all(5),
                                        child: const Image(
                                          image: AssetImage(
                                              'assets/icons/baby.png'),
                                        ),
                                      ),
                                      Text(
                                        AppLocalizations.of(context)
                                            .search_baby,
                                        style: TextStyle(
                                            color: Color(0xff757d90),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 120,
                    ),
                  ],
                ),
              ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor:
          _startedSearch ? const Color(0xffffffff) : const Color(0xfff6f6f6),
      body: searchPage(context),
      onEndDrawerChanged: (isOpen) {
        searchFilterSideDrawMenuOpen.value = isOpen;
      },
      endDrawer: Drawer(
        child: Padding(
          padding: const EdgeInsets.only(top: 24, bottom: 80),
          child: ListView(
            // Important: Remove any padding from the ListView.
            padding: EdgeInsets.zero,
            children: [
              Container(
                color: const Color(0xffeeeeee),
                child: Container(
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        width: 0.8,
                        color: Color(0xffdddddd),
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(
                          child: Text(
                            AppLocalizations.of(context).search_filterClear,
                            style: TextStyle(
                              color: Colors.black54,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                          onPressed: () {},
                        ),
                        TextButton(
                          child: Text(
                            AppLocalizations.of(context).search_filterClose,
                            style: TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                          onPressed: () {
                            _scaffoldKey.currentState?.closeEndDrawer();
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                color: const Color(0xfff6f6f6),
                child: Container(
                  decoration: const BoxDecoration(
                      border: Border(
                          bottom: BorderSide(
                    width: 0.8,
                    color: Color(0xffdddddd),
                  ))),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: CustomExpansionTile(
                      initiallyExpanded: true,
                      title: Text(
                        "${AppLocalizations.of(context).search_filterSortBy}:",
                      ),
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              RadioListTile(
                                title: Text(AppLocalizations.of(context)
                                    .search_filterRelevance),
                                value: SortOptions.relevance,
                                groupValue: _sortBy,
                                onChanged: (SortOptions? value) {
                                  setState(() {
                                    filter['sort'] = 'relevance';
                                    _sortBy = value!;
                                    if (_startedSearch) {
                                      paginationViewKey =
                                          GlobalKey<PaginationViewState>();
                                    }
                                  });
                                },
                              ),
                              RadioListTile(
                                title: Text(AppLocalizations.of(context)
                                    .search_filterMostView),
                                value: SortOptions.mostView,
                                groupValue: _sortBy,
                                onChanged: (SortOptions? value) {
                                  setState(() {
                                    filter['sort'] = 'most_view';
                                    _sortBy = value!;
                                    if (_startedSearch) {
                                      paginationViewKey =
                                          GlobalKey<PaginationViewState>();
                                    }
                                  });
                                },
                              ),
                              RadioListTile(
                                title: Text(AppLocalizations.of(context)
                                    .search_filterReleaseDate),
                                value: SortOptions.releaseDate,
                                groupValue: _sortBy,
                                onChanged: (SortOptions? value) {
                                  setState(() {
                                    filter['sort'] = 'latest_release_date';
                                    // _startedSearch = true;
                                    _sortBy = value!;
                                    if (_startedSearch) {
                                      paginationViewKey =
                                          GlobalKey<PaginationViewState>();
                                    }
                                  });
                                },
                              ),
                              RadioListTile(
                                title: Text(AppLocalizations.of(context)
                                    .search_filterPriceHighToLow),
                                value: SortOptions.priceAsc,
                                groupValue: _sortBy,
                                onChanged: (SortOptions? value) {
                                  setState(() {
                                    filter['sort'] = 'price_asc';
                                    _sortBy = value!;
                                    if (_startedSearch) {
                                      paginationViewKey =
                                          GlobalKey<PaginationViewState>();
                                    }
                                  });
                                },
                              ),
                              RadioListTile(
                                title: Text(AppLocalizations.of(context)
                                    .search_filterPriceHighToLow),
                                value: SortOptions.priceDsc,
                                groupValue: _sortBy,
                                onChanged: (SortOptions? value) {
                                  setState(() {
                                    filter['sort'] = 'price_desc';
                                    _sortBy = value!;
                                    if (_startedSearch) {
                                      paginationViewKey =
                                          GlobalKey<PaginationViewState>();
                                    }
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                color: const Color(0xfff6f6f6),
                child: Column(
                  children: [
                    Container(
                      decoration: const BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            width: 0.8,
                            color: Color(0xffdddddd),
                          ),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: CustomExpansionTile(
                          initiallyExpanded: true,
                          title: Text(
                              AppLocalizations.of(context).search_filterPrice),
                          children: <Widget>[
                            RangeSlider(
                              divisions: 51,
                              activeColor: Colors.grey[700],
                              inactiveColor: Colors.grey[500],
                              min: priceFrom,
                              max: priceTo,
                              values: rangeValues,
                              labels: rangeLabels,
                              onChanged: (value) {
                                setState(() {
                                  rangeValues = RangeValues(
                                    double.parse(value.start
                                        .toDouble()
                                        .toStringAsFixed(0)),
                                    double.parse(value.end
                                        .toDouble()
                                        .toStringAsFixed(0)),
                                  );
                                  rangeLabels = RangeLabels(
                                    "${value.start.toDouble().toStringAsFixed(0)}€",
                                    "${value.end.toDouble() != 2550 ? value.end.toDouble().toStringAsFixed(0) : '2500+'}€",
                                  );
                                  filter['filter']['price']['gte'] =
                                      value.start;
                                  if (value.end <= 2500) {
                                    filter['filter']['price']['lte'] =
                                        value.end;
                                  } else {
                                    filter['filter']['price']['lte'] =
                                        1000000.0;
                                  }
                                  if (_startedSearch) {
                                    paginationViewKey =
                                        GlobalKey<PaginationViewState>();
                                  }
                                });
                              },
                            ),
                            InkWell(
                              onTap: (() {
                                if (filter['filter']['underretail'] == 'yes') {
                                  setState(() {
                                    filter['filter']['underretail'] = '';
                                  });
                                } else {
                                  setState(() {
                                    filter['filter']['underretail'] = 'yes';
                                  });
                                }

                                if (_startedSearch) {
                                  paginationViewKey =
                                      GlobalKey<PaginationViewState>();
                                }
                              }),
                              child: Container(
                                padding:
                                    const EdgeInsets.fromLTRB(0, 10, 0, 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    filter['filter']['underretail'] == 'yes'
                                        ? Icon(
                                            Icons.check,
                                            color: Color(0xFF313036),
                                            size: 18,
                                          )
                                        : Icon(
                                            Icons.square_outlined,
                                            color: Color(0xFF313036),
                                            size: 18,
                                          ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(AppLocalizations.of(context)
                                        .search_filterUnderRetail),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                color: const Color(0xfff6f6f6),
                child: Container(
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        width: 0.8,
                        color: Color(0xffdddddd),
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: CustomExpansionTile(
                      initiallyExpanded: true,
                      title: Text(
                          AppLocalizations.of(context).search_filterGender),
                      children: <Widget>[
                        MultiSelectContainer<GenderOptions>(
                          prefix: MultiSelectPrefix(
                            selectedPrefix: const Padding(
                              padding: EdgeInsets.only(right: 5),
                              child: Icon(
                                Icons.check,
                                color: Colors.white,
                                size: 14,
                              ),
                            ),
                          ),
                          itemsDecoration: MultiSelectDecorations(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(color: Colors.grey[400]!),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            selectedDecoration: BoxDecoration(
                              color: Colors.grey[700]!,
                              border: Border.all(color: Colors.grey[900]!),
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          items: [
                            MultiSelectCard(
                              selected:
                                  filter['filter']['gender'].contains('MEN'),
                              value: GenderOptions.men,
                              label:
                                  '${AppLocalizations.of(context).search_filterMen} ($_amount4Men)',
                            ),
                            MultiSelectCard(
                              selected:
                                  filter['filter']['gender'].contains('WOMEN'),
                              value: GenderOptions.women,
                              label:
                                  '${AppLocalizations.of(context).search_filterWomen} ($_amount4Women)',
                            ),
                            MultiSelectCard(
                              selected:
                                  filter['filter']['gender'].contains('KIDS'),
                              value: GenderOptions.kids,
                              label:
                                  '${AppLocalizations.of(context).search_filterKids} ($_amount4Kids)',
                            ),
                          ],
                          onChange: (allSelectedItems, selectedItem) {
                            filter['filter']['gender'] = allSelectedItems.map(
                              (e) => e.toString().split('.').last.toUpperCase(),
                            );
                            if (_startedSearch) {
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                            }
                            setState(() {});
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                color: const Color(0xfff6f6f6),
                child: Container(
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        width: 0.8,
                        color: Color(0xffdddddd),
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: CustomExpansionTile(
                      initiallyExpanded: true,
                      title: Text(
                          AppLocalizations.of(context).search_filterColors),
                      children: <Widget>[
                        MultiSelectContainer(
                          itemsDecoration: MultiSelectDecorations(
                            selectedDecoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(100)),
                          ),
                          items: productColorMap.map((e) {
                            var result = MultiSelectCard(
                              selected: filter['filter']['color']
                                  .contains(e.keys.toList().first),
                              value: e.keys.toList().first,
                              child: Container(
                                width: 30,
                                height: 30,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.grey[400]!,
                                  ),
                                  color: e[e.keys.toList().first],
                                ),
                              ),
                            );

                            if (e.keys.toList().first == 'multicolor') {
                              result = MultiSelectCard(
                                value: e.keys.toList().first,
                                selected: filter['filter']['color']
                                    .contains(e.keys.toList().first),
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Colors.grey[400]!,
                                    ),
                                    gradient: const SweepGradient(
                                      colors: [
                                        Color(0xff8e1f23),
                                        Color(0xffd04514),
                                        Color(0xffe96321),
                                        Color(0xffee9100),
                                        Color(0xfff6b600),
                                        Color(0xffdec200),
                                        Color(0xff79a439),
                                        Color(0xff43744e),
                                        Color(0xff3a748f),
                                        Color(0xff4053a0),
                                        Color(0xff3a3d99),
                                        Color(0xff8b2e61),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }
                            return result;
                          }).toList(),
                          onChange: (allSelectedItems, selectedItem) {
                            filter['filter']['color'] = allSelectedItems;
                            if (_startedSearch) {
                              paginationViewKey =
                                  GlobalKey<PaginationViewState>();
                            }
                            setState(() {});
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  DateTime currentBackPressTime = DateTime.now();

  void _reloadSearchScreen() {
    setState(() {
      searchKeywordController?.text = '';
      filter = {
        'page': 1,
        'sort': 'most_view',
        'filter': {
          'color': [],
          'brand': '',
          'gender': ['', '', ''],
          'price': {
            'gte': 1.0,
            'lte': 1000000.0,
          },
        },
      };
      paginationViewKey = GlobalKey<PaginationViewState>();
      _startedSearch = false;
      startedSearchGlobal = _startedSearch;
    });
  }

  Future<bool> _onBackPressed() {
    if (_startedSearch) {
      _reloadSearchScreen();

      return Future.value(false);
    } else {
      DateTime now = DateTime.now();
      if (now.difference(currentBackPressTime) > const Duration(seconds: 2)) {
        currentBackPressTime = now;
        Fluttertoast.showToast(msg: 'Press Back Button Again to Exit');

        return Future.value(false);
      }
      exit(0);
    }
  }
}
