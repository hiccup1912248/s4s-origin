import 'dart:convert';

import 'package:app_settings/app_settings.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_fgbg/flutter_fgbg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'package:intl/intl.dart';
import 'package:pagination_view/pagination_view.dart';
import 'package:s4s_mobileapp/map/page_map.dart';
import 'package:s4s_mobileapp/product/product_detail_widget.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:s4s_mobileapp/widgets/custom_expansion_tile.dart';
import 'dart:async';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:wakelock/wakelock.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:http/http.dart' as http;
import 'package:notification_permissions/notification_permissions.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../models/product.dart';

int positionRestockPage = 0;
int positionRestockMain = 0;

bool isOnline = true;
bool isInstore = false;

bool isJordan = false;
bool isNike = false;
bool isAdidas = false;
bool isYeezy = false;
bool isNewbalance = false;

String colorQuery = '';
String getQueryParams(Map filter) {
  String query = '';
  // color filter
  List color = filter['filter']['color'];
  // String colorQuery = '';
  colorQuery = '';
  for (var e in color) {
    // colorQuery = '&filter%5Bcolor%5D%5B%5D=$e$colorQuery';
    colorQuery = '$colorQuery%20$e';
  }
  var gender = filter['filter']['gender'];
  String genderQuery = '';
  for (var e in gender) {
    if (e != '') {
      genderQuery = '&filter%5Bgender%5D%5B%5D=$e$genderQuery';
    }
  }
  String sortQuery = '';
  switch (filter['sort']) {
    case 'latest_release_date':
      {
        sortQuery = '&sort%5B0%5D%5Bproduct_release_date%5D=desc';
      }
      break;
    case 'price_asc':
      {
        sortQuery = '&sort%5B0%5D%5Bprice%5D=asc';
      }
      break;
    case 'price_desc':
      {
        sortQuery = '&sort%5B0%5D%5Bprice%5D=desc';
      }
      break;
    default:
      {
        sortQuery = '';
      }
      break;
  }
  // price filter
  String priceQuery = '';
  priceQuery =
      '&filter%5Bprice%5D%5Bgte%5D=${filter['filter']['price']['gte']}&filter%5Bprice%5D%5Blt%5D=${filter['filter']['price']['lte']}';

  // query = '$colorQuery$brandQuery$genderQuery$sortQuery$priceQuery';
  query = '$genderQuery$sortQuery$priceQuery';

  return query;
}

String notificationProductSku = "";

class RestockWidget extends StatefulWidget {
  const RestockWidget({Key? key}) : super(key: key);

  @override
  State<RestockWidget> createState() => _RestockWidgetState();
}

class _RestockWidgetState extends State<RestockWidget> {
  List<Map> restock = [];
  List<Map> instore = [];
  Timer? timer;
  List<String> checkedShops = [];
  List<String> checkedCountrys = [];
  List<String> expandedShopDetail = [];
  List<String> brands = [];
  List<Map<dynamic, dynamic>> shopDetails = [
    {
      'shopTypeName': 'EU',
      'shopType': "EU",
      'shopTypeLogo': "assets/etc/shop_region/EU.png",
      'shops': [
        {'id': 'EU_18Montrose', 'name': '18Montrose'},
        {'id': 'EU_4Elementos', 'name': '4Elementos'},
        {'id': 'EU_43Einhalb', 'name': '43Einhalb'},
        {'id': 'EU_About You', 'name': 'About You'},
        {'id': 'EU_Adidas', 'name': 'Adidas'},
        {'id': 'EU_Afew', 'name': 'Afew'},
        {'id': 'EU_Allike', 'name': 'Allike'},
        {'id': 'EU_Arcteryx', 'name': 'Arcteryx'},
        {'id': 'EU_Asphaltgold', 'name': 'Asphaltgold'},
        {'id': 'EU_Asos', 'name': 'Asos'},
        {'id': 'EU_Bata', 'name': 'Bata'},
        {'id': 'EU_Breuninger', 'name': 'Breuninger'},
        {'id': 'EU_BSTN', 'name': 'BSTN', 'marked': true},
        {'id': 'EU_Courir', 'name': 'Courir', 'marked': true},
        {'id': 'EU_End Clothing', 'name': 'End Clothing'},
        {'id': 'EU_Engelhorn', 'name': 'Engelhorn'},
        {'id': 'EU_Eschuhe', 'name': 'Eschuhe'},
        {'id': 'EU_Footasylum', 'name': 'Footasylum'},
        {'id': 'EU_Footdistrict', 'name': 'Footdistrict'},
        {'id': 'EU_Footlocker', 'name': 'Footlocker'},
        {'id': 'EU_Footpatrol', 'name': 'Footpatrol'},
        {'id': 'EU_Footshop', 'name': 'Footshop'},
        {'id': 'EU_Harvey Nichols', 'name': 'Harvey Nichols'},
        {'id': 'EU_HHV', 'name': 'HHV'},
        {'id': 'EU_JDSports', 'name': 'JDSports'},
        {'id': 'EU_Juice', 'name': 'Juice'},
        {'id': 'EU_Kickz', 'name': 'Kickz'},
        {'id': 'EU_Luisaviaroma', 'name': 'Luisaviaroma', 'marked': true},
        {'id': 'EU_Mr Porter', 'name': 'Mr Porter'},
        {'id': 'EU_MyTheresa', 'name': 'MyTheresa'},
        {'id': 'EU_Naked', 'name': 'Naked'},
        {'id': 'EU_New Balance', 'name': 'New Balance'},
        {'id': 'EU_Nigra Mercato', 'name': 'Nigra Mercato'},
        {'id': 'EU_Nike', 'name': 'Nike', 'marked': true},
        {'id': 'EU_Nordstrom', 'name': 'Nordstrom'},
        {'id': 'EU_Office', 'name': 'Office'},
        {'id': 'EU_Offspring', 'name': 'Offspring'},
        {'id': 'EU_Onygo', 'name': 'Onygo'},
        {'id': 'EU_Opium Paris', 'name': 'Opium Paris'},
        {'id': 'EU_Overkill', 'name': 'Overkill'},
        {'id': 'EU_Puma', 'name': 'Puma'},
        {'id': 'EU_Queens', 'name': 'Queens'},
        {'id': 'EU_Saks', 'name': 'Saks'},
        {'id': 'EU_Schuh', 'name': 'Schuh'},
        {'id': 'EU_Sidestep', 'name': 'Sidestep'},
        {'id': 'EU_Size', 'name': 'Size'},
        {'id': 'EU_Slamjam', 'name': 'Slamjam'},
        {'id': 'EU_Sneakerbaas', 'name': 'Sneakerbaas'},
        {'id': 'EU_Sneakersnstuff', 'name': 'Sneakersnstuff', 'marked': true},
        {'id': 'EU_Snipes', 'name': 'Snipes'},
        {'id': 'EU_Solebox', 'name': 'Solebox'},
        {'id': 'EU_SSENSE', 'name': 'SSENSE'},
        {'id': 'EU_Urban Outfitters', 'name': 'Urban Outfitters'},
      ],
    },
    {
      'shopTypeName': 'USA',
      'shopType': "US",
      'shopTypeLogo': "assets/etc/shop_region/US.png",
      'shops': [
        {'id': 'US_Adidas', 'name': 'Adidas'},
        {'id': 'US_Arcteryx', 'name': 'Arcteryx'},
        {'id': 'US_Asos', 'name': 'Asos'},
        {'id': 'US_Bodega', 'name': 'Bodega'},
        {'id': 'US_BSTN', 'name': 'BSTN'},
        {'id': 'US_Champs Sports', 'name': 'Champs Sports'},
        {'id': 'US_DTLR', 'name': 'DTLR'},
        {'id': 'US_End Clothing', 'name': 'End Clothing', 'marked': true},
        {'id': 'US_Finish Line', 'name': 'Finish Line'},
        {'id': 'US_Footlocker', 'name': 'Footlocker'},
        {'id': 'US_Footshop', 'name': 'Footshop'},
        {'id': 'US_JDSports', 'name': 'JDSports'},
        {'id': 'US_Jimmy Jazz', 'name': 'Jimmy Jazz'},
        {'id': 'US_Juice', 'name': 'Juice'},
        {'id': 'US_Kids Footlocker', 'name': 'Kids Footlocker'},
        {'id': 'US_Luisaviaroma', 'name': 'Luisaviaroma', 'marked': true},
        {'id': 'US_Mr Porter', 'name': 'Mr Porter'},
        {'id': 'US_Net A Porter', 'name': 'Net A Porter', 'marked': true},
        {'id': 'US_New Balance', 'name': 'New Balance', 'marked': true},
        {'id': 'US_Nike', 'name': 'Nike', 'marked': true},
        {'id': 'US_Nordstrom', 'name': 'Nordstrom'},
        {'id': 'US_Revolve', 'name': 'Revolve'},
        {'id': 'US_Saks', 'name': 'Saks'},
        {'id': 'US_Shiekh', 'name': 'Shiekh'},
        {'id': 'US_Shoe Palace', 'name': 'Shoe Palace', 'marked': true},
        {'id': 'US_Shop Nice Kicks', 'name': 'Shop Nice Kicks', 'marked': true},
        {'id': 'US_Slamjam', 'name': 'Slamjam'},
        {'id': 'US_Sneakersnstuff', 'name': 'Sneakersnstuff', 'marked': true},
        {'id': 'US_SSENSE', 'name': 'SSENSE'},
        {'id': 'US_Under Armour', 'name': 'Under Armour'},
        {'id': 'US_WSS', 'name': 'WSS'},
        {'id': 'US_YCMC', 'name': 'YCMC'},
      ],
    },
    {
      'shopTypeName': 'CA',
      'shopType': "CA",
      'shopTypeLogo': "assets/etc/shop_region/CA.png",
      'shops': [
        {'id': 'CA_Deadstock', 'name': 'Deadstock'},
        {'id': 'CA_Footlocker', 'name': 'Footlocker'},
        {'id': 'CA_Jdsports', 'name': 'Jdsports'},
        {'id': 'CA_Nike', 'name': 'Nike'},
        {'id': 'CA_Size', 'name': 'Size'},
      ],
    },
  ];

  List<Map<dynamic, dynamic>> regionDetails = [
    {
      'regionName': 'Europe',
      'region': "EU",
      'regionLogo': "assets/etc/shop_region/EU.png",
      'countrys': [
        'Austria',
        'Belgium',
        'Bulgaria',
        'Czech Republic',
        'Denmark',
        'England',
        'Estonia',
        'European Union',
        'Finland',
        'France',
        'Germany',
        'Greece',
        'Hungary',
        'Iceland',
        'Ireland',
        'Italy',
        'Luxembourg',
        'Malta',
        'Netherlands',
        'Norway',
        'Poland',
        'Portugal',
        'Romania',
        'Spain',
        'Sweden',
        'Switzerland',
        'Turkey',
        'Ukraine',
        'United Kingdom',
      ],
    },
    {
      'regionName': 'USA',
      'region': "US",
      'regionLogo': "assets/etc/shop_region/US.png",
      'countrys': [],
    },
    {
      'regionName': 'Canada',
      'region': "CA",
      'regionLogo': "assets/etc/shop_region/CA.png",
      'countrys': [],
    },
  ];
  List<String> checkedBrands = [];
  List<String> checkedSizes = [];
  Map userData = {};
  bool euShopCheckAll = false;
  bool usShopCheckAll = false;
  bool caShopCheckAll = false;

  bool euRegionCheckAll = false;
  bool usRegionCheckAll = false;
  bool caRegionCheckAll = false;

  RegExp euShopReg = RegExp(r'^EU');
  RegExp usShopReg = RegExp(r'^US');
  RegExp caShopReg = RegExp(r'^CA');

  bool notifRestock = false;

  bool euChanceCheck = true;
  bool usChanceCheck = true;
  bool caChanceCheck = true;

  bool _speechRecognitionAvailable = false;
  final SpeechToText _speechToText = SpeechToText();
  final TextEditingController? searchKeywordController =
      TextEditingController();
  final ScrollController onlineScrollController = ScrollController();
  final ScrollController instoreScrollController = ScrollController();
  bool _isListening = false;
  bool _startedSearch = false;

  Map filter = {
    'page': 1,
    'sort': '',
    'filter': {
      'color': [],
      'brand': '',
      'gender': ['', '', ''],
      'price': {
        'gte': 1.0,
        'lte': 2550.0,
      },
    },
  };

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late GlobalKey<PaginationViewState> paginationViewKey;
  List<Product> goodList = [];
  List<Product> searchedProducts = [];

  bool autoFocus = false;
  late StreamSubscription<FGBGType> subscription;
  final PageController restockMainPageController =
      PageController(initialPage: 0);
  bool searchClick = false;

  bool resellLow = true;
  bool resellMid = true;
  bool resellHigh = true;

  @override
  void initState() {
    initSharePref();
    restock = restocks;
    instore = instores;
    getRestock().then((e) {
      restocks = e;
      if (mounted) {
        setState(() {
          restock = e;
        });
      }
    });
    getInstore().then((e) {
      instores = e;
      if (mounted) {
        setState(() {
          instore = e;
        });
      }
    });
    timer = Timer.periodic(const Duration(seconds: 10), (Timer timer) {
      getRestock().then((e) {
        restocks = e;
        if (mounted) {
          setState(() {
            restock = e;
          });
        }
      });

      getInstore().then((e) {
        instores = e;
        if (mounted) {
          setState(() {
            instore = e;
          });
        }
      });
    });

    Wakelock.toggle(enable: true);
    _initSpeech();

    searchKeywordController?.addListener(_triggerChanged);
    paginationViewKey = GlobalKey<PaginationViewState>();
    setWishProducts();
    // checkNotificationSettingStatus();
    subscription = FGBGEvents.stream.listen((event) {
      if (event == FGBGType.foreground) {
        checkNotificationSettingStatus();
        checkInitialScrollPosition();
      }
    });

    checkInitialScrollPosition();
    super.initState();
  }

  int getRestockIndex() {
    for (int i = 0; i < restock.length; i++) {
      if (notificationProductSku == restock[i]['ProductSKU']) {
        return i;
      }
    }

    return 0;
  }

  int getInstoreIndex() {
    for (int i = 0; i < instore.length; i++) {
      if (notificationProductSku == instore[i]['ProductSKU']) {
        return i;
      }
    }

    return 0;
  }

  void checkInitialScrollPosition() {
    if (notificationProductSku.isNotEmpty) {
      if (isOnline) {
        int i = getRestockIndex();
        onlineScrollController.animateTo(
          (i * 300).toDouble(),
          duration: const Duration(milliseconds: 50),
          curve: Curves.easeInOut,
        );
      }
      if (isInstore) {
        int i = getInstoreIndex();
        instoreScrollController.animateTo(
          (i * 407).toDouble(),
          duration: const Duration(milliseconds: 50),
          curve: Curves.easeInOut,
        );
      }
    }
  }

  void checkNotificationSettingStatus() {
    Future<PermissionStatus> permissionStatus =
        NotificationPermissions.getNotificationPermissionStatus();
    permissionStatus.then((value) {
      if (value == PermissionStatus.granted) {
        userNotificationOn(true);
        setState(() {
          notifRestock = true;
        });
      } else {
        userNotificationOn(false);
        setState(() {
          notifRestock = false;
        });
      }
    });
  }

  void setWishProducts() {
    List<String> wishProducts = prefs.getStringList("wishProducts") ?? [];
    List<Product> temp = [];
    if (wishProducts.isNotEmpty) {
      for (var el in wishProducts) {
        Map wishObject = jsonDecode(el);
        Product productTemp = Product(
          id: wishObject['productSku'],
          description: '',
          link: '',
          imageLink: wishObject['productImage'],
          productChangeArrow: '',
          shopfoundsearch: '',
          productSubcategory: '',
          bestPrice: 0,
          gender: '',
          dfGroupingId: '',
          dfid: '',
          dfscore: 0,
          highlight: {},
          price: 0,
          productChangeValue: '',
          productCount: '',
          productReleaseDate: wishObject['releaseDate'],
          showprice: '',
          title: wishObject['productName'],
          type: '',
          underretail: '',
        );
        temp.add(productTemp);
      }
    }
    setState(() {
      goodList = temp;
    });
  }

  Future<void> _triggerChanged() async {
    if (searchKeywordController?.value.text != '') {
      _startedSearch = true;
      paginationViewKey = GlobalKey<PaginationViewState>();
      List<Product> temp = await getProductWithPage();

      setState(() {
        searchedProducts = temp;
      });
    }
  }

  /// This has to happen only once per app
  void _initSpeech() async {
    _speechRecognitionAvailable = await _speechToText.initialize();
    setState(() {});
  }

  /// Each time to start a speech recognition session
  void _startListening() async {
    await _speechToText.listen(onResult: _onSpeechResult);
    setState(() {});
  }

  void _stopListening() async {
    await _speechToText.stop();
    setState(() {});
  }

  void _onSpeechResult(SpeechRecognitionResult result) {
    if (result.recognizedWords != '') {
      setState(() {
        searchKeywordController!.text = result.recognizedWords;
        _isListening = false;
      });
    } else {
      setState(() {
        _isListening = false;
      });
    }
  }

  bool checkShopIdByBestShops(String element, List<Map> shops) {
    for (var i = 0; i < shops.length; i++) {
      if (shops[i]['id'] == element) {
        return true;
      }
    }

    return false;
  }

  Future<void> shopCheckAllDetect(List<String> alreadyCheckedShops) async {
    bool euShop = alreadyCheckedShops
            .where((element) => euShopReg.hasMatch(element))
            .toList()
            .length ==
        shopDetails[0]['shops'].length;

    bool usShop = alreadyCheckedShops
            .where((element) => usShopReg.hasMatch(element))
            .toList()
            .length ==
        shopDetails[1]['shops'].length;
    bool caShop = alreadyCheckedShops
            .where((element) => caShopReg.hasMatch(element))
            .toList()
            .length ==
        shopDetails[2]['shops'].length;

    setState(() {
      euShopCheckAll = euShop;
      usShopCheckAll = usShop;
      caShopCheckAll = caShop;
    });
  }

  Future<void> countryCheckAllDetect(
      List<String> alreadyCheckedCountrys) async {
    List<String> countrys = alreadyCheckedCountrys
        .where((element) => (element != "US" && element != "CA"))
        .toList();
    bool euShop = alreadyCheckedCountrys
            .where((element) => (element != "US" && element != "CA"))
            .toList()
            .length ==
        regionDetails[0]['countrys'].length;

    bool usShop = !alreadyCheckedCountrys.indexOf("US").isNegative;
    bool caShop = !alreadyCheckedCountrys.indexOf("CA").isNegative;

    setState(() {
      euRegionCheckAll = euShop;
      usRegionCheckAll = usShop;
      caRegionCheckAll = caShop;
    });
  }

  Future<void> bestShopCheckAllDetect(List<String> alreadyCheckedShops) async {
    if (alreadyCheckedShops.isEmpty) {
      List<Map> shops = [];
      List<String> checkedShopsTemp = [];
      shops = shopDetails[0]['shops'];
      for (var i = 0; i < shops.length; i++) {
        String id = shops[i]['id'];
        if (shops[i]['marked'] == true) {
          checkedShopsTemp.add(id);
        }
      }

      shops = shopDetails[1]['shops'];
      for (var i = 0; i < shops.length; i++) {
        String id = shops[i]['id'];
        if (shops[i]['marked'] == true) {
          checkedShopsTemp.add(id);
        }
      }

      shops = shopDetails[2]['shops'];
      for (var i = 0; i < shops.length; i++) {
        String id = shops[i]['id'];
        if (shops[i]['marked'] == true) {
          checkedShopsTemp.add(id);
        }
      }
      if (mounted) {
        setState(() {
          checkedShops = checkedShopsTemp;
          euChanceCheck = true;
          usChanceCheck = true;
          caChanceCheck = true;
        });
      }
    } else {
      List<Map<dynamic, dynamic>> euBestShops = shopDetails[0]['shops']
          .where((element) => element['marked'] == true)
          .toList();
      List<Map<dynamic, dynamic>> usBestShops = shopDetails[1]['shops']
          .where((element) => element['marked'] == true)
          .toList();
      List<Map<dynamic, dynamic>> caBestShops = shopDetails[2]['shops']
          .where((element) => element['marked'] == true)
          .toList();
      bool euBestCheck = alreadyCheckedShops
              .where((element) => checkShopIdByBestShops(element, euBestShops))
              .toList()
              .length ==
          euBestShops.length;
      bool usBestCheck = alreadyCheckedShops
              .where((element) => checkShopIdByBestShops(element, usBestShops))
              .toList()
              .length ==
          usBestShops.length;
      bool caBestCheck = alreadyCheckedShops
              .where((element) => checkShopIdByBestShops(element, caBestShops))
              .toList()
              .length ==
          caBestShops.length;

      setState(() {
        euChanceCheck = euBestCheck;
        usChanceCheck = usBestCheck;
        caChanceCheck = caBestCheck;
      });
    }
  }

  initSharePref() async {
    Map temp = {
      'username': prefs.getString('username') ?? '',
      'email': prefs.getString('email') ?? '',
      'first_name': prefs.getString('firstname') ?? '',
      'last_name': prefs.getString('lastname') ?? '',
      'phone_number': prefs.getString('phone') ?? '',
      'profile_picture': prefs.getString('photo') ?? '',
      'Shipping': [
        {
          'address_line1': prefs.getString('shippingAddr1') ?? '',
          'address_line2': prefs.getString('shippingAddr2') ?? '',
          'city': prefs.getString('city') ?? '',
          'zip_code': prefs.getString('zipcode') ?? '',
          'state': prefs.getString('state') ?? '',
          'country': prefs.getString('country') ?? '',
          'country_code': prefs.getString('countryCode') ?? '',
          'country_flag': prefs.getString('countryFlag') ?? ''
        }
      ],
      'General': {
        'prefered_size': prefs.getString('preferredSize') ?? '',
        'default_currency': prefs.getString('defaultCurrency') ?? '',
        'location_area': prefs.getString('locationArea') ?? '',
      },
      'shops': prefs.getStringList('shops'),
      'brands': prefs.getStringList('brands'),
      'sizes': prefs.getStringList("sizes"),
      'regions': prefs.getStringList("regions"),
      'notifFlag': prefs.getBool('notifFlag') == true,
      'resellLow': prefs.getBool('resellLow') ?? true,
      'resellMid': prefs.getBool('resellMid') ?? true,
      'resellHigh': prefs.getBool('resellHigh') ?? true,
    };
    setState(() {
      userData = temp;
      notifRestock = temp['notifFlag'];
      checkedShops = temp['shops'] ?? [];
      checkedBrands = temp['brands'] ?? [];
      checkedSizes = temp['sizes'] ?? [];
      checkedCountrys = temp['regions'] ?? [];
      resellLow = temp['resellLow'] ?? true;
      resellMid = temp['resellMid'] ?? true;
      resellHigh = temp['resellHigh'] ?? true;
    });
    shopCheckAllDetect(temp['shops'] ?? []);
    bestShopCheckAllDetect(temp['shops'] ?? []);
    countryCheckAllDetect(temp['regions'] ?? []);
  }

  @override
  void dispose() {
    timer?.cancel();
    searchKeywordController?.dispose();
    subscription.cancel();
    super.dispose();
  }

  bool checkShopId(String id) {
    if (checkedShops.indexOf(id).isNegative) {
      return false;
    } else {
      return true;
    }
  }

  bool checkCountry(String country) {
    if (checkedCountrys.indexOf(country).isNegative) {
      return false;
    } else {
      return true;
    }
  }

  void toggleCheck(String id) {
    List<String> checkedShopsTemp = checkedShops;
    if (!checkShopId(id)) {
      checkedShopsTemp.add(id);
    } else {
      checkedShopsTemp.remove(id);
    }

    shopCheckAllDetect(checkedShopsTemp);
    bestShopCheckAllDetect(checkedShopsTemp);

    setState(() {
      checkedShops = checkedShopsTemp;
    });
  }

  void toggleCountryCheck(String id) {
    List<String> checkedCountrysTemp = checkedCountrys;
    if (!checkCountry(id)) {
      checkedCountrysTemp.add(id);
    } else {
      checkedCountrysTemp.remove(id);
    }

    countryCheckAllDetect(checkedCountrysTemp);

    setState(() {
      checkedCountrys = checkedCountrysTemp;
    });
  }

  void toggleShopDetail(String shopType) {
    List<String> temp = expandedShopDetail;
    if (expandedShopDetail.indexOf(shopType).isNegative) {
      temp.add(shopType);
    } else {
      temp.remove(shopType);
    }
    setState(() {
      expandedShopDetail = temp;
    });
  }

  void shopCheckAll(bool value, String type) {
    List<String> checkedShopsTemp = checkedShops;
    List<Map> shops = [];
    if (type == 'EU') {
      shops = shopDetails[0]['shops'];
    } else if (type == 'US') {
      shops = shopDetails[1]['shops'];
    } else if (type == 'CA') {
      shops = shopDetails[2]['shops'];
    }
    for (var i = 0; i < shops.length; i++) {
      String id = shops[i]['id'];
      if (value) {
        if (!checkShopId(id)) {
          checkedShopsTemp.add(id);
        }
      } else {
        if (checkShopId(id)) {
          checkedShopsTemp.remove(id);
        }
      }
    }
    setState(() {
      checkedShops = checkedShopsTemp;
      if (type == 'EU') {
        euShopCheckAll = value;
        euChanceCheck = value;
      } else if (type == 'US') {
        usShopCheckAll = value;
        usChanceCheck = value;
      } else if (type == 'CA') {
        caShopCheckAll = value;
        caChanceCheck = value;
      }
    });
  }

  void regionCheckAll(bool value, String type) {
    List<String> checkedRegionTemp = checkedCountrys;
    List<String> countrys = [];
    if (type == 'EU') {
      countrys = regionDetails[0]['countrys'];
      for (var i = 0; i < countrys.length; i++) {
        String country = countrys[i];
        if (value) {
          if (!checkCountry(country)) {
            checkedRegionTemp.add(country);
          }
        } else {
          if (checkCountry(country)) {
            checkedRegionTemp.remove(country);
          }
        }
      }
    } else {
      if (value) {
        if (!checkCountry(type)) {
          checkedRegionTemp.add(type);
        }
      } else {
        if (checkCountry(type)) {
          checkedRegionTemp.remove(type);
        }
      }
    }

    setState(() {
      checkedCountrys = checkedRegionTemp;
      if (type == 'EU') {
        euRegionCheckAll = value;
      } else if (type == 'US') {
        usRegionCheckAll = value;
      } else if (type == 'CA') {
        caRegionCheckAll = value;
      }
    });
  }

  void bestShopCheckAll(bool value, String type) {
    List<String> checkedShopsTemp = checkedShops;
    List<Map> shops = [];
    if (type == 'EU') {
      shops = shopDetails[0]['shops'];
    } else if (type == 'US') {
      shops = shopDetails[1]['shops'];
    } else if (type == 'CA') {
      shops = shopDetails[2]['shops'];
    }
    for (var i = 0; i < shops.length; i++) {
      if (shops[i]['marked'] == true) {
        String id = shops[i]['id'];
        if (value) {
          if (!checkShopId(id)) {
            checkedShopsTemp.add(id);
          }
        } else {
          if (checkShopId(id)) {
            checkedShopsTemp.remove(id);
          }
        }
      }
    }
    setState(() {
      checkedShops = checkedShopsTemp;
    });
    shopCheckAllDetect(checkedShopsTemp);
    // bestShopCheckAllDetect(checkedShopsTemp);
  }

  List<Widget> getShopCheck(List<dynamic> shops, String side) {
    List<Widget> result = [];
    for (var i = 0; i < shops.length; i++) {
      if (side == 'left') {
        if (i % 3 == 0) {
          result.add(Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                activeColor: Colors.white,
                checkColor: const Color(0xffF55E5E),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                value: checkShopId(shops[i]['id']),
                onChanged: ((value) => {toggleCheck(shops[i]['id'])}),
              ),
              Container(
                constraints: BoxConstraints(
                  maxWidth: (MediaQuery.of(context).size.width - 20) / 3 - 65,
                ),
                child: Text(
                  shops[i]['name'],
                  overflow: TextOverflow.ellipsis,
                  style: robotoStyle(
                      shops[i]['marked'] == true
                          ? FontWeight.bold
                          : FontWeight.w600,
                      shops[i]['marked'] == true
                          ? Colors.black
                          : Colors.black54,
                      12,
                      null),
                ),
              ),
              shops[i]['marked'] == true
                  ? Container(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Image.asset('assets/etc/restock/star.png'),
                    )
                  : Container(),
            ],
          ));
        }
      } else if (side == 'center') {
        if (i % 3 == 1) {
          result.add(Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  activeColor: Colors.white,
                  checkColor: const Color(0xffF55E5E),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                  value: checkShopId(shops[i]['id']),
                  onChanged: ((value) => {toggleCheck(shops[i]['id'])})),
              Container(
                constraints: BoxConstraints(
                    maxWidth:
                        (MediaQuery.of(context).size.width - 20) / 3 - 65),
                child: Text(
                  shops[i]['name'],
                  overflow: TextOverflow.ellipsis,
                  style: robotoStyle(
                      shops[i]['marked'] == true
                          ? FontWeight.bold
                          : FontWeight.w600,
                      shops[i]['marked'] == true
                          ? Colors.black
                          : Colors.black54,
                      12,
                      null),
                ),
              ),
              shops[i]['marked'] == true
                  ? Container(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Image.asset('assets/etc/restock/star.png'),
                    )
                  : Container(),
            ],
          ));
        }
      } else {
        if (i % 3 == 2) {
          result.add(Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  activeColor: Colors.white,
                  checkColor: const Color(0xffF55E5E),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                  value: checkShopId(shops[i]['id']),
                  onChanged: ((value) => {toggleCheck(shops[i]['id'])})),
              Container(
                constraints: BoxConstraints(
                    maxWidth:
                        (MediaQuery.of(context).size.width - 20) / 3 - 65),
                child: Text(
                  shops[i]['name'],
                  overflow: TextOverflow.ellipsis,
                  style: robotoStyle(
                      shops[i]['marked'] == true
                          ? FontWeight.bold
                          : FontWeight.w600,
                      shops[i]['marked'] == true
                          ? Colors.black
                          : Colors.black54,
                      12,
                      null),
                ),
              ),
              shops[i]['marked'] == true
                  ? Container(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Image.asset('assets/etc/restock/star.png'),
                    )
                  : Container(),
            ],
          ));
        }
      }
    }

    return result;
  }

  List<Widget> getCountryCheck(List<dynamic> countrys, String side) {
    List<Widget> result = [];
    for (var i = 0; i < countrys.length; i++) {
      if (side == 'left') {
        if (i % 3 == 0) {
          result.add(Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  activeColor: Colors.white,
                  checkColor: const Color(0xffF55E5E),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                  value: checkCountry(countrys[i]),
                  onChanged: ((value) => {toggleCountryCheck(countrys[i])})),
              Container(
                constraints: BoxConstraints(
                    maxWidth:
                        (MediaQuery.of(context).size.width - 20) / 3 - 65),
                child: Text(
                  countrys[i],
                  overflow: TextOverflow.ellipsis,
                  style: w600Black12,
                ),
              ),
            ],
          ));
        }
      } else if (side == 'center') {
        if (i % 3 == 1) {
          result.add(Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                activeColor: Colors.white,
                checkColor: const Color(0xffF55E5E),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                value: checkCountry(countrys[i]),
                onChanged: ((value) => {toggleCountryCheck(countrys[i])}),
              ),
              Container(
                constraints: BoxConstraints(
                  maxWidth: (MediaQuery.of(context).size.width - 20) / 3 - 65,
                ),
                child: Text(
                  countrys[i],
                  overflow: TextOverflow.ellipsis,
                  style: w600Black12,
                ),
              ),
            ],
          ));
        }
      } else {
        if (i % 3 == 2) {
          result.add(Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                activeColor: Colors.white,
                checkColor: const Color(0xffF55E5E),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                value: checkCountry(countrys[i]),
                onChanged: ((value) => {toggleCountryCheck(countrys[i])}),
              ),
              Container(
                constraints: BoxConstraints(
                  maxWidth: (MediaQuery.of(context).size.width - 20) / 3 - 65,
                ),
                child: Text(
                  countrys[i],
                  overflow: TextOverflow.ellipsis,
                  style: w600Black12,
                ),
              ),
            ],
          ));
        }
      }
    }

    return result;
  }

  bool checkShopDetailExpand(String detailName) {
    return !expandedShopDetail.indexOf(detailName).isNegative;
  }

  Future<void> userNotificationOn(bool flag) async {
    prefs.setBool("notifFlag", flag);
    userData['notifFlag'] = flag;
    await postRequest('https://api.sneaks4sure.com/user', userData);
  }

  List<Widget> renderBrands() {
    List<Widget> result = [];
    List<String> brandData = [
      'Jordan',
      'Nike',
      'Converse',
      'Off White',
      'Yeezy',
      'Adidas',
      'New Balance',
      'Travis Scott',
      'Asics',
      'Reebok',
      'Puma',
    ];
    for (String brand in brandData) {
      result.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
          child: Container(
            padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
            decoration: BoxDecoration(
              border: checkedBrands.indexOf(brand).isNegative
                  ? Border(
                      bottom: BorderSide(
                        color: Colors.red.shade400,
                        width: 0.2,
                      ),
                    )
                  : const Border(
                      bottom: BorderSide(
                        color: Colors.white70,
                        width: 2,
                      ),
                    ),
            ),
            child: IconButton(
              onPressed: () {
                List<String> temp = checkedBrands;
                if (temp.indexOf(brand).isNegative) {
                  checkedBrands.add(brand);
                } else {
                  checkedBrands.remove(brand);
                }
                setState(() {
                  checkedBrands = temp;
                });
              },
              icon: Image.asset('assets/brands/white/${brand}.png',
                  color: Colors.white),
              iconSize: 50,
            ),
          ),
        ),
      );
    }
    return result;
  }

  List<Widget> renderSizes() {
    List<Widget> result = [];
    List<Map> sizeData = [
      {
        "key": "US 3.5-EU 35.5 / UK 3",
        "us": "US 3.5",
        "other": "EU 35.5 / UK 3"
      },
      {"key": "US 4-EU 36 / UK 3.5", "us": "US 4", "other": "EU 36 / UK 3.5"},
      {
        "key": "US 4.5-EU 36.5 / UK 4",
        "us": "US 4.5",
        "other": "EU 36.5 / UK 4"
      },
      {
        "key": "US 5-EU 37.5 / UK 4.5",
        "us": "US 5",
        "other": "EU 37.5 / UK 4.5"
      },
      {"key": "US 5.5-EU 38 / UK 5", "us": "US 5.5", "other": "EU 38 / UK 5"},
      {
        "key": "US 6-EU 38.5 / UK 5.5",
        "us": "US 6",
        "other": "EU 38.5 / UK 5.5"
      },
      {"key": "US 6.5-EU 39 / UK 6", "us": "US 6.5", "other": "EU 39 / UK 6"},
      {"key": "US 7-EU 40 / UK 6", "us": "US 7", "other": "EU 40 / UK 6"},
      {
        "key": "US 7.5-EU 40.5 / UK 6.5",
        "us": "US 7.5",
        "other": "EU 40.5 / UK 6.5"
      },
      {"key": "US 8-EU 41 / UK 7", "us": "US 8", "other": "EU 41 / UK 7"},
      {
        "key": "US 8.5-EU 35.5 / UK 3",
        "us": "US 8.5",
        "other": "EU 42 / UK 7.5"
      },
      {"key": "US 9-EU 42.5 / UK 8", "us": "US 9", "other": "EU 42.5 / UK 8"},
      {
        "key": "US 9.5-EU 43 / UK 8.5",
        "us": "US 9.5",
        "other": "EU 43 / UK 8.5"
      },
      {"key": "US 10-EU 44 / UK 9", "us": "US 10", "other": "EU 44 / UK 9"},
      {
        "key": "US 10.5-EU 44.5 / UK 9.5",
        "us": "US 10.5",
        "other": "EU 44.5 / UK 9.5"
      },
      {"key": "US 11-EU 45 / UK 10", "us": "US 11", "other": "EU 45 / UK 10"},
      {
        "key": "US 11.5-EU 45.5 / UK 10.5",
        "us": "US 11.5",
        "other": "EU 45.5 / UK 10.5"
      },
      {"key": "US 12-EU 46 / UK 11", "us": "US 12", "other": "EU 46 / UK 11"},
      {
        "key": "US 11-EU 47 / UK 11.5",
        "us": "US 11",
        "other": "EU 47 / UK 11.5"
      },
      {
        "key": "US 11.5-EU 47.5 / UK 12",
        "us": "US 11.5",
        "other": "EU 47.5 / UK 12"
      },
      {
        "key": "US 12-EU 48 / UK 12.5",
        "us": "US 12",
        "other": "EU 48 / UK 12.5"
      },
    ];
    for (Map size in sizeData) {
      result.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
          child: Container(
            padding: const EdgeInsets.fromLTRB(5, 0, 5, 0),
            decoration: BoxDecoration(
              border: checkedSizes.indexOf(size["key"]).isNegative
                  ? Border(
                      bottom: BorderSide(
                        color: Colors.red.shade400,
                        width: 0.2,
                      ),
                    )
                  : const Border(
                      bottom: BorderSide(
                        color: Colors.white70,
                        width: 2,
                      ),
                    ),
            ),
            child: InkWell(
              onTap: () {
                List<String> temp = checkedSizes;
                if (temp.indexOf(size["key"]).isNegative) {
                  checkedSizes.add(size["key"]);
                } else {
                  checkedSizes.remove(size["key"]);
                }
                setState(() {
                  checkedSizes = temp;
                });
              },
              child: Container(
                width: (MediaQuery.of(context).size.width - 120) / 3,
                height: 60,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      size["us"],
                      style: w900White20,
                    ),
                    Text(
                      size["other"],
                      style: w900White10,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    return result;
  }

  List<Widget> renderShops() {
    List<Widget> result = [];
    for (Map<dynamic, dynamic> item in shopDetails) {
      result.add(
        CustomExpansionTile(
          controlAffinity: ListTileControlAffinity.leading,
          leading: Image.asset(
            "assets/etc/plus-minus.gif",
            width: 35,
            height: 35,
          ),
          tilePadding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
          initiallyExpanded: false,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Material(
                elevation: 8,
                borderRadius: const BorderRadius.all(Radius.circular(20)),
                child: Container(
                  width: 72,
                  padding: const EdgeInsets.fromLTRB(5, 8, 5, 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        item['shopTypeLogo'],
                        height: 21,
                        width: 21,
                      ),
                      const SizedBox(
                        width: 7,
                      ),
                      Text(
                        item['shopTypeName'],
                        style: w700Black17,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 4,
              ),
              euShopReg.hasMatch(item['shopType'])
                  ? InkWell(
                      onTap: () {
                        bestShopCheckAll(!euChanceCheck, 'EU');
                        setState(() {
                          euChanceCheck = !euChanceCheck;
                        });
                      },
                      child: Material(
                        elevation: 8,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(20)),
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(12, 7, 12, 7),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Column(
                                children: [
                                  Text(
                                    AppLocalizations.of(context)
                                        .restock_filterRecommended,
                                    style: robotoStyle(
                                      FontWeight.w600,
                                      euChanceCheck
                                          ? Colors.red
                                          : const Color(0xFF313036),
                                      11,
                                      null,
                                    ),
                                  ),
                                  Wrap(
                                    crossAxisAlignment:
                                        WrapCrossAlignment.center,
                                    children: [
                                      Text(
                                        AppLocalizations.of(context)
                                            .calDetail_shops,
                                        style: robotoStyle(
                                          FontWeight.w600,
                                          euChanceCheck
                                              ? Colors.red
                                              : const Color(0xFF313036),
                                          11,
                                          null,
                                        ),
                                      ),
                                      Text(
                                        AppLocalizations.of(context)
                                            .restock_filterShopsOnly,
                                        style: robotoStyle(
                                          FontWeight.w600,
                                          euChanceCheck
                                              ? Colors.red
                                              : const Color(0xFF313036),
                                          9,
                                          null,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(
                                width: 5,
                              ),
                              InkWell(
                                onTap: () {
                                  bestShopCheckAll(!euChanceCheck, 'EU');
                                  setState(() {
                                    euChanceCheck = !euChanceCheck;
                                  });
                                },
                                child: euChanceCheck
                                    ? Image.asset(
                                        'assets/etc/restock/checked.png',
                                        height: 20,
                                      )
                                    : Image.asset(
                                        'assets/etc/restock/unchecked.png',
                                        height: 20,
                                      ),
                              )
                            ],
                          ),
                        ),
                      ),
                    )
                  : usShopReg.hasMatch(item['shopType'])
                      ? InkWell(
                          onTap: () {
                            bestShopCheckAll(!usChanceCheck, 'US');
                            setState(() {
                              usChanceCheck = !usChanceCheck;
                            });
                          },
                          child: Material(
                            elevation: 8,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(20)),
                            child: Container(
                              padding: const EdgeInsets.fromLTRB(12, 7, 12, 7),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Column(
                                    children: [
                                      Text(
                                        AppLocalizations.of(context)
                                            .restock_filterRecommended,
                                        style: robotoStyle(
                                            FontWeight.w600,
                                            usChanceCheck
                                                ? Colors.red
                                                : const Color(0xFF313036),
                                            11,
                                            null),
                                      ),
                                      Wrap(
                                        crossAxisAlignment:
                                            WrapCrossAlignment.end,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calDetail_shops,
                                            style: robotoStyle(
                                                FontWeight.w600,
                                                usChanceCheck
                                                    ? Colors.red
                                                    : const Color(0xFF313036),
                                                11,
                                                null),
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterShopsOnly,
                                            style: robotoStyle(
                                                FontWeight.w600,
                                                usChanceCheck
                                                    ? Colors.red
                                                    : const Color(0xFF313036),
                                                9,
                                                null),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  InkWell(
                                    onTap: () {
                                      bestShopCheckAll(!usChanceCheck, 'US');
                                      setState(() {
                                        usChanceCheck = !usChanceCheck;
                                      });
                                    },
                                    child: usChanceCheck
                                        ? Image.asset(
                                            'assets/etc/restock/checked.png',
                                            height: 20,
                                          )
                                        : Image.asset(
                                            'assets/etc/restock/unchecked.png',
                                            height: 20,
                                          ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        )
                      : InkWell(
                          onTap: () {
                            bestShopCheckAll(!caChanceCheck, 'CA');
                            setState(() {
                              caChanceCheck = !caChanceCheck;
                            });
                          },
                          child: Material(
                            elevation: 8,
                            borderRadius:
                                const BorderRadius.all(Radius.circular(20)),
                            child: Container(
                              padding: const EdgeInsets.fromLTRB(12, 7, 12, 7),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        AppLocalizations.of(context)
                                            .restock_filterRecommended,
                                        style: robotoStyle(
                                            FontWeight.w600,
                                            caChanceCheck
                                                ? Colors.red
                                                : const Color(0xFF313036),
                                            11,
                                            null),
                                      ),
                                      Wrap(
                                        crossAxisAlignment:
                                            WrapCrossAlignment.center,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calDetail_shops,
                                            style: robotoStyle(
                                                FontWeight.w600,
                                                caChanceCheck
                                                    ? Colors.red
                                                    : const Color(0xFF313036),
                                                11,
                                                null),
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterShopsOnly,
                                            style: robotoStyle(
                                                FontWeight.w600,
                                                caChanceCheck
                                                    ? Colors.red
                                                    : const Color(0xFF313036),
                                                9,
                                                null),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  InkWell(
                                    onTap: () {
                                      bestShopCheckAll(!caChanceCheck, 'CA');
                                      setState(() {
                                        caChanceCheck = !caChanceCheck;
                                      });
                                    },
                                    child: caChanceCheck
                                        ? Image.asset(
                                            'assets/etc/restock/checked.png',
                                            height: 20,
                                          )
                                        : Image.asset(
                                            'assets/etc/restock/unchecked.png',
                                            height: 20,
                                          ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
              Transform.scale(
                scale: 0.6,
                child: Column(
                  children: [
                    CupertinoSwitch(
                      onChanged: (value) {
                        setState(
                          () {
                            shopCheckAll(
                                value,
                                euShopReg.hasMatch(item['shopType'])
                                    ? 'EU'
                                    : usShopReg.hasMatch(item['shopType'])
                                        ? 'US'
                                        : 'CA');
                          },
                        );
                      },
                      value: euShopReg.hasMatch(item['shopType'])
                          ? euShopCheckAll
                          : usShopReg.hasMatch(item['shopType'])
                              ? usShopCheckAll
                              : caShopCheckAll,
                      activeColor: const Color.fromARGB(255, 33, 237, 91),
                      trackColor: const Color.fromARGB(255, 255, 35, 35),
                      thumbColor: Colors.white,
                    ),
                    Container(
                      width: 70,
                      child: Center(
                        child: Text(
                          (euShopReg.hasMatch(item['shopType'])
                                  ? euShopCheckAll
                                  : usShopReg.hasMatch(item['shopType'])
                                      ? usShopCheckAll
                                      : caShopCheckAll)
                              ? AppLocalizations.of(context)
                                  .restock_filterUnselectAll
                              : AppLocalizations.of(context)
                                  .restock_filterSelectAll,
                          style: const TextStyle(
                            color: Color(0xFF313036),
                            decoration: TextDecoration.underline,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          children: [
            const SizedBox(
              height: 8,
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  alignment: Alignment.topCenter,
                  width: (MediaQuery.of(context).size.width - 60) / 3,
                  child: Column(
                    children: getShopCheck(item['shops'], 'left'),
                  ),
                ),
                Container(
                  alignment: Alignment.topCenter,
                  width: (MediaQuery.of(context).size.width - 60) / 3,
                  child: Column(
                    children: getShopCheck(item['shops'], 'center'),
                  ),
                ),
                Container(
                  alignment: Alignment.topCenter,
                  width: (MediaQuery.of(context).size.width - 60) / 3,
                  child: Column(
                    children: getShopCheck(item['shops'], 'right'),
                  ),
                ),
              ],
            ),
          ],
          onExpansionChanged: (bool expanded) {
            toggleShopDetail(item['shopType']);
          },
        ),
      );
    }
    return result;
  }

  List<Widget> renderRegions() {
    List<Widget> result = [];
    for (Map<dynamic, dynamic> item in regionDetails) {
      if (item["region"] == "EU") {
        result.add(
          CustomExpansionTile(
            controlAffinity: ListTileControlAffinity.leading,
            leading: Image.asset(
              "assets/etc/plus-minus.gif",
              width: 35,
              height: 35,
            ),
            tilePadding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
            initiallyExpanded: false,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Material(
                  elevation: 8,
                  borderRadius: const BorderRadius.all(Radius.circular(20)),
                  child: Container(
                    width: 160,
                    padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Image.asset(
                          item['regionLogo'],
                          height: 21,
                          width: 21,
                        ),
                        Expanded(
                          child: Center(
                            child: Text(
                              item['regionName'],
                              style: w700Black17,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 4,
                ),
                Container(
                  padding: const EdgeInsets.only(top: 8),
                  child: Transform.scale(
                    scale: 0.6,
                    child: Column(
                      children: [
                        CupertinoSwitch(
                          onChanged: (value) {
                            setState(
                              () {
                                regionCheckAll(value, item['region']);
                              },
                            );
                          },
                          value: item['region'] == "EU"
                              ? euRegionCheckAll
                              : item['region'] == "US"
                                  ? usRegionCheckAll
                                  : caRegionCheckAll,
                          activeColor: const Color.fromARGB(255, 33, 237, 91),
                          trackColor: const Color.fromARGB(255, 255, 35, 35),
                          thumbColor: Colors.white,
                        ),
                        Container(
                          width: 70,
                          child: Center(
                            child: Text(
                              (item['region'] == "EU"
                                      ? euRegionCheckAll
                                      : item['region'] == "US"
                                          ? usRegionCheckAll
                                          : caRegionCheckAll)
                                  ? AppLocalizations.of(context)
                                      .restock_filterUnselectAll
                                  : AppLocalizations.of(context)
                                      .restock_filterSelectAll,
                              style: const TextStyle(
                                color: Colors.black54,
                                decoration: TextDecoration.underline,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                )
              ],
            ),
            children: [
              const SizedBox(
                height: 8,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    alignment: Alignment.topCenter,
                    width: (MediaQuery.of(context).size.width - 60) / 3,
                    child: Column(
                      children: getCountryCheck(item['countrys'], 'left'),
                    ),
                  ),
                  Container(
                    alignment: Alignment.topCenter,
                    width: (MediaQuery.of(context).size.width - 60) / 3,
                    child: Column(
                      children: getCountryCheck(item['countrys'], 'center'),
                    ),
                  ),
                  Container(
                    alignment: Alignment.topCenter,
                    width: (MediaQuery.of(context).size.width - 60) / 3,
                    child: Column(
                      children: getCountryCheck(item['countrys'], 'right'),
                    ),
                  ),
                ],
              ),
            ],
            onExpansionChanged: (bool expanded) {
              toggleShopDetail(item['shopType']);
            },
          ),
        );
      } else {
        result.add(
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Material(
                elevation: 8,
                borderRadius: const BorderRadius.all(Radius.circular(20)),
                child: Container(
                  width: 160,
                  padding: const EdgeInsets.fromLTRB(15, 8, 15, 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        item['regionLogo'],
                        height: 21,
                        width: 21,
                      ),
                      Expanded(
                        child: Center(
                          child: Text(
                            item['regionName'],
                            style: w700Black17,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 4,
              ),
              Container(
                padding: const EdgeInsets.only(top: 8),
                child: Transform.scale(
                  scale: 0.6,
                  child: Column(
                    children: [
                      CupertinoSwitch(
                        onChanged: (value) {
                          setState(
                            () {
                              regionCheckAll(value, item['region']);
                            },
                          );
                        },
                        value: item['region'] == "EU"
                            ? euRegionCheckAll
                            : item['region'] == "US"
                                ? usRegionCheckAll
                                : caRegionCheckAll,
                        activeColor: const Color.fromARGB(255, 33, 237, 91),
                        trackColor: const Color.fromARGB(255, 255, 35, 35),
                        thumbColor: Colors.white,
                      ),
                      Container(
                        width: 70,
                        child: Center(
                          child: Text(
                            (item['region'] == "EU"
                                    ? euRegionCheckAll
                                    : item['region'] == "US"
                                        ? usRegionCheckAll
                                        : caRegionCheckAll)
                                ? AppLocalizations.of(context)
                                    .restock_filterUnselectAll
                                : AppLocalizations.of(context)
                                    .restock_filterSelectAll,
                            style: const TextStyle(
                              color: Colors.black54,
                              decoration: TextDecoration.underline,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 30,
              )
            ],
          ),
        );
      }
    }
    return result;
  }

  bool checkIsExist(String type) {
    if (type == 'EU') {
      return checkedShops
          .where((element) => euShopReg.hasMatch(element))
          .toList()
          .isNotEmpty;
    }
    if (type == 'US') {
      return checkedShops
          .where((element) => usShopReg.hasMatch(element))
          .toList()
          .isNotEmpty;
    }
    if (type == 'CA') {
      return checkedShops
          .where((element) => caShopReg.hasMatch(element))
          .toList()
          .isNotEmpty;
    }
    return false;
  }

  bool checkCountryIsExist(String type) {
    if (type == 'EU') {
      return checkedCountrys
          .where((element) => (element != "US" && element != "CA"))
          .toList()
          .isNotEmpty;
    } else {
      return checkedCountrys
          .where((element) => element == type)
          .toList()
          .isNotEmpty;
    }
  }

  void animateToMainPage(int pageIndex) {
    Future.delayed(const Duration(milliseconds: 200), () {
      if (restockMainPageController.hasClients) {
        restockMainPageController.animateToPage(pageIndex,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeInOut);
      }
    });
  }

  Widget restockMain() {
    animateToMainPage(positionRestockMain);

    return PageView(
      controller: restockMainPageController,
      onPageChanged: (value) {
        setState(() {
          isOnline = value == 0;
          isInstore = value == 1;
          positionRestockMain = value;
        });
      },
      children: [
        restockOnline(),
        restockInstore(),
      ],
    );
  }

  goToProductDetail(String productSKU) async {
    productDetail = await getProductDetail(productSKU);
    // productDetail['productChangeArrow'] =
    //     product.productChangeArrow;
    // productDetail['showprice'] =
    //     product.showprice;
    // ignore: use_build_context_synchronously
    Navigator.of(context).pushNamed('/ProductDetail');
  }

  Widget restockOnline() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        Stack(
          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 30),
                child: InkWell(
                  onTap: () {
                    positionRestockPage = 0;
                    Navigator.of(context).pushReplacementNamed('/Restock');
                  },
                  child: const Image(
                    height: 35,
                    image: AssetImage('./assets/etc/splash-cropped.png'),
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(0.48, 0),
              child: Container(
                width: 37,
                height: 60,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      positionRestockPage = 1;
                    });
                  },
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Image.asset(
                          'assets/etc/slider.gif',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: notifRestock
                  ? const Alignment(0.80, 0)
                  : const Alignment(0.78, 0),
              child: IconButton(
                alignment: Alignment.center,
                onPressed: () {
                  AppSettings.openNotificationSettings();
                },
                icon: Icon(
                  notifRestock
                      ? FontAwesomeIcons.bell
                      : FontAwesomeIcons.bellSlash,
                  size: 30,
                  color: notifRestock ? Colors.red : Colors.black54,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        const Divider(
          color: Colors.grey,
          height: 0,
          thickness: 1,
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _pullRefresh,
            child: ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              controller: onlineScrollController,
              key: const PageStorageKey<String>('Listview Restock'),
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 70),
              itemCount: restock.length,
              separatorBuilder: (BuildContext context, int index) =>
                  const SizedBox(),
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 35,
                      decoration: const BoxDecoration(
                        color: Color(0xff757D90),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            restock[index]['ShopName'] ?? "",
                            style: w900White18,
                          ),
                          Text(
                            " - ${returnRestockDate(restock[index]['DateTime'])}",
                            style: w400White18,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(5, 15, 10, 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                            child: SizedBox(
                              width: 150,
                              child: InkWell(
                                onTap: () {
                                  goToProductDetail(
                                    restock[index]['ProductSKU'],
                                  );
                                },
                                child: CachedNetworkImage(
                                  imageUrl: restock[index]['ProductImage'],
                                  fit: BoxFit.contain,
                                  errorWidget: (context, error, stackTrace) {
                                    return Image.asset(
                                      'assets/etc/NoImage.png',
                                      fit: BoxFit.contain,
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  restock[index]['ProductName'],
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: w700Black18,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  AppLocalizations.of(context)
                                      .restock_selectYourShopArea,
                                  textAlign: TextAlign.center,
                                  style: w400Gray11,
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Wrap(
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  alignment: WrapAlignment.center,
                                  verticalDirection: VerticalDirection.down,
                                  spacing: 4,
                                  runSpacing: 10.0,
                                  children: [
                                    for (var v
                                        in restock[index]['Url_Link'] == null
                                            ? []
                                            : restock[index]['Url_Link'].values)
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            3, 0, 3, 0),
                                        child: InkWell(
                                          onTap: () {
                                            urlLauncher(v['url']);
                                          },
                                          child: SizedBox(
                                            width: 32,
                                            height: 32,
                                            child: CachedNetworkImage(
                                              imageUrl: v['flag'],
                                              fit: BoxFit.contain,
                                            ),
                                          ),
                                        ),
                                      )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 25),
                      child: restock[index]['ProductATCSize']
                              .toString()
                              .isNotEmpty
                          ? Container(
                              padding: const EdgeInsets.fromLTRB(20, 7, 20, 7),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    width: (MediaQuery.of(context).size.width -
                                            60) /
                                        2,
                                    padding: const EdgeInsets.only(left: 10),
                                    height: 55,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF6F6F6),
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          width: 65,
                                          child: Center(
                                            child: Text(
                                              AppLocalizations.of(context)
                                                  .calDetail_marketAnalysis,
                                              textAlign: TextAlign.center,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: w800Black14,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: restock[index]
                                                      ['ResellValuePourcent']
                                                  .toString()
                                                  .isEmpty
                                              ? const Center(
                                                  child: Text(
                                                    "TBC",
                                                    style: TextStyle(
                                                      // color: Color(0xff313036),
                                                      color: Color(0xFF313036),
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                )
                                              : Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          AppLocalizations.of(
                                                                  context)
                                                              .search_margin,
                                                          style: w400Black14,
                                                        ),
                                                        const SizedBox(
                                                          width: 3,
                                                        ),
                                                        Text(
                                                          ('${returnSignCalendarCote(restock[index]['ResellValuePourcent'].toString().replaceAll('%', ''))}${restock[index]['ResellValuePourcent']}%'),
                                                          style: robotoStyle(
                                                              FontWeight.w800,
                                                              returnColorCalendarCote(
                                                                  restock[index]
                                                                          [
                                                                          'ResellValuePourcent']
                                                                      .toString()
                                                                      .replaceAll(
                                                                          '%',
                                                                          '')),
                                                              14,
                                                              null),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          AppLocalizations.of(
                                                                  context)
                                                              .search_profit,
                                                          style: w400Black14,
                                                        ),
                                                        const SizedBox(
                                                          width: 3,
                                                        ),
                                                        Text(
                                                          "> ${restock[index]['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(restock[index]['ResellValueProfit'])}",
                                                          style: robotoStyle(
                                                              FontWeight.w800,
                                                              returnColorCalendarCote(
                                                                  restock[index]
                                                                          [
                                                                          'ResellValuePourcent']
                                                                      .toString()
                                                                      .replaceAll(
                                                                          '%',
                                                                          '')),
                                                              14,
                                                              null),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF6F6F6),
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    width: (MediaQuery.of(context).size.width -
                                            60) /
                                        2,
                                    height: 55,
                                    child:
                                        restock[index]['ProductATCSize'] != ""
                                            ? Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    AppLocalizations.of(context)
                                                        .restock_addToCartLink,
                                                    style: w400Black11,
                                                  ),
                                                  restock[index][
                                                              'ProductATCSize'] ==
                                                          ""
                                                      ? Container(
                                                          child: Center(
                                                            child: Text(
                                                              "",
                                                              style:
                                                                  w800Black18,
                                                            ),
                                                          ),
                                                        )
                                                      : Container(
                                                          height: 30,
                                                          width: 150,
                                                          child: Center(
                                                            child:
                                                                SingleChildScrollView(
                                                              scrollDirection:
                                                                  Axis.horizontal,
                                                              child: Wrap(
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .center,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .center,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                spacing: 2,
                                                                // runSpacing: 8.0,
                                                                children: [
                                                                  for (var v in restock[index]
                                                                              [
                                                                              'ProductATCSize'] ==
                                                                          ""
                                                                      ? []
                                                                      : restock[index]
                                                                              [
                                                                              'ProductATCSize']
                                                                          .keys
                                                                          .toList())
                                                                    Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              3,
                                                                              0,
                                                                              3,
                                                                              0),
                                                                      child:
                                                                          InkWell(
                                                                        onTap:
                                                                            () {
                                                                          urlLauncher(restock[index]['ProductATCSize'][v]
                                                                              [
                                                                              'atc_url']);
                                                                        },
                                                                        child:
                                                                            Text(
                                                                          restock[index]['ProductATCSize'].keys.toList().last == v
                                                                              ? v
                                                                              : "$v  |",
                                                                          style:
                                                                              w800Black18,
                                                                        ),
                                                                      ),
                                                                    )
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                ],
                                              )
                                            : Container(),
                                  ),
                                ],
                              ),
                            )
                          : Container(
                              padding: const EdgeInsets.fromLTRB(20, 7, 20, 7),
                              width: (MediaQuery.of(context).size.width - 40),
                              height: 55,
                              decoration: BoxDecoration(
                                color: const Color(0xFFF6F6F6),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    child: Text(
                                      AppLocalizations.of(context)
                                          .calDetail_marketAnalysis,
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: w800Black15,
                                    ),
                                  ),
                                  Expanded(
                                    child: restock[index]['ResellValuePourcent']
                                            .toString()
                                            .isEmpty
                                        ? Center(
                                            child: Text(
                                              "TBC",
                                              style: w400Black17,
                                            ),
                                          )
                                        : Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    AppLocalizations.of(context)
                                                        .search_margin,
                                                    style: w400Black17,
                                                  ),
                                                  const SizedBox(
                                                    width: 3,
                                                  ),
                                                  Text(
                                                    ('${returnSignCalendarCote(restock[index]['ResellValuePourcent'].toString().replaceAll('%', ''))}${restock[index]['ResellValuePourcent']}%'),
                                                    style: robotoStyle(
                                                        FontWeight.w800,
                                                        returnColorCalendarCote(
                                                            restock[index][
                                                                    'ResellValuePourcent']
                                                                .toString()
                                                                .replaceAll(
                                                                    '%', '')),
                                                        17,
                                                        null),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    AppLocalizations.of(context)
                                                        .search_profit,
                                                    style: w400Black17,
                                                  ),
                                                  const SizedBox(
                                                    width: 3,
                                                  ),
                                                  Text(
                                                    "> ${restock[index]['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(restock[index]['ResellValueProfit'])}",
                                                    style: robotoStyle(
                                                        FontWeight.w800,
                                                        returnColorCalendarCote(
                                                            restock[index][
                                                                    'ResellValuePourcent']
                                                                .toString()
                                                                .replaceAll(
                                                                    '%', '')),
                                                        17,
                                                        null),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ],
                );
              },
              // },
            ),
            // ),
          ),
        ),
      ],
    );
  }

  String getInstoreProductSize(List<dynamic> sizeList) {
    return sizeList.join(" | ");
  }

  Widget restockInstore() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 30),
                child: InkWell(
                  onTap: () {
                    positionRestockPage = 1;
                    Navigator.of(context).pushReplacementNamed('/Restock');
                  },
                  child: const Image(
                    height: 35,
                    image: AssetImage('./assets/etc/splash-cropped.png'),
                  ),
                ),
              ),
            ),
            Align(
              alignment: const Alignment(0.48, 0),
              child: Container(
                width: 37,
                height: 60,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      positionRestockPage = 2;
                    });
                  },
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Image.asset(
                          'assets/etc/slider.gif',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Align(
              alignment: notifRestock
                  ? const Alignment(0.80, 0)
                  : const Alignment(0.78, 0),
              child: IconButton(
                alignment: Alignment.center,
                onPressed: () {
                  AppSettings.openNotificationSettings();
                },
                icon: Icon(
                  notifRestock
                      ? FontAwesomeIcons.bell
                      : FontAwesomeIcons.bellSlash,
                  size: 30,
                  color: notifRestock ? Colors.red : Colors.black54,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        const Divider(
          color: Colors.grey,
          height: 0,
          thickness: 1,
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _pullInstoreRefresh,
            child: ListView.separated(
              physics: const AlwaysScrollableScrollPhysics(),
              controller: instoreScrollController,
              key: const PageStorageKey<String>('Listview Instore'),
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 70),
              itemCount: instore.length,
              separatorBuilder: (BuildContext context, int index) =>
                  const SizedBox(),
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 35,
                      decoration: const BoxDecoration(
                        color: Color(0xff757D90),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Flag.fromString(instore[index]['StoreCountry'],
                          //     borderRadius: 100,
                          //     fit: BoxFit.fill,
                          //     height: 35,
                          //     width: 35),
                          // SizedBox(
                          //   width: 50,
                          //   height: 50,
                          //   child: CachedNetworkImage(
                          //     imageUrl: instore[index]['StoreCountyFlag'],
                          //     fit: BoxFit.contain,
                          //   ),
                          // ),
                          Text(
                            instore[index]['StoreName'],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            softWrap: true,
                            style: w900White18,
                          ),
                          Text(
                            " - ${returnRestockDate(instore[index]['DateTime'])}",
                            style: w400White18,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(5, 15, 10, 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                            child: SizedBox(
                              width: 150,
                              child: InkWell(
                                onTap: () {
                                  goToProductDetail(
                                    instore[index]['ProductSKU'],
                                  );
                                },
                                child: CachedNetworkImage(
                                  imageUrl: instore[index]['ProductImage'],
                                  fit: BoxFit.contain,
                                  errorWidget: (context, error, stackTrace) {
                                    return Image.asset(
                                      'assets/etc/NoImage.png',
                                      fit: BoxFit.contain,
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  instore[index]['ProductName'],
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: w700Black18,
                                ),
                                const SizedBox(
                                  height: 7,
                                ),
                                Text(
                                  instore[index]['ProductPrice']
                                      .toString()
                                      .replaceAll("null", ""),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: w500Black15,
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                SizedBox(
                                  width: 40,
                                  height: 40,
                                  child: CachedNetworkImage(
                                    imageUrl: instore[index]['StoreCountyFlag'],
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 20),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(20, 7, 20, 7),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              width:
                                  (MediaQuery.of(context).size.width - 60) / 2,
                              padding: const EdgeInsets.only(left: 10),
                              height: 55,
                              decoration: BoxDecoration(
                                color: const Color(0xFFF6F6F6),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 65,
                                    child: Text(
                                      AppLocalizations.of(context)
                                          .calDetail_marketAnalysis,
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: w800Black14,
                                    ),
                                  ),
                                  Expanded(
                                    child: instore[index]['ResellValuePourcent']
                                            .toString()
                                            .isEmpty
                                        ? const Center(
                                            child: Text(
                                              "TBC",
                                              style: TextStyle(
                                                // color: Color(0xff313036),
                                                color: Color(0xFF313036),
                                                fontSize: 14,
                                              ),
                                            ),
                                          )
                                        : Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    AppLocalizations.of(context)
                                                        .search_margin,
                                                    style: w400Black14,
                                                  ),
                                                  const SizedBox(
                                                    width: 3,
                                                  ),
                                                  Text(
                                                    ('${returnSignCalendarCote(instore[index]['ResellValuePourcent'].toString().replaceAll('%', ''))}${instore[index]['ResellValuePourcent']}%'),
                                                    style: robotoStyle(
                                                      FontWeight.w800,
                                                      returnColorCalendarCote(
                                                          instore[index][
                                                                  'ResellValuePourcent']
                                                              .toString()
                                                              .replaceAll(
                                                                  '%', '')),
                                                      14,
                                                      null,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text(
                                                    AppLocalizations.of(context)
                                                        .search_profit,
                                                    style: w400Black14,
                                                  ),
                                                  const SizedBox(
                                                    width: 3,
                                                  ),
                                                  Text(
                                                    "> ${instore[index]['ResellValueProfit'] == '-' ? '' : getPriceWithCurrency(instore[index]['ResellValueProfit'])}",
                                                    style: robotoStyle(
                                                      FontWeight.w800,
                                                      returnColorCalendarCote(
                                                          instore[index][
                                                                  'ResellValuePourcent']
                                                              .toString()
                                                              .replaceAll(
                                                                  '%', '')),
                                                      14,
                                                      null,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                color: const Color(0xFFF6F6F6),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              width:
                                  (MediaQuery.of(context).size.width - 60) / 2,
                              padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                              height: 55,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  InkWell(
                                    child: Text(
                                      AppLocalizations.of(context)
                                          .restock_availableSize,
                                      style: w400Black12,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 30,
                                    child: Center(
                                      child: Text(
                                        getInstoreProductSize(
                                          instore[index]['ProductSize'],
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: w800Black18,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        Text(
                          AppLocalizations.of(context).restock_storeLocation,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: w500Gray11,
                        ),
                        InkWell(
                          onTap: () async {
                            storeAddress = instore[index]['StoreAddress'];
                            List<Location> locations =
                                await locationFromAddress(
                                    instore[index]['StoreAddress']);
                            Location loc = locations.first;
                            latitude = loc.latitude ?? 0.0;
                            longitude = loc.longitude ?? 0.0;
                            Navigator.pushNamed(context, '/MapView');
                          },
                          child: Container(
                            padding: const EdgeInsets.fromLTRB(30, 0, 30, 10),
                            child: Column(
                              children: [
                                for (var v in instore[index]['StoreAddress']
                                    .toString()
                                    .split(","))
                                  Text(
                                    "$v",
                                    textAlign: TextAlign.center,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: w500Black18,
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                );
              },
              // },
            ),
            // ),
          ),
        ),
      ],
    );
  }

  Future fetchProduct(query) async {
    var response = await http.get(
      Uri.parse(
          'https://eu1-search.doofinder.com/5/search?hashid=30a5f46195133e966f269146a6805518&query=$query'),
      headers: {'Authorization': 'c59dadc5d822ca2b134fb8c7048274a7ec68e170'},
    );
    if (response.statusCode == 200) {
      // log(prettyJson(jsonDecode(response.body)));
      return response.body;
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load data');
    }
  }

  Future<List<Product>> getProductWithPage() async {
    var result = await fetchProduct(searchKeywordController!.text);

    List<Product> searchedProducts = jsonDecode(result)['results']
        ?.map((e) {
          return Product.fromJson(e);
        })
        .toList()
        .cast<Product>();
    List temp = jsonDecode(result)['facets']['gender']['terms']['buckets'];
    return searchedProducts;
  }

  List<String> getFormatedDate(String date) {
    if (date != '') {
      DateFormat formatter = DateFormat("MMM.dd-yyyy");
      String formatedString = formatter.format(DateTime.parse(date));
      return formatedString.split("-");
    } else {
      return ['', ''];
    }
  }

  Widget pageRestockFilters() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        Stack(
          alignment: Alignment.center,
          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                height: 60,
                padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                child: IconButton(
                  padding: const EdgeInsets.all(0),
                  icon: const Icon(Icons.arrow_circle_left_outlined),
                  color: const Color.fromARGB(255, 49, 48, 54),
                  iconSize: 32,
                  onPressed: () {
                    notificationProductSku = "";
                    setState(
                      () {
                        positionRestockPage = 0;
                      },
                    );
                  },
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: InkWell(
                onTap: (() {
                  positionRestockPage = 0;
                  Navigator.of(context).pushReplacementNamed('/Restock');
                }),
                child: const SizedBox(
                  height: 25,
                  child: Image(
                    image: AssetImage('./assets/etc/splash-cropped.png'),
                    fit: BoxFit.fitHeight,
                  ),
                ),
              ),
            ),
          ],
        ),
        Expanded(
          child: SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                "Customize your ",
                                style: w900White23,
                              ),
                              Text(
                                "notifications",
                                style: w900Red23,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                "Sneakers restock ",
                                style: w700Red16,
                              ),
                              Text(
                                "based on your ",
                                style: w700White16,
                              ),
                              Text(
                                "preferences",
                                style: w700Red16,
                              ),
                            ],
                          ),
                          // const SizedBox(
                          //   height: 8,
                          // ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(10, 15, 10, 15),
                            child: Container(
                              padding:
                                  const EdgeInsets.fromLTRB(10, 10, 10, 10),
                              decoration: BoxDecoration(
                                  color: Colors.red,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    flex: 4,
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        border: Border(
                                          right: BorderSide(
                                            color: Colors.white,
                                            width: 1,
                                          ),
                                        ),
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterActivated,
                                            style: w900White21,
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterFilters,
                                            style: w900White21,
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterFromSettings,
                                            style: w600White12,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 5,
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Text(
                                                    '${AppLocalizations.of(context).calDetail_shops}: ',
                                                    style: w500White16,
                                                  ),
                                                  Text(
                                                    checkedShops.length
                                                        .toString(),
                                                    style: w500White16,
                                                  ),
                                                  Text(
                                                    '  (${AppLocalizations.of(context).instore_filterSelected})',
                                                    style: w600White9,
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Container(
                                                    width: 70,
                                                    child: Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              checkedBrands
                                                                      .isNotEmpty
                                                                  ? FontAwesomeIcons
                                                                      .check
                                                                  : FontAwesomeIcons
                                                                      .square,
                                                              color:
                                                                  Colors.white,
                                                              size: 11,
                                                            ),
                                                            const SizedBox(
                                                              width: 2,
                                                            ),
                                                            Text(
                                                              AppLocalizations.of(
                                                                      context)
                                                                  .restock_filterBrands,
                                                              style: robotoStyle(
                                                                  FontWeight
                                                                      .w600,
                                                                  Colors.white,
                                                                  10,
                                                                  null),
                                                            ),
                                                          ],
                                                        ),
                                                        const SizedBox(
                                                          height: 5,
                                                        ),
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              goodList.isNotEmpty
                                                                  ? FontAwesomeIcons
                                                                      .check
                                                                  : FontAwesomeIcons
                                                                      .square,
                                                              color:
                                                                  Colors.white,
                                                              size: 11,
                                                            ),
                                                            const SizedBox(
                                                              width: 2,
                                                            ),
                                                            Text(
                                                              AppLocalizations.of(
                                                                      context)
                                                                  .restock_filterSneakers,
                                                              style: robotoStyle(
                                                                  FontWeight
                                                                      .w600,
                                                                  Colors.white,
                                                                  10,
                                                                  null),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 70,
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              checkIsExist('EU')
                                                                  ? FontAwesomeIcons
                                                                      .check
                                                                  : FontAwesomeIcons
                                                                      .square,
                                                              color:
                                                                  Colors.white,
                                                              size: 11,
                                                            ),
                                                            const SizedBox(
                                                              width: 1,
                                                            ),
                                                            Text(
                                                              'EU',
                                                              style: robotoStyle(
                                                                  FontWeight
                                                                      .w600,
                                                                  Colors.white,
                                                                  10,
                                                                  null),
                                                            ),
                                                            const SizedBox(
                                                              width: 3,
                                                            ),
                                                            Icon(
                                                              checkIsExist('CA')
                                                                  ? FontAwesomeIcons
                                                                      .check
                                                                  : FontAwesomeIcons
                                                                      .square,
                                                              color:
                                                                  Colors.white,
                                                              size: 11,
                                                            ),
                                                            const SizedBox(
                                                              width: 1,
                                                            ),
                                                            Text(
                                                              'CA',
                                                              style: robotoStyle(
                                                                  FontWeight
                                                                      .w600,
                                                                  Colors.white,
                                                                  10,
                                                                  null),
                                                            ),
                                                          ],
                                                        ),
                                                        const SizedBox(
                                                          height: 5,
                                                        ),
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              checkIsExist('US')
                                                                  ? FontAwesomeIcons
                                                                      .check
                                                                  : FontAwesomeIcons
                                                                      .square,
                                                              color:
                                                                  Colors.white,
                                                              size: 11,
                                                            ),
                                                            const SizedBox(
                                                              width: 1,
                                                            ),
                                                            Text(
                                                              'USA',
                                                              style: robotoStyle(
                                                                  FontWeight
                                                                      .w600,
                                                                  Colors.white,
                                                                  10,
                                                                  null),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "You can manage app notification",
                                style: w500White12,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "permissions in your ",
                                    style: w500White12,
                                  ),
                                  InkWell(
                                    onTap: (() {
                                      AppSettings.openNotificationSettings();
                                    }),
                                    child: Text(
                                      "Phone Settings",
                                      style: w600Blue12,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color.fromARGB(255, 240, 240, 240),
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  AppLocalizations.of(context)
                                      .calendar_byResellValue,
                                  style: w900Black30,
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  AppLocalizations.of(context)
                                      .calendar_filterFromMarketType,
                                  style: w500Black22,
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Container(
                              height: 10,
                              decoration: const BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.black87,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                              top: 20,
                              left: 10,
                              right: 10,
                              bottom: 10,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (mounted) {
                                      setState(() {
                                        resellLow = !resellLow;
                                      });
                                    }
                                  },
                                  child: Material(
                                    elevation: 8,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(20),
                                    ),
                                    child: Container(
                                      width: 97,
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(
                                        12,
                                        7,
                                        12,
                                        7,
                                      ),
                                      decoration: BoxDecoration(
                                        color: resellLow
                                            ? const Color(0xFFF55E5E)
                                            : Colors.grey,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calendar_filterLow,
                                            style: w900White14,
                                          ),
                                          const SizedBox(
                                            width: 7,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (mounted) {
                                                setState(() {
                                                  resellLow = !resellLow;
                                                });
                                              }
                                            },
                                            child: resellLow
                                                ? Image.asset(
                                                    'assets/etc/restock/checked_white.png',
                                                    height: 20,
                                                  )
                                                : Image.asset(
                                                    'assets/etc/restock/unchecked_white.png',
                                                    height: 20,
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    if (mounted) {
                                      setState(() {
                                        resellMid = !resellMid;
                                      });
                                    }
                                  },
                                  child: Material(
                                    elevation: 8,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(20),
                                    ),
                                    child: Container(
                                      width: 97,
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(
                                          12, 7, 12, 7),
                                      decoration: BoxDecoration(
                                        color: resellMid
                                            ? const Color(0xFFFFC654)
                                            : Colors.grey,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calendar_filterMid,
                                            style: w900White14,
                                          ),
                                          const SizedBox(
                                            width: 7,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (mounted) {
                                                setState(() {
                                                  resellMid = !resellMid;
                                                });
                                              }
                                            },
                                            child: resellMid
                                                ? Image.asset(
                                                    'assets/etc/restock/checked_white.png',
                                                    height: 20,
                                                  )
                                                : Image.asset(
                                                    'assets/etc/restock/unchecked_white.png',
                                                    height: 20,
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    if (mounted) {
                                      setState(() {
                                        resellHigh = !resellHigh;
                                      });
                                    }
                                  },
                                  child: Material(
                                    elevation: 8,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(20),
                                    ),
                                    child: Container(
                                      width: 97,
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(
                                          12, 7, 12, 7),
                                      decoration: BoxDecoration(
                                        color: resellHigh
                                            ? const Color(0xFF21ED8B)
                                            : Colors.grey,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calendar_filterHigh,
                                            style: w900White14,
                                          ),
                                          const SizedBox(
                                            width: 7,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (mounted) {
                                                setState(() {
                                                  resellHigh = !resellHigh;
                                                });
                                              }
                                            },
                                            child: resellHigh
                                                ? Image.asset(
                                                    'assets/etc/restock/checked_white.png',
                                                    height: 20,
                                                  )
                                                : Image.asset(
                                                    'assets/etc/restock/unchecked_white.png',
                                                    height: 20,
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.black12,
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  AppLocalizations.of(context)
                                      .restock_filterByShops,
                                  style: w900Black30,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Text(
                                    AppLocalizations.of(context)
                                        .restock_filterAndRegions,
                                    style: w800Black20,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Text(
                              AppLocalizations.of(context)
                                  .restock_filterFromLocationArea,
                              style: w500Black22,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Container(
                              height: 10,
                              decoration: const BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.black87,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: Column(
                              children: renderShops(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.red.shade400,
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(
                                AppLocalizations.of(context).calendar_byBrands,
                                style: w900White30,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width - 80,
                                child: Text(
                                  AppLocalizations.of(context)
                                      .restock_filterFromSelectedBrands,
                                  style: w500White22,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            height: 10,
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: Colors.white,
                                  width: 1,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 10,
                              left: 0,
                              right: 0,
                            ),
                            child: Wrap(
                              spacing: 0,
                              runSpacing: 0,
                              alignment: WrapAlignment.center,
                              children: renderBrands(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color.fromARGB(255, 49, 48, 54),
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(
                                AppLocalizations.of(context)
                                    .restock_filterBySneakers,
                                style: w900White30,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                                AppLocalizations.of(context)
                                    .restock_filterForTargetedProduct,
                                style: w500White22,
                              ),
                            ],
                          ),
                          Container(
                            height: 10,
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: Colors.white70,
                                  width: 1,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                10, 20, 10, 0),
                            child: Container(
                              height: 60,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  width: 0.5,
                                  color: Colors.white,
                                ),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    15, 12, 15, 12),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Container(
                                      width: 35,
                                      height: 35,
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        border: Border.all(
                                          color: Colors.black26,
                                          width: 1,
                                        ),
                                      ),
                                      child: IconButton(
                                        padding: const EdgeInsets.all(0.0),
                                        icon: Icon(
                                          Icons.mic,
                                          color: _speechRecognitionAvailable &&
                                                  !_isListening
                                              ? Colors.black87
                                              : const Color(0xffff2323),
                                          size: 24,
                                        ),
                                        onPressed: () {
                                          if (_speechRecognitionAvailable &&
                                              !_isListening) {
                                            // start();
                                            _startListening();
                                            setState(() {
                                              searchClick = true;
                                              _isListening = !_isListening;
                                            });
                                          }
                                        },
                                      ),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.only(
                                        left: 15,
                                      ),
                                      decoration: const BoxDecoration(
                                        border: Border(
                                          right: BorderSide(
                                            color: Colors.black12,
                                            width: 1,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 8,
                                    ),
                                    Expanded(
                                      child: !searchClick
                                          ? InkWell(
                                              onTap: (() {
                                                setState(() {
                                                  searchClick = true;
                                                  autoFocus = true;
                                                });
                                              }),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    AppLocalizations.of(context)
                                                        .restock_filterSearchForProducts,
                                                    style: w700Black16,
                                                  ),
                                                ],
                                              ),
                                            )
                                          : Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(8, 0, 0, 0),
                                              child: TextFormField(
                                                controller:
                                                    searchKeywordController,
                                                obscureText: false,
                                                autofocus: autoFocus,
                                                onChanged: (_) =>
                                                    EasyDebounce.debounce(
                                                  'tFMemberController',
                                                  const Duration(
                                                      milliseconds: 500),
                                                  () {},
                                                ),
                                                decoration: InputDecoration(
                                                  isCollapsed: true,
                                                  labelText: '',
                                                  labelStyle: w600Gray16,
                                                  enabledBorder:
                                                      const UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0x00000000),
                                                      width: 1,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(4.0),
                                                      topRight:
                                                          Radius.circular(4.0),
                                                    ),
                                                  ),
                                                  focusedBorder:
                                                      const UnderlineInputBorder(
                                                    borderSide: BorderSide(
                                                      color: Color(0x00000000),
                                                      width: 1,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(4.0),
                                                      topRight:
                                                          Radius.circular(4.0),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                    ),
                                    _startedSearch
                                        ? InkWell(
                                            onTap: () {
                                              searchKeywordController?.text =
                                                  '';
                                              _startedSearch = false;
                                              autoFocus = false;
                                              searchClick = false;
                                              FocusScopeNode currentFocus =
                                                  FocusScope.of(context);
                                              if (!currentFocus
                                                  .hasPrimaryFocus) {
                                                currentFocus.focusedChild
                                                    ?.unfocus();
                                              }
                                              setState(() {});
                                            },
                                            child: const Icon(
                                              CupertinoIcons.clear_circled,
                                              color: Color(0xff757D90),
                                              size: 32,
                                            ),
                                          )
                                        : Container(),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      AppLocalizations.of(context)
                                          .restock_filterAdded,
                                      style: w600White14,
                                    ),
                                    Text(
                                      AppLocalizations.of(context)
                                          .restock_filterDate,
                                      style: w600White14,
                                    ),
                                  ],
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      AppLocalizations.of(context)
                                          .restock_filterProductsNames,
                                      style: w600White14,
                                    ),
                                    Text(
                                      "SKU",
                                      style: w600White14,
                                    ),
                                  ],
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      AppLocalizations.of(context)
                                          .restock_filterPictures,
                                      style: w600White14,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          _startedSearch
                              ? Container(
                                  padding: const EdgeInsets.only(bottom: 20),
                                  height: 160,
                                  // key: paginationViewKey,
                                  child: ListView.separated(
                                    key: const PageStorageKey<String>(
                                      'searchedProducts',
                                    ),
                                    itemCount: searchedProducts.length,
                                    padding: const EdgeInsets.only(
                                      left: 0,
                                      right: 0,
                                      top: 0,
                                      bottom: 0,
                                    ),
                                    separatorBuilder: (context, position) =>
                                        const Divider(
                                      color: Colors.transparent,
                                    ),
                                    itemBuilder: (context, position) => InkWell(
                                      onTap: () {
                                        List<Product> temp = goodList;
                                        temp.add(searchedProducts[position]);
                                        setState(() {
                                          searchedProducts = [];
                                          _startedSearch = false;
                                          searchKeywordController?.text = "";
                                          searchClick = false;
                                          autoFocus = false;
                                          goodList = temp;
                                        });
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.fromLTRB(
                                            10, 0, 10, 0),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            SizedBox(
                                              width: 45,
                                              child: Column(
                                                children: [
                                                  Text(
                                                    getFormatedDate(
                                                        searchedProducts[
                                                                position]
                                                            .productReleaseDate)[0],
                                                    textAlign: TextAlign.center,
                                                    style: w600Gray14,
                                                  ),
                                                  Text(
                                                    getFormatedDate(
                                                        searchedProducts[
                                                                position]
                                                            .productReleaseDate)[1],
                                                    textAlign: TextAlign.center,
                                                    style: w400Gray14,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(width: 2),
                                            Expanded(
                                              flex: 1,
                                              child: Column(
                                                children: [
                                                  Text(
                                                    searchedProducts[position]
                                                        .title,
                                                    textAlign: TextAlign.center,
                                                    style: w900Gray16,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 1,
                                                  ),
                                                  Text(
                                                    searchedProducts[position]
                                                        .id,
                                                    textAlign: TextAlign.center,
                                                    style: w300Gray14,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(width: 2),
                                            SizedBox(
                                              width: 80,
                                              height: 60,
                                              child: CachedNetworkImage(
                                                imageUrl:
                                                    searchedProducts[position]
                                                        .imageLink,
                                                fit: BoxFit.contain,
                                                errorWidget: (
                                                  context,
                                                  error,
                                                  stackTrace,
                                                ) =>
                                                    Image.asset(
                                                  'assets/etc/NoImage.png',
                                                  fit: BoxFit.contain,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              : Container(),
                          Container(
                            padding: const EdgeInsets.fromLTRB(60, 0, 60, 0),
                            child: const Divider(
                              thickness: 1,
                              color: Colors.white70,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0, 20, 0, 10),
                            child: goodList.isNotEmpty
                                ? Container(
                                    height: goodList.length * 70,
                                    decoration: const BoxDecoration(),
                                    // key: paginationViewKey,
                                    child: ListView.separated(
                                      key: const PageStorageKey<String>(
                                        'goodList',
                                      ),
                                      itemCount: goodList.length,
                                      padding: const EdgeInsets.only(
                                        left: 0,
                                        right: 0,
                                        top: 0,
                                      ),
                                      separatorBuilder: (context, position) =>
                                          const Divider(
                                        color: Colors.transparent,
                                      ),
                                      itemBuilder: (context, position) =>
                                          Dismissible(
                                        key: Key(
                                          "item ${goodList[position].id}",
                                        ),
                                        direction: DismissDirection.endToStart,
                                        background: Container(
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color: const Color.fromARGB(
                                              255,
                                              255,
                                              35,
                                              35,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(15),
                                          ),
                                          child: Text(
                                            "Remove",
                                            style: robotoStyle(
                                              FontWeight.w800,
                                              Colors.white,
                                              null,
                                              null,
                                            ),
                                          ),
                                        ),
                                        confirmDismiss: (_) async {
                                          return showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(30),
                                                ),
                                                title: Text(
                                                  'Remove Item',
                                                  style: robotoStyle(
                                                    FontWeight.w700,
                                                    const Color.fromARGB(
                                                      255,
                                                      49,
                                                      48,
                                                      54,
                                                    ),
                                                    null,
                                                    null,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                                content: Text(
                                                  "Do you really want to remove this item from your list?",
                                                  style: robotoStyle(
                                                    FontWeight.w400,
                                                    const Color.fromARGB(
                                                      255,
                                                      49,
                                                      48,
                                                      54,
                                                    ),
                                                    null,
                                                    null,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                ),
                                                actions: <Widget>[
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      TextButton(
                                                        style: ButtonStyle(
                                                          overlayColor:
                                                              MaterialStateProperty
                                                                  .all(const Color
                                                                          .fromARGB(
                                                                      255,
                                                                      235,
                                                                      235,
                                                                      235)),
                                                        ),
                                                        child: Text(
                                                          'Cancel',
                                                          style: w600Gray17,
                                                        ),
                                                        onPressed: () =>
                                                            Navigator.of(
                                                          context,
                                                        ).pop(false),
                                                      ),
                                                      TextButton(
                                                        style: ButtonStyle(
                                                          overlayColor:
                                                              MaterialStateProperty
                                                                  .all(const Color
                                                                          .fromARGB(
                                                                      255,
                                                                      235,
                                                                      235,
                                                                      235)),
                                                        ),
                                                        child: Text(
                                                          'Remove',
                                                          style: w600Red17,
                                                        ),
                                                        onPressed: () {
                                                          Navigator.of(
                                                            context,
                                                          ).pop(true);
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        },
                                        onDismissed: (_) {
                                          setState(() {
                                            Product elmt = goodList[position];
                                            goodList.remove(elmt);
                                          });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.fromLTRB(
                                              10, 0, 10, 0),
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(15),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: <Widget>[
                                              SizedBox(
                                                width: 45,
                                                child: Column(
                                                  children: [
                                                    Text(
                                                      getFormatedDate(goodList[
                                                              position]
                                                          .productReleaseDate)[0],
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: w600Gray14,
                                                    ),
                                                    Text(
                                                      getFormatedDate(goodList[
                                                              position]
                                                          .productReleaseDate)[1],
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: w400Gray14,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                flex: 1,
                                                child: Column(
                                                  children: [
                                                    Text(
                                                      goodList[position].title,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: w900Gray16,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                    ),
                                                    Text(
                                                      goodList[position].id,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: w300Gray14,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(
                                                width: 80,
                                                height: 60,
                                                child: CachedNetworkImage(
                                                  imageUrl: goodList[position]
                                                      .imageLink,
                                                  fit: BoxFit.contain,
                                                  errorWidget: (context, error,
                                                          stackTrace) =>
                                                      Image.asset(
                                                    'assets/etc/NoImage.png',
                                                    fit: BoxFit.contain,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                : Container(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(
                      top: 20,
                    ),
                    child: buildSimpleButton(
                        AppLocalizations.of(context).saveButton, () async {
                      userData['shops'] = checkedShops;
                      userData['brands'] = checkedBrands;

                      var token = await FirebaseMessaging.instance.getToken();
                      userData['fcmtoken'] = token;
                      List<String> wishProducts = [];
                      for (var i = 0; i < goodList.length; i++) {
                        Map wishProduct = {
                          'productSku': goodList[i].id,
                          'productImage': goodList[i].imageLink,
                          'productName': goodList[i].title,
                          'releaseDate': goodList[i].productReleaseDate
                        };
                        wishProducts.add(jsonEncode(wishProduct));
                      }
                      userData['wishProducts'] = wishProducts;
                      prefs.setStringList('shops', checkedShops);
                      prefs.setStringList('brands', checkedBrands);
                      prefs.setStringList('wishProducts', wishProducts);
                      prefs.setBool("resellLow", resellLow);
                      prefs.setBool("resellMid", resellMid);
                      prefs.setBool("resellHigh", resellHigh);
                      prefs.setString('fcmtoken', token.toString());
                      userData['resellLow'] = resellLow;
                      userData['resellMid'] = resellMid;
                      userData['resellHigh'] = resellHigh;
                      String result = await postRequest(
                          'https://api.sneaks4sure.com/user', userData);

                      if (result.contains('ERROR')) {
                      } else {
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                              launchSnackbar(
                                  'Save success.',
                                  Icons.info,
                                  AppColors.lightblack,
                                  AppColors.white,
                                  AppColors.lightblack));
                          _pullRefresh();
                          setState(
                            () {
                              positionRestockPage = 0;
                            },
                          );
                        }
                      }
                    }),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).padding.bottom + 25,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget pageInstoreFilters() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).padding.top + 5,
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                height: 60,
                padding: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                child: IconButton(
                  padding: const EdgeInsets.all(0),
                  icon: const Icon(Icons.arrow_circle_left_outlined),
                  color: const Color.fromARGB(255, 49, 48, 54),
                  iconSize: 32,
                  onPressed: () {
                    notificationProductSku = "";
                    setState(
                      () {
                        positionRestockPage = 0;
                      },
                    );
                  },
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: InkWell(
                onTap: (() {
                  positionRestockPage = 1;
                  Navigator.of(context).pushReplacementNamed(
                    '/Restock',
                  );
                }),
                child: const SizedBox(
                  height: 25,
                  child: Image(
                    image: AssetImage('./assets/etc/splash-cropped.png'),
                    fit: BoxFit.fitHeight,
                  ),
                ),
              ),
            ),
          ],
        ),
        Expanded(
          child: SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                "Customize your ",
                                style: w900White23,
                              ),
                              Text(
                                "notifications",
                                style: w900Red23,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                "Sneakers restock ",
                                style: w700Red16,
                              ),
                              Text(
                                "based on your ",
                                style: w700White16,
                              ),
                              Text(
                                "preferences",
                                style: w700Red16,
                              ),
                            ],
                          ),
                          // const SizedBox(
                          //   height: 8,
                          // ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(10, 15, 10, 15),
                            child: Container(
                              padding:
                                  const EdgeInsets.fromLTRB(10, 10, 10, 10),
                              decoration: BoxDecoration(
                                  color: Colors.red,
                                  borderRadius: BorderRadius.circular(20)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    flex: 3,
                                    child: Container(
                                      height: 75,
                                      decoration: const BoxDecoration(
                                        border: Border(
                                          right: BorderSide(
                                            color: Colors.white,
                                            width: 1,
                                          ),
                                        ),
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterActivated,
                                            style: w900White21,
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterFilters,
                                            style: w900White21,
                                          ),
                                          Text(
                                            AppLocalizations.of(context)
                                                .restock_filterFromSettings,
                                            style: w600White12,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Container(
                                      height: 75,
                                      decoration: const BoxDecoration(
                                        border: Border(
                                          right: BorderSide(
                                            color: Colors.white,
                                            width: 1,
                                          ),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          RotatedBox(
                                            quarterTurns: 3,
                                            child: Text(
                                              AppLocalizations.of(context)
                                                  .instore_filterAreas,
                                              style: w500White16,
                                            ),
                                          ),
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Row(
                                                children: [
                                                  Icon(
                                                    checkCountryIsExist('EU')
                                                        ? FontAwesomeIcons.check
                                                        : FontAwesomeIcons
                                                            .square,
                                                    color: Colors.white,
                                                    size: 11,
                                                  ),
                                                  const SizedBox(
                                                    width: 1,
                                                  ),
                                                  Text(
                                                    'EU',
                                                    style: w600White10,
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  Icon(
                                                    checkCountryIsExist('US')
                                                        ? FontAwesomeIcons.check
                                                        : FontAwesomeIcons
                                                            .square,
                                                    color: Colors.white,
                                                    size: 11,
                                                  ),
                                                  const SizedBox(
                                                    width: 1,
                                                  ),
                                                  Text(
                                                    'USA',
                                                    style: w600White10,
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  Icon(
                                                    checkCountryIsExist('CA')
                                                        ? FontAwesomeIcons.check
                                                        : FontAwesomeIcons
                                                            .square,
                                                    color: Colors.white,
                                                    size: 11,
                                                  ),
                                                  const SizedBox(
                                                    width: 1,
                                                  ),
                                                  Text(
                                                    'CA',
                                                    style: w600White10,
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 2,
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            RotatedBox(
                                              quarterTurns: 3,
                                              child: Text(
                                                AppLocalizations.of(context)
                                                    .instore_filterSizes,
                                                style: w500White16,
                                              ),
                                            ),
                                            RotatedBox(
                                              quarterTurns: 3,
                                              child: Text(
                                                AppLocalizations.of(context)
                                                    .instore_filterSelected,
                                                style: w300White7,
                                              ),
                                            ),
                                          ],
                                        ),
                                        Text(
                                          checkedSizes.length.toString(),
                                          style: w900White21,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "You can manage app notification",
                                style: w500White12,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "permissions in your ",
                                    style: w500White12,
                                  ),
                                  InkWell(
                                    onTap: (() {
                                      AppSettings.openNotificationSettings();
                                    }),
                                    child: Text(
                                      "Phone Settings",
                                      style: w600Blue12,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color.fromARGB(255, 240, 240, 240),
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  AppLocalizations.of(context)
                                      .calendar_byResellValue,
                                  style: w900Black30,
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  AppLocalizations.of(context)
                                      .calendar_filterFromMarketType,
                                  style: w500Black22,
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Container(
                              height: 10,
                              decoration: const BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.black87,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(
                              top: 20,
                              left: 10,
                              right: 10,
                              bottom: 10,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (mounted) {
                                      setState(() {
                                        resellLow = !resellLow;
                                      });
                                    }
                                  },
                                  child: Material(
                                    elevation: 8,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(20),
                                    ),
                                    child: Container(
                                      width: 97,
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(
                                        12,
                                        7,
                                        12,
                                        7,
                                      ),
                                      decoration: BoxDecoration(
                                        color: resellLow
                                            ? const Color(0xFFF55E5E)
                                            : Colors.grey,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calendar_filterLow,
                                            style: w900White14,
                                          ),
                                          const SizedBox(
                                            width: 7,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (mounted) {
                                                setState(() {
                                                  resellLow = !resellLow;
                                                });
                                              }
                                            },
                                            child: resellLow
                                                ? Image.asset(
                                                    'assets/etc/restock/checked_white.png',
                                                    height: 20,
                                                  )
                                                : Image.asset(
                                                    'assets/etc/restock/unchecked_white.png',
                                                    height: 20,
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    if (mounted) {
                                      setState(() {
                                        resellMid = !resellMid;
                                      });
                                    }
                                  },
                                  child: Material(
                                    elevation: 8,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(20),
                                    ),
                                    child: Container(
                                      width: 97,
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(
                                          12, 7, 12, 7),
                                      decoration: BoxDecoration(
                                        color: resellMid
                                            ? const Color(0xFFFFC654)
                                            : Colors.grey,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calendar_filterMid,
                                            style: w900White14,
                                          ),
                                          const SizedBox(
                                            width: 7,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (mounted) {
                                                setState(() {
                                                  resellMid = !resellMid;
                                                });
                                              }
                                            },
                                            child: resellMid
                                                ? Image.asset(
                                                    'assets/etc/restock/checked_white.png',
                                                    height: 20,
                                                  )
                                                : Image.asset(
                                                    'assets/etc/restock/unchecked_white.png',
                                                    height: 20,
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    if (mounted) {
                                      setState(() {
                                        resellHigh = !resellHigh;
                                      });
                                    }
                                  },
                                  child: Material(
                                    elevation: 8,
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(20),
                                    ),
                                    child: Container(
                                      width: 97,
                                      height: 40,
                                      padding: const EdgeInsets.fromLTRB(
                                          12, 7, 12, 7),
                                      decoration: BoxDecoration(
                                        color: resellHigh
                                            ? const Color(0xFF21ED8B)
                                            : Colors.grey,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Text(
                                            AppLocalizations.of(context)
                                                .calendar_filterHigh,
                                            style: w900White14,
                                          ),
                                          const SizedBox(
                                            width: 7,
                                          ),
                                          InkWell(
                                            onTap: () {
                                              if (mounted) {
                                                setState(() {
                                                  resellHigh = !resellHigh;
                                                });
                                              }
                                            },
                                            child: resellHigh
                                                ? Image.asset(
                                                    'assets/etc/restock/checked_white.png',
                                                    height: 20,
                                                  )
                                                : Image.asset(
                                                    'assets/etc/restock/unchecked_white.png',
                                                    height: 20,
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.black12,
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  AppLocalizations.of(context)
                                      .instore_filterByRegions,
                                  style: w900Black30,
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Text(
                              AppLocalizations.of(context)
                                  .restock_filterFromLocationArea,
                              style: w500Black22,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                            child: Container(
                              height: 10,
                              decoration: const BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.black87,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: Column(
                              children: renderRegions(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.red.shade400,
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(
                                AppLocalizations.of(context)
                                    .instore_filterBySize,
                                style: w900White30,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                                AppLocalizations.of(context)
                                    .instore_filterFromUSSize,
                                style: w500White22,
                              ),
                            ],
                          ),
                          Container(
                            height: 10,
                            decoration: const BoxDecoration(
                              border: Border(
                                bottom: BorderSide(
                                  color: Colors.white,
                                  width: 1,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 10,
                              left: 0,
                              right: 0,
                            ),
                            child: Wrap(
                              spacing: 0,
                              runSpacing: 0,
                              alignment: WrapAlignment.center,
                              children: renderSizes(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(
                      top: 20,
                    ),
                    child: buildSimpleButton(
                        AppLocalizations.of(context).saveButton, () async {
                      userData['sizes'] = checkedSizes;
                      var token = await FirebaseMessaging.instance.getToken();
                      userData['fcmtoken'] = token;
                      userData['regions'] = checkedCountrys;

                      prefs.setStringList('sizes', checkedSizes);
                      prefs.setString('fcmtoken', token.toString());
                      prefs.setStringList('regions', checkedCountrys);
                      prefs.setBool("resellLow", resellLow);
                      prefs.setBool("resellMid", resellMid);
                      prefs.setBool("resellHigh", resellHigh);
                      userData['resellLow'] = resellLow;
                      userData['resellMid'] = resellMid;
                      userData['resellHigh'] = resellHigh;

                      String result = await postRequest(
                          'https://api.sneaks4sure.com/user', userData);

                      if (result.contains('ERROR')) {
                      } else {
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                              launchSnackbar(
                                  'Save success.',
                                  Icons.info,
                                  AppColors.lightblack,
                                  AppColors.white,
                                  AppColors.lightblack));
                          _pullInstoreRefresh();
                          setState(
                            () {
                              positionRestockPage = 0;
                            },
                          );
                        }
                      }
                    }),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).padding.bottom + 50,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget buildBody() {
    if (positionRestockPage == 0) {
      return restockMain();
    } else if (positionRestockPage == 1) {
      return pageRestockFilters();
    } else {
      return pageInstoreFilters();
    }
  }

  void scrollToTop(int index) async {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (index == 0) {
        if (onlineScrollController.hasClients) {
          onlineScrollController.animateTo(0,
              duration: const Duration(milliseconds: 50),
              curve: Curves.easeInOut);
        }
      } else {
        if (instoreScrollController.hasClients) {
          instoreScrollController.animateTo(0,
              duration: const Duration(milliseconds: 50),
              curve: Curves.easeInOut);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      // body: KeyboardDismissOnTap(
      //   dismissOnCapturedTaps: true,
      //   child: buildBody(),
      // ),
      body: buildBody(),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.miniCenterFloat,
      floatingActionButton: (positionRestockPage == 0
          ? Stack(
              alignment: Alignment.center,
              children: [
                !isOnline
                    ? Align(
                        alignment: const Alignment(-0.6, 0.92),
                        child: GestureDetector(
                          onDoubleTap: () {
                            scrollToTop(0);
                            setState(() {
                              isOnline = true;
                              isInstore = false;
                              positionRestockMain = 0;
                            });
                          },
                          child: buildFloatingButtonMainCalendar(
                            AppLocalizations.of(context).restock_online,
                            isOnline ? const Color(0xFFF55E5E) : Colors.white,
                            isOnline ? Colors.white : const Color(0xFF757D90),
                            () {
                              setState(() {
                                isOnline = true;
                                isInstore = false;
                                positionRestockMain = 0;
                              });
                            },
                            width: 170,
                          ),
                        ),
                      )
                    : Align(
                        alignment: const Alignment(0.6, 0.92),
                        child: GestureDetector(
                          onDoubleTap: () {
                            scrollToTop(1);
                            setState(() {
                              isOnline = false;
                              isInstore = true;
                              positionRestockMain = 1;
                            });
                          },
                          child: buildFloatingButtonMainCalendar(
                            AppLocalizations.of(context).restock_instore,
                            !isInstore ? Colors.white : const Color(0xFFF55E5E),
                            !isInstore ? const Color(0xFF757D90) : Colors.white,
                            () {
                              setState(() {
                                isOnline = false;
                                isInstore = true;
                                positionRestockMain = 1;
                              });
                            },
                            width: 170,
                          ),
                        ),
                      ),
                !isInstore
                    ? Align(
                        alignment: const Alignment(-0.6, 0.92),
                        child: GestureDetector(
                          onDoubleTap: () {
                            scrollToTop(0);
                            setState(() {
                              isOnline = true;
                              isInstore = false;
                              positionRestockMain = 0;
                            });
                          },
                          child: buildFloatingButtonMainCalendar(
                            AppLocalizations.of(context).restock_online,
                            isOnline ? const Color(0xFFF55E5E) : Colors.white,
                            isOnline ? Colors.white : const Color(0xFF757D90),
                            () {
                              setState(() {
                                isOnline = true;
                                isInstore = false;
                                positionRestockMain = 0;
                              });
                            },
                            width: 170,
                          ),
                        ),
                      )
                    : Align(
                        alignment: const Alignment(0.6, 0.92),
                        child: GestureDetector(
                          onDoubleTap: () {
                            scrollToTop(1);
                            setState(() {
                              isOnline = false;
                              isInstore = true;
                              positionRestockMain = 1;
                            });
                          },
                          child: buildFloatingButtonMainCalendar(
                            AppLocalizations.of(context).restock_instore,
                            !isInstore ? Colors.white : const Color(0xFFF55E5E),
                            !isInstore ? const Color(0xFF757D90) : Colors.white,
                            () {
                              setState(() {
                                isOnline = false;
                                isInstore = true;
                                positionRestockMain = 1;
                              });
                            },
                            width: 170,
                          ),
                        ),
                      ),
              ],
            )
          : null),
    );
  }

  DateTime currentBackPressTime = DateTime.now();

  Future<bool> _onBackPressed() {
    if (positionRestockPage != 0) {
      setState(() {
        positionRestockPage = 0;
        // SchedulerBinding.instance.addPostFrameCallback((_) {
        //   scrollRestock.jumpTo(scrollRestock.position.minScrollExtent);
        // });
      });

      return Future.value(false);
    } else {
      DateTime now = DateTime.now();
      if (now.difference(currentBackPressTime) > const Duration(seconds: 2)) {
        currentBackPressTime = now;
        Fluttertoast.showToast(msg: 'Press Back Button Again to Exit');

        return Future.value(false);
      }
      exit(0);
      // return Future.value(false);
    }
  }

  Future<void> _pullRefresh() async {
    restock = await getRestock();
    if (mounted) setState(() {});
  }

  Future<void> _pullInstoreRefresh() async {
    instore = await getInstore();
    if (mounted) setState(() {});
  }
}
