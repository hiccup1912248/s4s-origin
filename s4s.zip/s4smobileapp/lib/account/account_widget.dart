import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:app_settings/app_settings.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flag/flag_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_fgbg/flutter_fgbg.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:notification_permissions/notification_permissions.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/restock/restock_widget.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:s4s_mobileapp/tools/firebase_service.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

bool accountStatus = false;
bool notifCalendar = false;
bool notifRestock = false;
bool linkSetting = true;

bool isNotifsExpanded = false;
bool isSetupExpanded = false;

class AccountWidget extends StatefulWidget {
  const AccountWidget({Key? key}) : super(key: key);

  @override
  State<AccountWidget> createState() => _AccountWidgetState();
}

class _AccountWidgetState extends State<AccountWidget> {
  String version = "";
  late StreamSubscription<FGBGType> subscription;

  bool netState = true;
  String photoURL = '';
  String createdDate = '1999-02-05';
  String username = "";
  String countryCode = "EU";
  String counryText = "";
  String cityText = "";

  initSharePref() {
    photoURL = prefs.getString('photo') ?? '';
    createdDate = prefs.getString('createdDate') ?? '';
    username = prefs.getString('username') ?? '';
    countryCode = prefs.getString('countryCode') ?? '';
    counryText = prefs.getString('country') ?? '';
    cityText = prefs.getString('city') ?? '';
    setState(() {
      notifRestock = prefs.getBool("notifFlag") == true;
    });
  }

  @override
  void initState() {
    initSharePref();
    getPackageInfo();

    subscription = FGBGEvents.stream.listen((event) {
      if (event == FGBGType.foreground) {
        checkNotificationSettingStatus();
        checkUserInfo();
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  void checkNotificationSettingStatus() {
    Future<PermissionStatus> permissionStatus =
        NotificationPermissions.getNotificationPermissionStatus();
    permissionStatus.then((value) {
      if (value == PermissionStatus.granted) {
        userNotificationOn(true);
        setState(() {
          notifRestock = true;
        });
      } else {
        userNotificationOn(false);
        setState(() {
          notifRestock = false;
        });
      }
    });
  }

  void checkUserInfo() {
    setState(() {
      username = prefs.getString('username') ?? '';
      countryCode = prefs.getString('countryCode') ?? '';
      counryText = prefs.getString('country') ?? '';
      cityText = prefs.getString('city') ?? '';
    });
  }

  getPackageInfo() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String versionNumber = packageInfo.version;
    setState(() {
      version = "V$versionNumber";
    });
  }

  final FirebaseService _fireService = FirebaseService();

  final ScrollController scroll = ScrollController();

  XFile? _imageFile;

  Future pickImage() async {
    try {
      final imageInit =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      String emailStr = prefs.getString("email") ?? "";
      if (imageInit == null) return;
      setState(() {
        if (mounted) {
          _imageFile = imageInit;
        }
      });
      if (_imageFile != null) {
        var uploadResult = await fileUpload(
          'https://api.sneaks4sure.com/upload',
          _imageFile!.path,
          {'email': emailStr},
        );
        if (uploadResult.contains('ERROR')) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(launchSnackbar(
              'Error',
              Icons.error,
              AppColors.white,
              AppColors.red,
              Colors.white,
            ));
          }
        } else {
          await prefs.setString(
            'photo',
            jsonDecode(uploadResult)['data']['profilePic'],
          );
          Map data = {
            "email": emailStr,
            "profile_picture": jsonDecode(uploadResult)['data']['profilePic'],
          };
          String result =
              await postRequest('https://api.sneaks4sure.com/user', data);
          if (result.contains('ERROR')) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(launchSnackbar(
                'Error',
                Icons.error,
                AppColors.white,
                AppColors.red,
                Colors.white,
              ));
            }
          } else {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(launchSnackbar(
                'Save success',
                Icons.error,
                AppColors.white,
                AppColors.red,
                Colors.white,
              ));
              setState(() {
                photoURL = jsonDecode(uploadResult)['data']['profilePic'];
              });
            }
          }
        }
      }
    } on PlatformException {
      ScaffoldMessenger.of(context).showSnackBar(launchSnackbar(
        "Failed to edit profile picture.",
        Icons.info,
        Colors.white,
        const Color.fromARGB(255, 255, 35, 35),
        Colors.white,
      ));
    }
  }

  void scrollDown() {
    scroll.animateTo(
      scroll.position.maxScrollExtent * 2,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  Future<void> userNotificationOn(bool flag) async {
    Map userData = {};
    userData['email'] = prefs.getString("email");
    prefs.setBool("notifFlag", flag);
    userData['notifFlag'] = flag;
    await postRequest('https://api.sneaks4sure.com/user', userData);
  }

  Future logoutPopUp(BuildContext context) {
    var temp =
        MaterialStateProperty.all(const Color.fromARGB(255, 235, 235, 235));

    return showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            title: Text(
              'Logout',
              textAlign: TextAlign.center,
              style: robotoStyle(
                FontWeight.w800,
                const Color.fromARGB(255, 49, 48, 54),
                null,
                null,
              ),
            ),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  "Are you sure you want to logout ?",
                  style: robotoStyle(
                    FontWeight.w400,
                    const Color.fromARGB(255, 49, 48, 54),
                    null,
                    null,
                  ),
                ),
              ],
            ),
            actions: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    style: ButtonStyle(
                      overlayColor: temp,
                    ),
                    child: Text(
                      'Cancel',
                      style:
                          robotoStyle(FontWeight.w600, Colors.grey, 17, null),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                  TextButton(
                    style: ButtonStyle(
                      overlayColor: temp,
                    ),
                    child: Text(
                      'Confirm',
                      style: robotoStyle(
                        FontWeight.w600,
                        const Color.fromARGB(255, 255, 35, 35),
                        17,
                        null,
                      ),
                    ),
                    onPressed: () {
                      setState(
                        () {
                          positionRestockPage = 0;
                          isJordan = false;
                          isNike = false;
                          isAdidas = false;
                          isYeezy = false;
                          isNewbalance = false;
                          isNotifsExpanded = false;
                          isSetupExpanded = false;
                          // here to reinit all the positions used to go to other pages inside onglet
                        },
                      );
                      _fireService.signOut();
                      Navigator.of(context).pushNamedAndRemoveUntil(
                        '/Landing',
                        (route) => false,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(launchSnackbar(
                        "You are successfully logged out.",
                        Icons.check,
                        const Color.fromARGB(255, 255, 35, 35),
                        Colors.white,
                        const Color.fromARGB(255, 255, 35, 35),
                      ));
                    },
                  ),
                ],
              ),
            ],
          );
        });
      },
    );
  }

  Widget pageAccountMain() {
    return Scaffold(
      key: GlobalKey<ScaffoldState>(),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        controller: scroll,
        key: const PageStorageKey<String>('Account Scroll Main'),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: MediaQuery.of(context).padding.top + 25,
              ),
              Stack(
                children: [
                  Align(
                    alignment: const Alignment(-0.9, 0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: 50,
                          child: Image.asset(
                            'assets/etc/logo_account.png',
                            fit: BoxFit.fitWidth,
                          ),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "Build",
                              style: w500Black12,
                            ),
                            Text(
                              version,
                              style: w700Black12,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Have to retrieve the account picture from database
                  Align(
                    alignment: Alignment.bottomCenter,
                    // Image.network(url, height, width)
                    child: GestureDetector(
                      onTap: () {
                        pickImage();
                      },
                      child: ClipOval(
                        child: photoURL == ''
                            ? Container(
                                width: 180,
                                height: 180,
                                color: const Color(0xffd1d3d4),
                                child: const Icon(
                                  FontAwesomeIcons.user,
                                  size: 140,
                                  color: Color(0xffa7a9ac),
                                ),
                              )
                            : CachedNetworkImage(
                                imageUrl: photoURL,
                                width: 180,
                                height: 180,
                                fit: BoxFit.cover,
                              ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      logoutPopUp(context);
                    },
                    child: const Align(
                      alignment: Alignment(0.9, 0),
                      child: Icon(
                        Icons.power_settings_new_rounded,
                        color: Color.fromARGB(255, 255, 35, 35),
                        size: 40,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Have to retrieve account username from database
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      username,
                      style: w800Black22,
                    ),
                    const SizedBox(width: 5),
                    const Icon(
                      Icons.circle_rounded,
                      size: 16,
                      color: Color.fromARGB(255, 33, 237, 91),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 15),
                child: Text(
                  "${AppLocalizations.of(context).account_joinedUsSince} ${DateFormat.yMMMd().format(DateTime.parse(createdDate))}",
                  style: robotoStyle(
                    FontWeight.w400,
                    const Color.fromARGB(255, 49, 48, 54),
                    null,
                    null,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 10, bottom: 5),
                width: MediaQuery.of(context).size.width - 60,
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black38, width: 0.5),
                          borderRadius: BorderRadius.circular(100),
                        ),
                        child: Flag.fromString(
                          countryCode.isEmpty ? "EU" : countryCode,
                          borderRadius: 100,
                          fit: BoxFit.fill,
                          height: 35,
                          width: 35,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        children: [
                          Container(
                            constraints: const BoxConstraints(maxWidth: 180),
                            child: Text(
                              counryText,
                              style: w700Black14,
                              maxLines: 2,
                              softWrap: true,
                            ),
                          ),
                          Container(
                            constraints: const BoxConstraints(maxWidth: 180),
                            child: Text(
                              cityText,
                              style: w500Black14,
                              maxLines: 2,
                              softWrap: true,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 5),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        width: 20,
                      ),
                      Text(
                        AppLocalizations.of(context).account_public,
                        style: robotoStyle(
                          FontWeight.w500,
                          accountStatus
                              ? const Color.fromARGB(255, 33, 237, 91)
                              : const Color.fromARGB(255, 49, 48, 54),
                          16,
                          null,
                        ),
                      ),
                      Text(
                        " - ",
                        style: w500Black16,
                      ),
                      Text(
                        AppLocalizations.of(context).account_private,
                        style: robotoStyle(
                          FontWeight.w500,
                          !accountStatus
                              ? const Color.fromARGB(255, 255, 35, 35)
                              : const Color.fromARGB(255, 49, 48, 54),
                          16,
                          null,
                        ),
                      ),
                      Transform.scale(
                        scale: 0.6,
                        child: CupertinoSwitch(
                          onChanged: (value) {
                            setState(
                              () {
                                accountStatus = value;
                              },
                            );
                          },
                          value: accountStatus,
                          activeColor: const Color.fromARGB(255, 33, 237, 91),
                          trackColor: const Color.fromARGB(255, 255, 35, 35),
                          thumbColor: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Container(
                padding: const EdgeInsets.only(top: 10),
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildIconButton(
                        const Icon(
                          Icons.vpn_key_outlined,
                          color: Color.fromARGB(255, 255, 35, 35),
                          size: 30,
                        ),
                        AppLocalizations.of(context).account_myProfile,
                        AppLocalizations.of(context)
                            .account_everythingAboutProfil,
                        () {
                          Navigator.of(context).pushNamed(
                            '/AccountProfile',
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_forward_ios_rounded),
                        color: const Color.fromARGB(255, 49, 48, 54),
                        onPressed: () {
                          Navigator.of(context).pushNamed(
                            '/AccountProfile',
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 10),
                child: Align(
                  alignment: const Alignment(-0.8, 0),
                  child: Text(
                    AppLocalizations.of(context).account_allSettings,
                    style: w800Black18,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 5),
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildIconButton(
                        const Icon(
                          Icons.notifications_none_rounded,
                          color: Color.fromARGB(255, 255, 35, 35),
                          size: 30,
                        ),
                        AppLocalizations.of(context).account_myNotifications,
                        AppLocalizations.of(context)
                            .account_manageYourPushMessageAlert,
                        () {
                          setState(
                            () {
                              isNotifsExpanded = !isNotifsExpanded;
                            },
                          );
                          // if (isNotifsExpanded) scrollDown();
                        },
                      ),
                      IconButton(
                        icon: Icon(
                          !isNotifsExpanded
                              ? Icons.expand_more_rounded
                              : Icons.expand_less_rounded,
                          size: 35,
                        ),
                        color: const Color.fromARGB(255, 49, 48, 54),
                        onPressed: () {
                          setState(
                            () {
                              isNotifsExpanded = !isNotifsExpanded;
                            },
                          );
                          // if (isNotifsExpanded) scrollDown();
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: 300,
                    height: isNotifsExpanded ? 150 : 0,
                    child: Visibility(
                      key: const PageStorageKey<String>(
                        'Scroll MyNotifications',
                      ),
                      visible: isNotifsExpanded,
                      child: ListView(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        children: [
                          SizedBox(
                            width: 300,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      "assets/etc/internet.gif",
                                      width: 45,
                                      height: 45,
                                    ),
                                    Column(
                                      children: [
                                        Text(
                                          AppLocalizations.of(context)
                                              .account_online,
                                          style: w700Black18,
                                        ),
                                        const SizedBox(
                                          height: 3,
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            positionRestockPage = 1;
                                            Navigator.of(context).pushNamed(
                                              '/Restock',
                                            );
                                          },
                                          child: Text(
                                            AppLocalizations.of(context)
                                                .account_advancedSettings,
                                            style: w500Blue10,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Transform.scale(
                                      scale: 0.75,
                                      child: CupertinoSwitch(
                                        onChanged: (value) {
                                          AppSettings
                                              .openNotificationSettings();
                                        },
                                        value: notifRestock,
                                        activeColor: const Color.fromARGB(
                                          255,
                                          33,
                                          237,
                                          91,
                                        ),
                                        trackColor: const Color.fromARGB(
                                          255,
                                          255,
                                          35,
                                          35,
                                        ),
                                        thumbColor: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                                const Divider(
                                  color: Colors.grey,
                                  height: 30,
                                  thickness: 1,
                                  indent: 100,
                                  endIndent: 100,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      "assets/etc/shop.gif",
                                      width: 45,
                                      height: 45,
                                    ),
                                    Column(
                                      children: [
                                        Text(
                                          AppLocalizations.of(context)
                                              .account_instore,
                                          style: w700Black18,
                                        ),
                                        const SizedBox(
                                          height: 3,
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            positionRestockPage = 1;
                                            Navigator.of(context).pushNamed(
                                              '/Restock',
                                            );
                                          },
                                          child: Text(
                                            AppLocalizations.of(context)
                                                .account_advancedSettings,
                                            style: w500Blue10,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Transform.scale(
                                      scale: 0.75,
                                      child: CupertinoSwitch(
                                        onChanged: (value) {
                                          AppSettings
                                              .openNotificationSettings();
                                        },
                                        value: notifRestock,
                                        activeColor: const Color.fromARGB(
                                          255,
                                          33,
                                          237,
                                          91,
                                        ),
                                        trackColor: const Color.fromARGB(
                                          255,
                                          255,
                                          35,
                                          35,
                                        ),
                                        thumbColor: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 48,
                  ),
                ],
              ),
              Center(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildIconButton(
                      const Icon(
                        Icons.favorite_border_rounded,
                        color: Color.fromARGB(255, 255, 35, 35),
                        size: 30,
                      ),
                      AppLocalizations.of(context).account_myWishList,
                      AppLocalizations.of(context)
                          .account_allProductsYouSpotted,
                      () {
                        Navigator.of(context).pushNamed(
                          '/Wishlist',
                        );
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.arrow_forward_ios_rounded),
                      color: const Color.fromARGB(255, 49, 48, 54),
                      onPressed: () {
                        Navigator.of(context).pushNamed(
                          '/Wishlist',
                        );
                      },
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(
                  top: 5,
                ),
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildIconButton(
                        const Icon(
                          Icons.settings,
                          color: Color.fromARGB(255, 255, 35, 35),
                          size: 30,
                        ),
                        AppLocalizations.of(context).account_mySetup,
                        AppLocalizations.of(context)
                            .account_adjustYourPersonalSettings,
                        () {
                          setState(
                            () {
                              isSetupExpanded = !isSetupExpanded;
                            },
                          );
                          // if (isSetupExpanded) scrollDown();
                        },
                      ),
                      IconButton(
                        icon: Icon(
                          !isSetupExpanded
                              ? Icons.expand_more_rounded
                              : Icons.expand_less_rounded,
                          size: 35,
                        ),
                        color: const Color.fromARGB(255, 49, 48, 54),
                        onPressed: () {
                          setState(
                            () {
                              isSetupExpanded = !isSetupExpanded;
                            },
                          );
                          // if (isNotifsExpanded) scrollDown();
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: 300,
                    child: Visibility(
                      key: const PageStorageKey<String>(
                        'Scroll MySetupSettings',
                      ),
                      visible: isSetupExpanded,
                      child: Column(
                        children: [
                          Stack(
                            alignment: AlignmentDirectional.center,
                            children: [
                              Align(
                                alignment: const Alignment(-1, 0),
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 6),
                                  child: Image.asset(
                                    'assets/etc/website.png',
                                    fit: BoxFit.fitWidth,
                                    width: 32,
                                    height: 32,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: Container(
                                  width: 200,
                                  child: Text(
                                    linkSetting
                                        ? AppLocalizations.of(context)
                                            .account_inAppWebView
                                        : AppLocalizations.of(context)
                                            .account_externalWebView,
                                    style: robotoStyle(
                                      FontWeight.w800,
                                      const Color.fromARGB(255, 49, 48, 54),
                                      20,
                                      null,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: const Alignment(1, 0),
                                child: Transform.scale(
                                  scale: 0.75,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      CupertinoSwitch(
                                        onChanged: (value) {
                                          setState(() {
                                            linkSetting = value;
                                          });
                                          prefs.setBool("linkSetting", value);
                                        },
                                        value: linkSetting,
                                        activeColor: const Color.fromARGB(
                                          255,
                                          33,
                                          237,
                                          91,
                                        ),
                                        trackColor: const Color.fromARGB(
                                          255,
                                          255,
                                          35,
                                          35,
                                        ),
                                        thumbColor: Colors.white,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 48,
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.only(top: 5, bottom: 15),
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildIconButton(
                        const Icon(
                          Icons.expand,
                          color: Color.fromARGB(255, 255, 35, 35),
                          size: 30,
                        ),
                        AppLocalizations.of(context).account_sneakersSizeGuide,
                        AppLocalizations.of(context)
                            .account_byBrandsAndGeographicalRegion,
                        () {
                          Navigator.pushNamed(context, '/SizeGuide');
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_forward_ios_rounded),
                        color: const Color.fromARGB(255, 49, 48, 54),
                        onPressed: () {
                          Navigator.pushNamed(context, '/SizeGuide');
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(top: 10),
                child: Align(
                  alignment: const Alignment(-0.8, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Sneaks4Sure",
                        style: w900Black18,
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(5, 3, 0, 0),
                        child: Text(
                          "(TM)",
                          style: w500Black10,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.only(bottom: 15),
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      buildIconButton(
                        const Icon(
                          FontAwesomeIcons.handPointer,
                          color: Color.fromARGB(255, 255, 35, 35),
                          size: 30,
                        ),
                        AppLocalizations.of(context).account_aboutUs,
                        AppLocalizations.of(context)
                            .account_s4sCompanyInformation,
                        () {
                          Navigator.of(context).pushNamed(
                            '/AboutUS',
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_forward_ios_rounded),
                        color: const Color.fromARGB(255, 49, 48, 54),
                        onPressed: () {
                          Navigator.of(context).pushNamed(
                            '/AboutUS',
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(40, 0, 40, 30),
                child: Material(
                  elevation: 8,
                  borderRadius: const BorderRadius.all(Radius.circular(20)),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(8, 20, 8, 20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              "“Your ",
                              style: w400Black20,
                            ),
                            Text(
                              "app store review",
                              style: w900Red20,
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              "helps ",
                              style: w400Black20,
                            ),
                            Text(
                              "spread the word ",
                              style: w900Black20,
                            ),
                            Text(
                              "and",
                              style: w400Black20,
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              "grow ",
                              style: w400Black20,
                            ),
                            Text(
                              "S4S community!",
                              style: w900Black20,
                            ),
                            Text(
                              "”",
                              style: w400Black20,
                            ),
                          ],
                        ),
                        InkWell(
                          onTap: (() {
                            urlLauncher(
                              "https://trustpilot.com/review/www.sneaks4sure.com",
                            );
                          }),
                          child: Column(
                            children: [
                              const SizedBox(
                                height: 30,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Image.asset(
                                    Platform.isAndroid
                                        ? "assets/etc/playstore.png"
                                        : "assets/etc/appstore.png",
                                    height: 40,
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 30,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    "- Lx@ -",
                                    style: w700Black12,
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    "Sneaks4Sure CEO",
                                    style: w700Black12,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              RatingBarIndicator(
                                rating: 4.9,
                                itemBuilder: (context, index) => const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                ),
                                itemCount: 5,
                                itemSize: 15.0,
                              ),
                              Text(
                                "(4.9)",
                                style: robotoStyle(
                                  FontWeight.w400,
                                  const Color.fromARGB(255, 49, 48, 54),
                                  10,
                                  null,
                                ),
                              ),
                            ],
                          ),
                        ),
                        InkWell(
                          onTap: () async {
                            final InAppReview inAppReview =
                                InAppReview.instance;
                            bool isAvalable = await inAppReview.isAvailable();
                            if (Platform.isAndroid) {
                              inAppReview.openStoreListing();
                            } else {
                              inAppReview.openStoreListing(
                                  appStoreId: "6445998208");
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.fromLTRB(40, 10, 40, 10),
                            decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 33, 237, 91),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              AppLocalizations.of(context).account_RateUs,
                              style: robotoStyle(
                                FontWeight.w900,
                                Colors.white,
                                17,
                                null,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              Container(
                padding: const EdgeInsets.only(top: 0, bottom: 10),
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () {
                          urlLauncher("https://www.instagram.com/sneaks4sure/");
                        },
                        child: Image.asset(
                          'assets/icons/instagram_outlined.png',
                          height: 30,
                        ),
                      ),
                      const SizedBox(width: 30),
                      GestureDetector(
                        onTap: () {
                          urlLauncher("https://www.tiktok.com/@sneaks4sure/");
                        },
                        child: Image.asset(
                          'assets/icons/tiktok_outlined.png',
                          height: 30,
                        ),
                      ),
                      const SizedBox(width: 30),
                      GestureDetector(
                        onTap: () {
                          urlLauncher("https://twitter.com/Sneaks4sure/");
                        },
                        child: Image.asset(
                          'assets/icons/twitter_outlined.png',
                          height: 30,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                AppLocalizations.of(context).account_joinUsSocialNetworks,
                style: w800Black12,
              ),
              const SizedBox(
                height: 40,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildBody() {
    return pageAccountMain();
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return Scaffold(
      body: KeyboardDismissOnTap(
        dismissOnCapturedTaps: true,
        child: buildBody(),
      ),
    );
  }

  DateTime currentBackPressTime = DateTime.now();

  Future<bool> _onBackPressed() {
    if (Navigator.canPop(context)) {
      Navigator.pop(context);
    }
    DateTime now = DateTime.now();
    if (now.difference(currentBackPressTime) > const Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(msg: 'Press Back Button Again to Exit');

      return Future.value(false);
    }
    exit(0);
  }
}
