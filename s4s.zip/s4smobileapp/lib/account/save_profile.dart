import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/account/account_page.dart';
import 'package:s4s_mobileapp/account/account_profile_widget.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
// ignore: depend_on_referenced_packages
import 'package:uuid/uuid.dart';
import 'package:s4s_mobileapp/tools/address_search.dart';
import 'package:s4s_mobileapp/tools/place_service.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'dart:convert';
import 'package:country_calling_code_picker/picker.dart';

import '../main.dart';

File? image;

class SaveProfile extends StatefulWidget {
  const SaveProfile({Key? key}) : super(key: key);

  @override
  State<SaveProfile> createState() => _SaveProfileState();
}

class _SaveProfileState extends State<SaveProfile> {
  List<String> listSizes = regularSizes
      .map((e) =>
          'US ${e.keys.first}/UK ${e[e.keys.first][0]}/EU ${e[e.keys.first][1]}')
      .toList()
      .cast<String>();
  String? defaultSizes;
  var checkSizeField = [0, 0];

  final List<String> listCurrencies = [
    '€ - EUR',
    r'$ - USD',
    r'$ - CAD',
    '£ - GBP',
    '¥ - YEN',
    '¥ - CNY',
  ];
  String? defaultCurrencies;
  var checkCurrencyField = [0, 0];
  final List<String> listLocations = [
    '🌎 Worldwide',
    '🇨🇦 Canada',
    '🇨🇳 China',
    '🇪🇺 Europe',
    '🇯🇵 Japan',
    '🇺🇸 USA',
  ];
  String? defaultLocations;
  var checkAreaField = [0, 0];
  var checkUsernameField = [0, 0];
  var checkFirstNameField = [0, 0];
  var checkLastNameField = [0, 0];
  var checkPhoneField = [0, 0];
  var checkAL1Field = [0, 0];
  var checkAL2Field = [0, 0];
  var checkCityField = [0, 0];
  var checkZipcodeField = [0, 0];
  var checkStateField = [0, 0];
  var checkCountryField = [0, 0];
  var checkUserMailField = [0, 0];
  final controllerUsername = TextEditingController();
  final controllerFirstName = TextEditingController();
  final controllerLastName = TextEditingController();
  final controllerPhone = TextEditingController();
  final controllerAL1 = TextEditingController();
  final controllerAL2 = TextEditingController();
  final controllerCity = TextEditingController();
  final controllerZipcode = TextEditingController();
  final controllerState = TextEditingController();
  final controllerUserMail = TextEditingController();
  // String? _streetNumber = '';
  // String? _street = '';
  // String? _city = '';
  // String? _zipCode = '';
  String selectedCountryFlag = "";
  String selectedCountryText = "";
  String selectedCountryCode = "";
  String photoURL = '';

  XFile? _imageFile;

  String fcmToken = '';

  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          print('Data connection is available.');
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          print('You are disconnected from the internet.');
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    checkNetworkStatus();
    initSharePref();
    getFcmToken();

    super.initState();
  }

  Future<void> getFcmToken() async {
    var token = await FirebaseMessaging.instance.getToken();
    setState(() {
      fcmToken = token!;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF6F6F6),
      body: KeyboardDismissOnTap(
        dismissOnCapturedTaps: true,
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).padding.top + 18,
            ),
            Center(
              child: Align(
                alignment: Alignment.center,
                child: Text(
                  "Informations",
                  style: robotoStyle(
                      FontWeight.w700, const Color(0xff313036), 20, null),
                ),
              ),
            ),
            const SizedBox(
              height: 18,
            ),
            Container(
              height: 6,
              width: 80,
              decoration: const BoxDecoration(
                color: Color(0xff313036),
              ),
            ),
            const Divider(
              color: Colors.grey,
              height: 0,
              thickness: 1,
            ),
            Expanded(
              child: SingleChildScrollView(
                key: const PageStorageKey<String>('Account Scroll MyProfile'),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.only(top: 35),
                        child: Align(
                          alignment: const Alignment(-0.8, 0),
                          child: Text(
                            "General",
                            style: robotoStyle(
                                FontWeight.w800,
                                const Color.fromARGB(255, 49, 48, 54),
                                16,
                                null),
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              myDropDownButton(
                                  const Icon(
                                    Icons.stars_rounded,
                                    size: 25,
                                    color: Colors.grey,
                                  ),
                                  "Preferred Size",
                                  listSizes,
                                  defaultSizes,
                                  260, (value) {
                                setState(() {
                                  defaultSizes = value as String;
                                  checkSizeField[0] = 0;
                                  checkSizeField[1] = 1;
                                });
                              }),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkSizeField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              myDropDownButton(
                                  const Icon(
                                    Icons.payments,
                                    size: 25,
                                    color: Colors.grey,
                                  ),
                                  "Default Currency",
                                  listCurrencies,
                                  defaultCurrencies,
                                  260, (value) {
                                setState(() {
                                  defaultCurrencies = value as String;
                                  checkCurrencyField[0] = 0;
                                  checkCurrencyField[1] = 1;
                                });
                              }),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkCurrencyField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              myDropDownButton(
                                  const Icon(
                                    Icons.my_location_rounded,
                                    size: 25,
                                    color: Colors.grey,
                                  ),
                                  "Location Area",
                                  listLocations,
                                  defaultLocations,
                                  260, (value) {
                                setState(() {
                                  defaultLocations = value as String;
                                  checkAreaField[0] = 0;
                                  checkAreaField[1] = 1;
                                });
                              }),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkAreaField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 40),
                        child: Align(
                          alignment: const Alignment(-0.8, 0),
                          child: Text(
                            "Personal",
                            style: robotoStyle(
                                FontWeight.w800,
                                const Color.fromARGB(255, 49, 48, 54),
                                16,
                                null),
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextFieldEmail(
                                  "example.example@gmail.com", // to be replaced by the real user infos from DB
                                  const Icon(
                                    Icons.alternate_email_rounded,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  controllerUserMail,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              // returnCheckingIcon(checkUserMailField),
                              const SizedBox(
                                width: 30,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "Username",
                                  const Icon(
                                    Icons.account_circle_outlined,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerUsername,
                                  TextInputType.name,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkUsernameField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "First Name",
                                  const Icon(
                                    Icons.abc_rounded,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerFirstName,
                                  TextInputType.name,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkFirstNameField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "Last Name",
                                  const Icon(
                                    Icons.abc_rounded,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerLastName,
                                  TextInputType.name,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkLastNameField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "Phone Number",
                                  const Icon(
                                    Icons.phone_outlined,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerPhone,
                                  TextInputType.phone,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkPhoneField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 40),
                        child: Align(
                          alignment: const Alignment(-0.8, 0),
                          child: Text(
                            "Shipping Address",
                            style: robotoStyle(
                                FontWeight.w800,
                                const Color.fromARGB(255, 49, 48, 54),
                                16,
                                null),
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildAddressTextField(
                                  "Address Line 1",
                                  const Icon(
                                    Icons.location_on,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerAL1,
                                  TextInputType.streetAddress,
                                  () async {
                                    final sessionToken = const Uuid().v4();
                                    final Suggestion? result = await showSearch(
                                      context: context,
                                      delegate: AddressSearch(sessionToken),
                                    );
                                    // This will change the text displayed in the TextField
                                    if (result != null) {
                                      final placeDetails =
                                          await PlaceApiProvider(sessionToken)
                                              .getPlaceDetailFromId(
                                                  result.placeId);

                                      controllerAL1.text = result.description;
                                      controllerCity.text =
                                          placeDetails.city ?? '';
                                      controllerZipcode.text =
                                          placeDetails.zipCode ?? '';
                                      controllerState.text =
                                          placeDetails.state ?? '';
                                      selectedCountryCode =
                                          placeDetails.countryCode ?? '';
                                      initCountry();
                                      setState(() {
                                        if (mounted) {
                                          if (controllerAL1.text != '') {
                                            //isAL1 = true;
                                            checkAL1Field[0] = 0;
                                            checkAL1Field[1] = 1;
                                          } else {
                                            //isAL1 = false;
                                            checkAL1Field[0] = 1;
                                            checkAL1Field[1] = 0;
                                          }
                                          if (controllerCity.text != '') {
                                            //isAL1 = true;
                                            checkCityField[0] = 0;
                                            checkCityField[1] = 1;
                                          } else {
                                            //isAL1 = false;
                                            checkCityField[0] = 1;
                                            checkCityField[1] = 0;
                                          }
                                          if (controllerZipcode.text != '') {
                                            //isAL1 = true;
                                            checkZipcodeField[0] = 0;
                                            checkZipcodeField[1] = 1;
                                          } else {
                                            //isAL1 = false;
                                            checkZipcodeField[0] = 1;
                                            checkZipcodeField[1] = 0;
                                          }
                                          if (controllerState.text != '') {
                                            //isAL1 = true;
                                            checkStateField[0] = 0;
                                            checkStateField[1] = 1;
                                          } else {
                                            //isAL1 = false;
                                            checkStateField[0] = 1;
                                            checkStateField[1] = 0;
                                          }
                                          if (selectedCountryCode != '') {
                                            checkCountryField[0] = 0;
                                            checkCountryField[1] = 1;
                                          } else {
                                            checkCountryField[0] = 1;
                                            checkCountryField[1] = 0;
                                          }
                                        }
                                      });
                                    }
                                  },
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkAL1Field)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "Address Line 2",
                                  const Icon(
                                    Icons.location_on,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerAL2,
                                  TextInputType.streetAddress,
                                ),
                              ),
                              const SizedBox(
                                width: 40,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "City",
                                  const Icon(
                                    Icons.map_outlined,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerCity,
                                  TextInputType.streetAddress,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkCityField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "Zipcode",
                                  const Icon(
                                    Icons.markunread_mailbox_outlined,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerZipcode,
                                  TextInputType.number,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkZipcodeField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.only(top: 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextField(
                                  "State",
                                  const Icon(
                                    Icons.share_location_rounded,
                                    color: Colors.grey,
                                    size: 25,
                                  ),
                                  Colors.white,
                                  controllerState,
                                  TextInputType.streetAddress,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkStateField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 300,
                        padding: const EdgeInsets.fromLTRB(0, 20, 0, 20),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: buildTextFieldCountryReadOnly(
                                  "Country",
                                  selectedCountryText,
                                  const Icon(
                                    Icons.flag_rounded,
                                    size: 25,
                                    color: Colors.grey,
                                  ),
                                  selectedCountryFlag,
                                  const Icon(
                                    Icons.arrow_drop_down_rounded,
                                    size: 30,
                                    color: Color.fromARGB(255, 49, 48, 54),
                                  ),
                                  (() async {
                                    final country =
                                        await showCountryPickerSheet(context);
                                    if (country != null) {
                                      if (mounted) {
                                        setState(() {
                                          selectedCountryText = country.name;
                                          selectedCountryFlag = country.flag;
                                        });
                                      }
                                    }
                                  }),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              returnCheckingIcon(checkCountryField)
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(top: 30, bottom: 80),
                        child: buildSimpleButton(
                          "Save",
                          () async {
                            await prefs.setBool('savedProfile', true);
                            if (checkAL1Field[1] == 1 &&
                                checkAreaField[1] == 1 &&
                                checkCityField[1] == 1 &&
                                checkCountryField[1] == 1 &&
                                checkCurrencyField[1] == 1 &&
                                checkFirstNameField[1] == 1 &&
                                checkLastNameField[1] == 1 &&
                                checkPhoneField[1] == 1 &&
                                checkSizeField[1] == 1 &&
                                checkStateField[1] == 1 &&
                                checkUsernameField[1] == 1 &&
                                checkZipcodeField[1] == 1) {
                              Map data = {
                                'username': controllerUsername.text,
                                'email': controllerUserMail.text,
                                'first_name': controllerFirstName.text,
                                'last_name': controllerLastName.text,
                                'phone_number': controllerPhone.text,
                                'profile_picture': photoURL,
                                'Shipping': [
                                  {
                                    'address_line1': controllerAL1.text,
                                    'address_line2': controllerAL2.text,
                                    'city': controllerCity.text,
                                    'zip_code': controllerZipcode.text,
                                    'state': controllerState.text,
                                    'country': selectedCountryText,
                                    'country_code': selectedCountryCode,
                                    'country_flag': selectedCountryFlag
                                  }
                                ],
                                'General': {
                                  'prefered_size': defaultSizes,
                                  'default_currency': defaultCurrencies,
                                  'location_area': defaultLocations,
                                },
                                'fcmtoken': fcmToken,
                                'savedProfile': true,
                              };
                              String result = await postRequest(
                                  'https://api.sneaks4sure.com/user', data);
                              if (result.contains('ERROR')) {
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      launchSnackbar(
                                          result,
                                          Icons.error,
                                          AppColors.white,
                                          AppColors.red,
                                          Colors.white));
                                }
                              } else {
                                var showResult = jsonDecode(result);
                                await prefs.setString('createdDate',
                                    showResult['data']['create_date']);
                                await prefs.setString(
                                    'city', controllerCity.text);
                                await prefs.setString(
                                    'country', selectedCountryText);
                                await prefs.setString(
                                    'countryCode', selectedCountryCode);
                                await prefs.setString(
                                    'countryFlag', selectedCountryFlag);
                                await prefs.setString(
                                    'username', controllerUsername.text);
                                await prefs.setString(
                                    'preferredSize', defaultSizes!);
                                await prefs.setString(
                                    'defaultCurrency', defaultCurrencies!);
                                await prefs.setString(
                                    'locationArea', defaultLocations!);
                                await prefs.setString(
                                    'username', controllerUsername.text);
                                await prefs.setString(
                                    'email', controllerUserMail.text);
                                await prefs.setString(
                                    'firstname', controllerFirstName.text);
                                await prefs.setString(
                                    'lastname', controllerLastName.text);
                                await prefs.setString(
                                    'phone', controllerPhone.text);
                                await prefs.setString(
                                    'shippingAddr1', controllerAL1.text);
                                await prefs.setString(
                                    'shippingAddr2', controllerAL2.text);
                                await prefs.setString(
                                    'zipcode', controllerZipcode.text);
                                await prefs.setString(
                                    'state', controllerState.text);
                                await prefs.setString('fcmtoken', fcmToken);

                                if (_imageFile != null) {
                                  var uploadResult = await fileUpload(
                                      'https://api.sneaks4sure.com/upload',
                                      _imageFile!.path,
                                      {'email': controllerUserMail.text});
                                  if (uploadResult.contains('ERROR')) {
                                    if (mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(launchSnackbar(
                                              result,
                                              Icons.error,
                                              AppColors.white,
                                              AppColors.red,
                                              Colors.white));
                                    }
                                  } else {
                                    await prefs.setString(
                                        'photo',
                                        jsonDecode(uploadResult)['data']
                                            ['profilePic']);
                                    await prefs.setString('createdDate',
                                        DateTime.now().toString());
                                    if (showResult['data']['data'] ==
                                        'user created') {
                                      if (mounted) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(launchSnackbar(
                                                'A new user has been created.',
                                                Icons.info,
                                                AppColors.lightblack,
                                                AppColors.white,
                                                AppColors.lightblack));
                                      }
                                    } else if (showResult['data']['data'] ==
                                        'user updated') {
                                      if (mounted) {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(launchSnackbar(
                                                'This user has been updated.',
                                                Icons.info,
                                                AppColors.lightblack,
                                                AppColors.white,
                                                AppColors.lightblack));
                                      }
                                    }
                                    if (mounted) {
                                      setState(() {
                                        photoURL =
                                            jsonDecode(uploadResult)['data']
                                                ['profilePic'];
                                        Navigator.of(context)
                                            .pushAndRemoveUntil(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        AccountPage()),
                                                (route) => false);
                                      });
                                    }
                                  }
                                } else {
                                  await prefs.setString(
                                      'createdDate', DateTime.now().toString());
                                  if (showResult['data']['data'] ==
                                      'user created') {
                                    if (mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(launchSnackbar(
                                              'A new user has been created.',
                                              Icons.info,
                                              AppColors.lightblack,
                                              AppColors.white,
                                              AppColors.lightblack));
                                    }
                                  } else if (showResult['data']['data'] ==
                                      'user updated') {
                                    if (mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(launchSnackbar(
                                              'This user has been updated.',
                                              Icons.info,
                                              AppColors.lightblack,
                                              AppColors.white,
                                              AppColors.lightblack));
                                    }
                                  }
                                  setState(() {
                                    Navigator.of(context).pushAndRemoveUntil(
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                AccountPage()),
                                        (route) => false);
                                  });
                                }
                              }
                            } else {
                              if (checkAL1Field[1] != 1) {
                                setState(() {
                                  checkAL1Field[0] = 1;
                                });
                              }
                              if (checkAL2Field[1] != 1) {
                                setState(() {
                                  checkAL2Field[0] = 1;
                                });
                              }
                              if (checkAreaField[1] != 1) {
                                setState(() {
                                  checkAreaField[0] = 1;
                                });
                              }
                              if (checkCityField[1] != 1) {
                                setState(() {
                                  checkCityField[0] = 1;
                                });
                              }
                              if (checkCountryField[1] != 1) {
                                setState(() {
                                  checkCountryField[0] = 1;
                                });
                              }
                              if (checkCurrencyField[1] != 1) {
                                setState(() {
                                  checkCurrencyField[0] = 1;
                                });
                              }
                              if (checkFirstNameField[1] != 1) {
                                setState(() {
                                  checkFirstNameField[0] = 1;
                                });
                              }
                              if (checkLastNameField[1] != 1) {
                                setState(() {
                                  checkLastNameField[0] = 1;
                                });
                              }
                              if (checkPhoneField[1] != 1) {
                                setState(() {
                                  checkPhoneField[0] = 1;
                                });
                              }
                              if (checkSizeField[1] != 1) {
                                setState(() {
                                  checkSizeField[0] = 1;
                                });
                              }
                              if (checkStateField[1] != 1) {
                                setState(() {
                                  checkStateField[0] = 1;
                                });
                              }
                              if (checkUsernameField[1] != 1) {
                                setState(() {
                                  checkUsernameField[0] = 1;
                                });
                              }
                              if (checkZipcodeField[1] != 1) {
                                setState(() {
                                  checkZipcodeField[0] = 1;
                                });
                              }
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    launchSnackbar(
                                        "At least one information is missing or invalid.",
                                        Icons.info,
                                        Colors.white,
                                        const Color.fromARGB(255, 255, 35, 35),
                                        Colors.white));
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildTextField(
    String title,
    Icon icon,
    Color color,
    TextEditingController controller,
    TextInputType keyType,
  ) {
    return TextField(
      textAlign: TextAlign.left,
      cursorColor: const Color.fromARGB(255, 255, 35, 35),
      controller: controller,
      keyboardType: keyType,
      decoration: InputDecoration(
        filled: true,
        fillColor: color,
        prefixIcon: icon,
        prefixIconColor: color,
        hintText: title,
        contentPadding: const EdgeInsets.all(15),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.circular(30),
        ),
      ),
      onChanged: (value) {
        if (controller == controllerUsername) checkUsername(value);
        if (controller == controllerFirstName) {
          if (isAlphabetics(value)) {
            setState(() {
              //isFirstName = true;
              checkFirstNameField[0] = 0;
              checkFirstNameField[1] = 1;
            });
          } else {
            setState(() {
              //isFirstName = false;
              checkFirstNameField[0] = 1;
              checkFirstNameField[1] = 0;
            });
          }
        }
        if (controller == controllerLastName) {
          if (isAlphabetics(value)) {
            setState(() {
              //isLastName = true;
              checkLastNameField[0] = 0;
              checkLastNameField[1] = 1;
            });
          } else {
            setState(() {
              //isLastName = false;
              checkLastNameField[0] = 1;
              checkLastNameField[1] = 0;
            });
          }
        }
        if (controller == controllerPhone) {
          if (isNumerics(value)) {
            setState(() {
              //isPhone = true;
              checkPhoneField[0] = 0;
              checkPhoneField[1] = 1;
            });
          } else {
            setState(() {
              //isPhone = false;
              checkPhoneField[0] = 1;
              checkPhoneField[1] = 0;
            });
          }
        }
        if (controller == controllerAL1) {
          if (isAlphaNum(value)) {
            setState(() {
              //isAL1 = true;
              checkAL1Field[0] = 0;
              checkAL1Field[1] = 1;
            });
          } else {
            setState(() {
              //isAL1 = false;
              checkAL1Field[0] = 1;
              checkAL1Field[1] = 0;
            });
          }
        }
        if (controller == controllerAL2) {
          if (isAlphaNum(value)) {
            setState(() {
              //isAL2 = true;
              checkAL2Field[0] = 0;
              checkAL2Field[1] = 1;
            });
          } else {
            setState(() {
              //isAL2 = false;
              checkAL2Field[0] = 1;
              checkAL2Field[1] = 0;
            });
          }
        }
        if (controller == controllerCity) {
          if (isAlphabetics(value)) {
            setState(() {
              //isCity = true;
              checkCityField[0] = 0;
              checkCityField[1] = 1;
            });
          } else {
            setState(() {
              //isCity = false;
              checkCityField[0] = 1;
              checkCityField[1] = 0;
            });
          }
        }
        if (controller == controllerZipcode) {
          if (isNumerics(value)) {
            setState(() {
              //isZipcode = true;
              checkZipcodeField[0] = 0;
              checkZipcodeField[1] = 1;
            });
          } else {
            setState(() {
              //isZipcode = false;
              checkZipcodeField[0] = 1;
              checkZipcodeField[1] = 0;
            });
          }
        }
        if (controller == controllerState) {
          if (isAlphabetics(value)) {
            setState(() {
              //isState = true;
              checkStateField[0] = 0;
              checkStateField[1] = 1;
            });
          } else {
            setState(() {
              //isState = false;
              checkStateField[0] = 1;
              checkStateField[1] = 0;
            });
          }
        }
      },
    );
  }

  Widget buildAddressTextField(
    String title,
    Icon icon,
    Color color,
    TextEditingController controller,
    TextInputType keyType,
    addressTap,
  ) {
    return TextField(
      textAlign: TextAlign.left,
      cursorColor: const Color.fromARGB(255, 255, 35, 35),
      controller: controller,
      keyboardType: keyType,
      readOnly: true,
      decoration: InputDecoration(
        filled: true,
        fillColor: color,
        prefixIcon: icon,
        prefixIconColor: color,
        hintText: title,
        contentPadding: const EdgeInsets.all(15),
        border: OutlineInputBorder(
          borderSide: BorderSide.none,
          borderRadius: BorderRadius.circular(30),
        ),
      ),
      onTap: addressTap,
    );
  }

  initSharePref() {
    controllerUsername.text = prefs.getString('username') ?? '';
    controllerFirstName.text = prefs.getString('firstname') ?? '';
    controllerLastName.text = prefs.getString('lastname') ?? '';
    controllerPhone.text = prefs.getString('phone') ?? '';
    controllerUserMail.text = prefs.getString('email') ?? '';
    defaultSizes = prefs.getString('preferredSize');
    defaultCurrencies = prefs.getString('defaultCurrency');
    defaultLocations = prefs.getString('locationArea');
    controllerAL1.text = prefs.getString('shippingAddr1') ?? '';
    controllerAL2.text = prefs.getString('shippingAddr2') ?? '';
    controllerCity.text = prefs.getString('city') ?? '';
    controllerZipcode.text = prefs.getString('zipcode') ?? '';
    controllerState.text = prefs.getString('state') ?? '';
    selectedCountryText = prefs.getString('country') ?? '';
    selectedCountryCode = prefs.getString('countryCode') ?? '';
    selectedCountryFlag = prefs.getString('countryFlag') ?? '';
    photoURL = prefs.getString('photo') ?? '';
    createdDate = prefs.getString('createdDate') ?? '';

    if (mounted) {
      setState(() {
        checkUserMailField = controllerUserMail.text == '' ? [1, 0] : [0, 1];
        checkUsernameField = controllerUsername.text == '' ? [1, 0] : [0, 1];
        checkFirstNameField = controllerFirstName.text == '' ? [1, 0] : [0, 1];
        checkLastNameField = controllerLastName.text == '' ? [1, 0] : [0, 1];
        checkPhoneField = controllerPhone.text == '' ? [1, 0] : [0, 1];
        checkPhoneField = controllerUserMail.text == '' ? [1, 0] : [0, 1];
        checkSizeField =
            defaultSizes == '' || defaultSizes == null ? [1, 0] : [0, 1];
        checkCurrencyField =
            defaultCurrencies == '' || defaultCurrencies == null
                ? [1, 0]
                : [0, 1];
        checkAreaField = defaultLocations == '' || defaultLocations == null
            ? [1, 0]
            : [0, 1];
        checkAL1Field = controllerAL1.text == '' ? [1, 0] : [0, 1];
        checkAL2Field = controllerAL2.text == '' ? [1, 0] : [0, 1];
        checkCityField = controllerCity.text == '' ? [1, 0] : [0, 1];
        checkZipcodeField = controllerZipcode.text == '' ? [1, 0] : [0, 1];
        checkStateField = controllerState.text == '' ? [1, 0] : [0, 1];
        checkCountryField = selectedCountryText == '' ? [1, 0] : [0, 1];
        photoURL = prefs.getString('photo') ?? '';
      });
    }
  }

  Future pickImage() async {
    try {
      final imageInit =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (imageInit == null) return;
      setState(() {
        if (mounted) {
          _imageFile = imageInit;
        }
      });
    } on PlatformException {
      ScaffoldMessenger.of(context).showSnackBar(launchSnackbar(
        "Failed to edit profile picture.",
        Icons.info,
        Colors.white,
        const Color.fromARGB(255, 255, 35, 35),
        Colors.white,
      ));
    }
  }

  void checkUsername(String value) {
    if (isAlphaNum(value)) {
      setState(() {
        //isUsername = true;
        checkUsernameField[0] = 0;
        checkUsernameField[1] = 1;
      });
    } else {
      setState(() {
        //isUsername = false;
        checkUsernameField[0] = 1;
        checkUsernameField[1] = 0;
      });
    }
  }

  void initCountry() async {
    final country = await getCountryByCountryCode(context, selectedCountryCode);
    if (mounted) {
      setState(() {
        if (country != null) {
          selectedCountryText = country.name;
          selectedCountryFlag = country.flag;
        }
      });
    }
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    super.dispose();
  }
}
