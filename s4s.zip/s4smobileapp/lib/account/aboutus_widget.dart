import 'package:flutter/material.dart';
import 'package:s4s_mobileapp/account/account_widget.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/restock/restock_widget.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/firebase_service.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AboutUSWidget extends StatefulWidget {
  const AboutUSWidget({Key? key}) : super(key: key);

  @override
  State<AboutUSWidget> createState() => _AboutUSWidgetState();
}

class _AboutUSWidgetState extends State<AboutUSWidget> {
  final FirebaseService _fireService = FirebaseService();

  Future deleteAccountPopup(BuildContext context) {
    var temp =
        MaterialStateProperty.all(const Color.fromARGB(255, 235, 235, 235));

    return showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            title: Text(
              'Delete this Account?',
              textAlign: TextAlign.center,
              style: robotoStyle(
                FontWeight.w800,
                const Color.fromARGB(255, 49, 48, 54),
                null,
                null,
              ),
            ),
            content: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Text(
                  "Are you sure you want to delete this account?",
                  style: robotoStyle(
                    FontWeight.w400,
                    const Color.fromARGB(255, 49, 48, 54),
                    null,
                    null,
                  ),
                ),
              ],
            ),
            actions: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    style: ButtonStyle(
                      overlayColor: temp,
                    ),
                    child: Text(
                      'Cancel',
                      style:
                          robotoStyle(FontWeight.w600, Colors.grey, 17, null),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                  TextButton(
                    style: ButtonStyle(
                      overlayColor: temp,
                    ),
                    child: Text(
                      'Confirm',
                      style: robotoStyle(
                        FontWeight.w600,
                        const Color.fromARGB(255, 255, 35, 35),
                        17,
                        null,
                      ),
                    ),
                    onPressed: () {
                      deleteAccount();
                    },
                  ),
                ],
              ),
            ],
          );
        });
      },
    );
  }

  deleteAccount() async {
    setState(
      () {
        positionRestockPage = 0;
        isJordan = false;
        isNike = false;
        isAdidas = false;
        isYeezy = false;
        isNewbalance = false;
        isNotifsExpanded = false;
        isSetupExpanded = false;
        // here to reinit all the positions used to go to other pages inside onglet
      },
    );
    //delete user from api.
    var email = prefs.getString("email");
    await getData('https://api.sneaks4sure.com/deleteUser/$email');
    prefs.setBool("savedProfile", false);
    prefs.setBool("loggedin", false);
    _fireService.deleteUser();
    // ignore: use_build_context_synchronously
    Navigator.of(context).pushNamedAndRemoveUntil('/Landing', (route) => false);
    // ignore: use_build_context_synchronously
    ScaffoldMessenger.of(context).showSnackBar(
      launchSnackbar(
        "Your account is successfully deleted.",
        Icons.check,
        const Color.fromARGB(255, 255, 35, 35),
        Colors.white,
        const Color.fromARGB(255, 255, 35, 35),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).padding.top + 25,
          ),
          Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: const Alignment(-0.85, 0),
                child: IconButton(
                  icon: const Icon(Icons.arrow_circle_left_outlined),
                  color: const Color.fromARGB(255, 49, 48, 54),
                  iconSize: 32,
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Text(
                  AppLocalizations.of(context).aboutus_title,
                  style: w700Black20,
                ),
              ),
            ],
          ),
          Container(
            height: 5,
            width: 80,
            decoration: const BoxDecoration(
              color: Color.fromARGB(255, 49, 48, 54),
            ),
          ),
          const Divider(
            color: Colors.grey,
            height: 0,
            thickness: 1,
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(50, 50, 50, 0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    urlLauncher("http://sneaks4sure.com/");
                  },
                  child: Material(
                    elevation: 8,
                    borderRadius: const BorderRadius.all(Radius.circular(100)),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(0, 13, 0, 13),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              AppLocalizations.of(context)
                                  .aboutus_termsAndConditions,
                              style: w700Black15,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                InkWell(
                  onTap: () {
                    urlLauncher(
                      "https://mobile.sneaks4sure.com/privacy-policy/",
                    );
                  },
                  child: Material(
                    elevation: 8,
                    borderRadius: const BorderRadius.all(Radius.circular(100)),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(0, 13, 0, 13),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              AppLocalizations.of(context)
                                  .aboutus_privacyPolicy,
                              style: w700Black15,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                InkWell(
                  onTap: () {
                    urlLauncher("mailto:contact@sneaks4sure.com");
                  },
                  child: Material(
                    elevation: 8,
                    borderRadius: const BorderRadius.all(Radius.circular(100)),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Container(
                        padding: const EdgeInsets.fromLTRB(0, 13, 0, 13),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              AppLocalizations.of(context).aboutus_contact,
                              style: w700Black15,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Image.asset(
                  "assets/s4s_dunk_man.png",
                  height: 160,
                ),
                const SizedBox(
                  height: 50,
                ),
                GestureDetector(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                    child: Text(
                      AppLocalizations.of(context).aboutus_deleteMyAccount,
                      style: w800White14,
                    ),
                  ),
                  onTap: () {
                    deleteAccountPopup(context);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
