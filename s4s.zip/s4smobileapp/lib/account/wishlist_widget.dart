import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:s4s_mobileapp/main.dart';
import 'package:s4s_mobileapp/product/product_detail_page.dart';
import 'package:s4s_mobileapp/product/product_detail_widget.dart';
import 'package:s4s_mobileapp/tools/constant_style.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class WishlistWidget extends StatefulWidget {
  const WishlistWidget({Key? key}) : super(key: key);

  @override
  State<WishlistWidget> createState() => _WishlistWidgetState();
}

class _WishlistWidgetState extends State<WishlistWidget> {
  bool sortWishlistPrice = false;
  bool sortWishlistName = false;
  bool sortWishlistDate = true;
  bool sortWishlistSize = false;

  List<Map> wishlist = [];

  List<Map> sortData = [
    {'name': 'Price'},
    {'name': 'Product Name'},
    {'name': 'Added date'},
    {'name': 'Size'},
  ];

  @override
  void initState() {
    setWishList();
    super.initState();
  }

  List<Map> goodList() {
    if (!sortWishlistName &&
        !sortWishlistPrice &&
        !sortWishlistDate &&
        !sortWishlistSize) {
      return wishlist;
    } else {
      sortWishList();

      return wishlist;
    }
  }

  void setWishList() {
    List<String> prefWishlist = prefs.getStringList("wishlist") ?? [];
    List<Map> temp = [];
    if (prefWishlist.isNotEmpty) {
      for (var el in prefWishlist) {
        Map wishObject = jsonDecode(el);
        temp.add(wishObject);
      }
    }
    setState(() {
      wishlist = temp;
    });
  }

  checkSortFlagStatus(String sortType) {
    if (sortType == "price") {
      return sortWishlistPrice;
    }
    if (sortType == "name") {
      return sortWishlistName;
    }
    if (sortType == "date") {
      return sortWishlistDate;
    }
    if (sortType == "size") {
      return sortWishlistSize;
    }
  }

  void sortWishList() {
    if (sortWishlistName) {
      //sort by name
      wishlist.sort((a, b) {
        try {
          return a['productName']
              .toString()
              .toLowerCase()
              .compareTo(b['productName'].toString().toLowerCase());
        } catch (e) {
          return 1;
        }
      });
    }
    if (sortWishlistPrice) {
      //sort by price
      wishlist.sort((a, b) {
        try {
          if (a["price"] == null || a["price"].toString().isEmpty) {
            return 1;
          }
          if (b["price"] == null || b["price"].toString().isEmpty) {
            return -1;
          }

          return int.parse(a['price'].toString())
              .compareTo(int.parse(b['price'].toString()));
        } catch (e) {
          return 1;
        }
      });
    }

    if (sortWishlistDate) {
      wishlist.sort((a, b) {
        try {
          if (a["addTime"] == null) {
            return 1;
          }
          if (b["addTime"] == null) {
            return -1;
          }

          return a['addTime'].compareTo(b['addTime']);
        } catch (e) {
          return 1;
        }
      });
    }

    if (sortWishlistSize) {
      //sort by product name
      wishlist.sort((a, b) {
        try {
          return b['size']
              .toString()
              .toLowerCase()
              .compareTo(a['size'].toString().toLowerCase());
        } catch (e) {
          return 1;
        }
      });
    }
  }

  Future wishlistSortPopUp(BuildContext context) {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          title: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.sort_rounded),
                const SizedBox(
                  width: 5,
                ),
                Text(
                  AppLocalizations.of(context).wishlist_sortBy,
                  style: robotoStyle(
                    FontWeight.w700,
                    const Color.fromARGB(255, 49, 48, 54),
                    null,
                    null,
                  ),
                ),
              ],
            ),
          ),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const SizedBox(
                height: 5,
              ),
              getFilterWidget(
                "price",
                AppLocalizations.of(context).wishlist_sortByPrice,
              ),
              const SizedBox(
                height: 15,
              ),
              getFilterWidget(
                "name",
                AppLocalizations.of(context).wishlist_sortByProductName,
              ),
              const SizedBox(
                height: 15,
              ),
              getFilterWidget(
                "date",
                AppLocalizations.of(context).wishlist_sortByAddedDate,
              ),
              const SizedBox(
                height: 15,
              ),
              getFilterWidget(
                "size",
                AppLocalizations.of(context).wishlist_sortBySize,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget getFilterWidget(String sortType, String data) {
    return InkWell(
      splashColor: Colors.transparent,
      onTap: () {
        if (sortType == "price") {
          if (sortWishlistPrice) {
            setState(
              () {
                sortWishlistPrice = false;
              },
            );
          } else {
            setState(
              () {
                sortWishlistPrice = true;
                sortWishlistName = false;
                sortWishlistDate = false;
                sortWishlistSize = false;
              },
            );
          }
        }

        if (sortType == "name") {
          if (sortWishlistName) {
            setState(
              () {
                sortWishlistName = false;
              },
            );
          } else {
            setState(
              () {
                sortWishlistName = true;
                sortWishlistPrice = false;
                sortWishlistDate = false;
                sortWishlistSize = false;
              },
            );
          }
        }

        if (sortType == "date") {
          if (sortWishlistDate) {
            setState(
              () {
                sortWishlistDate = false;
              },
            );
          } else {
            setState(
              () {
                sortWishlistDate = true;
                sortWishlistName = false;
                sortWishlistPrice = false;
                sortWishlistSize = false;
              },
            );
          }
        }

        if (sortType == "size") {
          if (sortWishlistSize) {
            setState(
              () {
                sortWishlistSize = false;
              },
            );
          } else {
            setState(
              () {
                sortWishlistSize = true;
                sortWishlistName = false;
                sortWishlistPrice = false;
                sortWishlistDate = false;
              },
            );
          }
        }

        Navigator.pop(context);
      },
      child: Row(
        children: [
          const SizedBox(
            width: 30,
          ),
          Icon(
            checkSortFlagStatus(sortType)
                ? CupertinoIcons.checkmark_alt_circle_fill
                : CupertinoIcons.circle,
            color: checkSortFlagStatus(sortType)
                ? const Color.fromARGB(255, 255, 35, 35)
                : Colors.grey,
            size: 30,
          ),
          const SizedBox(
            width: 10,
          ),
          Text(
            data,
            style: robotoStyle(
              FontWeight.w400,
              const Color.fromARGB(255, 49, 48, 54),
              null,
              null,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> removeWishItem(String productSku) async {
    List<String> wishlist = prefs.getStringList('wishlist') ?? [];
    if (wishlist.isNotEmpty) {
      for (var el in wishlist) {
        if (el.contains(productSku)) {
          wishlist.remove(el);
          break;
        }
      }
      Map userData = {
        'email': prefs.getString('email') ?? '',
        'wishlist': wishlist,
      };

      await postRequest('https://api.sneaks4sure.com/user', userData);
      prefs.setStringList('wishlist', wishlist);
    }
  }

  @override
  Widget build(BuildContext context) {
    double devicePaddingTop = MediaQuery.of(context).padding.top;

    List<Map> goods = goodList();

    return Scaffold(
      backgroundColor: Colors.white,
      body: goods.isEmpty
          ? Column(children: [
              SizedBox(
                height: devicePaddingTop + 25,
              ),
              Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: const Alignment(-0.85, 0),
                    child: IconButton(
                      icon: const Icon(Icons.arrow_circle_left_outlined),
                      color: const Color.fromARGB(255, 49, 48, 54),
                      iconSize: 32,
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      AppLocalizations.of(context).wishlist_myWishList,
                      style: w700Black20,
                    ),
                  ),
                ],
              ),
              Container(
                height: 5,
                width: 80,
                decoration: const BoxDecoration(
                  color: Color.fromARGB(255, 49, 48, 54),
                ),
              ),
              const Divider(
                color: Colors.grey,
                height: 0,
                thickness: 1,
              ),
              const SizedBox(height: 250),
              Text(
                "Your Wishlist is currently empty.",
                style: robotoStyle(
                  FontWeight.w500,
                  const Color.fromARGB(255, 49, 48, 54),
                  null,
                  null,
                ),
              ),
            ])
          : Column(
              children: [
                SizedBox(
                  height: devicePaddingTop + 5,
                ),
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: const Alignment(-0.9, 0),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_circle_left_outlined),
                        color: const Color.fromARGB(255, 49, 48, 54),
                        iconSize: 32,
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        AppLocalizations.of(context).wishlist_myWishList,
                        style: w700Black20,
                      ),
                    ),
                    Align(
                      alignment: const Alignment(0.9, 0),
                      child: IconButton(
                        icon: const Icon(Icons.sort_rounded),
                        color: sortWishlistName ||
                                sortWishlistPrice ||
                                sortWishlistSize
                            ? const Color.fromARGB(255, 255, 35, 35)
                            : const Color.fromARGB(255, 49, 48, 54),
                        iconSize: 32,
                        onPressed: () {
                          wishlistSortPopUp(context);
                        },
                      ),
                    ),
                  ],
                ),
                Container(
                  height: 5,
                  width: 80,
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 49, 48, 54),
                  ),
                ),
                const Divider(
                  color: Colors.grey,
                  height: 0,
                  thickness: 1,
                ),
                Expanded(
                  child: ListView.separated(
                    key: const PageStorageKey<String>(
                      'Account Listview MyWishlist',
                    ),
                    itemCount: goods.length,
                    padding: const EdgeInsets.only(bottom: 80),
                    separatorBuilder: (context, position) => const Divider(
                      color: Colors.transparent,
                    ),
                    itemBuilder: (context, position) {
                      return InkWell(
                        onTap: () async {
                          productDetail = await getProductDetail(
                              goodList()[position]['productSku']);
                          Navigator.of(context).pushNamed("/ProductDetail");
                        },
                        child: Dismissible(
                          direction: DismissDirection.endToStart,
                          key: Key("item ${goods[position]['productSku']}"),
                          background: Container(
                            alignment: Alignment.center,
                            color: const Color.fromARGB(255, 255, 35, 35),
                            child: Text(
                              "Remove",
                              style: robotoStyle(
                                FontWeight.w800,
                                Colors.white,
                                null,
                                null,
                              ),
                            ),
                          ),
                          confirmDismiss: (_) async {
                            return showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  title: Text(
                                    'Remove Item',
                                    style: robotoStyle(
                                      FontWeight.w700,
                                      const Color.fromARGB(255, 49, 48, 54),
                                      null,
                                      null,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  content: Text(
                                    "Do you really want to remove this item from your wishlist?",
                                    style: robotoStyle(
                                      FontWeight.w400,
                                      const Color.fromARGB(255, 49, 48, 54),
                                      null,
                                      null,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  actions: <Widget>[
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        TextButton(
                                          style: ButtonStyle(
                                            overlayColor:
                                                MaterialStateProperty.all(
                                                    const Color.fromARGB(
                                                        255, 235, 235, 235)),
                                          ),
                                          child: Text(
                                            'Cancel',
                                            style: robotoStyle(
                                              FontWeight.w600,
                                              Colors.grey,
                                              17,
                                              null,
                                            ),
                                          ),
                                          onPressed: () =>
                                              Navigator.of(context).pop(false),
                                        ),
                                        TextButton(
                                          style: ButtonStyle(
                                            overlayColor:
                                                MaterialStateProperty.all(
                                                    const Color.fromARGB(
                                                        255, 235, 235, 235)),
                                          ),
                                          child: Text(
                                            'Remove',
                                            style: robotoStyle(
                                              FontWeight.w600,
                                              const Color.fromARGB(
                                                255,
                                                255,
                                                35,
                                                35,
                                              ),
                                              17,
                                              null,
                                            ),
                                          ),
                                          onPressed: () {
                                            Navigator.of(context).pop(true);
                                            removeWishItem(
                                              goods[position]['productSku'],
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                          onDismissed: (_) {
                            setState(() {
                              Map elmt = goods[position];
                              wishlist.remove(elmt);
                            });
                          },
                          child: ListTile(
                            leading: CachedNetworkImage(
                              imageUrl: goods[position]['productImage'],
                              width: 70,
                              height: 50,
                              fit: BoxFit.contain,
                            ),
                            title: Center(
                              child: Text(
                                goods[position]['productName'],
                                style: robotoStyle(
                                  FontWeight.w800,
                                  const Color.fromARGB(255, 49, 48, 54),
                                  null,
                                  null,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            subtitle: Center(
                              child:
                                  // ignore: prefer_interpolation_to_compose_strings
                                  Text("Size: " + goods[position]['size']),
                            ),
                            trailing: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              spacing: 10,
                              children: <Widget>[
                                Icon(
                                    goods[position]['productChangeArrow'] ==
                                            'red'
                                        ? Icons.trending_down_rounded
                                        : Icons.trending_up_rounded,
                                    color: goods[position]
                                                ['productChangeArrow'] ==
                                            'red'
                                        ? const Color.fromARGB(255, 255, 35, 35)
                                        : const Color.fromARGB(
                                            255, 33, 237, 91)),
                                Text(
                                  getPriceWithCurrency(
                                    goods[position]['price'],
                                  ),
                                  style: TextStyle(
                                    color: goods[position]
                                                ['productChangeArrow'] ==
                                            'red'
                                        ? const Color.fromARGB(255, 255, 35, 35)
                                        : const Color.fromARGB(
                                            255, 33, 237, 91),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
