import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:s4s_mobileapp/account/wishlist_widget.dart';
import 'package:s4s_mobileapp/tools/bottom_navbar.dart';
import 'package:s4s_mobileapp/tools/functions.dart';
import 'package:s4s_mobileapp/tools/bottom_search_button.dart';

class WishlistPage extends StatefulWidget {
  const WishlistPage({Key? key}) : super(key: key);

  @override
  State<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage>
    with TickerProviderStateMixin {
  bool isNotificatinoDialogShowing = false;
  late AnimationController _resizableController;
  bool netState = true;
  late final StreamSubscription<InternetConnectionStatus> _netStateListener;

  checkNetworkStatus() {
    _netStateListener =
        InternetConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case InternetConnectionStatus.connected:
          if (kDebugMode) {
            print('Data connection is available.');
          }
          setState(() {
            netState = true;
          });

          break;
        case InternetConnectionStatus.disconnected:
          if (kDebugMode) {
            print('You are disconnected from the internet.');
          }
          setState(() {
            netState = false;
          });
          break;
      }
    });
  }

  @override
  void initState() {
    checkNetworkStatus();

    // ignore: unnecessary_new
    _resizableController = new AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1000,
      ),
    );
    _resizableController.addStatusListener((animationStatus) {
      switch (animationStatus) {
        case AnimationStatus.completed:
          _resizableController.reverse();
          break;
        case AnimationStatus.dismissed:
          _resizableController.forward();
          break;
        case AnimationStatus.forward:
          break;
        case AnimationStatus.reverse:
          break;
      }
    });
    _resizableController.forward();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (!netState) {
      return returnOfflineWidget(context);
    }

    return const Scaffold(
      extendBody: true,
      resizeToAvoidBottomInset: false,
      appBar: null,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: WishlistWidget(),
      ),
      bottomNavigationBar: BottomNavBar(4),
      floatingActionButton: BottomSearchButton(false),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.miniCenterDocked,
    );
  }

  @override
  void dispose() {
    _netStateListener.cancel();
    _resizableController.dispose();
    super.dispose();
  }
}
