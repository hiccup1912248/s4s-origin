package com.alx.s4s_mobileapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
