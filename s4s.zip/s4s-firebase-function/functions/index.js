const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();


//restock notification every 1 minutes
const restockNotificationHandler = require('./restockRequest');
exports.restockNotification = functions.pubsub
    .schedule("every 1 minutes")
    .onRun(async function (context) {
        var i = 0;
        var nIntervId = setInterval(() => {
            i++;
            if (i > 2) {
                restockNotificationHandler.handler(context, admin, functions);
                clearInterval(nIntervId);
            } else {
                restockNotificationHandler.handler(context, admin, functions);
            }
        }, 20000);
        return;
        // return restockNotificationHandler.handler(context, admin, functions);
    })