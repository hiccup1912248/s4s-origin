const tiny = require("tiny-json-http");
const API_SERVER_URL = 'https://api.sneaks4sure.com/';

exports.get = (method) => {
    const url = `${API_SERVER_URL}${method}`;
    const options = {
        url,
        headers: {
            "Content-Type": "application/json",
        },
    };

    return tiny.get(options);
};