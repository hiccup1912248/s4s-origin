const { get } = require('./utils/api');

exports.handler = async (context, admin, functions) => {
    try {
        const response = await get("firebase/restock");
        if (response.body.length > 0) {
            response.body.map(userNotificationData => {
                userNotificationData.productNames.map(item => {

                    console.log('notificatoin message ====> ', {
                        token: userNotificationData.fcmtoken,
                        notification: {
                            title: "S4S - Just Restocked",
                            body: item.name,
                            imageUrl: item.image,
                        },
                        data: {
                            productSku: item.productSku,
                            linkUrl: item.linkUrl,
                        }
                    });

                    admin.messaging().send({
                        token: userNotificationData.fcmtoken,
                        notification: {
                            title: "S4S - Just Restocked",
                            body: item.name,
                            imageUrl: item.image,
                        },
                        data: {
                            productSku: item.productSku,
                            linkUrl: item.linkUrl,
                        }
                    })
                })

            })
        } else {
            console.log('There is no data!');
        }
    } catch (error) { console.log("error =======> ", error); }
}