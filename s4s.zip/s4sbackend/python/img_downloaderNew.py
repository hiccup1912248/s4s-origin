import urllib.parse
from pymongo import MongoClient, collation, mongo_client
import time
import requests
import datetime
import boto3
from io import BytesIO
from PIL import Image
from cairosvg import svg2png
import pillow_avif
import re
import math
import os, psutil
from common import get_mongoDb, getConfig
import logging


config = getConfig()

logging.basicConfig(filename =config['path']+'logs/img.log', level = logging.INFO)

s3 = boto3.resource('s3',
                    aws_access_key_id=config['AWS_ACCESS_KEY'],
                    aws_secret_access_key=config['AWS_SECRET_KEY'])
bucket = s3.Bucket(config['BUCKET'])

mainPath = '' #testing
#mainPath = '/home/sneaks4sure/www'
site = 'https://sneakers4sure.s3.amazonaws.com/'

novelshipPath = 'sneakers/SKU/OOTD/'
thumbImgPath = 'sneakers/SKU/Thumb/'
smallImgPath = 'sneakers/SKU/SmallImage/'
imgPath = 'sneakers/SKU/Image/'
ImgPath360 = 'sneakers/SKU/360/'
calendarShopLogoPath = 'sneakers/Calendar/ShopLogo/'
trustPilotPath = 'sneakers/TrustPilot/'

savingPath = mainPath + novelshipPath
savingPathThumbImg = mainPath + thumbImgPath
savingPathSmallImg = mainPath + smallImgPath
savingPathImg = mainPath + imgPath
savingPath360Img = mainPath + ImgPath360
savingPathCalendarShopLogo = mainPath + calendarShopLogoPath
savingPathTrustPilot = mainPath + trustPilotPath

def memoryUsage():
  #process = psutil.Process(os.getpid())
  return ""#(process.memory_info().rss)/1024 ** 2

def getValue(regexVal, strVal, allR = "no"): 
  href = re.findall(regexVal, strVal, re.MULTILINE | re.IGNORECASE | re.DOTALL)
  if len(href) == 0:
    return None
  else:
    if allR == "yes":
      return href
    else:  
      return href[0]
    
def novelShipImgDownloader(obj):
  newObj = {}
  productName = " "
  if 'product_name' in obj:
    productName = obj['product_name']
    sku = obj['product_sku_id']
  try:
    if 'product_novelship_image_raw' in obj and len(obj['product_novelship_image_raw']) > 0:
      i = 1
      a = []
      b = []
      changeInObj = False
      if 'downloaded_product_novelship_image' in obj:
        b = obj['downloaded_product_novelship_image'].copy()
        #a = obj['product_novelship_image']
      for x in obj['product_novelship_image_raw']:
        if ('downloaded_product_novelship_image' in obj and x['img_url'] not in obj['downloaded_product_novelship_image']) or 'downloaded_product_novelship_image' not in obj:
          imgNameDB = imgDownloaderFunction(x['img_url'], productName, sku+'-'+str(i).zfill(2), 'product_novelship_image', savingPath)
          b.append(x['img_url'])
          if imgNameDB == "NoImage.png":
            continue
          a.append(site + novelshipPath + imgNameDB)
          i+=1
          changeInObj = True
          
      if a != [] and changeInObj == True:
        newObj['product_novelship_image'] = list(set(a))
        newObj['product_novelship_image'] = [{"img_url":x} for x in newObj['product_novelship_image']]
        newObj['downloaded_product_novelship_image'] = list(set(b))
      elif 'downloaded_product_novelship_image' in obj and b != obj['downloaded_product_novelship_image']:
        newObj['downloaded_product_novelship_image'] = list(set(b))
      elif 'downloaded_product_novelship_image' not in obj:
        newObj['downloaded_product_novelship_image'] = b
    
    if newObj != {}:
      #print(newObj)
      collection.update_one({'product_sku_id':sku},{'$set':newObj})
      #print(datetime.datetime.now(), " - Updated NovelShip--- ", sku)
      logging.info("{} -- Updated NovelShip -- {}".format(datetime.datetime.now(), sku))

  except Exception as ex:
    #print("novelShipImgDownloader -- exception -", obj, ex, ", datetime:", datetime.datetime.now())
    logging.exception("novelShipImgDownloader -- exception:{}, datetime:{}, obj:{}".format(ex, datetime.datetime.now(), obj))

def designAPI(imgBites, imgName, small=False):
  url = "https://api.designify.com/v1.0/designify/92f67229-e6df-449d-80f6-be524a0b92c3"

  payload={}
  files=[
    ('',('a.jpeg',imgBites,'image/jpeg'))
  ]
  headers = {
    'X-API-Key': '4a2ce54493b2cf44c3372ae39f719617'
  }
  logging.info("designifyAPI called:{}, datetime:{}".format(imgName, datetime.datetime.now()))
  response = requests.request("POST", url, headers=headers, data=payload, files=files)
  if response.status_code not in ['200',200]:
    logging.info(response.text)
    logging.info('.................DESIGN API ERR........................ datetime:{}'.format(datetime.datetime.now()))
    #print('.................DESIGN API ERR........................ datetime:{}'.format(datetime.datetime.now()))
  img = response.content
  global exceptionImg
  exceptionImg = img
  if small:
    img = imgResize(img)
    
  uploadFile(BytesIO(img), imgName)
  '''
  with open (imgName, 'wb') as f:
    f.write(img)
  '''
    
def skus(heats=False, recent=False, past=False, upcoming=False, top=False):
  heatsArr = []
  recentsArr = []
  pastArr = []
  upcomingArr = []
  topArr = []
  def apiSKUS(apiUrl, key):
    arr = []
    api = None
    i = 0
    
    while i <= 5:
      i = i + 1
      r = requests.get('https://api.sneaks4sure.com/'+apiUrl+'?custom=Eel1cJx2nttp9Vw2nqcu43')
      if r.status_code == 200:
        api = r.json()
        break
      else:
        print("api_response:", r)  
        
    
    if api != None:
      if 'code' in api and api['code'] == 200 and key in api['data']:
        if type(api['data'][key]) == dict:
          for a in api['data'][key].keys():
            for item in api['data'][key][a]:
              arr.append(item['ProductSKU'])
        
        else:
          for a in api['data'][key]:
            arr.append(a['ProductSKU'])
    return arr

  if heats:
    heatsArr = apiSKUS('heats', 'heats')
  if recent:
    recentsArr = apiSKUS('recent', 'recentlyDropped')
  if past:
    pastArr = apiSKUS('past', 'pastProducts')
  if upcoming:
    upcomingArr = apiSKUS('upcoming', 'upcomings')
  if top:
    topArr = apiSKUS('top', 'topClicked')
    
  return list(set(heatsArr + recentsArr + pastArr + upcomingArr + topArr))
  

  
def get_imgFormat(r):
  imgFormat = '.jpeg'
  if 'Content-Type' in r.headers and 'image' in r.headers['Content-Type']:
    content = r.headers['Content-Type']
    if 'svg' in content:
      content = content.replace('+xml', '')  
    imgFormat = content.replace('image/', '.')
  return imgFormat
  
def avifToJpeg(r):
  img = Image.open(BytesIO(r.content))
  temp = BytesIO()
  img.save(temp, format="png")
  return temp.getvalue()
      
def imgDownloaderFunction(url, productName, sku, key, savingPathExc, obj = False):
  if url == 'https://sneaks4sure.com/NoImage.png' and ((sku in apiArr and key == 'product_thumbUrl') or (sku in upAndPast and key == 'product_smallimageUrl')):
    return None, None, 'NoImage.png'
  elif url == 'https://sneaks4sure.com/NoImage.png':
    return 'NoImage.png'
  elif url in ['', None, 'null', ' ']:
    return 'NoImage.png'
    
  #cleanUrl = getValue('.*?stockx.*?\.jpg|.*?stockx.*?\.png', url)
  #if cleanUrl != None:
  #  url = cleanUrl
  
  for ran in range(10):
    try:
      logging.info('Downloading from:{}, datetime:{}, memUsage:{}, TRY NO:{}'.format(url, datetime.datetime.now(), memoryUsage(), ran+1))
      r = requests.get(url, headers={'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'})
      if 'Press & Hold to confirm you are' in r.text:
        logging.info("detected as bot sleeping for 20 sec, datetime:{}".format(datetime.datetime.now()))
        time.sleep(20)
        continue
      elif '<html><body>404</body></html>' in r.text:
        logging.info("404 err on url:{}".format(url))
        return 'NoImage.png'
      img = r.content
      imgFormat = get_imgFormat(r)
      if imgFormat not in ['.jpeg', '.png']:
        if imgFormat == '.avif':
          img = avifToJpeg(r)
        if imgFormat == '.svg':
          img = svgImgConvertor(r)
      imgFormat = '.png'
      img1 = Image.open(BytesIO(img))
      img1.close()
      break
    except Exception as ex:
      #print("Exception in imgDownloading function:",ex, ",Sleeping for 10sec", ", datetime:", datetime.datetime.now())
      logging.exception("Exception in imgDownloading function:{}, Sleeping for 10sec, datetime:{}".format(ex, datetime.datetime.now()))
      time.sleep(10)
  
  
  global ogExceptionImg
  ogExceptionImg = img
  
  
  if '/' in productName:
    productName = productName.replace('/','')
  productNameUrl = urllib.parse.quote(productName)
    
  imgName = productName+'-'+sku+'-'+key+imgFormat
  imgNameUrl = urllib.parse.quote(imgName)
  
  if key == 'shop_logo' and obj == True:
    imgName =  productName + imgFormat
    imgNameUrl = productNameUrl + imgFormat
    
  downloadedImg = savingPathExc+imgName
  
  if key == 'product_thumbUrl' and sku in apiArr:
  #  designAPI(img, downloadedImg)   
    return imgName, img, imgNameUrl
    
  if key == 'product_smallimageUrl' and sku in upAndPast:
    return imgName, img, imgNameUrl
    
  uploadFile(BytesIO(img), downloadedImg)
  ''' 
  with open(downloadedImg, 'wb') as fd:
    fd.write(img)
  '''

  return imgNameUrl
  
def designFunction(url, productName, sku, key, path):
  cleanUrl = getValue('.*?stockx.*?\.jpg|.*?stockx.*?\.png', url)
  if cleanUrl != None:
    url = cleanUrl
  imgName, img, imgNameUrl = imgDownloaderFunction(url, productName, sku, key, path)
  if imgNameUrl == 'NoImage.png':
    return imgNameUrl
  imgName = imgName.replace('.jpeg', '.png')
  #print("sku:" ,sku, ",designFunction by key:", key, ",on:", datetime.datetime.now(), " ,url:",url)
  logging.info("sku:{}, designFunction by key:{}, on:{}, url:".format(sku, key, datetime.datetime.now(), url))
  designAPI(img, path + imgName, small=True)
  return imgNameUrl.replace('.jpeg', '.png')
  
def stockxImgDownloader(obj):
  newObj = {}
  try:
    productName = " "
    if 'product_name' in obj:
      productName = obj['product_name']
    sku = obj['product_sku_id']
    if 'product_imageUrl_raw' in obj and len(obj['product_imageUrl_raw']) > 0:
      b = []
      if 'downloaded_product_imageUrl' in obj:
        b = obj['downloaded_product_imageUrl']
      for x in obj['product_imageUrl_raw']:
        if ('downloaded_product_imageUrl' in obj and x['img_url'] not in obj['downloaded_product_imageUrl']) or 'downloaded_product_imageUrl' not in obj:
          imgNameDB = imgDownloaderFunction(x['img_url'], productName, sku, 'product_imageUrl', savingPathImg)
          b.append(x['img_url'])
          newObj['product_imageUrl'] = site + imgPath + imgNameDB
          if imgNameDB == 'NoImage.png':
            newObj['product_imageUrl'] = site + imgNameDB
          newObj['downloaded_product_imageUrl'] = b
      
    if 'product_smallimageUrl_raw' in obj and len(obj['product_smallimageUrl_raw']) > 0:
      b = []
      if 'downloaded_product_smallimageUrl' in obj:
        b = obj['downloaded_product_smallimageUrl']
      a = []
      if 'downloaded_smallimageDesignAPI' in obj:
        a = obj['downloaded_smallimageDesignAPI']
        
      for x in obj['product_smallimageUrl_raw']:
        if sku in upAndPast and (('downloaded_smallimageDesignAPI' in obj and x['img_url'] not in obj['downloaded_smallimageDesignAPI']) or 'downloaded_smallimageDesignAPI' not in obj):
          imgNameDB = designFunction(x['img_url'], productName, sku, 'product_smallimageUrl', savingPathSmallImg)
          a.append(x['img_url'])
          if x['img_url'] not in b:
            b.append(x['img_url'])
          newObj['product_smallimageUrl'] = site + smallImgPath +imgNameDB
          if imgNameDB == 'NoImage.png':
            newObj['product_smallimageUrl'] = site + imgNameDB
          #if b != []:
          #  newObj['downloaded_product_smallimageUrl'] = b
          if a != []:
            newObj['downloaded_smallimageDesignAPI'] = a
            
        if ('downloaded_product_smallimageUrl' in obj and x['img_url'] not in obj['downloaded_product_smallimageUrl']) or 'downloaded_product_smallimageUrl' not in obj:
          imgNameDB = imgDownloaderFunction(x['img_url'], productName, sku, 'product_smallimageUrl_clean', savingPathSmallImg)
          b.append(x['img_url'])
          newObj['product_smallimageUrl_clean'] = site + smallImgPath + imgNameDB
          if imgNameDB == 'NoImage.png':
            newObj['product_smallimageUrl'] = site + imgNameDB
          newObj['downloaded_product_smallimageUrl'] = b
      
    if 'product_thumbUrl_raw' in obj and len(obj['product_thumbUrl_raw']) > 0:
      b = []
      if 'downloaded_product_thumbUrl' in obj:
        b = obj['downloaded_product_thumbUrl']
      a = []
      if 'downloaded_thumbDesignAPI' in obj:
        a = obj['downloaded_thumbDesignAPI']
        
      for x in obj['product_thumbUrl_raw']:
        if sku in apiArr and (('downloaded_thumbDesignAPI' in obj and x['img_url'] not in obj['downloaded_thumbDesignAPI']) or 'downloaded_thumbDesignAPI' not in obj):
          imgNameDB = designFunction(x['img_url'], productName, sku, 'product_thumbUrl', savingPathThumbImg)
          a.append(x['img_url'])
          if x['img_url'] not in b:
            b.append(x['img_url'])
          newObj['product_thumbUrl'] = site + thumbImgPath + imgNameDB
          if imgNameDB == 'NoImage.png':
            newObj['product_thumbUrl'] = site + imgNameDB
          if b != []:
            newObj['downloaded_product_thumbUrl'] = b
          if a !=[]:
            newObj['downloaded_thumbDesignAPI'] = a
        
        elif ('downloaded_product_thumbUrl' in obj and x['img_url'] not in obj['downloaded_product_thumbUrl']) or 'downloaded_product_thumbUrl' not in obj:
          imgNameDB = imgDownloaderFunction(x['img_url'], productName, sku, 'product_thumbUrl', savingPathThumbImg)
          b.append(x['img_url'])
          newObj['product_thumbUrl'] = site + thumbImgPath + imgNameDB
          if imgNameDB == 'NoImage.png':
            newObj['product_thumbUrl'] = site + imgNameDB
          if 'downloaded_thumbDesignAPI' in obj:
            collection.update_one({'product_sku_id':sku}, {'$unset':{'downloaded_thumbDesignAPI':1}})
          newObj['downloaded_product_thumbUrl'] = b

    if 'product_image_360_raw' in obj and len(obj['product_image_360_raw']) > 0:
      i = 1
      a = []
      b = []
      changeInObj = False
      if 'downloaded_product_image_360' in obj:
        b = obj['downloaded_product_image_360'].copy()
        #a = obj['product_image_360']
      for x in obj['product_image_360_raw']:
        if ('downloaded_product_image_360' in obj and x['img_url'] not in obj['downloaded_product_image_360']) or 'downloaded_product_image_360' not in obj:
          imgNameDB = imgDownloaderFunction(x['img_url'], productName, sku+'-'+str(i).zfill(2), 'product_image_360', savingPath360Img)
          b.append(x['img_url'])
          if imgNameDB == "NoImage.png":
            continue
          a.append(site + ImgPath360 + imgNameDB)
          i+=1
          changeInObj = True
      if a != [] and changeInObj == True:
        newObj['product_image_360'] = list(set(a))
        newObj['downloaded_product_image_360'] = list(set(b))
      elif b != obj['downloaded_product_image_360']:
        newObj['downloaded_product_image_360'] = list(set(b))
        
    if newObj != {}:
      #print(newObj)
      collection.update_one({'product_sku_id':sku},{'$set':newObj})
      logging.info("{} --- Updated --- {}".format(datetime.datetime.now(), sku))
  except Exception as ex:
    #print("Exception happened in stockxImgDownloader:",ex,"with Object",obj, ", datetime:", datetime.datetime.now())
    logging.exception("Exception happened in stockxImgDownloader:{}, with Object:{}, datetime:{}".format(ex, obj, datetime.datetime.now()))
    try:
      with open('images/'+obj['product_sku_id']+' design', 'wb') as f:
        f.write(exceptionImg)
      with open('images/'+obj['product_sku_id']+' OG', 'wb') as f:
        f.write(ogExceptionImg)
    except Exception as ex:
      logging.exception("exception in exception:{}, datetime:{}".format(ex, datetime.datetime.now()))

def calenderShopLogo(obj):
  changeinObj = False
  try:
    sku = obj['product_sku_id']
    b = []
    if 'downloaded_logos' in obj:
      b = obj['downloaded_logos']
    if 'shops_raffles' in obj:
      for shops in obj['shops_raffles']:
        for x in b:
          if x['raw'] == shops['shop_logo']:
            shops['shop_logo'] = x['downloaded']
            shops['shop_logo_downloaded'] = 1
            changeinObj = True
            continue
        if 'shop_logo_downloaded' not in shops:
          imgNameDB = imgDownloaderFunction(shops['shop_logo'], shops['shop_name'], sku, 'shop_logo', savingPathCalendarShopLogo, True)
          shopLogoObj = {'raw':shops['shop_logo'], 'downloaded':site + calendarShopLogoPath + imgNameDB}
          shops['shop_logo'] = site + calendarShopLogoPath + imgNameDB
          shops['shop_logo_downloaded'] = 1
          b.append(shopLogoObj)
          changeinObj = True
        
    if 'shops_retail' in obj:
      for shops in obj['shops_retail']:
        for x in b:
          if x['raw'] == shops['shop_logo']:
            shops['shop_logo'] = x['downloaded']
            shops['shop_logo_downloaded'] = 1
            changeinObj = True
            continue
        if 'shop_logo_downloaded' not in shops:
          imgNameDB = imgDownloaderFunction(shops['shop_logo'], shops['shop_name'], sku, 'shop_logo', savingPathCalendarShopLogo, True)
          shopLogoObj = {'raw':shops['shop_logo'], 'downloaded':site + calendarShopLogoPath + imgNameDB}
          shops['shop_logo'] = site + calendarShopLogoPath + imgNameDB
          shops['shop_logo_downloaded'] = 1
          b.append(shopLogoObj)
          changeinObj = True
          
    if changeinObj == True:
      obj['downloaded_logos'] = b
      
      #print(obj)
      logging.info("{} --- Updated --- {}".format(datetime.datetime.now(), sku))
      collectionCalendar.update_one({'product_sku_id':sku},{'$set':obj})
  except Exception as ex:
    #print("Exception happened in calenderShopLogo:",ex,"with Object",obj, ", datetime:", datetime.datetime.now())
    logging.exception("Exception happened in calenderShopLogo:{}, with Object:{}, datetime:{}".format(ex, obj, datetime.datetime.now()))
    
def uploadFile(fro, to):
  bucket.upload_fileobj(fro, to, ExtraArgs={'ACL':'public-read'})
    
def trustPilotDownloader(obj):
  try:
    b = []
    if 'downloaded_shop_logo' in obj:
      b = obj['downloaded_shop_logo']
    if 'downloaded_shop_logo' in obj and 'shop_logo_raw' in obj and obj['shop_logo_raw'] in obj['downloaded_shop_logo']:
      return None
    if 'shop_logo_raw' in obj:
      imgNameDB = imgDownloaderFunction(obj['shop_logo_raw'], obj['shop_name'], '', 'shop_logo', savingPathTrustPilot, True)
      obj['shop_logo'] = site + trustPilotPath + imgNameDB
      b.append(obj['shop_logo_raw'])
      obj['downloaded_shop_logo'] = b
      #print(obj)
      logging.info("{} --- Updated --- {}".format(datetime.datetime.now(), obj['shop_name']))
      collectionTrustPilot.update_one({'shop_name':obj['shop_name']},{'$set':obj})
  except Exception as ex:
    #print("Exception happened in trustPilotDownloader:",ex,"with Object",obj, ", datetime:", datetime.datetime.now())
    logging.exception("Exception happened in trustPilotDownloader:{}, with Object:{}, datetime:{}".format(ex, obj, datetime.datetime.now()))
    
def imgResize(img):
  logging.info('imgResizeLine1')
  foo = Image.open(BytesIO(img))
  logging.info('imgResizeLine2')
  foo = foo.resize((200,160),Image.Resampling.LANCZOS)
  logging.info('imgResizeLine3')
  temp = BytesIO()
  logging.info('imgResizeLine4')
  foo.save(temp, format="png")
  logging.info('imgResizeLine5')
  return temp.getvalue()
  
def svgImgConvertor(r):
  img = r.text
  tempPng = BytesIO()
  svg2png(bytestring=img,write_to=tempPng)
  return tempPng.getvalue()

def duplicateSkuRemove(collection):
  sku = []
  for x in collection.find({}, {'product_sku_id':1}):
    if x.get('product_sku_id') not in sku:
      sku.append(x.get('product_sku_id'))
      continue
    duplicate = [x for x in collection.find({'product_sku_id':x.get('product_sku_id')})]
    if len(duplicate[0]) > len(duplicate[1]):
      query = x
    else:
      query = x
    collection.delete_one(query)
    logging.info("duplicate SKU deleted:{}".format(query))

if __name__ == "__main__":
  try:
    while True:
      memoryUsage()
      apiArr = skus(heats=True, recent=True, top=True)
      
      upAndPast = skus(past=True, upcoming=True)
      db = get_mongoDb()
      collection = db.SKU
      collectionCalendar = db.Calendar
      collectionTrustPilot = db.TrustPilot
      #heatsSkus = skus(heats=True, recent=False)

      #duplicateSkuRemove
      duplicateSkuRemove(collection)

      #trustPilot
      cursor = collectionTrustPilot.find(no_cursor_timeout=True)
      cursor_list = [x for x in cursor]
      logging.info("{}------------------TrustPilot query completed------------------, memUsage:{}".format(datetime.datetime.now(), memoryUsage()))
      for x in cursor_list:
        trustPilotDownloader(x)
      logging.info("{}------------------TrustPilot Downloader completed------------------, memUsage:{}".format(datetime.datetime.now(), memoryUsage()))
      
      #calendarShopLogo
      cursor = collectionCalendar.find(no_cursor_timeout=True)
      cursor_list = [x for x in cursor]
      logging.info("{}------------------Calendar query completed------------------, memUsage:{}".format(datetime.datetime.now(), memoryUsage()))
      for x in cursor_list:
        calenderShopLogo(x)
      logging.info("{}------------------Calendar Downloader completed------------------, memUsage:{}".format(datetime.datetime.now(), memoryUsage()))

      #stockxAndNovelShip
      count = collection.count_documents({})
      for itr in range(math.ceil(count/100)):
        logging.info("mem before query:{}".format(memoryUsage()))
        skip = ((itr+1)*100)-100
        cursor = collection.find({},{
                                      'product_sku_id':'$product_sku_id', 
                                      'product_name':'$product_name', 
                                      'product_imageUrl_raw':'$product_imageUrl_raw',
                                      'product_image_360_raw':'$product_image_360_raw',
                                      'product_smallimageUrl_raw':'$product_smallimageUrl_raw',
                                      'product_thumbUrl_raw':'$product_thumbUrl_raw',
                                      'downloaded_product_imageUrl':'$downloaded_product_imageUrl',
                                      'downloaded_product_image_360':'$downloaded_product_image_360',
                                      'downloaded_product_thumbUrl':'$downloaded_product_thumbUrl',
                                      'downloaded_product_smallimageUrl':'$downloaded_product_smallimageUrl',
                                      'downloaded_smallimageDesignAPI':'$downloaded_smallimageDesignAPI',
                                      'downloaded_thumbDesignAPI':'$downloaded_thumbDesignAPI',
                                      #'product_image_360':'$product_image_360',
                                      'product_novelship_image_raw':'$product_novelship_image_raw',
                                      'downloaded_product_novelship_image':'$downloaded_product_novelship_image'
                                     }).skip(skip).limit(100).sort('product_sku_id')
          

        cursor_list = [x for x in cursor]
        logging.info("{}------------------SKU query completed------------------skip:{}, limit:100, no of skus to run:{}, memUsage after query:{}".format(datetime.datetime.now(), skip, len(cursor_list), memoryUsage()))
        for x in cursor_list:
          novelShipImgDownloader(x)
          stockxImgDownloader(x)

      logging.info("{}------------------SKU Downloader completed------------------, memUsage:{}".format(datetime.datetime.now(), memoryUsage()))
      
      logging.info("{}----SLEEP FOR NEXT 5 Minutes----, memUsage:{}".format(datetime.datetime.now(), memoryUsage()))
      time.sleep(300)
  except Exception as ex:
    logging.exception("script Exited at:{}, Exception:{}".format(datetime.datetime.now(), ex))

  logging.info("while exited:{}".format(datetime.datetime.now()))
  
  
  
  
