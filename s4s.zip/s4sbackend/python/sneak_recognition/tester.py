import os
import logging
logging.disable(logging.WARNING)
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

from warnings import filterwarnings
filterwarnings("ignore")

import sys 
import json
import requests
import numpy as np
import torch
from PIL import Image
from torch.utils.tensorboard import SummaryWriter
from torchvision import transforms, utils
from collections import defaultdict
import service
from config import *
from data_transform import *
from model import *
from resnet import *

sys.path.append(p_path)
from common import get_mongoDb

activation = {}

def get_activation(name):
	def hook(model, input, output):
		activation[name] = output.detach()
	return hook


tensorboard = SummaryWriter('runs/sneaker_net');
net = Net(); 
net.load_state_dict(torch.load(MODEL_SAVE_PATH));
net.conv_layers[0].register_forward_hook(get_activation('conv'))

batch_size = 4
conv_count = 4
trainset = []
predicted = []
sneakers = []
predict = []

def load_requests(cmd, TEST_DIR):
    url  = cmd
    filename = url.split('/')[-1].replace("%","-").replace("20","")    
    r = requests.get(url, stream=True)
    if r.status_code == 200:
        with open(TEST_DIR +"/"+filename, 'wb') as f:
            for chunk in r:
                f.write(chunk)
    return filename                

def imagerecoginition(filename):
  trainset.append(image_tranform_to_tensor(os.path.join(TEST_DIR, filename)))
  dataloader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, num_workers=0, shuffle=False)
  dataiter = iter(dataloader)
  data_batch = next(dataiter)
  outputs = net(data_batch)
  values, labels = torch.max(outputs, 1)

  Modelname = ""
  if len(labels) > 0:
    db = get_mongoDb()
    collection = db.SKU
    cursorObj = collection.find({'recogId':int(labels[0])}, {"product_sku_id":1})
    for one in cursorObj:
      Modelname = one['product_sku_id']
    
  success = {"status":"success", "prediction":{"skuId" : Modelname}}
  print(json.dumps(success))

if len(sys.argv) < 2:
  print('{"status":"error","reason":"URL not found"}')
else:  
  filename = load_requests(sys.argv[1], TEST_DIR)
  imagerecoginition(filename)


