import requests
import sys
import time
import json
from config import *
from bs4 import BeautifulSoup

sys.path.append(p_path)
import common

start_time = time.time()

def googleimage_search(cmd):
  url = f"https://www.google.com/search?q={cmd}"+"+"+"stockx""&amp;tbm=isch"
  response = requests.get(url)
  soup = BeautifulSoup(response.text, "html.parser")
  product_details = soup.find('div', {"class":"egMi0 kCrYT"})
  if product_details is not None:
    stockxUrl = common.getValue(r'q=(.*?)&amp;', str(product_details)) 
    if stockxUrl is not None:
      cur = collection.find({"stockx_original_url":stockxUrl}, {'product_sku_id':1})
      for sku in cur:
         success = {"status":"success", "prediction":{"skuId" : sku['product_sku_id']}}
         print(json.dumps(success))  

db = common.get_mongoDb()
collection = db.SKU

if len(sys.argv) < 2:
  print('{"status":"error","reason":"URL not found"}')
else:
  googleimage_search(sys.argv[1])

print("--- %s seconds ---" % (time.time() - start_time))    
