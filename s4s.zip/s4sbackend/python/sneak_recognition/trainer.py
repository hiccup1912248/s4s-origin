from torch.utils.tensorboard import SummaryWriter
import sys 
from config import *
from dataset import *
from model import *
from resnet import *

sys.path.append(p_path)
from common import get_mongoDb


db = get_mongoDb()
collection = db.SKU

class Trainer:
	tensorboard = SummaryWriter('runs/sneaker_net');
	def __init__(self):
		super().__init__();

	def plug_net(self, net):
		self.net = net;

	def plug_data_set(self, data_set, batch_size=4, shuffle=True):
		self.data_set = data_set;
		self.batch_size = batch_size
		self.data_loader = torch.utils.data.DataLoader(data_set, batch_size=batch_size, num_workers=0, shuffle=shuffle);

	def train(self, epochs=10, use_gpu=False):
		if use_gpu: self.net.cuda();

		criterion = nn.CrossEntropyLoss()
		optimizer = optim.Adam(self.net.parameters(), lr=1e-3)
		
		sub_epoch = 0;
		for epoch in range(epochs):

			running_loss = 0.0;
			total_loss = 0.0;
			running_correct = 0.0;
			total_correct = 0.0;

			train_list = enumerate(self.data_loader, 0);

			log_batch_size = 100;
			log_batch_index = 0;
			progress = ProgressBar(total=log_batch_size, prefix='Training', suffix='Now', decimals=3, length=50, fill='\u2588', zfill='-')

			for i, data in train_list:
				progress.print_progress_bar(i - log_batch_index * log_batch_size + 1);

				inputs, labels = data;
				if use_gpu:
					inputs = inputs.cuda();
					labels = labels.cuda();

				#zero the parameter gradients
				optimizer.zero_grad()
				
				#forward + backward + optimize
				outputs = self.net(inputs);
        
				print("outputs, labels---", outputs, labels)
				loss = criterion(outputs, labels);
				loss.backward();
				optimizer.step();

				#statistics
				running_loss += loss.item();
				running_correct += self.__get_correct_total(outputs, labels);
				total_loss += loss.item();
				total_correct += self.__get_correct_total(outputs, labels);

				if i % log_batch_size == log_batch_size - 1:
					processed_count = self.batch_size * log_batch_size;
					print('[%d, %5d] loss: %.3f correct: %5d' %(epoch + 1, i + 1, running_loss / log_batch_size, running_correct))
					self.tensorboard.add_scalar("Loss", running_loss, sub_epoch);
					self.tensorboard.add_scalar("Correct", running_correct, sub_epoch);
					self.tensorboard.add_scalar("Accuracy", running_correct / processed_count, sub_epoch);
					running_loss = 0.0;
					running_correct = 0.0;
					log_batch_index += 1;
					sub_epoch += 1;

		self.tensorboard.close();
		print('\nFinished Training');

	def load_model(self, path):
		self.net.load_state_dict(torch.load(path))

	def save_model(self, path):
		torch.save(self.net.state_dict(), path);

	def __get_correct_total(self, preds, labels):
		return preds.argmax(dim=1).eq(labels).sum().item()

MODELS = []
imgUrl = []

cursor = collection.find({'recogId':{'$gte':0} }, {'product_sku_id':1, 'product_image_360':1, 'product_imageUrl':1, 'recogId':1}, limit=LIMIT)

for item in cursor:
   MODELS.append(item['product_sku_id'])
   if 'product_imageUrl' in item:
      out = {"actual":item['product_imageUrl']}
      if 'product_image_360' in item:
        out['product_image_360'] = item['product_image_360']
      imgUrl.append([out])
   else:
      imgUrl.append([{"actual":"https://m.media-amazon.com/images/I/41HbWgKCEeL.jpg"}])   

print("All MODELS count: ", len(MODELS))

trainer = Trainer();

net = Net();
#resnet = resnet101(3, len(MODELS));

print("Reading folder: ", os.path.join(ORIG_IMG_DIR))
train_set = SneakersDataset(os.path.join(ORIG_IMG_DIR), MODELS, imgUrl=imgUrl);
print("---Trainset done")

trainer.plug_net(net);
trainer.plug_data_set(train_set);

#trainer.load_model(MODEL_SAVE_PATH);

print("\nInit training protocol:\n")
trainer.train(20, use_gpu=False);

trainer.save_model(MODEL_SAVE_PATH);


print("Done")
