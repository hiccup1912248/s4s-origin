import requests
import datetime
from PIL import Image
import time
from io import BytesIO

def imgDownload(url):
  for ran in range(2):
    try:
      print('Downloading from:{}, datetime:{}, memUsage:{}, TRY NO:{}'.format(url, datetime.datetime.now(), "", ran+1))
      r = requests.get(url, headers={'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'})
      if 'Press & Hold to confirm you are' in r.text:
        print("detected as bot sleeping for 20 sec, datetime:{}".format(datetime.datetime.now()))
        time.sleep(20)
        continue
      elif '<html><body>404</body></html>' in r.text:
        print("404 err on url:{}".format(url))
        return 'NoImage.png'
      img = r.content
      imgFormat = get_imgFormat(r)
      if imgFormat not in ['.jpeg', '.png']:
        if imgFormat == '.avif':
          img = avifToJpeg(r)
        if imgFormat == '.svg':
          img = svgImgConvertor(r)
      imgFormat = '.png'
      img1 = Image.open(BytesIO(img))
      #img1.close()
      return img1 
    except Exception as ex:
      print("Exception in imgDownloading function:{}, Sleeping for 10sec, datetime:{}".format(ex, datetime.datetime.now()))
      time.sleep(10)
  return gimg
      
def get_imgFormat(r):
  imgFormat = '.jpeg'
  if 'Content-Type' in r.headers and 'image' in r.headers['Content-Type']:
    content = r.headers['Content-Type']
    if 'svg' in content:
      content = content.replace('+xml', '')  
    imgFormat = content.replace('image/', '.')
  return imgFormat
  
def avifToJpeg(r):
  img = Image.open(BytesIO(r.content))
  temp = BytesIO()
  img.save(temp, format="png")
  return temp.getvalue()
  
def svgImgConvertor(r):
  img = r.text
  tempPng = BytesIO()
  svg2png(bytestring=img,write_to=tempPng)
  return tempPng.getvalue()
  
  
#gimg = imgDownload('https://m.media-amazon.com/images/I/41HbWgKCEeL.jpg')
