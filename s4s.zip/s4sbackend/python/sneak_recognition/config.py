MAIN_PATH = "/home/ubuntu/MobileAPIs/"
#MAIN_PATH = "/var/www/html/old_fl_20221021/alexandre/mobileAPis/"

LIMIT = 6
#Sneaker model categories
MODELS = ["Air Max", "Air Force", "React", "Air Jordan", "Vans", "New Balance", "adidas", "Balenciaga","BAPE","Birkenstock", "Chanel", "Christian Louboutin", "Clarks", "Converse", "Crocs", "Dior", "Dr Martens", "Dunk", "Foamposite", "Gucci", "KD", "Kobe", "Lebron", "LeBron","Louis Vuitton", "Luxury Brands", "Nike", "Nike Apparel", "Nike Basketball", "Nike Dunk", "Nike Other", "Nike Running", "Nike SB", "Nike Training", "Othe Brands","Other", "Other Brands", "Puma", "Reebok", "Timberland", "UGG", "Ultra Boost", "Versace", "Yeezy"];
#MODELS = [{"id":1, "skuId":"Nike"}, {"id":2, "skuId":"Bata"}, {"id":3, "skuId":"LeBron"}, {"id":5, "skuId":"Sparx"} ] #testing
MODELS = ["Nike", "Bata", "LeBron", "Sparx", "Paragon" ] #testing
#MODELS = ["Nike"] #testing
#MODELS = ["", "", "", "Sparx" ] #testing
#Dataset images directory path

IMG_DIR = MAIN_PATH+"python/sneak_recognition/img/"
#Originals images directory path
ORIG_IMG_DIR = MAIN_PATH+"python/sneak_recognition/test/"
#Model to save directory path
MODEL_SAVE_PATH = MAIN_PATH+"python/sneak_recognition/sneaker_net.pth"
#Test images directory path
TEST_DIR = MAIN_PATH+"python/sneak_recognition/img";
#path for parent directory
p_path = MAIN_PATH+"python"

AWS_KEY_ID = "AKIAS34YGA4GEG2WDU6O"
AWS_ACCESS_KEY = "3ERb15c9BW/sZfZ6a00i/qvo9XIqCsUUrQo9UL3/"
AWS_BUCKET = 'sneakers4sure'
