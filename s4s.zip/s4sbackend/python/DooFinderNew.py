import xml.etree.ElementTree as ET
import re
import time
from pymongo import MongoClient, collation, mongo_client
import urllib.parse
from datetime import datetime
import requests
import json
import urllib.parse
import boto3
from io import BytesIO
import random
import os
import math
from common import get_mongoDb


#path = '/root/mobileAPis/S4S/xml/'
#path = '/home/jewel/Downloads/' #testing
#path = '/home/anandhu/Downloads/'#testing

s3 = boto3.resource('s3',
                    aws_access_key_id='AKIAS34YGA4GEG2WDU6O',
                    aws_secret_access_key='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')
bucket = s3.Bucket('sneakers4sure')

def uploadFile(fro, to):
  bucket.upload_fileobj(fro, to, ExtraArgs={'ACL':'public-read'})
  
def get_shortnered_link(url, is_calendar=False):
  key = '61ba57c7111dbd56717f9bcbaab894b6b0441'
  url_quoted = urllib.parse.quote(url)
  is_calendar = False  # http://cutt.ly   linit issue -----------
  userDomain = '1' if is_calendar else '0'
  try:
    while True:
      if proxies != None:
        proxyObj = {"all://": 'http://'+random.choice(proxies)}
        print("Using proxy:",proxyObj)
      else:
        proxyObj = {}
      r = requests.get('http://cutt.ly/api/api.php?key={}&short={}&userDomain={}'.format(key, url_quoted, userDomain), proxies=proxyObj)
      if r.status_code != 429:
          break
      time.sleep(30)
    res = json.loads(r.text)
    shortLink = res['url']['shortLink']
  except Exception as ex:
    print(ex)
    shortLink = url
  return shortLink
  
def smallLink(obj):
  if 'small_thumbUrl' in obj:
    data = obj['small_thumbUrl']
    if obj['product_thumbUrl'] == data['long']:
      return data['small']
  newObj = {'long':obj['product_thumbUrl'], 'small':get_shortnered_link(obj['product_thumbUrl'])}
  collection.update_one({'product_sku_id':obj['product_sku_id']}, {'$set':{'small_thumbUrl':newObj}})
  return newObj['small']
  
def getGender(name):
  name = name.upper()
  a = re.findall(r'TD\b|PS|INFANTS|TODDLER|PRESCHOOL|KIDS', name)
  b = re.findall(r'GS|W\b', name)
  if a != []:
    gender = 'KIDS'
  elif b != []:
    gender = 'WOMEN'
  else:
    gender = 'MEN'
  return gender
  
def productSlug(product_name, sku):
  product_slug = 'https://www.sneaks4sure.com/product/' + product_name.replace(' ','_').replace('_','-') + sku.replace(' ','_').replace('_','-')
  return product_slug
  
  
def fillItems(element, subElement, key, obj, convert=False):
  var = ET.SubElement(element, subElement)
  if key in obj:
    if convert == float:
      obj[key] = float(obj[key])
      #print(obj[key], obj['product_sku_id'])
    if type(obj[key]) != 'str':
      obj[key] = str(obj[key])
    var.text = obj[key]
    
def itemThreds(element, product):
  try:
    item = ET.SubElement(element, 'item')
    
    fillItems(item, 'title', 'product_name', product)
    
    link = ET.SubElement(item, 'link')
    if 'product_name' in product and 'product_sku_id' in product:
      link.text = ''#productSlug(product['product_name'],product['product_sku_id'])
      
    #if 'description' in product:
    ET.SubElement(item, 'description').text = ''
    
    fillItems(item, 'product_change_value', 'product_change_value', product)
    fillItems(item, 'shopfoundsearch', 'shops_number', product)
    fillItems(item, 'product_change_arrow', 'product_change_arrow', product)
    #fillItems(item, 'product_release_date', 'product_release_date', product)
    fillItems(item, 'product_subcategory', 'product_subCategory', product)
    fillItems(item, 'product_rank', 'product_hit_number' ,product, convert=float)
    fillItems(item, 'UnderRetail', 'UnderRetail', product)
    fillItems(item, 'collectionName', 'collectionName', product)
    #if '' in product:
    ET.SubElement(item, 'product_count').text = ''
    
    date = ''
    if 'product_release_date' in product:
      dateRaw = re.findall(r'(\d\d\d\d-\d\d-\d\d)' ,product['product_release_date'])
      if len(dateRaw) > 0:
        date = dateRaw[0]
    ET.SubElement(item, 'product_release_date').text = date  
    
    if 'product_name' in product:
      ET.SubElement(item, 'gender').text = getGender(product['product_name'])
    
    fillItems(item, 'color', 'product_colorway', product)
    
    if 'product_lowest_price' in product:
      ET.SubElement(item, 'showprice').text = str(product['product_lowest_price'])+'€'
      
    
    fillItems(item, 'g:id', 'product_sku_id', product)
    fillItems(item, 'g:price', 'product_lowest_price', product)

    
    if 'product_thumbUrl' in product:
      product['product_thumbUrl'] = smallLink(product)
    fillItems(item, 'g:image_link', 'product_thumbUrl', product)
    
  except Exception as ex:
    print("Exception", product['product_sku_id'], ex)

def starting():
  try:
    data = ET.Element('rss')
    data.set('xmlns:g', 'http://base.google.com/ns/1.0')
    data.set('version', '2.0')
    channel = ET.SubElement(data, 'channel')
    title = ET.SubElement(channel, 'title')
    title.text = 'Sneaks4Sure - Online Store'
    link = ET.SubElement(channel, 'link')
    link.text = 'https://www.sneaks4sure.com/'
    description = ET.SubElement(channel, 'description')
    description.text = 'This is a feed containing the required and recommended attributes for a variety of different products'
    
    
    count = collection.count_documents({})
    for itr in range(math.ceil(count/100)):
      skip = ((itr+1)*100)-100
    
      cursor = collection.find({},{'product_hit_number':1,'product_name':1, 'small_thumbUrl':1, 'product_sku_id':1, 'product_change_value':1, 'shops_number':1, 'product_change_arrow':1, 'product_release_date':1, 'product_subCategory':1, 'product_colorway':1, 'product_lowest_price':1, 'product_thumbUrl':1,'UnderRetail':1, 'collectionName':1}).skip(skip).limit(100).sort('product_hit_number', -1)
      
      cursor_list = [x for x in cursor]
      print("------------------SKU query completed------------------skip:",skip,"limit:100", "no of skus to run:",len(cursor_list))
      for product in cursor_list:
        itemThreds(channel, product)

  except Exception as ex:
    print("Exception:",ex)

  return data

def getProxys():
  if os.path.exists('realProxy.txt'):
    print("Proxy found using Proxies")
    with open('realProxy.txt', 'r') as f:
      proxies = [x.strip() for x in f.readlines()]
    return proxies
  return None

if __name__ == "__main__":

  while 1:
    db = get_mongoDb()
    collection = db.SKU
    proxies = getProxys()

    b_xml = ET.tostring(starting())
    
    #with open('a.xml', 'wb') as f:
      #f.write(b_xml) #testing
    uploadFile(BytesIO(b_xml), "XML/DooFinder.xml")

    print("----Sleeping For 1 Hour----",datetime.now())
    time.sleep(3600)
