from pymongo import MongoClient, collation, mongo_client
import sys
import re
import math
from datetime import datetime
from common import get_mongoDb

def update_lowest_price(collection, obj):
  product_lowest_price = '-'
  price = []
  for x in obj.keys():
    if '_priceSize' in x and obj[x] != '-':
      if x.upper() not in shopList:
        continue

      for y in obj[x]:
        try:
          if len(y) == 2 and y[1] not in [0, '0']:
            c = re.findall(r'(\d+.\d+|\d+)',str(y[1]))
            if len(c) == 1:
              price.append(int(c[0].split('.')[0]))
        except:
          pass
  try:
    product_lowest_price = min(price)
    print("updated SKU:", obj['product_sku_id'])
    collection.update_one({'product_sku_id': obj['product_sku_id']}, {'$set':{"product_lowest_price":product_lowest_price}})
  except:
    pass


db = get_mongoDb()
collection = db.Sneakers
shop = db.Shops

cursor = shop.find({'status':1})
shopList = [('product_'+document['shop']+'_priceSize').upper() for document in cursor]
                
count = collection.count_documents({})
for itr in range(math.ceil(count/100)):
  skip = ((itr+1)*100)-100
  cursor = collection.find({}).skip(skip).limit(100).sort('product_sku_id')
  for item in cursor:
    try:
      update_lowest_price(collection,item) 
    except Exception as ex:
      print("Exception happend:",ex)
  print("------------------SKU query completed------------------skip:",skip,"limit:100",  datetime.now())

print("Script run succussfull", datetime.now())  
    
