import requests
import common


hashid = '30a5f46195133e966f269146a6805518'
header = {
  "Authorization" : "Token eu1-c59dadc5d822ca2b134fb8c7048274a7ec68e170"
}
indexPost = {"name": "product", "preset": "product", "options": { "exclude_out_of_stock_items": False }, "datasources": [ { "type": "file", "options": { "url": "https://sneakers4sure.s3.amazonaws.com/XML/DooFinder.xml" } }]}
#indexPost = {}

out = requests.post("https://eu1-api.doofinder.com/api/v2/search_engines/"+hashid+"/_process", headers=header, json=indexPost)
print(out.text)
