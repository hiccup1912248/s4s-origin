import os
import shutil
from datetime import datetime, timedelta
from dotenv import dotenv_values
from common import sftp_connection, getConfig, get_mongoDb, 
from pathlib import Path
import logging

config = getConfig()

logging.basicConfig(filename =config['path']+'logs/backup_upload.log', level = logging.INFO)

backupzip = datetime.today().strftime('%Y-%m-%d')
mongozip = "Mongo_"+datetime.today().strftime('%Y-%m-%d')
Cronzip = "Cron_"+datetime.today().strftime('%Y-%m-%d')
pm2 = "Pm2_"+datetime.today().strftime('%Y-%m-%d')


def sftp_upload(sf):   

  shutil.make_archive(config['path']+backupzip,'zip',config['path']+backupzip)
 
  local_path = config['path']+backupzip+".zip"
  remote_path = config['backupPath']+backupzip+".zip"

  sf.put(local_path, remote_path)
  os.remove(local_path)
  
  logging.info(f"----------file has been uploaded--------{datetime.now()}")
  sf.close()


def mongo_dump():
  
  data = "mongodump --uri='"+config['MONGODBURL']+"' --db sneaks4sure --authenticationDatabase=admin --gzip --archive > "+config['path']+backupzip+"/"+mongozip+".zip"
  os.system(data) 
  
  logging.info(f"------mongodump has been completed!---------{datetime.now()}")
     

def pm2_backup():  
  
  shutil.make_archive(config['path']+backupzip+"/"+pm2,'zip',config['pm2path'])
          
def cron_backup():
  
  shutil.make_archive(config['path']+backupzip+"/"+Cronzip,'zip',config['path']+"logs")
      
def scraplog_deletion(collection):
  
  command = "db.collection.deleteMany( { updatedIntoSneakers : {'$lt' : new Date(Date.now() - 30*24*60*60 * 1000) } })"
  os.system(command)
  
  logging.info(f"-----scraplog before 30days has been removed------{datetime.now()}") 
  
def removing_olderdata(sf): 

  for f in sf.listdir(config['backupPath']):
    fullpath = os.path.join(config['backupPath'],f)
    
    timestamp  = sf.stat(fullpath).st_mtime
    createtime = datetime.fromtimestamp(timestamp)
    
    now = datetime.now()
    delta = now - timedelta(10)   
    
    if createtime < delta:
      logging.info(f" Removing : {f}")
      sf.remove(fullpath)
      
                                                        
if __name__ == "__main__":
  try:
    backupfolder = os.path.join(config['path'],backupzip)

    os.mkdir(backupfolder)
    
    try:
      sf = sftp_connection() 
          
      db = get_mongoDb()
      
      collection = db.scrapLog
      
      mongo_dump()  
      
      pm2_backup()
     
      cron_backup()
      
      sftp_upload(sf)
      
      scraplog_deletion(collection) 
      
      removing_olderdata(sf)

    except Exception as ex:
      logging.info(f"Exception happend:{ex}, datetime:{datetime.now()}")
    
    shutil.rmtree(backupfolder)
  except Exception as ex:
    logging.info(f'END ERR:{ex}, datetime:{datetime.now()}')
