from pymongo import MongoClient, collation, mongo_client
import common 
import time
import urllib.parse
import re
import math


def get_mongoDb():
    try: 
        uri = "mongodb://sneaksuser:S*9KL2%40gg&665@35.181.159.181:27017"
        client = MongoClient(uri)
        print("Connected successfully!!!") 
    except:   
        print("Could not connect to MongoDB")
    db = client["sneaks4sure"]
    return db

def getValue(regexVal, strVal, allR = "no"): 
  href = re.findall(regexVal, strVal, re.MULTILINE | re.IGNORECASE | re.DOTALL)
  if len(href) == 0:
    return None
  else:
    if allR == "yes":
      return href
    else:  
      return href[0]

def priceSizeChecker(prizeSizeArr, shopKey,sku):
  change = False
  badSize = []
  for size in prizeSizeArr:
    if size != '-' and size[0] != None:
      try:
        float(size[0])
      except:
        sizeNew = getValue('\d+\.\d+|\d+', size[0])
        if sizeNew == None:
          badSize.append(size[0])
        else:
          change = True
          size[0] = sizeNew
      
  if badSize != []:
    print(sku,"Bad Sizes:---",shopKey,':',badSize)
  if change:
    print("updated SKU:"+sku+'--'+shopKey+':'+str(prizeSizeArr))
    collection.update_one({'product_sku_id':sku},{'$set':{shopKey:prizeSizeArr}})
    
def sizeFinder(obj):
  try:
    for shopKey in keys:
      if shopKey in obj:
        priceSizeChecker(obj[shopKey], shopKey,obj['product_sku_id']) 
  except Exception as ex:
    print(ex, obj['product_sku_id'])


if __name__ == "__main__":

  while 1:
    projection = {'product_sku_id':1}
    db = get_mongoDb()
    collection = db.Sneakers
    collectionShops = db.Shops
    keys = ['product_'+x['priceSize_key']+'_priceSize' for x in collectionShops.find({'status':1})]
    
    for x in keys:
      projection[x] = 1
      
    count = collection.count_documents({})
    for itr in range(math.ceil(count/100)):
      skip = ((itr+1)*100)-100
      for obj in collection.find({},projection).skip(skip).limit(100).sort('product_sku_id'):
        sizeFinder(obj)
      print("------------------SKU query completed------------------skip:",skip,"limit:100")
    print("---Sleeping for 20 min---")
    time.sleep(1200)
