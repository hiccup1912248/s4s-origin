#!/bin/bash
sleep 20 && python3 /home/ubuntu/MobileAPIs/python/badSize.py >> /home/ubuntu/MobileAPIs/python/logs/badSize.log &
sleep 20 && python3 /home/ubuntu/MobileAPIs/python/DooFinderNew.py >> /home/ubuntu/MobileAPIs/python/logs/DooFinder.log &
sleep 20 && python3 /home/ubuntu/MobileAPIs/python/img_downloaderNew.py >/dev/null &
sleep 20 && python3 /home/ubuntu/MobileAPIs/python/API_imgs.py >/dev/null &
