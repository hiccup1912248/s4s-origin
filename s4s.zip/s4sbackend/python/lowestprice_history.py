import re
import math
from datetime import datetime, timedelta
from common import get_mongoDb, getValue
import time

check_date = str((datetime.today() - timedelta(30)).strftime('%Y-%m-%d'))
dt = datetime.today()
day = dt.strftime('%A')
print(check_date)


def release_date(sku,history):
   lesserthan = sku.aggregate([{'$lookup': {'from': "Sneakers",'localField': "product_sku_id",'foreignField': "product_sku_id", 'as': "product_sku"}},{ "$unwind": "$product_sku" },{'$match':{"product_release_date":{'$lt':check_date}}},{'$count':"count"}])
   for count in lesserthan:
      count = count['count']

   for itr in range(math.ceil(count/100)):
     skip = ((itr+1)*100)-100
     cursor = sku.aggregate([{'$lookup': {'from': "Sneakers",'localField': "product_sku_id",'foreignField': "product_sku_id", 'as': "product_sku"}},{ "$unwind": "$product_sku" },{'$match':{"product_release_date":{'$lt':check_date}}},{ '$skip' : skip },{ '$limit' : 100 },{'$sort': {'product_sku_id':1}}]);
     for item in cursor:
       lowest_price_history(history,item)
   
   
   if day  == 'Sunday':
     greaterthan = sku.aggregate([{'$lookup': {'from': "Sneakers",'localField': "product_sku_id",'foreignField': "product_sku_id", 'as': "product_sku"}},{ "$unwind": "$product_sku" },{'$match':{"product_release_date":{'$gt':check_date}}},{'$count':"count"}])
     for count in greaterthan:
        count = count['count']
        
     for itr in range(math.ceil(count/100)):
       skip = ((itr+1)*100)-100
       cursor = sku.aggregate([{'$lookup': {'from': "Sneakers",'localField': "product_sku_id",'foreignField': "product_sku_id",'as': "product_sku"}},{ "$unwind": "$product_sku" },{'$match':{"product_release_date":{'$gt':check_date}}},{ '$skip' : skip },{ '$limit' : 100 },{'$sort': {'product_sku_id':1}}]);     
       for item in cursor:                             
         lowest_price_history(history,item)
                    

def lowest_price_history(history, obj):
  product_lowest_priceSize = {}
  lowestPriceSize = []
  lowestPriceSize2 = []
  averagePriceSize = []
  lowestPrice = []
  lowestPrice2 = []
  
  for y in obj['product_sku'].keys():
    if '_priceSize' in y and obj['product_sku'][y] != '-':
      if y.upper() not in shopList:
         continue
      for z in obj['product_sku'][y]:
        try:
          z[1] = float(re.findall(r'(\d+.\d+|\d+)',str(z[1]))[0])
          if z[1] == None or z[1] in [0, '0']:
            continue
          if z[0] != None and z[0] not in product_lowest_priceSize:
            product_lowest_priceSize[z[0]] = [z[1]]
            
          elif product_lowest_priceSize[z[0]] != None:
            product_lowest_priceSize[z[0]] = product_lowest_priceSize[z[0]]+[z[1]]
        except:
          pass
          

  for x, y in product_lowest_priceSize.items():
    try:
      y.sort()
      price = round(y[0])
      lowestPrice.append(price)
      lowestPriceSize.append([x, price])
      averagePriceSize.append([x, round(sum(y)/len(y))])
    except:
      pass
    
    '''
    price2 = price
    if len(y) > 1:
      price2 = round(y[1])
      
    lowestPrice2.append(price2)
    lowestPriceSize2.append([x, price2])
    '''
    
  productLowestPrice = obj.get('product_lowest_price')
  try:
    productLowestPrice = min(lowestPrice)
  except:
    pass
    
  if productLowestPrice == None:
    productLowestPrice = '-'

  data = {'PriceHistoryDate':datetime.today().strftime('%Y-%m-%d'), 'product_lowest_price':productLowestPrice, 'PriceHistorySize':lowestPriceSize, 'MiddlePriceHistorySize':averagePriceSize}

  cursor = history.count_documents({"product_sku_id":obj['product_sku_id']})
  insert = True
  if cursor > 0: 
    insert = False
    print("updated SKU:", obj['product_sku_id'],  datetime.now())
    history.update_one({'product_sku_id':obj['product_sku_id']}, {'$push':{'history':data}})
  
  if insert:
    print("inserted SKU:", obj['product_sku_id'],  datetime.now())
    history.insert_one({'product_sku_id':obj['product_sku_id'], 'history':[data]})    

if __name__ == "__main__":
  db = get_mongoDb()
  history = db.History
  sku = db.SKU
  shop = db.Shops
  cursor = shop.find({"status":1})
  shopList = [('product_'+document['shop']+'_priceSize').upper() for document in cursor]
  release_date(sku,history) 

