import requests
import common
from  common import get_mongoDb, get_shortnered_link

def stockxaffiliateId():
  cur = collection.find({'product_stockx_url':{'$exists':True , '$ne':'-'}, 'UpdatedByAks':{'$exists':False}})
  for count, data in enumerate(cur):
    try:  
       a = requests.head(data['product_stockx_url'])
       stockxurl = a.headers['location']
       product_stock_url = common.getValue(r'=(.*$)', str(stockxurl))
       if product_stock_url is not None:
         product_stockx_url = get_shortnered_link("https://stockx.pvxt.net/c/4259387/570105/9060?u="+product_stock_url)          
         collection.update_one({'product_sku_id':data['product_sku_id']}, {'$set': {'product_stockx_url': product_stockx_url , 'UpdatedByAks':1}}) 
         print(data['product_sku_id'], ":", "Product_stockx_url has been updated")
         print(f"updatedcount:{count+1}/15319")    
    except Exception as ex:
        print("Exception happened:", ex)
        pass
  print("---------AffiliateId updation completed------------")


db = get_mongoDb()
collection = db.Sneakers
stockxaffiliateId()

