from pymongo import MongoClient, collation, mongo_client
from dotenv import dotenv_values
import pysftp as sftp
import random
import json
import urllib.parse
import requests
import re
from dotenv import dotenv_values
import sentry_sdk

sentry_sdk.init(dsn="https://74c596cb0e754a669f3ec91a5a552342@o4505204272988160.ingest.sentry.io/4505205126594560", traces_sample_rate=1.0,)


def getConfig():
  return dotenv_values("/home/ubuntu/MobileAPIs/.env")
  #return dotenv_values("/var/www/html/old_fl_20221021/alexandre/mobileAPis/.env") #testing 
  #return dotenv_values("/var/www/html/kt/ScraperNew/MobileAPIs/.env")#testing

config = getConfig()

def get_mongoDb():
  try: 
    uri = config['MONGODBURL']
    client = MongoClient(uri)
    #print("Connected successfully!!!") 
  except:   
    print("Could not connect to MongoDB")
  db = client["sneaks4sure"]
  return db
        
def getValue(regexVal, strVal, allR = "no"): 
  href = re.findall(regexVal, strVal, re.MULTILINE | re.IGNORECASE | re.DOTALL)
  if len(href) == 0:
    return None
  else:
    if allR == "yes":
      return href
    else:  
      return href[0]

def sftp_connection():
  cnopts = sftp.CnOpts()
  cnopts.hostkeys = None 

  s = sftp.Connection(host=config['host'], username=config['username'], password=config['password'], cnopts=cnopts)
  print("----------connected successfully!!------------")
  return s
  
def getAPIskus(heats=False, recent=False, past=False, upcoming=False, top=False):
  heatsArr = []
  recentsArr = []
  pastArr = []
  upcomingArr = []
  topArr = []
  def apiSKUS(apiUrl, key):
    arr = []
    api = None
    i = 0
    while i <= 5:
      i = i + 1
      r = requests.get('https://api.sneaks4sure.com/'+apiUrl+'?custom=Eel1cJx2nttp9Vw2nqcu43')
      if r.status_code == 200:
        api = r.json()
        break
      else:
        print("api_response:", r)  
        
    if api != None:
      if 'code' in api and api['code'] == 200 and key in api['data']:
        if type(api['data'][key]) == dict:
          for a in api['data'][key].keys():
            for item in api['data'][key][a]:
              arr.append(item['ProductSKU'])
        
        else:
          for a in api['data'][key]:
            arr.append(a['ProductSKU'])
    return arr

  if heats:
    heatsArr = apiSKUS('heats', 'heats')
  if recent:
    recentsArr = apiSKUS('recent', 'recentlyDropped')
  if past:
    pastArr = apiSKUS('past', 'pastProducts')
  if upcoming:
    upcomingArr = apiSKUS('upcoming', 'upcomings')
  if top:
    topArr = apiSKUS('top', 'topClicked')
    
  return list(set(heatsArr + recentsArr + pastArr + upcomingArr + topArr))
  
  
  
def get_shortnered_link(url, is_calendar=False):
    key = '61ba57c7111dbd56717f9bcbaab894b6b0441'
    url_quoted = urllib.parse.quote(url)
    is_calendar = False  # http://cutt.ly   linit issue -----------
    userDomain = '1' if is_calendar else '0'
    try:
        i = 0
        while i <= 50:
            i = i + 1
            print("Tryng for shortnered:",url)
            r = requests.get('http://cutt.ly/api/api.php?key={}&short={}&userDomain={}'.format(key, url_quoted, userDomain))
            if r.status_code != 429:
                break
            time.sleep(30)
        res = json.loads(r.text)
        shortLink = res['url']['shortLink']
    except Exception as ex:
        print(ex)
        shortLink = url
    return shortLink  
