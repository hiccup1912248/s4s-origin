/*
 +-----------------------------------------------------------+
 | Helper Name: Request Helper                               |
 | Helper Purpose: Manage the requests to the PMS            |
 +-----------------------------------------------------------+
*/

'use strict';

/**
 * Success response helper
 * @author 
 * @return json
 * @createdOn 
 */

var success = function (message, code, results) {
	let msg = ({
		status: 1,
		message: message,
		code: code,
		data: results
	});
	//console.log("Response", msg); //test
	return msg;
};

/**
 * Failure response helper
 * @author 
 * @return json
 * @createdOn 
 */

var failure = function (message, code) {
	var msg;
	if (message instanceof Array) {
		msg =  ({
			status: 0,
			message: "Validation errors!",
			code: code,
			data: message
		});
	} else {
		msg =  ({
			status: 0,
			message: message.toString(),
			code: code,
			data: null
		});
	}
	
	if(typeof message === "string"){ //For few days testing
	  console.log("Response: ", message);
	}
	else{
	  console.log("Response", msg); //test
	}
	
	return msg;
};


var cookies = function (req){
  if (req.headers.cookie !== undefined) {
    var values = req.headers.cookie.split(';').reduce((res, item) => {
      var data = item.trim().split('=');
      return { ...res, [data[0]]: data[1] };
    }, {});
    return values;
  }
  else{
    return {};
  }

}


module.exports = {
	success: success,
	failure: failure,
	cookies: cookies
}
