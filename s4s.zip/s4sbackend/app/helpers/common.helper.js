const fs = require('fs').promises;
const path = require('path');
const {authenticate} = require('@google-cloud/local-auth');
const {google} = require('googleapis');
var MongoClient = require('mongodb').MongoClient;
var MongoDBK;

const SCOPES = ['https://www.googleapis.com/auth/gmail.send'];

const TOKEN_PATH = path.join(__dirname, '../config/auth/token.json');
const CREDENTIALS_PATH = path.join(__dirname, '../config/auth/credentials.json');

/**
 * Reads previously authorized credentials from the save file.
 *
 * @return {Promise<OAuth2Client|null>}
 */
async function loadSavedCredentialsIfExist() {
  try {
    const content = await fs.readFile(TOKEN_PATH);
    const credentials = JSON.parse(content);
    return google.auth.fromJSON(credentials);
  } catch (err) {
    console.log("loadSavedCredentialsIfExist --- ", err);
    return null;
  }
}

/**
 * Serializes credentials to a file compatible with GoogleAUth.fromJSON.
 *
 * @param {OAuth2Client} client
 * @return {Promise<void>}
 */
async function saveCredentials(client) {
  const content = await fs.readFile(CREDENTIALS_PATH);
  const keys = JSON.parse(content);
  const key = keys.installed || keys.web;
  const payload = JSON.stringify({
    type: 'authorized_user',
    client_id: key.client_id,
    client_secret: key.client_secret,
    refresh_token: client.credentials.refresh_token,
  });
  await fs.writeFile(TOKEN_PATH, payload);
}

/**
 * Load or request or authorization to call APIs.
 *
 */
async function authorize() {
  let client = await loadSavedCredentialsIfExist();

  if (client) {
    return client;
  }
  client = await authenticate({
    scopes: SCOPES,
    keyfilePath: CREDENTIALS_PATH,
  });
  if (client.credentials) {
    await saveCredentials(client);
  }
  return client;
}

/**
 * Format the email to be sended.
 *
 * @param to,
 * @params subject
 * @params message
 * @return {Promise<void>}
 */
function makeBody(ip) {
    var str = ["Content-Type: text/plain; charset=\"UTF-8\"\n",
        "MIME-Version: 1.0\n",
        "Content-Transfer-Encoding: 7bit\n",
        "to: sneaks4sure@gmail.com\n",
        "from: contact@sneaks4sure.com\n",
        "subject: api.sneaks4sure.com - BOT Detected -- "+new Date()+" \n\n",
        "Hi, We are blocking this ip --"+ip
    ].join('');

    var encodedMail = new Buffer(str).toString("base64").replace(/\+/g, '-').replace(/\//g, '_');
        return encodedMail;
}

/**
 * To send the mail.
 *
 * @param {google.auth.OAuth2} auth An authorized OAuth2 client.
 */
async function sendMail(ip) {
  let auth = await authorize();
  const gmail = google.gmail({version: 'v1', auth});
  
  var raw = makeBody(ip);

  gmail.users.messages.send({
    auth: auth,
    userId: 'me',
    resource: {
      raw: raw
    }
  }, function(err, response) {
    console.log(err, response)
  });

  
}

MongoClient.connect(process.env.MONGODBURL, function (err, db) {
  if (err){
    console.log("Mongo Connect error: ", err);
  }
  else{
    console.log("Mongo connected successfully");
  }
  MongoDBK = db.db(process.env.MONGODB);
});


function findFromMongo(collectionName, query){
  return new Promise((resolve, reject) => {

    MongoDBK.collection(collectionName).find(query).toArray(function (err, result) {
      if (err){
        reject(err);
      }
      else{
        resolve(result);
      }
    });
  
  });
}

function findSpecField(collectionName, query, field){
  return new Promise((resolve, reject) => {

    MongoDBK.collection(collectionName).findOne(query, field, function (err, result) {
      if (err){
        reject(err);
      }
      else{
        resolve(result);
      }
    });
  
  });
}

function findAggregate(collectionName, query) {

  return new Promise((resolve, reject) => {
    
    MongoDBK.collection(collectionName).aggregate(query, { allowDiskUse: true }).toArray(function (err, result) {
      if (err){
        reject(err);
      }
      else{
        resolve(result);
      }
    });
  
  });
}

function mongoCreate(collectionName, query){
  return new Promise((resolve, reject) => {

    MongoDBK.collection(collectionName).insertOne(query, function(err, res) {
      if (err){
        reject(err);
      }
      else{
        
        resolve("user created");
      }
    });
  
  });
}

function findCount(collectionName){
  return new Promise((resolve, reject) => {

    MongoDBK.collection(collectionName).countDocuments(function (err, result) {
      if (err){
        reject(err);
      }
      else{
        resolve(result);
      }
    });
  
  });
}

function updateMongo(collectionName, query, newvalues){
  return new Promise((resolve, reject) => {

    MongoDBK.collection(collectionName).updateOne(query, newvalues, function(err, res) {
      if (err){
        reject(err);
      }
      else{
        resolve("user updated");
      }
    });
  
  });
}

function getToday(){
  var datetime = new Date();
  return datetime.toISOString().slice(0,10);
}

function yesterdayDatetime() {
  let today = new Date();
  let yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  var datetime = yesterday;
  return datetime;
}

function getDateArray(startDate, increCount, stat) {
  var listDate = [];
  var dateMove = new Date(startDate);
  var strDate = startDate;
  var count = 0
  while (count < increCount) {
      var strDate = dateMove.toISOString().slice(0, 10);
      listDate.push(strDate);
      if(stat == "decre"){
        dateMove.setDate(dateMove.getDate() - 1);
      }
      else{
        dateMove.setDate(dateMove.getDate() + 1);
      }
      count++;  
  }
  return listDate;
}

function getDateFn(startDate, increCount, stat) {
  var dateMove = new Date(startDate);
  if(stat == "decre"){
  	dateMove.setDate(dateMove.getDate() - increCount);
  }
  else{
  	dateMove.setDate(dateMove.getDate() + increCount);
  }
  return dateMove.toISOString().slice(0,10);
}

function deleteFromMongo(collectionName, query, newvalues){
  return new Promise((resolve, reject) => {

    MongoDBK.collection(collectionName).deleteOne(query, newvalues, function(err, res) {
      if (err){
        reject(err);
      }
      else{
        resolve("success");
      }
    });
  
  });
}


function onlyUnique(value, index, array) {
  return array.indexOf(value) === index;
}

module.exports = {
  findFromMongo: findFromMongo,
  findSpecField: findSpecField,
  findAggregate: findAggregate,
  getToday: getToday,
  yesterdayDatetime: yesterdayDatetime,
  getDateArray: getDateArray,
  mongoCreate: mongoCreate,
  findCount: findCount,
  updateMongo: updateMongo,
  deleteFromMongo: deleteFromMongo,
  sendMail: sendMail,
  onlyUnique : onlyUnique,
  getDateFn: getDateFn
}
