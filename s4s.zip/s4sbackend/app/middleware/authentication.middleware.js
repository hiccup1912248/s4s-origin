/*
 +-----------------------------------------------------------+
 | Module Name: Authentication                               |
 | Module Purpose: Middleware for manage the security        |
 +-----------------------------------------------------------+
*/

'use strict';

const isBot = require('isbot');
const K = require('../config/constants');
const admin = require('firebase-admin');
const { getAuth } = require('firebase-admin/auth');
const commonHelper = require('../helpers/common.helper');
const serviceAccount = require('../config/serviceAccountKey.json');

const firebaseConfig = {
  apiKey: process.env.FIRE_BASETOKEN,
  authDomain: "sneaks4sure-1088.firebaseapp.com",
  projectId: "sneaks4sure-1088",
  storageBucket: "sneaks4sure-1088.appspot.com",
  messagingSenderId: "779499834281",
  appId: "1:779499834281:web:9f71e8e33da74285de52b8",
  measurementId: "G-XGMSTYWJJ8",
  credential: admin.credential.cert(serviceAccount)
};
const firebaseApp = admin.initializeApp(firebaseConfig);

module.exports.auth = function (req, res, next) {
  if (req.query !== undefined && (req.query.custom === "Eel1cJx2nttp9Vw2nqcu43" || req.query.custom === "WfjKcJx2nthhe9Vw2fddfd867")) {
    next();
  } else if (req.headers.token === undefined) {
    return res.status(K.CODES.UNAUTHORIZED).send({ "error": "Token not found" });
  } else {
    commonHelper.findFromMongo("AuthToken", { authtoken: req.headers.token })
      .then(function (data) {
        if (data.length > 0 && data[0].botDetect === "yes") {
          return res.status(K.CODES.UNAUTHORIZED).send({ "error": "you are identified as bot" });
        }
        if (data.length > 0 && data[0].firebaseResponse !== undefined) {
          next();
        } else {
          if (isBot(req.get('user-agent'))) {
            var obj = {};
            obj.authtoken = req.headers.token;
            obj.botDetect = "yes";
            obj.addedDated = new Date();
            commonHelper.mongoCreate('AuthToken', obj);
            console.log(req.socket.remoteAddress);
            commonHelper.sendMail(req.socket.remoteAddress);
            return res.status(K.CODES.UNAUTHORIZED).send({ "error": "you are detected as bot" });
          }
          getAuth()
            .verifyIdToken(req.headers.token)
            .then((decodedToken) => {
              if (decodedToken.user_id !== undefined) {
                var obj = {};
                obj.authtoken = req.headers.token;
                obj.firebaseResponse = JSON.stringify(decodedToken);
                obj.addedDated = new Date();
                commonHelper.mongoCreate('AuthToken', obj);
                console.log(decodedToken);
                console.log({ "success": 1, "user_id": decodedToken.user_id });
                next();
              } else {
                return res.status(K.CODES.UNAUTHORIZED).send({ "error": "user-id not found" });
              }
            })
            .catch((error) => {
              console.log("error---", error);
              return res.status(K.CODES.UNAUTHORIZED).send({ "error": error });
            });
        }
      })
  }
};

module.exports.firebaseApp = firebaseApp;
