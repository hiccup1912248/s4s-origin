/*
 +--------------------------------------------------------------+
 | Module Name: Request Controller                              | 
 | Module Purpose: Manage API to send responses                 |
 +--------------------------------------------------------------+
*/

'use strict';

var ProductService = require('../services/product.service');
var UserService = require('../services/user.service');
var RestockNotificationService = require('../services/restockNotification.service');
var RestockService = require("../services/restock.service");
var Authenticate = require('../middleware/authentication.middleware');
var ObjectId = require("mongodb").ObjectId;

const fs = require('fs');
const path = require('path');

/**
 * Controller to get the product information.
 * @return json
 *
 */
function getProductInfo(req, res, next) {
	ProductService.getProductInfo(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("ProductInfo API response time:", new Date());
		return res.send(response);
	});
}

function getHeatsOfWeek(req, res, next) {
	ProductService.getHeatsOfWeek(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Heats API response time:" + new Date());
		return res.send(response);
	});
}

function recentlyDropped(req, res, next) {
	ProductService.recentlyDropped(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Recents API response time:" + new Date());
		return res.send(response);
	});
}

function s4sNews(req, res, next) {
	ProductService.s4sNews(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("s4snews API response time:" + new Date());
		return res.send(response);
	});
}

function topClicked(req, res, next) {
	ProductService.topClicked(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Top API response time:" + new Date());
		return res.send(response);
	});
}

function upcomingProducts(req, res, next) {
	ProductService.upcomingProducts(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Upcoming API response time:" + new Date());
		return res.send(response);
	});
}

function pastProducts(req, res, next) {
	ProductService.pastProducts(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Past API response time:" + new Date());
		return res.send(response);
	});
}

function getRaffles(req, res, next) {
	ProductService.getRaffles(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Raffles API response time:" + new Date());
		return res.send(response);
	});
}

function getRetail(req, res, next) {
	ProductService.getRetail(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Retail API response time:" + new Date());
		return res.send(response);
	});
}

function getProducts(req, res, next) {
	ProductService.getProducts(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("ProductPage API response time:" + new Date());
		return res.send(response);
	});
}

function getResell(req, res, next) {
	ProductService.getResell(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Resell API response time:" + new Date());
		return res.send(response);
	});
}

function getRestock(req, res, next) {
	ProductService.getRestock(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Restock API response time:" + new Date());
		return res.send(response);
	});
}

function getImg360(req, res, next) {
	ProductService.getImg360(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Img360 API response time:" + new Date());
		return res.send(response);
	});
}

function addUser(req, res, next) {
	UserService.addUser(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Add user API response time:" + new Date());
		return res.send(response);
	});
}

function fileUpload(req, res, next) {
	UserService.fileUpload(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("File upload API response time:" + new Date());
		return res.send(response);
	});
}

function checkFilterInfo(items, checkKey) {
	var returnVal = false;
	if (items != undefined && items.length > 0) {
		returnVal = items.filter(item => item.toLowerCase() === checkKey.toLowerCase()).length > 0
	}
	return returnVal;
}

function checkProductSKU(sku, wishProducts) {
	wishProducts.map((product) => {
		if (sku == JSON.parse(product)['productSku']) {
			return true;
		}
	});
	return false;
}

function getFirebaseRestock(req, res, next) {
	var resultData = [];
	ProductService.getRestockByTrigger(req, res, function (err, response) {
		if (err) return res.send(err);
		var restockData = response.data.restock;
		UserService.getUsers(req, res, function (err, response) {
			if (err) return res.send(err);
			var userList = response.data;
			RestockNotificationService.getNoficationByUser().then(function (oldNotification) {
				userList.map(user => {
					if (user.fcmtoken && user.notif_flag) {
						var notificationInfo = oldNotification.data.filter(item => item.fcmtoken === user.fcmtoken)[0];
						if (!notificationInfo) {
							notificationInfo = {
								fcmtoken: user.fcmtoken,
								products: []
							};
						}
						var productNames = [];
						restockData.map(restock => {
							if (user.wishProducts?.length > 0) {
								if (checkProductSKU(restock.ProductSKU, user.wishProducts)) {
									if (notificationInfo.products.filter(item =>
										(item.product_sku == restock.ProductSKU) &&
										(new Date(item.datetime).toISOString() == new Date(restock.DateTime).toISOString())).length === 0) {

										let key = '';
										if (Object.keys(restock.Url_Link).length == 1) {
											key = Object.keys(restock.Url_Link)[0];
										}

										productNames.push({
											productSku: restock.ProductSKU,
											name: restock.ShopName + ' - ' + restock.ProductName,
											image: restock.ProductImage,
											linkUrl: key != '' ? restock.Url_Link[key].url : '',
										});

										notificationInfo.products.push({
											product_sku: restock.ProductSKU,
											datetime: restock.DateTime
										});
									}
								}
							}

							if (
								checkFilterInfo(user.brands, restock.Brand) &&
								checkFilterInfo(user.shops, restock.RegionName + '_' + restock.ShopName)) {

								if (notificationInfo.products.filter(item =>
									(item.product_sku == restock.ProductSKU) &&
									(new Date(item.datetime).toISOString() == new Date(restock.DateTime).toISOString())).length === 0) {

									let key = '';
									if (Object.keys(restock.Url_Link).length == 1) {
										key = Object.keys(restock.Url_Link)[0];
									}

									productNames.push({
										productSku: restock.ProductSKU,
										name: restock.ShopName + ' - ' + restock.ProductName,
										image: restock.ProductImage,
										linkUrl: key != '' ? restock.Url_Link[key].url : '',
									});

									notificationInfo.products.push({
										product_sku: restock.ProductSKU,
										datetime: restock.DateTime
									});
								}
							}

						});
						if (productNames.length > 0) {
							resultData.push({
								fcmtoken: user.fcmtoken,
								productNames: productNames
							})
						}
						RestockNotificationService.updateNoficationByUser(notificationInfo);
					}
				});
				console.log("Get firebase restock API response time:" + new Date());
				return res.send(resultData);
			});
		})
	});
}

function getUserByEmail(req, res, next) {
	UserService.getUserInfo(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Get user API response time:" + new Date());
		return res.send(response);
	});
}

function incrementHitCount(req, res, next) {
	ProductService.incrementHitCount(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Increment hit count API response time:" + new Date());
		return res.send(response);
	})
}

function login(req, res, next) {
	UserService.login(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Login API response time:" + new Date());
		return res.send(response);
	})
}

function fileDownload(req, res, next) {
	var filepath = req.params.filepath;
	const directoryPath = path.join(__dirname, '../../S4S/products/', filepath);
	console.log("File download API response time:" + new Date());
	res.sendFile(directoryPath);
}

function deleteUser(req, res, next) {
	UserService.deleteUser(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Delete user API response time:" + new Date());
		return res.send(response);
	});
}

function disableShop(req, res, next) {
	ProductService.disableShop(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Disable shop API response time:" + new Date());
		return res.send(response);
	});
}

function enableShop(req, res, next) {
	ProductService.enableShop(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Enable shop API response time:" + new Date());
		return res.send(response);
	});
}

function productTextColor(req, res, next) {
	ProductService.productTextColor(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Product text color API response time:" + new Date());
		return res.send(response);
	});
}

function getRestockNewData(req, res, next) {
	const id = req.params.id;
	if(ObjectId.isValid(id) === false){
	  return res.send('INVALID_ID');
	}
	console.log('id ===> ', id);
	RestockService.getNewRestock({ id: id }).then(function (restockData) {
		if (restockData.data!== undefined && restockData.data.length > 0) {
			var restock = restockData.data[0];
			RestockService.getSKU({ productSKU: restock["product_sku_id"] }).then(function (skuDataResponse) {
				if(skuDataResponse.data !== undefined && skuDataResponse.data[0] !== undefined){
				  var sku = skuDataResponse.data[0];
				  var resellValuePourcent = sku["ResellValuePourcent"];
				  RestockService.getUsersByRestockSetting(restock, resellValuePourcent).then(function (users) {
					  let key = '';
					  var shopName = restock.shop_name;
					  var productName = restock.product_name;
					  var imageUrl = restock.product_img_url;
					  var productSku = restock.product_sku_id;
					  var linkUrl = JSON.parse(restock.product_shortened_affiliate_url);

					  if (Object.keys(linkUrl).length == 1) {
						  key = Object.keys(linkUrl)[0];
					  }

					  var fcmTokenList = users.data.map(user => user.fcmtoken);
					  var message = {
						  notification: {
							  title: "S4S - Just Restocked",
							  body: `${shopName} - ${productName}`,
							  imageUrl: imageUrl,
						  },
						  data: {
							  productSku: productSku,
							  linkUrl: key != '' ? linkUrl[key].url : '',
						  },
						  tokens: fcmTokenList
					  }
					  if (fcmTokenList.length > 0) {
						  Authenticate.firebaseApp.messaging().sendMulticast(message)
							.then((response) => {
							  console.log(`${response.successCount} messages were sent successfully`);
							})
							.catch((error) => {
							  console.error('Error sending messages:', error);
							})
					  }
				  })
				}
			})
		}
	})
	console.log("Get Restock new data API response time:" + new Date());
	return res.send("ok");
}

function getInstore(req, res, next) {
	ProductService.getInstore(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Instore API response time:" + new Date());
		return res.send(response);
	});
}

function getHistory(req, res, next) {
	ProductService.getHistory(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("History API response time:" + new Date());
		return res.send(response);
	});
}

function likeOrDislike(req, res, next) {
	ProductService.likeOrDislike(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("History API response time:" + new Date());
		return res.send(response);
	});
}

function recoverLikeOrDislike(req, res, next) {
	ProductService.recoverLikeOrDislike(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("History API response time:" + new Date());
		return res.send(response);
	});
}

function shoesUpload(req, res, next) {
	UserService.shoesUpload(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Add user API response time:" + new Date());
		return res.send(response);
	});
}

function disableSku(req, res, next) {
	ProductService.disableSku(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Disable sku API response time:" + new Date());
		return res.send(response);
	});
}

function enableSku(req, res, next) {
	ProductService.enableSku(req, res, function (err, response) {
		if (err) return res.send(err);
		console.log("Enable sku API response time:" + new Date());
		return res.send(response);
	});
}

function currency(req, res, next) {
	UserService.currency(req, res, function (err, response) {
		if (err) return res.send(err);
		return res.send(response);
	})
}

module.exports = {
	getProductInfo: getProductInfo,
	getHeatsOfWeek: getHeatsOfWeek,
	recentlyDropped: recentlyDropped,
	s4sNews: s4sNews,
	topClicked: topClicked,
	upcomingProducts: upcomingProducts,
	pastProducts: pastProducts,
	getRaffles: getRaffles,
	getRetail: getRetail,
	getProducts: getProducts,
	getResell: getResell,
	getRestock: getRestock,
	getImg360: getImg360,
	addUser: addUser,
	fileUpload: fileUpload,
	getFirebaseRestock: getFirebaseRestock,
	getUserByEmail: getUserByEmail,
	incrementHitCount: incrementHitCount,
	login: login,
	fileDownload: fileDownload,
	deleteUser: deleteUser,
	disableShop: disableShop,
	enableShop: enableShop,
	productTextColor: productTextColor,
	getRestockNewData: getRestockNewData,
	getInstore: getInstore,
	getHistory: getHistory,
	likeOrDislike: likeOrDislike,
	recoverLikeOrDislike: recoverLikeOrDislike,
	shoesUpload: shoesUpload,
	disableSku: disableSku,
	enableSku: enableSku,
	currency: currency,
}
