
'use strict';

var recordHelper = require('../helpers/response.helper');
var commonHelper = require('../helpers/common.helper');

function updateNoficationByUser(query) {
    return new Promise((resolve, reject) => {
        commonHelper
            .findFromMongo("RestockNotification", { fcmtoken: query.fcmtoken })
            .then(function (data) {
                if (data.length > 0) {
                    commonHelper.updateMongo("RestockNotification", { fcmtoken: query.fcmtoken }, { $set: query })
                        .then(function (data) {
                            resolve({
                                status: "success",
                            });
                        })
                } else {
                    commonHelper
                        .mongoCreate("RestockNotification", query)
                        .then(function (data) {
                            resolve({
                                status: "success",
                            });
                        })
                }
            });
    })
}

function getNoficationByUser() {
    return new Promise((resolve, reject) => {
        commonHelper.findFromMongo("RestockNotification")
            .then(function (data) {
                resolve({
                    data: data
                })
            })
    })
}

module.exports = {
    updateNoficationByUser: updateNoficationByUser,
    getNoficationByUser: getNoficationByUser
}
