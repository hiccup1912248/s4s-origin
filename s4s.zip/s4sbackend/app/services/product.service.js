/*
 +-----------------------------------------------------------+
 | Module Name: Request Services	                           |
 | Module Purpose: To handle all product queries             |
 +-----------------------------------------------------------+
*/

'use strict';
var nrc = require('node-run-cmd');
var recordHelper = require('../helpers/response.helper');
var commonHelper = require('../helpers/common.helper');
var failure = recordHelper.failure;
var success = recordHelper.success;
const K = require('../config/constants');
const E = K.errors;
const path = require('path');
const fs = require('fs');
const { result } = require('lodash');
var productdata = [];
var shopData = [];
var banSkus = [];
var banDomains = [];
var disableSkus = [];

function bannedDatas() {
	fs.readFile('Ban_SKU.txt', function (err, data) {
		if (err) throw err;
		banSkus = data.toString().split("\n");
		console.log(banSkus);
	});
	fs.readFile('Ban_DOMAINS.txt', function (err, data) {
		if (err) throw err;
		banDomains = data.toString().split("\n");
		console.log(banDomains);
	});
}

bannedDatas();

setInterval(bannedDatas, 600000);

function getColorData() {
	return new Promise((resolve) => {
		var filePath = path.join(__dirname, '../config/textcolor.json');
		fs.readFile(filePath, function (err, data) {
			if (err) throw err;
			resolve(JSON.parse(data));
		});
	})
}

function getShopStatus() {
	var query = [
		{
			$match: {
				status: 0
			}
		},
		{
			$project:
			{
				_id: 0,
				shops: "$priceSize_key",
			}
		},
	];
	commonHelper.findAggregate("Shops", query)
		.then(function (data) {
			shopData = [];
			data.forEach(i => {
				shopData.push(i.shops);
			})
		});

}

function getSkuStatus() {
	var query = [
		{
			$match: {
				status: 0
			}
		},
		{
			$project:
			{
				_id: 0,
				sku: "$product_sku_id",
			}
		},
	];
	commonHelper.findAggregate("SKU", query)
		.then(function (data) {
			disableSkus = [];
			data.forEach(i => {
				disableSkus.push(i.sku);
			})
		});

}

setTimeout(() => {
	getShopStatus();
	getSkuStatus();
	getShop();
	setInterval(getShop, 600000);
}, 5000);

function getShop() {
	// return new Promise((resolve, reject) => {
	var query = [
		{
			$lookup:
			{
				from: 'TrustPilot',
				localField: 'shop_id',
				foreignField: 'shop_id',
				as: 'TrustPilot'
			}
		},
	];
	commonHelper.findAggregate("Shops", query)
		.then(function (data) {
			//console.log(data[0].TrustPilot);            
			productdata = data;
		});

}

/**
 * To get the product info
 */
function getProductInfo(req, res, callback) {

	return getProductDetails(req)
		.then(function (productInfo) {

			return callback(
				null,
				success(productInfo.status, K.CODES.EVERYTHING_IS_OK, productInfo.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getHeatsOfWeek(req, res, callback) {

	return getHeats(req)
		.then(function (trendingProducts) {

			return callback(
				null,
				success(trendingProducts.status, K.CODES.EVERYTHING_IS_OK, trendingProducts.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function recentlyDropped(req, res, callback) {

	return getRecentProducts(req)
		.then(function (recentProducts) {

			return callback(
				null,
				success(recentProducts.status, K.CODES.EVERYTHING_IS_OK, recentProducts.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function topClicked(req, res, callback) {

	return getTopProducts(req)
		.then(function (topProducts) {

			return callback(
				null,
				success(topProducts.status, K.CODES.EVERYTHING_IS_OK, topProducts.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function s4sNews(req, res, callback) {

	return gets4sNews(req)
		.then(function (s4sNews) {

			return callback(
				null,
				success(s4sNews.status, K.CODES.EVERYTHING_IS_OK, s4sNews.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function upcomingProducts(req, res, callback) {

	return getUpcoming(req, "upcomings")
		.then(function (upcoming) {

			return callback(
				null,
				success(upcoming.status, K.CODES.EVERYTHING_IS_OK, upcoming.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function pastProducts(req, res, callback) {

	return getUpcoming(req, "pastProducts")
		.then(function (pastProducts) {

			return callback(
				null,
				success(pastProducts.status, K.CODES.EVERYTHING_IS_OK, pastProducts.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getRaffles(req, res, callback) {
	return raffles(req)
		.then(function (raffles) {

			return callback(
				null,
				success(raffles.status, K.CODES.EVERYTHING_IS_OK, raffles.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getRetail(req, res, callback) {
	return retail(req)
		.then(function (retail) {

			return callback(
				null,
				success(retail.status, K.CODES.EVERYTHING_IS_OK, retail.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getProducts(req, res, callback) {
	return productPage(req)
		.then(function (product) {

			return callback(
				null,
				success(product.status, K.CODES.EVERYTHING_IS_OK, product.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getResell(req, res, callback) {
	return resell(req)
		.then(function (resell) {

			return callback(
				null,
				success(resell.status, K.CODES.EVERYTHING_IS_OK, resell.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function disableShop(req, res, callback) {
	return disableShopFunc(req)
		.then(function (disableShopFunc) {

			return callback(
				null,
				success(disableShopFunc.status, K.CODES.EVERYTHING_IS_OK, disableShopFunc.message)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function enableShop(req, res, callback) {
	return enableShopFunc(req)
		.then(function (enableShopFunc) {

			return callback(
				null,
				success(enableShopFunc.status, K.CODES.EVERYTHING_IS_OK, enableShopFunc.message)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getRestock(req, res, callback) {
	return restock(req)
		.then(function (restock) {

			return callback(
				null,
				success(restock.status, K.CODES.EVERYTHING_IS_OK, restock.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getRestockByTrigger(req, res, callback) {
	return restockByTrigger(req)
		.then(function (restock) {

			return callback(
				null,
				success(restock.status, K.CODES.EVERYTHING_IS_OK, restock.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function productTextColor(req, res, callback) {
	return getProductTextColor(req)
		.then(function (color) {

			return callback(
				null,
				success(color.status, K.CODES.EVERYTHING_IS_OK, color.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function incrementHitCount(req, res, callback) {
	return getSkuDetail(req)
		.then(function (productInfo) {
			if (productInfo.data.productInfo.length > 0) {
				var productDetail = productInfo.data.productInfo[0];
				if (productDetail['product_hit_number']) {
					productDetail['product_hit_number'] = productDetail['product_hit_number'] + 1;
				} else {
					productDetail['product_hit_number'] = 1;
				}
				var query = { _id: productDetail['_id'] };
				commonHelper
					.updateMongo("SKU", query, { $set: productDetail })
					.then(function (data) {
						return callback(
							null,
							success(true)
						);
					});
			} else {
				return callback(
					null,
				);
			}
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});
}

function getImg360(req, res, callback) {
	return img360(req)
		.then(function (img360) {

			return callback(
				null,
				success(img360.status, K.CODES.EVERYTHING_IS_OK, img360.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getInstore(req, res, callback) {
	return instore(req)
		.then(function (products) {

			return callback(
				null,
				success(products.status, K.CODES.EVERYTHING_IS_OK, products.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getHistory(req, res, callback) {
	return history(req)
		.then(function (history) {

			return callback(
				null,
				success(history.status, K.CODES.EVERYTHING_IS_OK, history.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function disableSku(req, res, callback) {
	return disableSkuFunc(req)
		.then(function (disableSkuFunc) {

			return callback(
				null,
				success(disableSkuFunc.status, K.CODES.EVERYTHING_IS_OK, disableSkuFunc.message)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function enableSku(req, res, callback) {
	return enableSkuFunc(req)
		.then(function (enableSkuFunc) {

			return callback(
				null,
				success(enableSkuFunc.status, K.CODES.EVERYTHING_IS_OK, enableSkuFunc.message)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getProductDetails(req) {
	return new Promise((resolve, reject) => {
		commonHelper.findAggregate("Sneakers", [{ $match: { product_sku_id: req.params.skuId } }, { $project: { history: 0 } }])
			.then(function (data) {
				resolve({ "status": "success", "data": { "productInfo": data } });
			});
	});
}

function getSkuDetail(req) {
	return new Promise((resolve, reject) => {
		commonHelper.findFromMongo("SKU", { product_sku_id: req.params.skuId })
			.then(function (data) {
				resolve({ "status": "success", "data": { "productInfo": data } });
			});
	});
}

function getHeats(req) {
	var today = commonHelper.getToday();
	var twoMonthsData = commonHelper.getDateFn(commonHelper.getToday(), 61);
	return new Promise((resolve, reject) => {
		getColorData()
			.then(function (colorData) {
				var query = [
					{
						$match: {
							$and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { product_release_date: { $gte: today, $lte: twoMonthsData } }, { "ResellValuePourcent": { $gt: 25 } }, { product_name: { $ne: null } }, { product_name: { $not: /(TD)/ } }, { product_name: { $not: /(PS)/ } }, { product_name: { $not: /Kids/ } }]
						}
					},
					{
						$project:
						{
							_id: 0,
							ProductSKU: "$product_sku_id",
							ProductImage: "$product_thumbUrl",
							ProductName: "$product_name",
							MonthDay: "$product_release_date",
							ResellValuePourcent: "$ResellValuePourcent",
							product_colorway_reducted: "$product_colorway",
							Pictures: {
								$map:
								{
									input: "$product_image_360",
									as: "pic",
									in: "$$pic",
								}
							},
						}
					},
					{ $sort: { MonthDay: 1 } },
					// { $limit: 10 }
				];
				commonHelper.findAggregate("SKU", query)
					.then(function (data) {
						var finalData = [];
						data.forEach((i, index) => {
							var obj = {};
							var day = new Date(i.MonthDay).toLocaleString('en-us', { month: 'short', day: 'numeric' });
							var date = day.split(' ');
							var dateState;
							if (date[1] > 3 && date[1] < 21) {
								dateState = 'th';
							} else {
								switch (date[1] % 10) {
									case 1:
										dateState = 'st';
										break;
									case 2:
										dateState = 'nd';
										break;
									case 3:
										dateState = 'rd';
										break;
									default:
										dateState = 'th';
								}
							}
							obj.ProductSKU = i.ProductSKU;
							if (i.ProductImage === undefined || i.ProductImage === null) {
								obj.ProductImage = "";
							} else {
								obj.ProductImage = i.ProductImage;
							}
							if (i.ProductName === undefined || i.ProductName === null) {
								obj.ProductName = "";
							} else {
								obj.ProductName = i.ProductName;
							}
							if (i.MonthDay === undefined || i.MonthDay === null) {
								obj.MonthDay = "";
							} else {
								obj.MonthDay = `${date[0]}, ${date[1]}`;
							}
							if (i.MonthDay === undefined || i.MonthDay === null) {
								obj.dateState = "";
							} else {
								obj.dateState = dateState;
							}
							if (i.ResellValuePourcent === undefined || i.ResellValuePourcent === null) {
								obj.ResellValuePourcent = "";
							} else {
								obj.ResellValuePourcent = `${(i.ResellValuePourcent).toFixed()}%`;
							}
							if (i.product_colorway_reducted === null || i.product_colorway_reducted === undefined) {
								obj.product_colorway_reducted = "";
							} else {
								if (i.product_colorway_reducted.includes("/")) {
									var arr = i.product_colorway_reducted.split("/");
									if (arr[0] !== "White") {
										obj.product_colorway_reducted = arr[0];
									} else {
										obj.product_colorway_reducted = arr[1];
									}
								} else {
									obj.product_colorway_reducted = i.product_colorway_reducted
								}
							}
							if (colorData[i.ProductSKU] === undefined || colorData[i.ProductSKU] === null) {
								obj.product_colorway_HexCode = "";
							} else {
								obj.product_colorway_HexCode = colorData[i.ProductSKU]['hex'];
							}
							if (i.Pictures === undefined || i.Pictures === null || i.Pictures.length === 0) {
								obj["360Pictures"] = false;
							} else {
								obj["360Pictures"] = true;
							}
							finalData.push(obj);
						});
						resolve({ "status": "success", "data": { "heats": finalData } });
					});
			});
	});
}

function getRecentProducts(req) {
	var dateInterval = commonHelper.getDateArray(commonHelper.getToday(), 61, "decre");
	return new Promise((resolve, reject) => {
		var query = [
			{ $match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { product_last_sale: { $nin: [null, 0, '0'] } }, { product_release_date: { $in: dateInterval } }, { product_name: { $ne: null } }, { shops_number: { $ne: null } }, { shops_number: { $ne: 0 } }, { product_name: { $not: /(TD)/ } }, { product_name: { $not: /(PS)/ } }, { product_name: { $not: /Kids/ } }] } },
			{
				$project: {
					_id: 0,
					ProductSKU: "$product_sku_id",
					YearMonthDay: "$product_release_date",
					ProductImage: "$product_thumbUrl",
					ProductName: "$product_name",
					xxShops: "$shops_number",
					ProductMarketValue: "$product_lowest_price",
					ResellValuePourcent: "$ResellValuePourcent",
					ProductResellArrow: { $cond: { if: { $gt: ["$product_last_sale", "$product_RetailPrice"] }, then: "Up", else: "Down" } },
				}
			},
			{ $sort: { YearMonthDay: -1 } },
		];
		commonHelper.findAggregate("SKU", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					obj.ProductSKU = i.ProductSKU;
					if (i.YearMonthDay === undefined || i.YearMonthDay == null) {
						obj.YearMonthDay = "";
					} else {
						obj.YearMonthDay = i.YearMonthDay;
					}
					if (i.ProductImage === undefined || i.ProductImage === null) {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.xxShops === undefined) {
						obj.xxShops = 0;
					} else {
						obj.xxShops = i.xxShops;
					}
					if (i.ProductMarketValue === undefined || i.ProductMarketValue === null) {
						obj.ProductMarketValue = "";
					} else {
						obj.ProductMarketValue = i.ProductMarketValue;
					}
					if (i.ResellValuePourcent === undefined || i.ResellValuePourcent === null) {
						obj.ResellValuePourcent = "";
					} else {
						obj.ResellValuePourcent = i.ResellValuePourcent;
					}
					if (i.ProductResellArrow === undefined || i.ProductResellArrow === null) {
						obj.ProductResellArrow = "";
					} else {
						obj.ProductResellArrow = i.ProductResellArrow;
					}
					finalData.push(obj);
				})
				resolve({ "status": "success", "data": { "recentlyDropped": finalData } });
			});
	});
}

function getTopProducts(req) {
	return new Promise((resolve, reject) => {
		var query = [
			/*{ $match: { $and: [{ product_sku_id: { $nin: banSkus }}, { product_rank_number: { $lte: 48 } }, { product_thumbUrl: { $ne: null} }, { product_thumbUrl: { $ne: "https://sneaks4sure-s3.s3.eu-west-3.amazonaws.com/NoImage.png"} }, { product_rank_number: { $gt: 0 } }, { product_name: { $ne: null } }, { shops_number: { $ne: null } }, { shops_number: { $ne: 0 } }, { product_name: { $not: /(TD)/ }}, { product_name: { $not: /(PS)/ }}, { product_name: { $not: /Kids/ }}] } },*/
			{ $match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { product_thumbUrl: { $ne: null } }, { product_thumbUrl: { $ne: "https://sneaks4sure-s3.s3.eu-west-3.amazonaws.com/NoImage.png" } }, { product_name: { $ne: null } }, { shops_number: { $ne: null } }, { shops_number: { $ne: 0 } }, { product_name: { $not: /(TD)/ } }, { product_name: { $not: /(PS)/ } }, { product_name: { $not: /Kids/ } }] } },
			{
				$project: {
					_id: 0,
					ProductSKU: "$product_sku_id",
					ProductImage: "$product_thumbUrl",
					ProductName: "$product_name",
					product_change_arrow: "$product_change_arrow",
					xxShops: "$shops_number",
					ProductMarketValue: "$product_lowest_price",
					ProductResellArrow: { $cond: { if: { $gt: ["$product_last_sale", "$product_RetailPrice"] }, then: "Up", else: "Down" } },
					product_hit_number: "$product_hit_number",
				}
			},
			{ $sort: { product_hit_number: -1 } },
			{ $limit: 48 },
		];
		commonHelper.findAggregate("SKU", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductImage === undefined || i.ProductImage === null) {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.product_change_arrow === undefined || i.product_change_arrow === null) {
						obj.product_change_arrow = "";
					} else {
						obj.product_change_arrow = i.product_change_arrow;
					}
					if (i.xxShops === undefined || i.xxShops === null) {
						obj.xxShops = "";
					} else {
						obj.xxShops = i.xxShops;
					}
					if (i.ProductMarketValue === undefined || i.ProductMarketValue === null) {
						obj.ProductMarketValue = "";
					} else {
						obj.ProductMarketValue = i.ProductMarketValue;
					}
					if (i.ProductResellArrow === undefined || i.ProductResellArrow === null) {
						obj.ProductResellArrow = "";
					} else {
						obj.ProductResellArrow = i.ProductResellArrow;
					}
					finalData.push(obj);
				})
				resolve({ "status": "success", "data": { "topClicked": finalData } });
			});
	});
}

function getUpcoming(req, keyName) {
	//var today = commonHelper.getToday();
	var dateInterval = commonHelper.getDateArray(commonHelper.yesterdayDatetime(), 30, "decre");
	var dateIntervalUpcoming = commonHelper.getDateArray(commonHelper.getToday(), 183, "incre");
	var c = req.query.filter_resell;
	return new Promise((resolve, reject) => {
		getColorData()
			.then(function (colorData) {
				if (keyName === "upcomings") {
					var query;
					function Query(parameter) {
						var q = [
							{ $match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { product_release_date: { $in: dateIntervalUpcoming } }, { product_name: { $ne: null } }] } },
							parameter,
							{
								$lookup:
								{
									from: 'Calendar',
									localField: 'product_sku_id',
									foreignField: 'product_sku_id',
									as: 'sku'
								}
							},
							{
								$lookup:
								{
									from: 'Sneakers',
									localField: 'product_sku_id',
									foreignField: 'product_sku_id',
									as: 'sneakers'
								}
							},
							{
								$project: {
									_id: false,
									ProductSKU: "$product_sku_id",
									ProductBrand: "$product_brand",
									xxShops: {
										$map:
										{
											input: "$sku.shops_retail",
											as: "link",
											in: "$$link",
										}
									},
									RafflesLink: {
										$map:
										{
											input: "$sku.stores_raffles",
											as: "raffles",
											in: "$$raffles",
										}
									},
									ReleaseDate: "$product_release_date",
									ProductImage: "$product_smallimageUrl",
									ProductName: "$product_name",
									ResellValuePourcent: "$ResellValuePourcent",
									ResellValueProfit: "$ResellValueProfit",
									shops_number: "$shops_number",
									product_colorway_reducted: "$product_colorway",
									Pictures: {
										$map:
										{
											input: "$product_image_360",
											as: "pic",
											in: "$$pic",
										}
									},
									Sneakers: "$sneakers",
								}
							},
							{ $sort: { ReleaseDate: 1 } },
						];
						return q;
					}
					if (c === undefined) {
						query = Query({ $match: { $or: [{ ResellValuePourcent: { $eq: '' } }, { ResellValuePourcent: { $ne: '' } }] } });
					} else {
						var arr = c.split(",");
						if (arr.includes('high_resell') === true && arr.includes('medium_resell') === true && arr.includes('low_resell') === true) {
							query = Query({ $match: { ResellValuePourcent: { $gte: -100 } } });
						} else if (arr.includes('high_resell') === true && arr.includes('medium_resell') === true) {
							query = Query({ $match: { ResellValuePourcent: { $gte: 15 } } });
						} else if (arr.includes('low_resell') === true && arr.includes('medium_resell') === true) {
							query = Query({ $match: { $and: [{ ResellValuePourcent: { $gte: -100 } }, { ResellValuePourcent: { $lte: 25 } }] } });
						} else if (arr.includes('low_resell') === true && arr.includes('high_resell') === true) {
							query = Query({ $match: { $or: [{ $and: [{ ResellValuePourcent: { $gte: -100 } }, { ResellValuePourcent: { $lte: 14 } }] }, { ResellValuePourcent: { $gt: 25 } }] } });
						} else if (arr.includes('low_resell') === true) {
							query = Query({ $match: { $and: [{ ResellValuePourcent: { $gte: -100 } }, { ResellValuePourcent: { $lte: 14 } }] } });
						} else if (arr.includes('medium_resell') === true) {
							query = Query({ $match: { $and: [{ ResellValuePourcent: { $gte: 15 } }, { ResellValuePourcent: { $lte: 25 } }] } });
						} else if (arr.includes('high_resell') === true) {
							query = Query({ $match: { ResellValuePourcent: { $gt: 25 } } });
						}
					}
				} else {
					var query = [
						{ $match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { product_release_date: { $in: dateInterval } }, { product_name: { $ne: null } }] } },
						{
							$lookup:
							{
								from: 'Calendar',
								localField: 'product_sku_id',
								foreignField: 'product_sku_id',
								as: 'sku'
							}
						},
						{
							$lookup:
							{
								from: 'Sneakers',
								localField: 'product_sku_id',
								foreignField: 'product_sku_id',
								as: 'sneakers'
							}
						},
						{
							$project: {
								_id: false,
								ProductSKU: "$product_sku_id",
								ProductBrand: "$product_brand",
								xxShops: {
									$map:
									{
										input: "$sku.shops_retail",
										as: "link",
										in: "$$link",
									}
								},
								RafflesLink: {
									$map:
									{
										input: "$sku.stores_raffles",
										as: "raffles",
										in: "$$raffles",
									}
								},
								ReleaseDate: "$product_release_date",
								ProductImage: "$product_smallimageUrl",
								ProductName: "$product_name",
								ResellValuePourcent: "$ResellValuePourcent",
								ResellValueProfit: "$ResellValueProfit",
								shops_number: "$shops_number",
								product_colorway_reducted: "$product_colorway",
								Pictures: {
									$map:
									{
										input: "$product_image_360",
										as: "pic",
										in: "$$pic",
									}
								},
								Sneakers: "$sneakers",
							}
						},
						{ $sort: { ReleaseDate: -1 } },
					];
				}
				commonHelper.findAggregate("SKU", query)
					.then(function (data) {
						var finalData = {};
						var cData = [];
						data.forEach((key) => {
							var obj = {};
							var arr = [];
							var releaseDate = new Date(key.ReleaseDate).toLocaleString('en-us', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
							var date = releaseDate.split(', ');
							var dateNum = date[1].split(' ');
							var dateState;
							if (dateNum[1] > 3 && dateNum[1] < 21) {
								dateState = 'th';
							} else {
								switch (dateNum[1] % 10) {
									case 1:
										dateState = 'st';
										break;
									case 2:
										dateState = 'nd';
										break;
									case 3:
										dateState = 'rd';
										break;
									default:
										dateState = 'th';
								}
							}
							obj.ReleaseDate = releaseDate;
							obj.ProductSKU = key.ProductSKU;
							if (key.ProductImage === undefined || key.ProductImage === null) {
								obj.ProductImage = "";
							} else {
								obj.ProductImage = key.ProductImage;
							}
							if (key.ProductName === undefined || key.ProductName === null) {
								obj.ProductName = "";
							} else {
								obj.ProductName = key.ProductName;
							}
							if (key.ReleaseDate === undefined || key.ReleaseDate == null) {
								obj.dateState = "";
							} else {
								obj.dateState = dateState;
							}
							if (key.ProductBrand === undefined || key.ProductBrand === null) {
								obj.ProductBrand = "";
							} else {
								obj.ProductBrand = key.ProductBrand;
							}
							if (key.RafflesLink[0] !== undefined) {
								if (key.RafflesLink[0].length !== 0) {
									key.RafflesLink[0].forEach((j) => {
										if (shopData.includes(j.raffle_store_name) === false) {
											arr.push(j);
										}
									});
								}
							}
							if (key.xxShops[0] !== undefined && key.xxShops[0].length !== 0) {
								key.xxShops[0].forEach((j) => {
									if (shopData.includes(j.shop_name) === false) {
										arr.push(j);
									}
								});
							}
							var size = arr.length;
							productdata.forEach(i => {
								if (key.Sneakers.length !== 0 && shopData.includes(i.priceSize_key) === false && key.Sneakers[0]['product_' + i.priceSize_key + '_priceSize'] !== undefined && key.Sneakers[0]['product_' + i.priceSize_key + '_priceSize'] !== "-" && key.Sneakers[0]['product_' + i.priceSize_key + '_priceSize'].length !== 0) {
									size = size + 1;
								}
							})
							obj.xxShops = size;
							if (key.ResellValuePourcent === undefined || key.ResellValuePourcent === null || key.ResellValuePourcent === "0%" || key.ResellValuePourcent === 0) {
								obj.ResellValuePourcent = "TBC";
							} else if (isNaN(key.ResellValuePourcent)) {
								obj.ResellValuePourcent = key.ResellValuePourcent;
							} else {
								obj.ResellValuePourcent = `${key.ResellValuePourcent}%`;
							}
							if (key.ResellValueProfit === undefined || key.ResellValueProfit === null || key.ResellValueProfit === 0) {
								obj.ResellValueProfit = "TBC";
							} else {
								obj.ResellValueProfit = key.ResellValueProfit;
							}
							if (key.Pictures === undefined || key.Pictures === null || key.Pictures.length === 0) {
								obj["360Pictures"] = false;
							} else {
								obj["360Pictures"] = true;
							}
							if (obj.ResellValuePourcent === "" || obj.ResellValuePourcent === "TBC") {
								obj.ResellValueState = '-';
							} else {
								var temp = parseInt(obj.ResellValuePourcent.replace('%', ''));
								if (temp >= -100 && temp <= 14) {
									obj.ResellValueState = 'Low';
								} else if (temp >= 15 && temp <= 25) {
									obj.ResellValueState = 'Medium';
								} else if (temp > 25 && temp <= 50) {
									obj.ResellValueState = 'High';
								} else if (temp > 50) {
								  obj.ResellValueState = 'Heat';
								} else {
									obj.ResellValueState = '-';
								}
							}
							if (key.product_colorway_reducted === null || key.product_colorway_reducted === undefined) {
								obj.product_colorway_reducted = "";
							} else {
								if (key.product_colorway_reducted.includes("/")) {
									var arr = key.product_colorway_reducted.split("/");
									if (arr[0] !== "White") {
										obj.product_colorway_reducted = arr[0];
									} else {
										obj.product_colorway_reducted = arr[1];
									}
								} else {
									obj.product_colorway_reducted = key.product_colorway_reducted
								}
							}
							if (colorData[key.ProductSKU] === undefined || colorData[key.ProductSKU] === null) {
								obj.product_colorway_HexCode = "";
							} else {
								obj.product_colorway_HexCode = colorData[key.ProductSKU]['hex'];
							}
							if (obj.xxShops !== 0 || (key.shops_number !== undefined && key.shops_number !== 0)) {
								cData.push(obj);
							}
						});
						const groupByKey = (list, key, { omitKey = false }) => list.reduce((hash, { [key]: value, ...rest }) => ({ ...hash, [value]: (hash[value] || []).concat(omitKey ? { ...rest } : { [key]: value, ...rest }) }), {})
						var fData = groupByKey(cData, 'ReleaseDate', { omitKey: true });
						for (const [key, value] of Object.entries(fData)) {
							function compare(a, b) {
								let NameA;
								let NameB;
								if (a.ProductName !== undefined) {
									NameA = a.ProductName.toUpperCase();
								}
								if (b.ProductName !== undefined) {
									NameB = b.ProductName.toUpperCase();
								}
								let comparison = 0;
								if (NameA > NameB) {
									comparison = 1;
								} else if (NameA < NameB) {
									comparison = -1;
								}
								return comparison;
							}
							value.sort(compare);
						}
						finalData[keyName] = fData;
						resolve({ "status": "success", "data": finalData });
					});
			});
	});
}

function gets4sNews(req) {
	var arr = [];
	return new Promise((resolve, reject) => {
		const directoryPath = path.join(__dirname, '../../S4S/products');
		fs.readdir(directoryPath, function (err, files) {
			if (err) {
				reject(err);
			}
			else {
				files.forEach(function (file, index) {
					const absolutePath = process.env.LOCALURL + 'download/' + file;
					arr.push(absolutePath);
				});
				resolve({ "status": "success", "data": { "s4sNews": arr } });
			}
		});
		// arr = [
		// 	"https://www.sneaks4sure.com/sneakers/trend/s4s01.jpeg",
		// 	"https://www.sneaks4sure.com/sneakers/trend/s4s02.jpeg",
		// 	"https://www.sneaks4sure.com/sneakers/trend/s4s03.jpeg"
		// ];
		// resolve({ "status": "success", "data": { "s4sNews": arr } });
	});
}

function raffles(req) {
	var today = commonHelper.getToday();
	return new Promise((resolve, reject) => {
		var query
		function Query(parameter) {
			var q = [
				{
					$lookup:
					{
						from: 'Calendar',
						localField: 'product_sku_id',
						foreignField: 'product_sku_id',
						as: 'sku'
					}
				},
				{
					$lookup:
					{
						from: 'Instore',
						localField: 'product_sku_id',
						foreignField: 'product_sku',
						as: 'instore'
					}
				},
				{
					$match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, parameter, { product_name: { $ne: null } }] }
				},
				{
					$project: {
						_id: 0,
						ProductSKU: "$product_sku_id",
						ProductImage: "$product_smallimageUrl_clean",
						ProductName: "$product_name",
						ProductBrand: "$product_brand",
						Country: {
							$map:
							{
								input: "$instore.store_country",
								as: "countries",
								in: "$$countries",
							}
						},
						Shop: {
							$map:
							{
								input: "$sku.stores_raffles",
								as: "shop",
								in: "$$shop",
							}
						},
						CountryFlag: {
							$map:
							{
								input: "$instore.store_country_pic_url",
								as: "countryFlag",
								in: "$$countryFlag"
							}
						},
						RetailPrice: "$product_RetailPrice",
						ReleaseDate: "$product_release_date",
						ColorWay: "$product_colorway",
						ProductImage360: {
							$map:
							{
								input: "$product_image_360",
								as: "image",
								in: "$$image",
							}
						},
						ProductLike: "$product_like",
						ProductDislike: "$product_dislike",
					}
				}
			];
			return q;
		}
		if (req.params.skuId !== undefined) {
			query = Query({ product_sku_id: req.params.skuId });
		} else {
			query = Query({ product_release_date: { $gt: today } });
		}
		commonHelper.findAggregate("SKU", query)
			.then(function (data) {
				var finaldata = [];
				data.forEach((key) => {
					var obj = {};
					obj.ProductSKU = key.ProductSKU;
					if (key.ProductImage === undefined || key.ProductImage === null) {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = key.ProductImage;
					}
					if (key.ProductName === undefined || key.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = key.ProductName;
					}
					if (key.ProductBrand === undefined || key.ProductBrand === null) {
						obj.ProductBrand = "";
					} else {
						obj.ProductBrand = key.ProductBrand;
					}
					obj.ShopName = [];
					obj.ShopLocation = [];
					obj.ShopLogo = [];
					obj.ShopShipping = [];
					obj.ShopRaffleMethod = [];
					obj.ShopRaffleAccount = [];
					obj.ShopOpenTime = [];
					obj.ShopCloseTime = [];
					obj.ShopRaffeLink = [];
					obj.RegionLogo = [];
					obj.ShopLocationLogo = [];
					if (key.Shop !== null && key.Shop[0] !== undefined && key.Shop[0].length !== 0) {
						key.Shop[0].forEach(j => {
							if (banDomains.includes(j.raffle_store_name) === false && shopData.includes(j.raffle_store_name) === false && j.raffle_store_name !== undefined) {
								obj.ShopName.push(j.raffle_store_name);
								if (j.raffle_region === undefined) {
									obj.ShopLocation.push("-");
								} else {
									obj.ShopLocation.push(j.raffle_region);
								}
								if (j.raffle_store_logo_url === undefined) {
									obj.ShopLogo.push("-");
								} else {
									obj.ShopLogo.push(j.raffle_store_logo_url);
								}
								if (j.raffle_shipping_mode === undefined) {
									obj.ShopShipping.push("-");
								} else {
									obj.ShopShipping.push(j.raffle_shipping_mode);
								}
								if (j.raffle_type === undefined) {
									j.ShopRaffleMethod.push("-");
								} else {
									obj.ShopRaffleMethod.push(j.raffle_type);
								}
								if (j.raffle_account_required === undefined) {
									obj.ShopRaffleAccount.push("-");
								} else {
									obj.ShopRaffleAccount.push(j.raffle_account_required);
								}
								if (j.raffle_open_time === undefined || j.raffle_open_time === '') {
									obj.ShopOpenTime.push("-");
								} else {
									obj.ShopOpenTime.push(j.raffle_open_time);
								}
								if (j.raffle_close_time === undefined || j.raffle_close_time === '') {
									obj.ShopCloseTime.push("-");
								} else {
									obj.ShopCloseTime.push(j.raffle_close_time);
								}
								if (j.raffle_url === undefined) {
									obj.ShopRaffeLink, push("-");
								} else {
									obj.ShopRaffeLink.push(j.raffle_url);
								}
								if (j.raffle_region_logo === undefined) {
									obj.RegionLogo.push("-");
									obj.ShopLocationLogo.push("-");
								} else {
									obj.RegionLogo.push(j.raffle_region_logo);
									obj.ShopLocationLogo.push(j.raffle_region_logo);
								}
							}
						});
					} else {
						obj.ShopOpenTime = "-";
						obj.ShopCloseTime = "-";
					}
					if (key.RetailPrice === undefined || key.RetailPrice === null) {
						obj.RetailPrice = "";
					} else {
						obj.RetailPrice = key.RetailPrice;
					}
					if (key.ReleaseDate === undefined || key.ReleaseDate === null) {
						obj.ReleaseDate = "";
					} else {
						obj.ReleaseDate = key.ReleaseDate;
					}
					if (key.ColorWay === undefined || key.ColorWay === null) {
						obj.ColorWay = "";
					} else {
						obj.ColorWay = key.ColorWay;
					}
					if (key.ProductImage360 === undefined || key.ProductImage360 === null) {
						obj.ProductImage360 = [];
					} else {
						obj.ProductImage360 = key.ProductImage360.sort();
					}
					if (key.ProductLike === undefined || key.ProductLike === null) {
						obj.ProductLike = 0;
					} else {
						obj.ProductLike = key.ProductLike;
					}
					if (key.ProductDislike === undefined || key.ProductDislike === null) {
						obj.ProductDislike = 0;
					} else {
						obj.ProductDislike = key.ProductDislike;
					}
					if (key.Country !== undefined && key.Country !== null) {
						obj.StoreCountrys = key.Country.filter(commonHelper.onlyUnique);
					} else {
						obj.StoreCountrys = [];
					}
					if (key.CountryFlag === undefined || key.CountryFlag === null) {
						obj.RegionLogo = [];
					} else {
						obj.RegionLogo = key.CountryFlag.filter(commonHelper.onlyUnique);
					}
					finaldata.push(obj);
				});
				resolve({ "status": "success", "data": { "raffles": finaldata } });
			});
	});
}

function retail(req) {
	var today = commonHelper.getToday();
	return new Promise((resolve, reject) => {
		var query;
		function Query(parameter) {
			var q = [
				{
					$lookup:
					{
						from: 'Calendar',
						localField: 'product_sku_id',
						foreignField: 'product_sku_id',
						as: 'sku'
					}
				},
				{
					$match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, parameter, { product_name: { $ne: null } }] }
				},
				{
					$project: {
						_id: 0,
						ProductSKU: "$product_sku_id",
						ProductImage: "$product_smallimageUrl_clean",
						ProductName: "$product_name",
						shops_retail: {
							$map:
							{
								input: "$sku.shops_retail",
								as: "shop",
								in: "$$shop",
							}
						},
						ProductImage360: {
							$map:
							{
								input: "$product_image_360",
								as: "image",
								in: "$$image",
							}
						},
					}
				},
				// { $limit: 10 }
			];
			return q;
		}
		if (req.params.skuId === undefined) {
			query = Query({ product_release_date: { $gt: today } });
		} else {
			query = Query({ product_sku_id: req.params.skuId });
		}
		commonHelper.findAggregate("SKU", query)
			.then(function (data) {
				var finaldata = [];
				data.forEach(i => {
					var obj = {};
					var arr = [];
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductImage === undefined || i.ProductImage === null) {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.shops_retail[0] !== undefined) {
						if (i.shops_retail[0].length === 0 || i.shops_retail[0] === null) {
							var shop = {};
							shop.ShopLogo = "";
							shop.ShopName = "";
							shop.ShopPrice = "";
							shop.ShopLink = "";
							arr.push(shop);
						} else {
							i.shops_retail[0].forEach(j => {
								var shop = {};
								if (j.shop_logo === undefined || j.shop_logo === null) {
									shop._ShopLogo = "";
								} else {
									shop.ShopLogo = j.shop_logo;
								}
								if (j.shop_name === undefined || j.shop_name === null) {
									shop._ShopName = "";
								} else {
									shop._ShopName = j.shop_name;
								}
								if (j.shop_price === undefined || j.shop_price === null) {
									shop._ShopPrice = "";
								} else {
									shop._ShopPrice = j.shop_price;
								}
								if (j.shop_link === undefined || j.shop_link === null) {
									shop._ShopLink = "";
								} else {
									shop._ShopLink = j.shop_link;
								}
								if (banDomains.includes(j.shop_name) === false && shopData.includes(j.shop_name) === false) {
									arr.push(shop);
								}
							});
						}
					} else {
						var shop = {};
						shop._ShopLogo = "";
						shop._ShopName = "";
						shop._ShopPrice = "";
						shop._ShopLink = "";
						arr.push(shop);
					}
					obj.Shops = arr;
					if (i.ProductImage360 === undefined || i.ProductImage360 === null) {
						obj.ProductImage360 = [];
					} else {
						obj.ProductImage360 = i.ProductImage360.sort();
					}
					if (obj.Shops.length !== 0) {
						finaldata.push(obj);
					}
				});
				resolve({ "status": "success", "data": { "retail": finaldata } });
			});
	});
}

function productPage(req) {
	return new Promise((resolve, reject) => {
		getColorData()
			.then(function (colorData) {
				var today = commonHelper.getToday();
				if (req.params.skuId === undefined) {
					var query = [
						{
							$lookup:
							{
								from: 'Sneakers',
								localField: 'product_sku_id',
								foreignField: 'product_sku_id',
								as: 'sneakers'
							}
						},
						{ $match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { "product_release_date": { $gt: today } }, { product_name: { $ne: null } }] } },
						{ $sort: { product_release_date: 1 } },
						{
							$project: {
								_id: 0,
								ProductSKU: "$product_sku_id",
								ProductImage_clean: "$product_smallimageUrl_clean",
								ProductImage: "$product_smallimageUrl",
								ProductName: "$product_name",
								ProductBrand: "$product_brand",
								ProductCat: "$product_subCategory",
								ProductRetailPrice: "$product_RetailPrice",
								ProductReleaseDate: "$product_release_date",
								ProductColorWay: "$product_colorway",
								ResellValuePourcent: "$ResellValuePourcent",
								ResellValueProfit: "$ResellValueProfit",
								ProductImageOOTD: "$product_novelship_image",
								ProductImage360: {
									$map:
									{
										input: "$product_image_360",
										as: "image",
										in: "$$image",
									}
								},
								Shops: "$sneakers",
								ProductLike: "$product_like",
								ProductDislike: "$product_dislike",
							}
						},
					];
				} else if (banSkus.includes(req.params.skuId) === false && disableSkus.includes(req.params.skuId) === false) {
					var query = [
						{
							$lookup:
							{
								from: 'Sneakers',
								localField: 'product_sku_id',
								foreignField: 'product_sku_id',
								as: 'sneakers'
							}
						},
						{ $match: { $and: [{ product_sku_id: req.params.skuId }, { product_name: { $ne: null } }] } },
						{
							$project: {
								_id: 0,
								ProductSKU: "$product_sku_id",
								ProductImage_clean: "$product_smallimageUrl_clean",
								ProductImage: "$product_smallimageUrl",
								ProductName: "$product_name",
								ProductBrand: "$product_brand",
								ProductCat: "$product_subCategory",
								ProductRetailPrice: "$product_RetailPrice",
								ProductReleaseDate: "$product_release_date",
								ProductColorWay: "$product_colorway",
								ResellValuePourcent: "$ResellValuePourcent",
								ResellValueProfit: "$ResellValueProfit",
								ProductImageOOTD: "$product_novelship_image",
								ProductImage360: {
									$map:
									{
										input: "$product_image_360",
										as: "image",
										in: "$$image",
									}
								},
								Shops: "$sneakers",
								ProductLike: "$product_like",
								ProductDislike: "$product_dislike",
							}
						},
					];
				}
				commonHelper.findAggregate("SKU", query)
					.then(function (data) {
						var finalData = [];
						data.forEach(i => {
							var obj = {};
							var maindata = {};
							var Best = [];
							var sorted = [];
							obj.ProductSKU = i.ProductSKU;
							if (i.ProductImage_clean !== undefined && i.ProductImage_clean !== null) {
								obj.ProductImage = i.ProductImage_clean;
							} else if (i.ProductImage !== undefined && i.ProductImage !== null) {
								obj.ProductImage = i.ProductImage;
							} else {
								obj.ProductImage = "";
							}
							if (i.ProductName === undefined || i.ProductName === null) {
								obj.ProductName = "";
							} else {
								obj.ProductName = i.ProductName;
							}
							if (i.ProductLike === undefined || i.ProductLike === null) {
								obj.ProductLike = 0;
							} else {
								obj.ProductLike = i.ProductLike;
							}
							if (i.ProductDislike === undefined || i.ProductDislike === null) {
								obj.ProductDislike = 0;
							} else {
								obj.ProductDislike = i.ProductDislike;
							}
							if (i.ProductBrand === undefined || i.ProductBrand === null) {
								obj.ProductBrand = "";
							} else {
								obj.ProductBrand = i.ProductBrand;
							}
							if (i.ProductCat === undefined || i.ProductCat === null) {
								obj.ProductCat = "";
							} else {
								obj.ProductCat = i.ProductCat;
							}
							if (i.ProductRetailPrice === undefined || i.ProductRetailPrice === null) {
								obj.ProductRetailPrice = "";
							} else {
								obj.ProductRetailPrice = i.ProductRetailPrice;
							}
							if (i.ProductReleaseDate === undefined || i.ProductReleaseDate === null) {
								obj.ProductReleaseDate = "";
							} else {
								obj.ProductReleaseDate = i.ProductReleaseDate;
							}
							if (i.ProductColorWay === undefined || i.ProductColorWay === null) {
								obj.ProductColorWay = "";
							} else {
								obj.ProductColorWay = i.ProductColorWay;
							}
							if (i.ResellValuePourcent === undefined || i.ResellValuePourcent === null || i.ResellValuePourcent === "TBC" || i.ResellValuePourcent === "") {
								obj.ResellValuePourcent = 0;
							} else {
								obj.ResellValuePourcent = i.ResellValuePourcent;
							}
							if (i.ResellValueProfit === undefined || i.ResellValueProfit === null || i.ResellValueProfit === "-") {
								obj.ResellValueProfit = 0;
							} else {
								obj.ResellValueProfit = i.ResellValueProfit;
							}
							if (obj.ResellValuePourcent === undefined || obj.ResellValuePourcent === null || obj.ResellValuePourcent === "TBC" || obj.ResellValuePourcent === "") {
								obj.ResellValueState = "";
							} else {
								if (obj.ResellValuePourcent >= -100 && obj.ResellValuePourcent <= 14) {
									obj.ResellValueState = 'Low';
								} else if (obj.ResellValuePourcent >= 15 && obj.ResellValuePourcent <= 25) {
									obj.ResellValueState = 'Medium';
								} else if (obj.ResellValuePourcent > 25) {
									obj.ResellValueState = 'High';
								} else {
									obj.ResellValueState = '';
								}
							}
							if (i.ProductName !== undefined && (i.ProductName.includes("Nike") === true || i.ProductName.includes("Jordan") === true)) {
								if (i.ProductName.includes("(W)") === true) {
									obj.sizeSlider = "Nike&JordanWomen";
								} else if (i.ProductName.includes("(GS)") === true) {
									obj.sizeSlider = "Nike&Jordan(GS)";
								} else if (i.ProductName.includes("(PS)") === true) {
									obj.sizeSlider = "Nike&Jordan(PS)";
								} else if (i.ProductName.includes("(TD)") === true) {
									obj.sizeSlider = "Nike&Jordan(TD)";
								} else {
									obj.sizeSlider = "Nike&Jordan";
								}
							} else if (i.ProductName !== undefined && (i.ProductName.includes("Adidas") === true || i.ProductName.includes("Yeezy") === true || i.ProductName.includes("adidas") === true)) {
								if (i.ProductName.includes("(W)") === true) {
									obj.sizeSlider = "Adidas&YeezyWomen";
								} else if (i.ProductName.includes("(Kids)") === true) {
									obj.sizeSlider = "Adidas&YeezyKids";
								} else if (i.ProductName.includes("Infants") === true) {
									obj.sizeSlider = "Adidas&YeezyInfants";
								} else {
									obj.sizeSlider = "Adidas&Yeezy";
								}
							} else if (i.ProductName !== undefined && (i.ProductName.includes("New Balance") === true)) {
								if (i.ProductName.includes("(W)") === true) {
									obj.sizeSlider = "NewBalanceWomen";
								} else if (i.ProductName.includes("(GS)") === true) {
									obj.sizeSlider = "NewBalance(GS)";
								} else if (i.ProductName.includes("(PS)") === true) {
									obj.sizeSlider = "NewBalance(PS)";
								} else if (i.ProductName.includes("(TD)") === true) {
									obj.sizeSlider = "NewBalance(TD)";
								} else {
									obj.sizeSlider = "NewBalance";
								}
							} else {
								obj.sizeSlider = "Regular";
							}
							if (i.ProductColorWay === null || i.ProductColorWay === undefined) {
								obj.product_colorway_reducted = "";
							} else {
								if (i.ProductColorWay.includes("/")) {
									var arr = i.ProductColorWay.split("/");
									if (arr[0] !== "White") {
										obj.product_colorway_reducted = arr[0];
									} else {
										obj.product_colorway_reducted = arr[1];
									}
								} else {
									obj.product_colorway_reducted = i.ProductColorWay
								}
							}
							if (colorData[i.ProductSKU] === undefined || colorData[i.ProductSKU] === null) {
								obj.product_colorway_HexCode = "";
							} else {
								obj.product_colorway_HexCode = colorData[i.ProductSKU]['hex'];
							}
							if (i.ProductImageOOTD === undefined || i.ProductImageOOTD === null || i.ProductImageOOTD.length === 1) {
								obj.ProductImageOOTD = "";
							} else {
								obj.ProductImageOOTD = i.ProductImageOOTD;
							}


							productdata.forEach(j => {
								var size = [];
								var shopUrl;
								var bbb = 'product_' + j.priceSize_key + '_priceSize';
								if (j.url_key !== undefined) {
									shopUrl = 'product_' + j.url_key + '_url';
								} else {
									shopUrl = 'product_' + j.priceSize_key + '_url';
								}
								if (i.Shops !== undefined && i.Shops.length !== 0) {
									if (i.Shops[0][bbb] !== undefined) {
										if (i.Shops[0][bbb] !== '-') {
											i.Shops[0][bbb].forEach(k => {
												if (size.includes(k[0]) === false) {
													size.push(k[0]);
												}
											})
											i.Shops[0][bbb].forEach(k => {
												size.forEach(l => {
												  if(l !== null){
													  var s;
													  if (l.toString().split('.')[1] !== undefined) {
														  //console.log(l);
														  if (l.toString().split('.')[1].includes('5') === true) {
															  s = l;
														  } else if (l.toString().split('.')[1].includes('0') === true) {
															  s = l.toString().split('.')[0];
														  } else {
															  l = '';
														  }
													  } else {
														  s = l;
														  //console.log(l);
													  }
													  var obj1 = {};
													  if (maindata[s] === undefined) {
														  maindata[s] = [];
													  }
													  if (k[0] === l && k[1] !== 0) {
														  if (typeof k[1] === 'string' && k[1].includes('$') === true) {
															  k[1] = k[1].replace('$', '')
														  }
														  obj1.Price = parseInt(k[1]);
														  obj1.Shop = j.priceSize_key;
														  if (j.TrustPilot !== undefined) {
															  if (j.TrustPilot[0] !== undefined) {
																  if (j.TrustPilot[0].shop_logo_new !== undefined) {
																	  obj1.ShopLogo = j.TrustPilot[0].shop_logo_new;
																  } else if (j.TrustPilot[0].shop_logo !== undefined) {
																	  obj1.ShopLogo = j.TrustPilot[0].shop_logo;
																  }
																  if (j.TrustPilot[0].score !== undefined) {
																	  obj1.ShopScore = parseFloat(j.TrustPilot[0].score);
																  }
																  if (j.TrustPilot[0].reviews !== undefined) {
																	  obj1.ShopReviews = j.TrustPilot[0].reviews;
																  }
															  }
														  }
														  if (i.Shops[0][shopUrl + '_affiliated'] != undefined) {
															  obj1.Link = i.Shops[0][shopUrl + '_affiliated'];
														  } else {
															  obj1.Link = i.Shops[0][shopUrl];
														  }
														  if(j.Shop_Location_Value === undefined || j.Shop_Location_Value === null){
							                  obj1.Shop_Location_Value = "";
							                } else {
							                  obj1.Shop_Location_Value = j.Shop_Location_Value;
							                }
														  if (banDomains.includes(obj1.Shop) === false && shopData.includes(obj1.Shop) === false) {
															  maindata[s].push(obj1);
														  }
													  }
													}
												})
											})
										}
									}
								}
							})
							//console.log(maindata);
							var testArrKeys = []
							var originalKeys = {}
							Object.keys(maindata).forEach(function (one) {
								var key = parseFloat(one)
								testArrKeys.push(key)
								if (originalKeys[key] === undefined) {
									originalKeys[key] = []
								}
								originalKeys[key].push(one)
							});
							testArrKeys.sort(function (a, b) {
								return a - b;
							});
							testArrKeys.forEach(p => {
								var num = originalKeys[p][0];
								sorted.push({ "Size": num, "Products": maindata[num] });
								originalKeys[p].shift();
							})
							obj.ProductSize = sorted;
							sorted.forEach(b => {
								var bestSize = [];
								var bestProduct = {};
								b.Products.forEach(p => {
									bestSize.push(p.Price);
								})
								var small = Math.min(...bestSize);
								b.Products.forEach(p => {
									if (p.Price === small) {
										bestProduct.Size = b.Size;
										bestProduct.Product = p;
									}
								})
								Best.push(bestProduct);
							})
							obj.ProductSizeBest = Best;
							if (i.ProductImage360 === undefined || i.ProductImage360 === null) {
								obj.ProductImage360 = [];
							} else {
								obj.ProductImage360 = i.ProductImage360.sort();
							}
							finalData.push(obj);
						})
						resolve({ "status": "success", "data": { "products": finalData } });
					});
			});
	});
}

function resell(req) {
	var today = commonHelper.getToday();
	return new Promise((resolve, reject) => {
		var query;
		function Query(parameter) {
			var q = [
				{
					$lookup:
					{
						from: 'Sneakers',
						localField: 'product_sku_id',
						foreignField: 'product_sku_id',
						as: 'sneakers'
					}
				},
				{
					$match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, parameter, { product_name: { $ne: null } }] }
				},
				{
					$project: {
						_id: 0,
						ProductSKU: "$product_sku_id",
						ProductName: "$product_name",
						ProductImage: "$product_smallimageUrl_clean",
						Shops: "$sneakers",
					}
				},
			];
			return q;
		}
		if (req.params.skuId !== undefined) {
			query = Query({ product_sku_id: req.params.skuId });
		} else {
			query = Query({ product_release_date: { $gt: today } });
		}
		commonHelper.findAggregate("SKU", query)
			.then(function (data) {
				var finalData = [];
				if (Array.isArray(data)) data.forEach(i => {
					var obj = {};
					var maindata = {};
					var Best = [];
					var sorted = [];
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.ProductImage === undefined || i.ProductImage === null) {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.ProductName.includes("Nike") === true || i.ProductName.includes("Jordan") === true) {
						if (i.ProductName.includes("(W)") === true) {
							obj.sizeSlider = "Nike&JordanWomen";
						} else if (i.ProductName.includes("(GS)") === true) {
							obj.sizeSlider = "Nike&Jordan(GS)";
						} else if (i.ProductName.includes("(PS)") === true) {
							obj.sizeSlider = "Nike&Jordan(PS)";
						} else if (i.ProductName.includes("(TD)") === true) {
							obj.sizeSlider = "Nike&Jordan(TD)";
						} else {
							obj.sizeSlider = "Nike&Jordan";
						}
					} else if (i.ProductName.includes("Adidas") === true || i.ProductName.includes("Yeezy") === true || i.ProductName.includes("adidas") === true) {
						if (i.ProductName.includes("(W)") === true) {
							obj.sizeSlider = "Adidas&YeezyWomen";
						} else if (i.ProductName.includes("(Kids)") === true) {
							obj.sizeSlider = "Adidas&YeezyKids";
						} else if (i.ProductName.includes("Infants") === true) {
							obj.sizeSlider = "Adidas&YeezyInfants";
						} else {
							obj.sizeSlider = "Adidas&Yeezy";
						}
					} else if (i.ProductName.includes("New Balance") === true) {
						if (i.ProductName.includes("(W)") === true) {
							obj.sizeSlider = "NewBalanceWomen";
						} else if (i.ProductName.includes("(GS)") === true) {
							obj.sizeSlider = "NewBalance(GS)";
						} else if (i.ProductName.includes("(PS)") === true) {
							obj.sizeSlider = "NewBalance(PS)";
						} else if (i.ProductName.includes("(TD)") === true) {
							obj.sizeSlider = "NewBalance(TD)";
						} else {
							obj.sizeSlider = "NewBalance";
						}
					} else {
						obj.sizeSlider = "Regular";
					}
					if (Array.isArray(productdata)) productdata.forEach(j => {
						var size = [];
						var shopUrl;
						var bbb = 'product_' + j.priceSize_key + '_priceSize';
						if (j.url_key !== undefined) {
							shopUrl = 'product_' + j.url_key + '_url';
						} else {
							shopUrl = 'product_' + j.priceSize_key + '_url';
						}
						if (i.Shops.length !== 0) {
							if (i.Shops[0][bbb] !== undefined && i.Shops[0][bbb] !== '-') {
								i.Shops[0][bbb].forEach(k => {
									if (size.includes(k[0]) === false) {
										size.push(k[0]);
									}
								})
								i.Shops[0][bbb].forEach(k => {
									size.forEach(l => {
										var obj1 = {};
										if (maindata[l] === undefined) {
											maindata[l] = [];
										}
										if (k[0] === l && k[1] !== 0) {
											if (typeof k[1] === 'string' && k[1].includes('$') === true) {
												k[1] = k[1].replace('$', '')
											}
											obj1.Price = parseInt(k[1]);
											obj1.Shop = j.priceSize_key;
											if (j.TrustPilot !== undefined) {
												if (j.TrustPilot[0] !== undefined) {
													if (j.TrustPilot[0].shop_logo_new !== undefined) {
														obj1.ShopLogo = j.TrustPilot[0].shop_logo_new;
													} else if (j.TrustPilot[0].shop_logo !== undefined) {
														obj1.ShopLogo = j.TrustPilot[0].shop_logo;
													}
													if (j.TrustPilot[0].score !== undefined) {
														obj1.ShopScore = parseFloat(j.TrustPilot[0].score);
													}
													if (j.TrustPilot[0].reviews !== undefined) {
														obj1.ShopReviews = j.TrustPilot[0].reviews;
													}
												}
											}
											if (i.Shops[0][shopUrl + '_affiliated'] != undefined) {
												obj1.Link = i.Shops[0][shopUrl + '_affiliated'];
											} else {
												obj1.Link = i.Shops[0][shopUrl];
											}
											if(j.Shop_Location_Value === undefined || j.Shop_Location_Value === null){
			                  obj1.Shop_Location_Value = "";
			                } else {
			                  obj1.Shop_Location_Value = j.Shop_Location_Value;
			                }
											if (banDomains.includes(obj1.Shop) === false && shopData.includes(obj1.Shop) === false) {
												maindata[l].push(obj1);
											}
										}
									})
								})
							}
						}
					})
					var testArrKeys = []
					var originalKeys = {}
					Object.keys(maindata).forEach(function (one) {
						var key = parseFloat(one)
						testArrKeys.push(key)
						if (originalKeys[key] === undefined) {
							originalKeys[key] = []
						}
						originalKeys[key].push(one)
					});
					testArrKeys.sort(function (a, b) {
						return a - b;
					});
					testArrKeys.forEach(p => {
						var num = originalKeys[p][0];
						sorted.push({ "Size": num, "Products": maindata[num] });
						originalKeys[p].shift();
					})
					obj.ProductSize = sorted;
					sorted.forEach(b => {
						var bestSize = [];
						var bestProduct = {};
						b.Products.forEach(p => {
							bestSize.push(p.Price);
						})
						var small = Math.min(...bestSize);
						b.Products.forEach(p => {
							if (p.Price === small) {
								bestProduct.Size = b.Size;
								bestProduct.Product = p;
							}
						})
						Best.push(bestProduct);
					})
					obj.ProductSizeBest = Best;
					finalData.push(obj);
				})
				resolve({ "status": "success", "data": { "resell": finalData } });
			});
	});
}

function restock(req) {
	const yesterday = commonHelper.yesterdayDatetime();
	return new Promise((resolve, reject) => {
		var query = [
			{
				$match: { $and: [{ product_sku_id: { $nin: banSkus, $nin: disableSkus } }, { update_date: { $gt: yesterday } }, { product_name: { $ne: null } }, { product_name: { $ne: "" } }] }
			},
			{
				$lookup: {
					from: "SKU",
					localField: "product_sku_id",
					foreignField: "product_sku_id",
					as: "sku"
				}
			},
			{
				$project: {
					_id: 0,
					DateTime: "$update_date",
					ProductSKU: "$product_sku_id",
					ProductName: "$product_name",
					ShopName: "$shop_name",
					ProductImage: "$product_img_url",
					Url_Link: "$product_shortened_affiliate_url",
					Brand: "$brand_name",
					RegionName: "$region_name",
					shortSize: "$product_shortened_size_atc",
					ResellValuePourcent: "$sku.ResellValuePourcent",
					ResellValueProfit: "$sku.ResellValueProfit",
				}
			},
			{ $sort: { DateTime: -1 } }
		];
		commonHelper.findAggregate("Restock", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					if (i.DateTime === undefined || i.DateTime === null) {
						obj.DateTime = "";
					} else {
						obj.DateTime = i.DateTime;
					}
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.ShopName === undefined || i.ShopName === null) {
						obj.ShopName = "";
					} else {
						obj.ShopName = i.ShopName;
					}
					if (i.ProductImage === undefined || i.ProductImage === null || i.ProductImage === 'null') {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.Url_Link === undefined || i.Url_Link === null || i.Url_Link === "") {
						obj.Url_Link = {};
					} else {
						obj.Url_Link = JSON.parse(i.Url_Link);
					}
					if (i.Brand === undefined || i.Brand === null || i.Brand === 'null') {
						obj.Brand = "";
					} else {
						obj.Brand = i.Brand;
					}
					if (i.RegionName === undefined || i.RegionName === null) {
						obj.RegionName = "";
					} else {
						obj.RegionName = i.RegionName;
					}
					if (i.shortSize === undefined || i.shortSize === null) {
						obj.product_shortened_size_atc = "";
					} else {
						obj.product_shortened_size_atc = JSON.parse(i.shortSize);
					}
					if (i.ResellValuePourcent[0] === undefined || i.ResellValuePourcent[0] === null) {
						obj.ResellValuePourcent = "";
					} else {
						obj.ResellValuePourcent = i.ResellValuePourcent[0];
					}
					if (i.ResellValueProfit[0] === undefined || i.ResellValueProfit[0] === null) {
						obj.ResellValueProfit = "";
					} else {
						obj.ResellValueProfit = i.ResellValueProfit[0];
					}
					if (banDomains.includes(obj.ShopName) === false && shopData.includes(obj.ShopName) === false) {
						finalData.push(obj);
					}
				})
				resolve({ "status": "success", "data": { "restock": finalData } });
			});
	});
}

function restockByTrigger(req) {
	// const triggerValue = process.env.TRIGGER_VALUE;
	const triggerValue = 1;	//triger every 1 minutes
	const triggerTime = new Date(Date.now() - 1000 * triggerValue * 60);
	return new Promise((resolve, reject) => {
		var query = [
			{
				$match: { $and: [{ update_date: { $gt: triggerTime } }, { product_name: { $ne: null } }, { product_name: { $ne: "" } }] }
			},
			{
				$project: {
					_id: 0,
					DateTime: "$update_date",
					ProductSKU: "$product_sku_id",
					ProductName: "$product_name",
					ShopName: "$shop_name",
					ProductImage: "$product_img_url",
					Url_Link: "$product_shortened_affiliate_url",
					Brand: "$brand_name",
					RegionName: "$region_name",
				}
			},
			{ $sort: { DateTime: -1 } }
		];
		commonHelper.findAggregate("Restock", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					if (i.DateTime === undefined || i.DateTime === null) {
						obj.DateTime = "";
					} else {
						obj.DateTime = i.DateTime;
					}
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.ShopName === undefined || i.ShopName === null) {
						obj.ShopName = "";
					} else {
						obj.ShopName = i.ShopName;
					}
					if (i.ProductImage === undefined || i.ProductImage === null || i.ProductImage === 'null') {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.Url_Link === undefined || i.Url_Link === null || i.Url_Link === "") {
						obj.Url_Link = {};
					} else {
						obj.Url_Link = JSON.parse(i.Url_Link);
					}
					if (i.Brand === undefined || i.Brand === null || i.Brand === 'null') {
						obj.Brand = "";
					} else {
						obj.Brand = i.Brand;
					}
					if (i.RegionName === undefined || i.RegionName === null) {
						obj.RegionName = "";
					} else {
						obj.RegionName = i.RegionName;
					}
					if (banDomains.includes(obj.ShopName) === false && shopData.includes(obj.ShopName) === false) {
						finalData.push(obj);
					}
				})
				resolve({ "status": "success", "data": { "restock": finalData } });
			});
	});
}

function img360(req) {
	return new Promise((resolve, reject) => {
		var query = [
			{
				$match: { product_sku_id: { $nin: banSkus, $nin: disableSkus } }
			},
			{
				$project: {
					_id: 0,
					ProductSKU: "$product_sku_id",
					ProductImage360: {
						$map:
						{
							input: "$product_image_360",
							as: "image",
							in: "$$image",
						}
					},
				}
			},
		];
		commonHelper.findAggregate("SKU", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductImage360 === null || i.ProductImage360 === undefined) {
						obj.ProductImage360 = [];
					} else {
						obj.ProductImage360 = i.ProductImage360.sort();
					}
					finalData.push(obj);
				})
				resolve({ "status": "success", "data": { "image360": finalData } });
			});
	});
}

function disableShopFunc(req) {
	return new Promise((resolve, reject) => {
		let query = { 'shop': req.params.shop };
		commonHelper.findFromMongo("Shops", query)
			.then(function (data) {
				if (data.length > 0) {
					commonHelper.updateMongo("Shops", query, { '$set': { 'status': 0 } })
						.then(function () {
							getShopStatus();
							nrc.run('python3 ' + process.env.LOWESTPRIZEPATH + 'lowestprice.py', { onData: dataCallback }).then(function (exitCodes) {
							}, function (err) {
								console.log('Command failed to run with error: ', err);
							});
							resolve({ "status": "success", "message": "Shop Updated" });
						});
				} else {
					reject("Shop Not Found");
				}
			})
	});
}

function enableShopFunc(req) {
	return new Promise((resolve, reject) => {
		let query = { 'shop': req.params.shop };
		commonHelper.findFromMongo("Shops", query)
			.then(function (data) {
				if (data.length > 0) {
					commonHelper.updateMongo("Shops", query, { '$set': { 'status': 1 } })
						.then(function () {
							getShopStatus();
							nrc.run('python3 ' + process.env.LOWESTPRIZEPATH + 'lowestprice.py', { onData: dataCallback }).then(function (exitCodes) {
							}, function (err) {
								console.log('Command failed to run with error: ', err);
							});
							resolve({ "status": "success", "message": "Shop Updated" });
						});
				} else {
					reject("Shop Not Found");
				}
			})
	});
}

function dataCallback(output) {
	console.log(output);
}

function getProductTextColor(req) {
	return new Promise((resolve, reject) => {
		getColorData()
			.then(function (colorData) {
				var query = [
					{
						$match: { product_sku_id: { $nin: banSkus, $nin: disableSkus } }
					},
					{
						$project: {
							_id: 0,
							ProductSKU: "$product_sku_id",
							product_colorway_reducted: "$product_colorway",
						}
					},
					{ $limit: 50 }
				];
				commonHelper.findAggregate("SKU", query)
					.then(function (data) {
						var finalData = [];
						data.forEach(i => {
							var obj = {};
							obj.ProductSKU = i.ProductSKU;
							if (i.product_colorway_reducted === null || i.product_colorway_reducted === undefined) {
								obj.product_colorway_reducted = "";
							} else {
								if (i.product_colorway_reducted.includes("/")) {
									var arr = i.product_colorway_reducted.split("/");
									if (arr[0] !== "White") {
										obj.product_colorway_reducted = arr[0];
									} else {
										obj.product_colorway_reducted = arr[1];
									}
								} else {
									obj.product_colorway_reducted = i.product_colorway_reducted
								}
							}
							if (colorData[i.ProductSKU] === undefined || colorData[i.ProductSKU] === null) {
								obj.product_colorway_HexCode = "";
							} else {
								obj.product_colorway_HexCode = colorData[i.ProductSKU]['hex'];
							}
							finalData.push(obj);
						})
						resolve({ "status": "success", "data": { "image360": finalData } });
					});
			});
	});
}

function instore(req) {

	return new Promise((resolve, reject) => {
		var query = [
			{
				$lookup: {
					from: "SKU",
					localField: "product_sku",
					foreignField: "product_sku_id",
					as: "sku"
				}
			},
			{
				$match: { product_sku: { $nin: banSkus, $nin: disableSkus } }
			},
			{
				$project: {
					_id: 0,
					DateTime: "$update_date",
					ProductSKU: "$product_sku",
					ProductName: "$product_name",
					StoreCountry: "$store_country",
					StoreCountyFlag: "$store_country_pic_url",
					StoreName: "$store_name",
					StoreAddress: "$store_address",
					StoreLocation: "$store_location_url",
					ProductImage: "$product_img_url",
					ProductPrice: "$product_price",
					ProductStockxURL: "$product_stockx_url",
					ProductSize: "$product_sizes_available",
					ResellValuePourcent: "$sku.ResellValuePourcent",
					ResellValueProfit: "$sku.ResellValueProfit",
				}
			},
			{ $sort: { DateTime: -1 } },
		];
		commonHelper.findAggregate("Instore", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					if (i.DateTime === undefined || i.DateTime === null) {
						obj.DateTime = "";
					} else {
						obj.DateTime = i.DateTime;
					}
					obj.ProductSKU = i.ProductSKU;
					if (i.ProductName === undefined || i.ProductName === null) {
						obj.ProductName = "";
					} else {
						obj.ProductName = i.ProductName;
					}
					if (i.StoreCountry === undefined || i.StoreCountry === null) {
						obj.StoreCountry = "";
					} else {
						obj.StoreCountry = i.StoreCountry;
					}
					if (i.StoreCountyFlag === undefined || i.StoreCountyFlag === null) {
						obj.StoreCountyFlag = "";
					} else {
						obj.StoreCountyFlag = i.StoreCountyFlag;
					}
					if (i.StoreName === undefined || i.StoreName === null) {
						obj.StoreName = "";
					} else {
						obj.StoreName = i.StoreName;
					}
					if (i.StoreAddress === undefined || i.StoreAddress === null) {
						obj.StoreAddress = "";
					} else {
						obj.StoreAddress = i.StoreAddress;
					}
					if (i.StoreLocation === undefined || i.StoreLocation === null) {
						obj.StoreLocation = "";
					} else {
						obj.StoreLocation = i.StoreLocation;
					}
					if (i.ProductImage === undefined || i.ProductImage === null) {
						obj.ProductImage = "";
					} else {
						obj.ProductImage = i.ProductImage;
					}
					if (i.ProductPrice === undefined || i.ProductPrice === null) {
						obj.ProductPrice = "";
					} else {
						obj.ProductPrice = i.ProductPrice;
					}
					if (i.ProductStockxURL === undefined || i.ProductStockxURL === null) {
						obj.ProductStockxURL = "";
					} else {
						obj.ProductStockxURL = i.ProductStockxURL;
					}
					if (i.ProductSize === undefined || i.ProductSize === null) {
						obj.ProductSize = "";
					} else {
						obj.ProductSize = i.ProductSize;
					}
					if (i.ResellValuePourcent[0] === undefined || i.ResellValuePourcent[0] === null) {
						obj.ResellValuePourcent = "";
					} else {
						obj.ResellValuePourcent = i.ResellValuePourcent[0];
					}
					if (i.ResellValueProfit[0] === undefined || i.ResellValueProfit[0] === null) {
						obj.ResellValueProfit = "";
					} else {
						obj.ResellValueProfit = i.ResellValueProfit[0];
					}
					if (banDomains.includes(obj.StoreName) === false && shopData.includes(obj.StoreName) === false) {
						finalData.push(obj);
					}
				})
				resolve({ "status": "success", "data": { "instore": finalData } });
			});
	});
}

function history(req) {

	return new Promise((resolve, reject) => {
		var query = [
			{
				$lookup:
				{
					from: 'Sneakers',
					localField: 'product_sku_id',
					foreignField: 'product_sku_id',
					as: 'sneakers'
				}
			},
			{ $match: { product_sku_id: req.params.skuId } },
			{
				$project: {
					_id: 0,
					DateTime: "$sneakers.update_date",
					ProductSKU: "$product_sku_id",
					History: "$history"
				}
			},
		];
		commonHelper.findAggregate("History", query)
			.then(function (data) {
				var finalData = [];
				data.forEach(i => {
					var obj = {};
					if (i.DateTime === undefined || i.DateTime === null) {
						obj.DateTime = "";
					} else {
						obj.DateTime = i.DateTime[0];
					}
					obj.ProductSKU = i.ProductSKU;
					if (i.History === undefined || i.History === null) {
						obj.History = [];
					} else {
						obj.History = i.History;
					}
					finalData.push(obj);
				})
				resolve({ "status": "success", "data": { "history": finalData } });
			});
	});
}

function likeOrDislike(req, res, callback) {
	const { sku, type } = req.query;

	return new Promise((resolve, reject) => {
		commonHelper.findFromMongo("SKU", { product_sku_id: sku })
			.then(function (data) {
				resolve({ "status": "success", "data": { "productInfo": data } });
			});
	}).then(function (productInfo) {
		if (productInfo.data.productInfo.length > 0) {
			var productDetail = productInfo.data.productInfo[0];
			if (type == 0) {
				if (productDetail['product_like']) {
					productDetail['product_like'] = productDetail['product_like'] + 1;
				} else {
					productDetail['product_like'] = 1;
				}
			} else {
				if (productDetail['product_dislike']) {
					productDetail['product_dislike'] = productDetail['product_dislike'] + 1;
				} else {
					productDetail['product_dislike'] = 1;
				}
			}
			var query = { _id: productDetail['_id'] };
			commonHelper
				.updateMongo("SKU", query, { $set: productDetail })
				.then(function (data) {
					return callback(
						null,
						success(true, K.CODES.EVERYTHING_IS_OK, { 'product_like': productDetail['product_like'], 'product_dislike': productDetail['product_dislike'] })
					);
				});
		} else {
			return callback(
				null,
			);
		}
	})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function recoverLikeOrDislike(req, res, callback) {
	const { sku, type } = req.query;

	return new Promise((resolve, reject) => {
		commonHelper.findFromMongo("SKU", { product_sku_id: sku })
			.then(function (data) {
				resolve({ "status": "success", "data": { "productInfo": data } });
			});
	}).then(function (productInfo) {
		if (productInfo.data.productInfo.length > 0) {
			var productDetail = productInfo.data.productInfo[0];
			if (type == 0) {
				if (productDetail['product_like']) {
					productDetail['product_like'] = productDetail['product_like'] - 1;
				} else {
					productDetail['product_like'] = 1;
				}
			} else {
				if (productDetail['product_dislike']) {
					productDetail['product_dislike'] = productDetail['product_dislike'] - 1;
				} else {
					productDetail['product_dislike'] = 1;
				}
			}
			var query = { _id: productDetail['_id'] };
			commonHelper
				.updateMongo("SKU", query, { $set: productDetail })
				.then(function (data) {
					return callback(
						null,
						success(true, K.CODES.EVERYTHING_IS_OK, { 'product_like': productDetail['product_like'], 'product_dislike': productDetail['product_dislike'] })
					);
				});
		} else {
			return callback(
				null,
			);
		}
	})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function disableSkuFunc(req) {
	return new Promise((resolve, reject) => {
		let query = { 'product_sku_id': req.params.skuId };
		commonHelper.findFromMongo("SKU", query)
			.then(function (data) {
				if (data.length > 0) {
					commonHelper.updateMongo("SKU", query, { '$set': { 'status': 0 } })
						.then(function () {
							getSkuStatus();
							/*nrc.run('python3 ' + process.env.LOWESTPRIZEPATH + 'lowestprice.py', { onData: dataCallback }).then(function (exitCodes) {
							}, function (err) {
								console.log('Command failed to run with error: ', err);
							});*/
							resolve({ "status": "success", "message": "Sku Updated" });
						});
				} else {
					reject("Sku Not Found");
				}
			})
	});
}

function enableSkuFunc(req) {
	return new Promise((resolve, reject) => {
		let query = { 'product_sku_id': req.params.skuId };
		commonHelper.findFromMongo("SKU", query)
			.then(function (data) {
				if (data.length > 0) {
					commonHelper.updateMongo("SKU", query, { '$set': { 'status': 1 } })
						.then(function () {
							getSkuStatus();
							/*nrc.run('python3 ' + process.env.LOWESTPRIZEPATH + 'lowestprice.py', { onData: dataCallback }).then(function (exitCodes) {
							}, function (err) {
								console.log('Command failed to run with error: ', err);
							});*/
							resolve({ "status": "success", "message": "Sku Updated" });
						});
				} else {
					reject("Sku Not Found");
				}
			})
	});
}

module.exports = {
	getProductInfo: getProductInfo,
	getHeatsOfWeek: getHeatsOfWeek,
	recentlyDropped: recentlyDropped,
	s4sNews: s4sNews,
	topClicked: topClicked,
	upcomingProducts: upcomingProducts,
	pastProducts: pastProducts,
	getRaffles: getRaffles,
	getRetail: getRetail,
	getProducts: getProducts,
	getResell: getResell,
	getRestock: getRestock,
	getImg360: getImg360,
	getRestockByTrigger: getRestockByTrigger,
	incrementHitCount: incrementHitCount,
	disableShop: disableShop,
	enableShop: enableShop,
	productTextColor: productTextColor,
	getInstore: getInstore,
	getHistory: getHistory,
	likeOrDislike: likeOrDislike,
	recoverLikeOrDislike: recoverLikeOrDislike,
	disableSku: disableSku,
	enableSku: enableSku
};
