/*
 +-----------------------------------------------------------+
 | Module Name: Request Services	                           |
 | Module Purpose: To handle all product queries             |
 +-----------------------------------------------------------+
*/

"use strict";

var AWS = require("aws-sdk");
var path = require("path");
var recordHelper = require("../helpers/response.helper");
var commonHelper = require("../helpers/common.helper");
var firebaseApp = require("../middleware/authentication.middleware");
const admin = require('firebase-admin');
const { getAuth } = require('firebase-admin/auth');
var failure = recordHelper.failure;
var success = recordHelper.success;
const K = require("../config/constants");
const E = K.errors;
const s3 = new AWS.S3({
	accessKeyId: process.env.AWS_ACCESS_KEY,
	secretAccessKey: process.env.AWS_SECRET_KEY,
});
const jwt = require("jsonwebtoken");
var exec = require('child_process').exec;


function addUser(req, res, callback) {
	return user(req)
		.then(function (user) {
			return callback(
				null,
				success(user.status, K.CODES.EVERYTHING_IS_OK, user.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr("OPERATION_FAILED")));
		});
}

function getUsers(req, res, callback) {
	return users(req)
		.then(function (users) {
			return callback(
				null,
				success(users.status, K.CODES.EVERYTHING_IS_OK, users.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});
}

function getUserInfo(req, res, callback) {

	return getUserDetails(req)
		.then(function (userInfo) {

			return callback(
				null,
				success(userInfo.status, K.CODES.EVERYTHING_IS_OK, userInfo.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function fileUpload(req, res, callback) {
	return upload(req)
		.then(function (upload) {
			return callback(
				null,
				success(upload.status, K.CODES.EVERYTHING_IS_OK, upload.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr("OPERATION_FAILED")));
		});
}


function shoesUpload(req, res, callback) {
	return uploadShoes(req)
		.then(function (upload) {
			return callback(
				null,
				success(upload.status, K.CODES.EVERYTHING_IS_OK, upload.data)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr("OPERATION_FAILED")));
		});
}

function user(req) {
	return new Promise((resolve, reject) => {
		var userMailCheck;
		commonHelper
			.findFromMongo("User", { email: req.body.email })
			.then(function (data) {
				data.forEach((i) => {
					userMailCheck = i.email;
				});
				var obj = {};
				var wishlist = [];
				obj.update_date = new Date();
				if (req.body.username !== undefined) {
					obj.username = req.body.username;
				}
				if (req.body.email !== undefined) {
					obj.email = req.body.email;
				}
				if (req.body.first_name !== undefined) {
					obj.first_name = req.body.first_name;
				}
				if (req.body.last_name !== undefined) {
					obj.last_name = req.body.last_name;
				}
				if (req.body.phone_number !== undefined) {
					obj.phone_number = req.body.phone_number;
				}
				if (req.body.profile_picture !== undefined) {
					obj.profile_picture = req.body.profile_picture;
				}
				if (req.body.profile_status !== undefined) {
					obj.profile_status = req.body.profile_status;
				}
				if (req.body.General !== undefined) {
					obj.General = req.body.General;
				}
				if (req.body.Shipping !== undefined) {
					obj.Shipping = req.body.Shipping;
				}
				if (req.body.fcmtoken !== undefined) {
					obj.fcmtoken = req.body.fcmtoken;
				}
				if (req.body.shops !== undefined) {
					obj.shops = req.body.shops;
				}
				if (req.body.brands !== undefined) {
					obj.brands = req.body.brands;
				}
				if (req.body.sizes !== undefined) {
					obj.sizes = req.body.sizes;
				}
				if (req.body.regions !== undefined) {
					obj.regions = req.body.regions;
				}
				if (req.body.notifFlag !== undefined) {
					obj.notif_flag = req.body.notifFlag;
				}
				if (req.body.resellLow !== undefined) {
					obj.resellLow = req.body.resellLow;
				}
				if (req.body.resellMid !== undefined) {
					obj.resellMid = req.body.resellMid;
				}
				if (req.body.resellHigh !== undefined) {
					obj.resellHigh = req.body.resellHigh;
				}
				if (req.body.savedProfile !== undefined) {
					obj.savedProfile = req.body.savedProfile;
				}
				//   if (req.body.wishlist.constructor === Array) {
				if (
					req.body.wishlist !== undefined &&
					req.body.wishlist.constructor === Array
				) {
					// req.body.wishlist.forEach((i) => {
					// 	i.added_date = new Date().toISOString().slice(0, 10);
					// 	if (
					// 		i.product_sku_id !== undefined &&
					// 		i.product_name !== undefined &&
					// 		i.product_size !== undefined &&
					// 		i.product_size_price !== undefined
					// 	) {
					// 		wishlist.push(i);
					// 	}
					// });
					obj.wishlist = req.body.wishlist;
				}
				if (
					req.body.shopMarks !== undefined &&
					req.body.shopMarks.constructor === Array
				) {
					obj.shopMarks = req.body.shopMarks;
				}
				if (
					req.body.wishProducts !== undefined &&
					req.body.wishProducts.constructor === Array
				) {
					obj.wishProducts = req.body.wishProducts;
				}

				if (userMailCheck === req.body.email) {
					var query = { email: req.body.email };
					commonHelper
						.updateMongo("User", query, { $set: obj })
						.then(function (data) {
							commonHelper
								.findSpecField(
									"User",
									{ email: obj.email },
									{ projection: { create_date: 1 } }
								)
								.then((res) => {
									resolve({
										status: "success",
										data: { data: data, create_date: res.create_date },
									});
								});
						});
				} else {
					obj.create_date = new Date();
					commonHelper.findCount("User").then(function (data) {
						obj.user_id = parseInt(data) + 1;
						var query = obj;
						commonHelper.mongoCreate("User", query).then(function (data) {
							commonHelper
								.findSpecField(
									"User",
									{ email: obj.email },
									{ projection: { create_date: 1 } }
								)
								.then((res) => {
									resolve({
										status: "success",
										data: { data: data, create_date: res.create_date },
									});
								});
						});
					});
				}
			});
	});
}

function users(req) {
	return new Promise((resolve, reject) => {
		var query = [
			{ $sort: { DateTime: -1 } }
		];
		commonHelper.findAggregate("User", query)
			.then(function (data) {
				resolve({ "status": "success", "data": data });
			});
	});
}

function upload(req) {
	return new Promise((resolve, reject) => {
		var params;
		//console.log(req.body);
		const correctFile = [".png", ".jpeg", ".jpg", ".gif"];
		var extention = path.extname(req.file.originalname);
		if (correctFile.includes(extention) === true) {
			params = {
				Bucket: process.env.BUCKET,
				Key: `users/${req.file.originalname}`,
				Body: req.file.buffer,
				ACL: "public-read",
			};
		} else {
			reject("File type is incorrect");
		}
		s3.upload(params, function (err, data) {
			if (err) {
				throw err;
				console.log(err);
				reject(err);
			} else {
				var obj = {};
				obj.profilePic = process.env.file_name + params.Key;
				if (req.body.email !== undefined) {
					var query = { email: parseInt(req.body.email) };
					commonHelper
						.updateMongo("User", query, {
							$set: { profile_picture: obj.profilePic },
						})
						.then(function (data) {
							resolve({ status: "success", data: obj });
						});
				} else {
					resolve({ status: "success", data: obj });
				}
			}
		});
	});
}

function getUserDetails(req) {
	return new Promise((resolve, reject) => {
		commonHelper.findFromMongo("User", { email: req.params.email })
			.then(function (data) {
				resolve({ "status": "success", "data": { "userInfo": data } });
			});
	});
}

function login(req, res, callback) {
	new Promise((resolve, reject) => {
		commonHelper.findFromMongo("User", { user_id: 1 })
			.then(function (data) {
				const token = jwt.sign(
					{ user_id: data.user_id },
					process.env.TOKEN_KEY,
					{
						expiresIn: 600,
					}
				);
				let a = { "status": "success", "token": token }
				return callback(
					null,
					success(a.status, K.CODES.EVERYTHING_IS_OK, a.token)
				);
			});
	});
}

function deleteUser(req, res, callback) {
	return commonHelper.deleteFromMongo("User", { email: req.params.email })
		.then(function (data) {
			admin.auth().verifyIdToken(req.headers.token)
				.then((decodedToken) => {
					commonHelper.deleteFromMongo("AuthToken", { authtoken: req.headers.token })
						.then(() => {
							admin.auth().deleteUser(decodedToken.sub)
								.then(() => {
									console.log("User deleted successfully");
								})
								.catch((error) => {
									console.error("Error deleting user:", error);
								});
						})
						.catch(function (reason) {
							console.log("Error deleting authtoken");
						});
				})
			return callback(
				null,
				success('success', K.CODES.EVERYTHING_IS_OK, null)
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));
		});
}

function uploadShoes(req) {
	return new Promise((resolve, reject) => {
		var params;
		//console.log(req.body);
		const correctFile = [".png", ".jpeg", ".jpg", ".gif"];
		var extention = path.extname(req.file.originalname);
		if (correctFile.includes(extention) === true) {
			var date = new Date();
			var timestamp = date.getFullYear() +
				("0" + (date.getMonth() + 1)).slice(-2) +
				("0" + date.getDate()).slice(-2) +
				("0" + date.getHours()).slice(-2) +
				("0" + date.getMinutes()).slice(-2) +
				("0" + date.getSeconds()).slice(-2);
			var newFileName = req.file.originalname.split('.')[0] + '_' + timestamp + extention;
			params = {
				Bucket: process.env.BUCKET,
				Key: `uploadedShoes/${newFileName}`,
				Body: req.file.buffer,
				ACL: "public-read",
			};
			const imageUrl = `https://${params.Bucket}.s3.amazonaws.com/${params.Key}`;

			s3.upload(params, function (err, data) {
				if (err) {
					console.log(err);
					reject("UPLOAD_FAILED");
				} else {
					console.log("Running command: ", 'python3 ' + process.env.path + 'sneak_recognition/tester.py "' + imageUrl + '"');
					exec('python3 ' + process.env.path + 'sneak_recognition/tester.py "' + imageUrl + '"', (error, stdout, stderr) => {
						if (error) {
							console.error(`Error: ${error}`);
							reject("FIND_IMAGE_DATA_FAILED");
						} else {
							const predictionJson = stdout.toString().trim();
							var predictionObj = JSON.parse(predictionJson);

							if (predictionObj.status === "error") {
								reject({ "status": "failure", "message": predictionObj.reason });
							} else {
								predictionObj.s3_url = imageUrl;
								predictionObj.newfilename = newFileName;
								predictionObj.datetime = timestamp;

								var userDataArray = [];

								var user_Data = {
									s3_url: predictionObj.s3_url,
									newfilename: predictionObj.newfilename,
									datetime: predictionObj.datetime,
									prediction: predictionObj.prediction
								};

								userDataArray.push(user_Data);

								if (req.body.email !== undefined) {
									var query = { email: parseInt(req.body.email) };
									commonHelper
										.updateMongo("User", query, {
											$set: { shoes_picture: process.env.file_name + params.Key },
										})
										.then(function (data) {
											resolve({ "status": "success", "data": { "user_data": userDataArray } });
										})
										.catch(function (err) {
											reject("FAILED_TO_UPLOAD");
										});
								} else {
									resolve({ "status": "success", "data": { "user_data": userDataArray } });
								}
							}
						}
					});
				}
			});
		} else {
			reject("FILE_TYPE_IS_INCORRECT");
		}
	});
}

function currency(req, res, callback) {
	return getLastCurrencyRate(req)
		.then(function (response) {
			return callback(
				null,
				response.data
			);
		})
		.catch(function (reason) {
			console.log(reason);
			return callback(failure(reason, E.newErr('OPERATION_FAILED')));

		});

}

function getLastCurrencyRate(req) {
	return new Promise((resolve, reject) => {
		commonHelper.findFromMongo("CurrencyRate", {})
			.then(function (data) {
				resolve({ "status": "success", "data": data.length > 0 ? data[0] : [] });
			});
	});
}


module.exports = {
	addUser: addUser,
	fileUpload: fileUpload,
	getUsers: getUsers,
	getUserInfo: getUserInfo,
	login: login,
	deleteUser: deleteUser,
	shoesUpload: shoesUpload,
	currency: currency,
};
