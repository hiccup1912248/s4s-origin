
'use strict';

var recordHelper = require('../helpers/response.helper');
var commonHelper = require('../helpers/common.helper');
var ObjectId = require("mongodb").ObjectId;

function getNewRestock(query) {
    return new Promise((resolve, reject) => {
        commonHelper
            .findFromMongo("Restock", { _id: ObjectId(query.id) })
            .then(function (data) {
                resolve({
                    data: data
                });
            });
    })
}

function getSKU(query) {
    return new Promise((resolve, reject) => {
        commonHelper
            .findFromMongo("SKU", { product_sku_id: query.productSKU })
            .then(function (data) {
                resolve({
                    data: data
                });
            });
    })
}

function resellStatus(resellValuePourcent) {
    try {
        var e = Number.parseInt(resellValuePourcent);
        if (e < -100) {
            return -1;
        } else if (e >= -100 && e < 15) {
            return 0;
        } else if (e >= 15 && e < 25) {
            return 1;
        } else {
            return 2;
        }
    } catch (err) {
        return -1;
    }
}

function getUsersByRestockSetting(restock, resellValuePourcent) {
    var resellVal = resellStatus(resellValuePourcent);
    return new Promise((resolve, reject) => {
        commonHelper.findFromMongo("User", {
            $or: [
                {
                    $and: [
                        { shops: `${restock.region_name}_${restock.shop_name}` },
                        { brands: restock.brand_name },
                        {
                            $or: [
                                {
                                    $and: [
                                        { resellLow: { $exists: true } },
                                        resellVal == 2 ? { resellHigh: true } : resellVal == 1 ? { resellMid: true } : { resellLow: true }
                                    ]
                                },
                                { resellLow: { $exists: false } }
                            ]
                        }
                    ]
                },
                { wishProducts: { $regex: `\"${restock.product_sku_id}\"`, $options: "i" } },
            ]
        })
            .then(function (data) {
                resolve({
                    data: data
                })
            });
    })
}

module.exports = {
    getNewRestock: getNewRestock,
    getUsersByRestockSetting: getUsersByRestockSetting,
    getSKU: getSKU,
    resellStatus: resellStatus,
}
