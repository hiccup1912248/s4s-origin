'use strict';

const XError = require('xerror');

//For Manually throwing errors
//c = code
//m = message

const errors = {
  OPERATION_FAILED:{
    code: 3000,
    message: 'Requested operation failed with errors'
  },
  throw: throwErr,
  newErr: newErr
};

XError.registerErrorCodes(errors);

//Throw new error to stop the app
function throwErr(e) {
  throw new XError(e);
}

//Return a new Xerror object
function newErr(e) {
  return new XError(e);
}

module.exports = {
  errors: errors
};
