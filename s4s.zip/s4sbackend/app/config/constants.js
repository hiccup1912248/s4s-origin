'use strict';

const _ = require('lodash');

const constants = {
  CODES: {
    EVERYTHING_IS_OK: 200,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403
  }
};

module.exports = _.extend(
  constants,
  require('./errors')
);
