require('dotenv').config()
var RequestCtrl = require('./controllers/request.controller');
var Authenticate = require('./middleware/authentication.middleware');
//const auth = require("./middleware/auth");

module.exports = function (app) {

  app.get('/', (req, res) => {
    res.status(401).send('Unauthorised');
  });

  app.get('/product/:skuId', Authenticate.auth, RequestCtrl.getProductInfo);
  app.get('/heats', Authenticate.auth, RequestCtrl.getHeatsOfWeek);
  app.get('/recent', Authenticate.auth, RequestCtrl.recentlyDropped);
  app.get('/s4snews', Authenticate.auth, RequestCtrl.s4sNews);
  app.get('/top', Authenticate.auth, RequestCtrl.topClicked);
  app.get('/upcoming', Authenticate.auth, RequestCtrl.upcomingProducts);
  app.get('/past', Authenticate.auth, RequestCtrl.pastProducts);
  app.get('/raffles', Authenticate.auth, RequestCtrl.getRaffles);
  app.get('/raffles/:skuId', Authenticate.auth, RequestCtrl.getRaffles);
  app.get('/retail', Authenticate.auth, RequestCtrl.getRetail);
  app.get('/retail/:skuId', Authenticate.auth, RequestCtrl.getRetail);
  app.get('/productpage', Authenticate.auth, RequestCtrl.getProducts);
  app.get('/productpage/:skuId', Authenticate.auth, RequestCtrl.getProducts);
  app.get('/resell', Authenticate.auth, RequestCtrl.getResell);
  app.get('/resell/:skuId', Authenticate.auth, RequestCtrl.getResell);
  app.get('/restock', Authenticate.auth, RequestCtrl.getRestock);
  app.get('/img360', Authenticate.auth, RequestCtrl.getImg360);
  app.post('/user', Authenticate.auth, RequestCtrl.addUser);
  app.post('/upload', Authenticate.auth, RequestCtrl.fileUpload);
  app.post('/uploadShoes', Authenticate.auth, RequestCtrl.shoesUpload);
  //app.get('/firebase/restock', RequestCtrl.getFirebaseRestock);
  app.get('/restock/newdata/:id', RequestCtrl.getRestockNewData);
  app.get('/getuser/:email', Authenticate.auth, RequestCtrl.getUserByEmail);
  app.get('/incrementHitCount/:skuId', Authenticate.auth, RequestCtrl.incrementHitCount);
  //app.get('/login', RequestCtrl.login);
  app.get('/download/:filepath', Authenticate.auth, RequestCtrl.fileDownload);
  app.get('/deleteUser/:email', Authenticate.auth, RequestCtrl.deleteUser);
  app.get('/disable-shop/:shop', Authenticate.auth, RequestCtrl.disableShop);
  app.get('/enable-shop/:shop', Authenticate.auth, RequestCtrl.enableShop);
  app.get('/disable-sku/:skuId', Authenticate.auth, RequestCtrl.disableSku);
  app.get('/enable-sku/:skuId', Authenticate.auth, RequestCtrl.enableSku);
  app.get('/productTextColor', Authenticate.auth, RequestCtrl.productTextColor);
  app.get('/Instore', Authenticate.auth, RequestCtrl.getInstore);
  app.get('/History/:skuId', Authenticate.auth, RequestCtrl.getHistory);
  app.get('/like-dislike', Authenticate.auth, RequestCtrl.likeOrDislike);
  app.get('/recover-like-dislike', Authenticate.auth, RequestCtrl.recoverLikeOrDislike);
  app.get('/currency', RequestCtrl.currency );


  //To disable stack-trace in browser 
  app.use(function (err, req, res, next) {
    console.error(err.stack)
    res.status(500).send('Error')
  })

}
