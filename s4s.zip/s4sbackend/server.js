const express = require('express');
const bodyParser = require('body-parser');
const rateLimit = require('express-rate-limit');
var multer = require('multer');
var upload = multer();
const Sentry = require("@sentry/node");
const Tracing = require("@sentry/tracing");
Sentry.init({
  dsn: "https://0eb9383c1706483a8fa834a8d4ba154d@o4505204272988160.ingest.sentry.io/4505205270183936",
  tracesSampleRate: 1.0,
});
Sentry.setTag("domain", "Sneaks4Sure");

//App
const app = express();
app.use(function (req, res, next) {
	console.log("URL------------------------>" + new Date() + req.protocol + '://' + req.get('host') + req.originalUrl);
	next()
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: true
}));

app.use(upload.single('upload'));

// const apiLimiter = rateLimit({
// 	windowMs: 15 * 60 * 1000,
// 	max: 100,
// 	standardHeaders: true,
// 	legacyHeaders: false,
// })

// app.use(apiLimiter)

// app.use(express.static("assets/"));
app.use(express.static("S4S/"));

// var router = require('./app/router', apiLimiter)(app);
var router = require('./app/router')(app);

app.listen(process.env.PORT, function () {
	console.log(`Running on - ${process.env.PORT}`);
});

const cron = require('node-cron');
const axios = require('axios');
const commonHelper = require('./app/helpers/common.helper');

const task = () => {
	console.log('Cron job is running!');
	axios.get('https://api.freecurrencyapi.com/v1/latest?apikey=Z0aYvB1ysnnuHqdbK169sQjHJUhPNHTU1XZCFPie')
		.then(response => {
			// Handle the API response data
			var currencyAPIObj = response.data;
			currencyAPIObj.update_date = new Date();
			commonHelper.mongoCreate('CurrencyRate', currencyAPIObj);
			console.log("save currency rate success");

		})
		.catch(error => {
			console.error(error);
		});
};

cron.schedule('0 0 * * *', task);
